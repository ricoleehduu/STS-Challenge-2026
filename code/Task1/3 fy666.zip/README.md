# MICCAI-STSR-2026-Task1

This repository provides a global-to-local nnU-Net v2 pipeline for tooth and
pulp instance segmentation in dental CBCT volumes.

## Pipeline

```text
CBCT volume
  -> global tooth segmentation
  -> per-class fragment cleanup
  -> tooth ROI extraction
  -> local tooth and pulp segmentation
  -> full-volume merging
```

The global model predicts 32 tooth-position classes. Each retained tooth region
is expanded by 10 voxels and passed to the local model. Local predictions are
then merged into a full-volume label map containing tooth and pulp instances.

## Repository structure

```text
data_preparation/
  build_dataset602.py       Build the global tooth dataset
  build_dataset603.py       Build and filter the local tooth/pulp ROI dataset
  validate_dataset.py       Validate generated nnU-Net datasets
inference/
  global_tooth_and_roi.py   Global prediction, cleanup, and ROI extraction
  local_tooth_pulp.py       Local tooth and pulp prediction
  merge_to_full_volume.py   Merge local predictions into full volumes
  run_pipeline.py           Run the complete batch pipeline
tests/
  test_data_preparation_contracts.py
  test_inference_contracts.py
```

## Environment

Install nnU-Net v2 following its official repository:

```bash
git clone https://github.com/MIC-DKFZ/nnUNet.git
cd nnUNet
pip install -e .
```

Install the utility dependencies used by the data preparation and inference
scripts:

```bash
pip install -r requirements.txt
```

## Dataset

The dataset is available from
[MICCAI STSR 2026 Task 1](https://www.codabench.org/competitions/16027/#/pages-tab).

The source training dataset must use the nnU-Net raw layout:

```text
SOURCE_DATASET/
  imagesTr/
    CASE_001_0000.nii.gz
  labelsTr/
    CASE_001.nii.gz
```

The source label encoding is:

| Label | Meaning |
| --- | --- |
| `0` | Background |
| `1..32` | Tooth instances |
| `33..64` | Pulp instances, where `pulp = tooth + 32` |

## Data preparation

Set the standard nnU-Net paths before preparing the datasets:

```bash
export nnUNet_raw=/path/to/nnUNet_raw
export nnUNet_preprocessed=/path/to/nnUNet_preprocessed
export nnUNet_results=/path/to/nnUNet_results
```

### Global dataset

Dataset602 merges each tooth and its corresponding pulp into one tooth-position
class in the range `1..32`.

```bash
python data_preparation/build_dataset602.py \
  --input /path/to/SOURCE_DATASET \
  --output "$nnUNet_raw/Dataset602_STSRStage1"

python data_preparation/validate_dataset.py \
  --dataset "$nnUNet_raw/Dataset602_STSRStage1" \
  --contract dataset602
```

### Local dataset

Dataset603 iterates over present pulp labels, crops the corresponding tooth
bounding box with 10-voxel padding, and stores local labels as `0=background`,
`1=tooth`, and `2=pulp`. A complete ROI sample is discarded when it contains
fewer than 50 pulp voxels.

```bash
python data_preparation/build_dataset603.py \
  --input /path/to/SOURCE_DATASET \
  --output "$nnUNet_raw/Dataset603_ToothPulpROI_clean" \
  --margin-voxels 10 \
  --min-pulp-voxels 50

python data_preparation/validate_dataset.py \
  --dataset "$nnUNet_raw/Dataset603_ToothPulpROI_clean" \
  --contract dataset603
```

## Training

Train the global model with the `3d_lowres` configuration and
`nnUNetTrainerNoDA`:

```bash
nnUNetv2_plan_and_preprocess -d 602 --verify_dataset_integrity
nnUNetv2_train 602 3d_lowres all -tr nnUNetTrainerNoDA
```

Train the local model with the `3d_fullres` configuration:

```bash
nnUNetv2_plan_and_preprocess -d 603 --verify_dataset_integrity
nnUNetv2_train 603 3d_fullres all
```

Inference uses fold `all` and `checkpoint_best.pth` by default.

## Inference

Place test volumes in one directory using the nnU-Net channel suffix:

```text
imagesTs/
  CASE_001_0000.nii.gz
  CASE_002_0000.nii.gz
```

Run the complete batch pipeline:

```bash
python inference/run_pipeline.py \
  --input-images /path/to/imagesTs \
  --global-model-root "$nnUNet_results/Dataset602_STSRStage1" \
  --local-model-root "$nnUNet_results/Dataset603_ToothPulpROI_clean" \
  --output-root /path/to/inference_results
```



## Output

```text
inference_results/
  global/
    global_raw/
    localization/
    roi_images/
    roi_records.json
  local/
    labels/
  final/
    labels/
  pipeline_manifest.json
```

Final labels use:

| Label | Meaning |
| --- | --- |
| `0` | Background |
| `1..32` | Tooth instances |
| `33..64` | Corresponding pulp instances |

## Tests

```bash
python -m unittest discover -s tests -v
```
