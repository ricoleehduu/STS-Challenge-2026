"""Dataset construction utilities for the STSR pipeline."""
