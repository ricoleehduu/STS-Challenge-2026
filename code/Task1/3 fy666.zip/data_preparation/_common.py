#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import os
import shutil
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import SimpleITK as sitk


NIFTI_SUFFIX = ".nii.gz"


def strip_nii_suffix(name: str) -> str:
    if name.endswith(".nii.gz"):
        return name[:-7]
    if name.endswith(".nii"):
        return name[:-4]
    return Path(name).stem


def image_case_id(path: Path) -> str:
    stem = strip_nii_suffix(path.name)
    if not stem.endswith("_0000"):
        raise ValueError(f"Expected a single-channel nnU-Net image: {path.name}")
    return stem[:-5]


def label_case_id(path: Path) -> str:
    return strip_nii_suffix(path.name)


def discover_training_pairs(root: Path) -> list[tuple[str, Path, Path]]:
    images_dir = root / "imagesTr"
    labels_dir = root / "labelsTr"
    if not images_dir.is_dir():
        raise FileNotFoundError(f"imagesTr does not exist: {images_dir}")
    if not labels_dir.is_dir():
        raise FileNotFoundError(f"labelsTr does not exist: {labels_dir}")

    image_index: dict[str, Path] = {}
    for path in sorted(images_dir.glob("*.nii.gz")):
        stem = strip_nii_suffix(path.name)
        channel = stem.rsplit("_", 1)[-1]
        if channel.isdigit() and len(channel) == 4 and channel != "0000":
            raise RuntimeError(
                "Only one input channel is supported; found extra channel "
                f"{path.name}"
            )
        if not stem.endswith("_0000"):
            raise RuntimeError(f"Unexpected file in imagesTr: {path.name}")
        case_id = image_case_id(path)
        if case_id in image_index:
            raise RuntimeError(f"Duplicate image case ID: {case_id}")
        image_index[case_id] = path

    label_index: dict[str, Path] = {}
    for path in sorted(labels_dir.glob("*.nii.gz")):
        case_id = label_case_id(path)
        if case_id in label_index:
            raise RuntimeError(f"Duplicate label case ID: {case_id}")
        label_index[case_id] = path

    if not image_index:
        raise RuntimeError(f"No *_0000.nii.gz images found in {images_dir}")
    if not label_index:
        raise RuntimeError(f"No .nii.gz labels found in {labels_dir}")

    missing_labels = sorted(set(image_index) - set(label_index))
    extra_labels = sorted(set(label_index) - set(image_index))
    if missing_labels or extra_labels:
        raise RuntimeError(
            "Training image/label pairing failed. "
            f"Missing labels={missing_labels[:20]}, extra labels={extra_labels[:20]}"
        )

    return [
        (case_id, image_index[case_id], label_index[case_id])
        for case_id in sorted(image_index)
    ]


def prepare_output(input_root: Path, output_root: Path, overwrite: bool) -> None:
    source = input_root.resolve()
    destination = output_root.resolve()
    if source == destination:
        raise ValueError("Input and output directories must be different")
    if source in destination.parents or destination in source.parents:
        raise ValueError(
            "Input and output directories must not contain one another: "
            f"{source}, {destination}"
        )
    if destination == Path(destination.anchor):
        raise ValueError(f"Refusing to use a filesystem root as output: {destination}")

    if output_root.exists() and any(output_root.iterdir()):
        if not overwrite:
            raise FileExistsError(
                f"Output directory is not empty: {output_root}. Use --overwrite."
            )
        shutil.rmtree(output_root)
    output_root.mkdir(parents=True, exist_ok=True)


def geometry_errors(
    image: sitk.Image,
    label: sitk.Image,
    tolerance: float,
) -> list[str]:
    errors: list[str] = []
    if image.GetDimension() != 3 or label.GetDimension() != 3:
        errors.append("image and label must both be 3D")
    if image.GetSize() != label.GetSize():
        errors.append(f"size mismatch: {image.GetSize()} != {label.GetSize()}")
    for field, image_value, label_value in (
        ("spacing", image.GetSpacing(), label.GetSpacing()),
        ("origin", image.GetOrigin(), label.GetOrigin()),
        ("direction", image.GetDirection(), label.GetDirection()),
    ):
        if not np.allclose(image_value, label_value, atol=tolerance, rtol=0):
            errors.append(f"{field} mismatch")
    return errors


def read_integer_label(path: Path) -> tuple[sitk.Image, np.ndarray]:
    image = sitk.ReadImage(str(path))
    array = sitk.GetArrayFromImage(image)
    rounded = np.rint(array)
    if not np.allclose(array, rounded, atol=1e-5, rtol=0):
        raise ValueError(f"Non-integer label values found in {path}")
    return image, rounded.astype(np.int64, copy=False)


def write_label(array: np.ndarray, reference: sitk.Image, path: Path) -> None:
    output = sitk.GetImageFromArray(array.astype(np.uint8, copy=False))
    output.CopyInformation(reference)
    sitk.WriteImage(output, str(path), True)


def save_json(path: Path, document: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8") as handle:
        json.dump(document, handle, ensure_ascii=False, indent=2)
    os.replace(temporary, path)


def write_csv(path: Path, rows: Iterable[dict[str, Any]]) -> None:
    materialized = list(rows)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not materialized:
        path.write_text("", encoding="utf-8")
        return

    fieldnames: list[str] = []
    seen: set[str] = set()
    for row in materialized:
        for field in row:
            if field not in seen:
                fieldnames.append(field)
                seen.add(field)

    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(materialized)


def copy_image(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)


def bbox_from_mask(mask: np.ndarray) -> tuple[np.ndarray, np.ndarray] | None:
    coordinates = np.argwhere(mask)
    if coordinates.size == 0:
        return None
    return coordinates.min(axis=0), coordinates.max(axis=0) + 1


def expand_bbox(
    start_zyx: np.ndarray,
    end_zyx: np.ndarray,
    shape_zyx: tuple[int, int, int],
    margin_voxels: int,
) -> tuple[np.ndarray, np.ndarray]:
    shape = np.asarray(shape_zyx, dtype=np.int64)
    start = np.maximum(0, start_zyx.astype(np.int64) - margin_voxels)
    end = np.minimum(shape, end_zyx.astype(np.int64) + margin_voxels)
    return start, end


def slices_from_bbox(
    start_zyx: np.ndarray,
    end_zyx: np.ndarray,
) -> tuple[slice, slice, slice]:
    return tuple(
        slice(int(start), int(end))
        for start, end in zip(start_zyx, end_zyx)
    )  # type: ignore[return-value]


def dataset603_json(dataset_name: str, num_training: int) -> dict[str, Any]:
    return {
        "name": dataset_name,
        "description": "Single-tooth ROI dataset for tooth and pulp segmentation",
        "channel_names": {"0": "CBCT"},
        "labels": {
            "background": 0,
            "Tooth": [1, 2],
            "Pulp": [2],
        },
        "regions_class_order": [1, 2],
        "numTraining": int(num_training),
        "file_ending": ".nii.gz",
    }
