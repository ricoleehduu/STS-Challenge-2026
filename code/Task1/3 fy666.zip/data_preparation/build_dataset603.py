#!/usr/bin/env python3
"""Build the single-tooth ROI dataset used by the local model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import numpy as np
import SimpleITK as sitk

try:
    from ._common import (
        bbox_from_mask,
        dataset603_json,
        discover_training_pairs,
        expand_bbox,
        geometry_errors,
        prepare_output,
        read_integer_label,
        save_json,
        slices_from_bbox,
        write_csv,
        write_label,
    )
except ImportError:
    from _common import (  # type: ignore[no-redef]
        bbox_from_mask,
        dataset603_json,
        discover_training_pairs,
        expand_bbox,
        geometry_errors,
        prepare_output,
        read_integer_label,
        save_json,
        slices_from_bbox,
        write_csv,
        write_label,
    )


def default_pulp_to_tooth_mapping() -> dict[int, int]:
    return {pulp: pulp - 32 for pulp in range(33, 65)}


def load_mapping(path: Path | None) -> dict[int, int]:
    if path is None:
        mapping = default_pulp_to_tooth_mapping()
    else:
        with path.open("r", encoding="utf-8") as handle:
            document = json.load(handle)
        if not isinstance(document, dict) or not document:
            raise ValueError("Mapping JSON must be a non-empty object")
        mapping = {int(pulp): int(tooth) for pulp, tooth in document.items()}

    invalid_teeth = sorted(
        tooth for tooth in mapping.values() if not 1 <= tooth <= 32
    )
    invalid_pulps = sorted(pulp for pulp in mapping if pulp <= 0)
    duplicate_teeth = sorted(
        tooth
        for tooth in set(mapping.values())
        if list(mapping.values()).count(tooth) > 1
    )
    overlapping_labels = sorted(set(mapping) & set(mapping.values()))
    if invalid_teeth:
        raise ValueError(f"Mapped tooth labels must be in 1-32: {invalid_teeth}")
    if invalid_pulps:
        raise ValueError(f"Mapped pulp labels must be positive: {invalid_pulps}")
    if duplicate_teeth:
        raise ValueError(
            f"Mapping must be one-to-one; duplicate teeth: {duplicate_teeth}"
        )
    if overlapping_labels:
        raise ValueError(
            "Tooth and pulp label sets must be disjoint; overlapping labels: "
            f"{overlapping_labels}"
        )
    return dict(sorted(mapping.items()))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Create one tooth/pulp ROI for each present pulp label and discard "
            "samples below the pulp voxel threshold."
        )
    )
    parser.add_argument(
        "--input",
        type=Path,
        required=True,
        help="Input nnU-Net dataset containing full-volume imagesTr and labelsTr.",
    )
    parser.add_argument(
        "--output",
        type=Path,
        required=True,
        help="Output nnU-Net single-tooth ROI dataset.",
    )
    parser.add_argument("--dataset-name", default="Dataset603_ToothPulpROI_clean")
    parser.add_argument(
        "--mapping-json",
        type=Path,
        default=None,
        help=(
            "Optional JSON object mapping pulp labels to tooth labels. "
            "Default: 33->1, ..., 64->32."
        ),
    )
    parser.add_argument("--margin-voxels", type=int, default=10)
    parser.add_argument("--min-pulp-voxels", type=int, default=50)
    parser.add_argument("--geometry-tolerance", type=float, default=1e-5)
    parser.add_argument("--overwrite", action="store_true")
    return parser.parse_args()


def actual_padding(
    tooth_start_zyx: np.ndarray,
    tooth_end_zyx: np.ndarray,
    roi_start_zyx: np.ndarray,
    roi_end_zyx: np.ndarray,
) -> dict[str, int]:
    lower = tooth_start_zyx - roi_start_zyx
    upper = roi_end_zyx - tooth_end_zyx
    return {
        "x_min": int(lower[2]),
        "x_max": int(upper[2]),
        "y_min": int(lower[1]),
        "y_max": int(upper[1]),
        "z_min": int(lower[0]),
        "z_max": int(upper[0]),
    }


def validate_case_labels(
    case_id: str,
    label: np.ndarray,
    mapping: dict[int, int],
) -> tuple[list[int], list[int], list[int]]:
    present = {int(value) for value in np.unique(label)}
    allowed = {0, *mapping.keys(), *mapping.values()}
    invalid = sorted(present - allowed)
    if invalid:
        raise ValueError(
            f"{case_id}: labels are outside the declared tooth/pulp mapping: {invalid}"
        )

    present_pulps = sorted(present & set(mapping))
    present_teeth = sorted(present & set(mapping.values()))
    orphan_pulps = [pulp for pulp in present_pulps if mapping[pulp] not in present]
    if orphan_pulps:
        details = {pulp: mapping[pulp] for pulp in orphan_pulps}
        raise ValueError(
            f"{case_id}: pulp labels have no mapped tooth label: {details}"
        )

    inverse = {tooth: pulp for pulp, tooth in mapping.items()}
    teeth_without_pulp = [
        tooth for tooth in present_teeth if inverse.get(tooth) not in present
    ]
    return present_teeth, present_pulps, teeth_without_pulp


def process_case(
    case_id: str,
    image_path: Path,
    label_path: Path,
    mapping: dict[int, int],
    output_images: Path,
    output_labels: Path,
    margin_voxels: int,
    min_pulp_voxels: int,
    geometry_tolerance: float,
    first_output_index: int,
) -> tuple[
    list[dict[str, Any]],
    list[dict[str, Any]],
    list[dict[str, Any]],
]:
    image = sitk.ReadImage(str(image_path))
    label_image, label = read_integer_label(label_path)
    errors = geometry_errors(image, label_image, geometry_tolerance)
    if errors:
        raise RuntimeError(f"{case_id}: image/label geometry errors: {errors}")

    _, present_pulps, teeth_without_pulp = validate_case_labels(
        case_id, label, mapping
    )
    inverse_mapping = {tooth: pulp for pulp, tooth in mapping.items()}
    skipped = [
        {
            "source_case_id": case_id,
            "tooth_label": tooth,
            "pulp_label": inverse_mapping[tooth],
            "reason": "tooth_has_no_present_pulp_label",
        }
        for tooth in teeth_without_pulp
    ]

    kept_records: list[dict[str, Any]] = []
    removed_records: list[dict[str, Any]] = []
    for pulp_label in present_pulps:
        tooth_label = mapping[pulp_label]
        tooth_mask = label == tooth_label
        pulp_mask = label == pulp_label
        tooth_bbox = bbox_from_mask(tooth_mask)
        if tooth_bbox is None:
            raise RuntimeError(f"{case_id}: mapped tooth {tooth_label} is empty")
        if not np.any(pulp_mask):
            raise RuntimeError(f"{case_id}: declared pulp {pulp_label} is empty")

        tooth_start_zyx, tooth_end_zyx = tooth_bbox
        roi_start_zyx, roi_end_zyx = expand_bbox(
            tooth_start_zyx,
            tooth_end_zyx,
            label.shape,
            margin_voxels,
        )
        roi_slices = slices_from_bbox(roi_start_zyx, roi_end_zyx)
        crop_source = label[roi_slices]
        crop_tooth_mask = crop_source == tooth_label
        crop_pulp_mask = crop_source == pulp_label

        full_tooth_voxels = int(np.count_nonzero(tooth_mask))
        full_pulp_voxels = int(np.count_nonzero(pulp_mask))
        crop_tooth_voxels = int(np.count_nonzero(crop_tooth_mask))
        crop_pulp_voxels = int(np.count_nonzero(crop_pulp_mask))
        if crop_tooth_voxels != full_tooth_voxels:
            raise RuntimeError(f"{case_id}: tooth {tooth_label} was clipped by its ROI")
        if crop_pulp_voxels != full_pulp_voxels:
            raise RuntimeError(
                f"{case_id}: pulp {pulp_label} extends outside the tooth ROI"
            )

        start_xyz = [int(value) for value in roi_start_zyx[::-1]]
        end_xyz = [int(value) for value in roi_end_zyx[::-1]]
        size_xyz = [end - start for start, end in zip(start_xyz, end_xyz)]
        spacing = np.asarray(label_image.GetSpacing(), dtype=np.float64)
        base_record: dict[str, Any] = {
            "source_case_id": case_id,
            "source_image": str(image_path),
            "source_label": str(label_path),
            "tooth_label": int(tooth_label),
            "pulp_label": int(pulp_label),
            "margin_voxels": int(margin_voxels),
            "tooth_voxels_checked": crop_tooth_voxels,
            "pulp_voxels_checked": crop_pulp_voxels,
            "pulp_volume_mm3_checked": float(crop_pulp_voxels * np.prod(spacing)),
            "roi_bbox_start_xyz": start_xyz,
            "roi_bbox_end_xyz_exclusive": end_xyz,
            "roi_size_xyz": size_xyz,
            "original_size_xyz": [int(value) for value in image.GetSize()],
            "spacing_xyz": [float(value) for value in image.GetSpacing()],
            "original_origin_xyz": [float(value) for value in image.GetOrigin()],
            "direction": [float(value) for value in image.GetDirection()],
            "actual_padding_voxels": actual_padding(
                tooth_start_zyx,
                tooth_end_zyx,
                roi_start_zyx,
                roi_end_zyx,
            ),
        }

        reasons: list[str] = []
        if crop_tooth_voxels == 0:
            reasons.append("empty_tooth_label")
        if crop_pulp_voxels == 0:
            reasons.append("empty_pulp_label")
        elif crop_pulp_voxels < min_pulp_voxels:
            reasons.append(f"pulp_voxels_lt_{min_pulp_voxels}")
        if reasons:
            removed_records.append(
                {
                    **base_record,
                    "remove_reasons": ";".join(reasons),
                }
            )
            continue

        output_index = first_output_index + len(kept_records)
        roi_case_id = f"ToothPulpROI_{output_index:04d}"
        crop_image = sitk.RegionOfInterest(image, size=size_xyz, index=start_xyz)
        crop_label_reference = sitk.RegionOfInterest(
            label_image, size=size_xyz, index=start_xyz
        )
        crop_label = np.zeros(crop_source.shape, dtype=np.uint8)
        crop_label[crop_tooth_mask] = 1
        crop_label[crop_pulp_mask] = 2

        output_image_path = output_images / f"{roi_case_id}_0000.nii.gz"
        output_label_path = output_labels / f"{roi_case_id}.nii.gz"
        sitk.WriteImage(crop_image, str(output_image_path), True)
        write_label(crop_label, crop_label_reference, output_label_path)
        kept_records.append(
            {
                **base_record,
                "roi_case_id": roi_case_id,
                "output_image": str(output_image_path),
                "output_label": str(output_label_path),
                "roi_origin_xyz": [
                    float(value) for value in crop_image.GetOrigin()
                ],
            }
        )

    if len(kept_records) + len(removed_records) != len(present_pulps):
        raise RuntimeError(f"{case_id}: not every present pulp was evaluated")
    return kept_records, removed_records, skipped


def main() -> None:
    args = parse_args()
    if args.margin_voxels < 0:
        raise ValueError("--margin-voxels must be non-negative")
    if args.min_pulp_voxels < 0:
        raise ValueError("--min-pulp-voxels must be non-negative")
    if args.geometry_tolerance < 0:
        raise ValueError("--geometry-tolerance must be non-negative")

    mapping = load_mapping(args.mapping_json)
    pairs = discover_training_pairs(args.input)
    prepare_output(args.input, args.output, args.overwrite)
    output_images = args.output / "imagesTr"
    output_labels = args.output / "labelsTr"
    output_images.mkdir(parents=True, exist_ok=True)
    output_labels.mkdir(parents=True, exist_ok=True)

    kept_records: list[dict[str, Any]] = []
    removed_records: list[dict[str, Any]] = []
    skipped_records: list[dict[str, Any]] = []
    for index, (case_id, image_path, label_path) in enumerate(pairs, start=1):
        print(f"[{index}/{len(pairs)}] Building Dataset603 from {case_id}")
        case_kept, case_removed, case_skipped = process_case(
            case_id=case_id,
            image_path=image_path,
            label_path=label_path,
            mapping=mapping,
            output_images=output_images,
            output_labels=output_labels,
            margin_voxels=args.margin_voxels,
            min_pulp_voxels=args.min_pulp_voxels,
            geometry_tolerance=args.geometry_tolerance,
            first_output_index=len(kept_records) + 1,
        )
        kept_records.extend(case_kept)
        removed_records.extend(case_removed)
        skipped_records.extend(case_skipped)

    if not kept_records:
        raise RuntimeError("No tooth/pulp ROI passed the voxel threshold")

    save_json(
        args.output / "dataset.json",
        dataset603_json(args.dataset_name, len(kept_records)),
    )
    save_json(args.output / "crop_info.json", kept_records)
    write_csv(args.output / "crop_info.csv", kept_records)
    save_json(args.output / "removed_samples.json", removed_records)
    write_csv(args.output / "removed_samples.csv", removed_records)
    write_csv(args.output / "skipped_samples.csv", skipped_records)
    save_json(
        args.output / "build_report.json",
        {
            "stage": "build_dataset603",
            "input": str(args.input),
            "output": str(args.output),
            "num_source_cases": len(pairs),
            "num_kept_rois": len(kept_records),
            "num_removed_rois": len(removed_records),
            "num_skipped_teeth_without_pulp": len(skipped_records),
            "margin_voxels": args.margin_voxels,
            "min_pulp_voxels": args.min_pulp_voxels,
            "pulp_to_tooth_mapping": {
                str(pulp): tooth for pulp, tooth in mapping.items()
            },
            "local_label_contract": {
                "background": 0,
                "tooth_without_pulp": 1,
                "pulp": 2,
            },
            "filter_unit": "complete_roi_sample",
            "voxel_modification": False,
        },
    )

    print(
        "Dataset603 completed: "
        f"{len(kept_records)} kept, {len(removed_records)} removed"
    )
    print(f"Output: {args.output}")


if __name__ == "__main__":
    main()
