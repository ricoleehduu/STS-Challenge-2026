#!/usr/bin/env python3
"""Validate Dataset602 or Dataset603 against its label contract."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import numpy as np
import SimpleITK as sitk

try:
    from ._common import (
        discover_training_pairs,
        geometry_errors,
        read_integer_label,
        save_json,
    )
except ImportError:
    from _common import (  # type: ignore[no-redef]
        discover_training_pairs,
        geometry_errors,
        read_integer_label,
        save_json,
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Validate an nnU-Net training dataset and its label contract."
    )
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument(
        "--contract",
        choices=("dataset602", "dataset603"),
        required=True,
    )
    parser.add_argument("--geometry-tolerance", type=float, default=1e-5)
    parser.add_argument("--report", type=Path, default=None)
    return parser.parse_args()


def load_json(path: Path) -> Any:
    if not path.is_file():
        raise FileNotFoundError(path)
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def validate_dataset_json(
    document: dict[str, Any],
    contract: str,
    num_cases: int,
) -> list[str]:
    errors: list[str] = []
    if document.get("file_ending") != ".nii.gz":
        errors.append("dataset.json file_ending must be .nii.gz")
    if document.get("numTraining") != num_cases:
        errors.append(
            "dataset.json numTraining mismatch: "
            f"{document.get('numTraining')} != {num_cases}"
        )

    channels = document.get("channel_names", document.get("modality"))
    if not isinstance(channels, dict) or len(channels) != 1:
        errors.append("dataset.json must define exactly one input channel")

    labels = document.get("labels")
    if not isinstance(labels, dict):
        errors.append("dataset.json labels must be an object")
        return errors
    normalized = {str(name).lower(): value for name, value in labels.items()}
    if normalized.get("background") != 0:
        errors.append("dataset.json background label must be 0")

    if contract == "dataset602":
        scalar_values = [value for value in labels.values() if isinstance(value, int)]
        if len(scalar_values) != len(labels):
            errors.append("Dataset602 labels must all be scalar integers")
        elif set(scalar_values) != set(range(33)):
            errors.append("Dataset602 dataset.json label values must be exactly 0-32")
    else:
        if normalized.get("tooth") != [1, 2]:
            errors.append("Dataset603 Tooth region must be [1, 2]")
        if normalized.get("pulp") != [2]:
            errors.append("Dataset603 Pulp region must be [2]")
        if document.get("regions_class_order") != [1, 2]:
            errors.append("Dataset603 regions_class_order must be [1, 2]")
    return errors


def crop_info_ids(path: Path) -> set[str]:
    document = load_json(path)
    if not isinstance(document, list):
        raise ValueError("crop_info.json must contain a list")
    result: set[str] = set()
    for item in document:
        if not isinstance(item, dict):
            raise ValueError("Every crop_info item must be an object")
        case_id = item.get("roi_case_id", item.get("new_case_id"))
        if not isinstance(case_id, str) or not case_id:
            raise ValueError("Every crop_info item must contain roi_case_id")
        if case_id in result:
            raise RuntimeError(f"Duplicate crop_info ROI ID: {case_id}")
        result.add(case_id)
    return result


def main() -> None:
    args = parse_args()
    if args.geometry_tolerance < 0:
        raise ValueError("--geometry-tolerance must be non-negative")

    errors: list[str] = []
    warnings: list[str] = []
    case_records: list[dict[str, Any]] = []

    try:
        pairs = discover_training_pairs(args.dataset)
    except Exception as exc:
        pairs = []
        errors.append(str(exc))

    dataset_json_path = args.dataset / "dataset.json"
    try:
        document = load_json(dataset_json_path)
        if not isinstance(document, dict):
            raise ValueError("dataset.json must contain an object")
        errors.extend(validate_dataset_json(document, args.contract, len(pairs)))
    except Exception as exc:
        errors.append(f"dataset.json: {exc}")

    for index, (case_id, image_path, label_path) in enumerate(pairs, start=1):
        print(f"[{index}/{len(pairs)}] Validating {case_id}")
        record: dict[str, Any] = {"case_id": case_id, "errors": []}
        try:
            image = sitk.ReadImage(str(image_path))
            label_image, label = read_integer_label(label_path)
            case_errors = geometry_errors(
                image, label_image, args.geometry_tolerance
            )
            if case_errors:
                record["errors"].extend(case_errors)

            present = sorted(int(value) for value in np.unique(label))
            record["present_labels"] = present
            record["foreground_voxels"] = int(np.count_nonzero(label))
            if args.contract == "dataset602":
                invalid = [value for value in present if not 0 <= value <= 32]
                if invalid:
                    record["errors"].append(f"labels outside 0-32: {invalid}")
            else:
                invalid = [value for value in present if value not in (0, 1, 2)]
                if invalid:
                    record["errors"].append(f"labels outside 0/1/2: {invalid}")
                tooth_voxels = int(np.count_nonzero(label == 1))
                pulp_voxels = int(np.count_nonzero(label == 2))
                record["tooth_voxels"] = tooth_voxels
                record["pulp_voxels"] = pulp_voxels
                if tooth_voxels == 0:
                    record["errors"].append("empty tooth label 1")
                if pulp_voxels == 0:
                    record["errors"].append("empty pulp label 2")
        except Exception as exc:
            record["errors"].append(str(exc))

        if record["errors"]:
            errors.append(f"{case_id}: " + "; ".join(record["errors"]))
        case_records.append(record)

    if args.contract == "dataset603" and pairs:
        crop_info_path = args.dataset / "crop_info.json"
        if crop_info_path.is_file():
            try:
                metadata_ids = crop_info_ids(crop_info_path)
                pair_ids = {case_id for case_id, _, _ in pairs}
                missing = sorted(pair_ids - metadata_ids)
                extra = sorted(metadata_ids - pair_ids)
                if missing or extra:
                    errors.append(
                        "crop_info pairing mismatch: "
                        f"missing={missing[:20]}, extra={extra[:20]}"
                    )
            except Exception as exc:
                errors.append(f"crop_info.json: {exc}")
        else:
            warnings.append("Dataset603 has no crop_info.json provenance file")

    report = {
        "dataset": str(args.dataset),
        "contract": args.contract,
        "num_cases": len(pairs),
        "num_errors": len(errors),
        "num_warnings": len(warnings),
        "status": "pass" if not errors else "fail",
        "errors": errors,
        "warnings": warnings,
        "cases": case_records,
    }
    if args.report is not None:
        save_json(args.report, report)

    print(json.dumps({key: report[key] for key in (
        "dataset", "contract", "num_cases", "num_errors", "num_warnings", "status"
    )}, ensure_ascii=False, indent=2))
    if errors:
        for error in errors[:50]:
            print(f"ERROR: {error}")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
