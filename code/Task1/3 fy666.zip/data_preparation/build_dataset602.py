#!/usr/bin/env python3
"""Build the 32-class dataset used by the global tooth model."""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

import numpy as np
import SimpleITK as sitk

try:
    from ._common import (
        copy_image,
        discover_training_pairs,
        geometry_errors,
        prepare_output,
        read_integer_label,
        save_json,
        write_label,
    )
except ImportError:
    from _common import (  # type: ignore[no-redef]
        copy_image,
        discover_training_pairs,
        geometry_errors,
        prepare_output,
        read_integer_label,
        save_json,
        write_label,
    )


TOOTH_LABELS = set(range(1, 33))
PULP_LABELS = set(range(33, 65))
ALLOWED_SOURCE_LABELS = {0, *TOOTH_LABELS, *PULP_LABELS}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Merge source tooth and pulp labels into a 32-class global tooth "
            "segmentation dataset."
        )
    )
    parser.add_argument(
        "--input",
        type=Path,
        required=True,
        help="Input nnU-Net dataset containing imagesTr and labelsTr.",
    )
    parser.add_argument(
        "--output",
        type=Path,
        required=True,
        help="Output directory, normally Dataset602_STSRStage1.",
    )
    parser.add_argument("--dataset-name", default="Dataset602_STSRStage1")
    parser.add_argument("--channel-name", default="CBCT")
    parser.add_argument("--geometry-tolerance", type=float, default=1e-5)
    parser.add_argument("--overwrite", action="store_true")
    return parser.parse_args()


def dataset_json(
    dataset_name: str,
    channel_name: str,
    num_training: int,
) -> dict[str, Any]:
    labels: dict[str, int] = {"background": 0}
    labels.update({f"tooth_{tooth:02d}": tooth for tooth in range(1, 33)})
    return {
        "name": dataset_name,
        "description": (
            "Global tooth-position dataset. Source tooth t and pulp t+32 are "
            "merged into output tooth class t."
        ),
        "channel_names": {"0": channel_name},
        "labels": labels,
        "numTraining": int(num_training),
        "file_ending": ".nii.gz",
    }


def validate_source_contract(case_id: str, label: np.ndarray) -> dict[str, Any]:
    present = {int(value) for value in np.unique(label)}
    invalid = sorted(present - ALLOWED_SOURCE_LABELS)
    if invalid:
        raise ValueError(f"{case_id}: source labels outside 0-64: {invalid}")

    present_teeth = present & TOOTH_LABELS
    present_pulps = present & PULP_LABELS
    orphan_pulps = sorted(
        pulp for pulp in present_pulps if (pulp - 32) not in present_teeth
    )
    if orphan_pulps:
        raise ValueError(
            f"{case_id}: pulp labels have no corresponding tooth t=pulp-32: "
            f"{orphan_pulps}"
        )

    return {
        "present_tooth_labels": sorted(present_teeth),
        "present_pulp_labels": sorted(present_pulps),
        "teeth_without_pulp": sorted(
            tooth for tooth in present_teeth if (tooth + 32) not in present_pulps
        ),
    }


def merge_labels(source: np.ndarray) -> np.ndarray:
    output = np.zeros(source.shape, dtype=np.uint8)
    for tooth in range(1, 33):
        output[(source == tooth) | (source == tooth + 32)] = tooth
    return output


def main() -> None:
    args = parse_args()
    if args.geometry_tolerance < 0:
        raise ValueError("--geometry-tolerance must be non-negative")

    pairs = discover_training_pairs(args.input)
    prepare_output(args.input, args.output, args.overwrite)
    output_images = args.output / "imagesTr"
    output_labels = args.output / "labelsTr"
    output_images.mkdir(parents=True, exist_ok=True)
    output_labels.mkdir(parents=True, exist_ok=True)

    case_records: list[dict[str, Any]] = []
    for index, (case_id, image_path, label_path) in enumerate(pairs, start=1):
        print(f"[{index}/{len(pairs)}] Building Dataset602 case {case_id}")
        image = sitk.ReadImage(str(image_path))
        label_image, source = read_integer_label(label_path)
        errors = geometry_errors(image, label_image, args.geometry_tolerance)
        if errors:
            raise RuntimeError(f"{case_id}: image/label geometry errors: {errors}")

        contract = validate_source_contract(case_id, source)
        merged = merge_labels(source)
        output_image_path = output_images / f"{case_id}_0000.nii.gz"
        output_label_path = output_labels / f"{case_id}.nii.gz"
        copy_image(image_path, output_image_path)
        write_label(merged, label_image, output_label_path)

        record = {
            "case_id": case_id,
            "source_image": str(image_path),
            "source_label": str(label_path),
            "output_image": str(output_image_path),
            "output_label": str(output_label_path),
            "source_foreground_voxels": int(np.count_nonzero(source)),
            "output_foreground_voxels": int(np.count_nonzero(merged)),
            "output_labels": sorted(int(value) for value in np.unique(merged)),
            **contract,
        }
        if (
            record["source_foreground_voxels"]
            != record["output_foreground_voxels"]
        ):
            raise RuntimeError(
                f"{case_id}: foreground voxel count changed during merge"
            )
        case_records.append(record)

    save_json(
        args.output / "dataset.json",
        dataset_json(args.dataset_name, args.channel_name, len(case_records)),
    )
    save_json(
        args.output / "build_report.json",
        {
            "stage": "build_dataset602",
            "input": str(args.input),
            "output": str(args.output),
            "num_cases": len(case_records),
            "source_contract": {
                "background": 0,
                "tooth": "1-32",
                "pulp": "tooth+32, range 33-64",
            },
            "output_contract": {
                "background": 0,
                "tooth": "1-32",
            },
            "cases": case_records,
        },
    )

    print(f"Dataset602 completed: {len(case_records)} case(s)")
    print(f"Output: {args.output}")


if __name__ == "__main__":
    main()
