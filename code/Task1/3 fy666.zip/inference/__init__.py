"""Global-to-local inference pipeline for tooth and pulp segmentation."""
