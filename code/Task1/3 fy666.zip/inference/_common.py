#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import shutil
from pathlib import Path
from typing import Any

import numpy as np
import SimpleITK as sitk


def strip_nii_suffix(name: str) -> str:
    if name.endswith(".nii.gz"):
        return name[:-7]
    if name.endswith(".nii"):
        return name[:-4]
    return Path(name).stem


def case_id_from_image(path: Path) -> str:
    stem = strip_nii_suffix(path.name)
    if not stem.endswith("_0000"):
        raise ValueError(f"Expected <case_id>_0000.nii.gz: {path.name}")
    return stem[:-5]


def discover_input_images(directory: Path) -> dict[str, Path]:
    if not directory.is_dir():
        raise FileNotFoundError(f"Input image directory does not exist: {directory}")

    cases: dict[str, Path] = {}
    for path in sorted(directory.glob("*_0000.nii.gz")):
        case_id = case_id_from_image(path)
        if case_id in cases:
            raise RuntimeError(f"Duplicate input case: {case_id}")
        cases[case_id] = path

    if not cases:
        raise RuntimeError(f"No *_0000.nii.gz images found in {directory}")

    extra_channels: list[str] = []
    unexpected: list[str] = []
    for path in sorted(directory.glob("*.nii.gz")):
        stem = strip_nii_suffix(path.name)
        channel = stem.rsplit("_", 1)[-1]
        if channel.isdigit() and len(channel) == 4 and channel != "0000":
            extra_channels.append(path.name)
        elif not stem.endswith("_0000"):
            unexpected.append(path.name)
    if extra_channels:
        raise RuntimeError(
            "Only one input channel is supported; extra channels found: "
            + ", ".join(extra_channels[:20])
        )
    if unexpected:
        raise RuntimeError(
            "Unexpected NIfTI files in input directory: "
            + ", ".join(unexpected[:20])
        )
    return cases


def read_json(path: Path) -> Any:
    if not path.is_file():
        raise FileNotFoundError(path)
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def save_json(path: Path, document: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8") as handle:
        json.dump(document, handle, ensure_ascii=False, indent=2)
    os.replace(temporary, path)


def prepare_output_root(
    output_root: Path,
    overwrite: bool,
    protected_paths: tuple[Path, ...] = (),
) -> None:
    destination = output_root.resolve()
    if destination == Path(destination.anchor):
        raise ValueError(f"Refusing to use a filesystem root as output: {destination}")

    for protected in protected_paths:
        source = protected.resolve()
        if destination == source:
            raise ValueError(f"Output and protected path are identical: {destination}")
        if destination in source.parents or source in destination.parents:
            raise ValueError(
                "Output and protected paths must not contain one another: "
                f"{destination}, {source}"
            )

    if output_root.exists() and any(output_root.iterdir()):
        if not overwrite:
            raise FileExistsError(
                f"Output directory is not empty: {output_root}. Use --overwrite."
            )
        shutil.rmtree(output_root)
    output_root.mkdir(parents=True, exist_ok=True)


def discover_training_directory(
    model_root: Path,
    configuration: str,
    requested_trainer: str | None,
    requested_plans: str | None,
) -> tuple[Path, str, str]:
    if not model_root.is_dir():
        raise FileNotFoundError(f"Model directory does not exist: {model_root}")

    matches: list[tuple[Path, str, str]] = []
    for path in sorted(model_root.iterdir()):
        if not path.is_dir():
            continue
        parts = path.name.split("__")
        if len(parts) != 3:
            continue
        trainer, plans, found_configuration = parts
        if found_configuration != configuration:
            continue
        if requested_trainer is not None and trainer != requested_trainer:
            continue
        if requested_plans is not None and plans != requested_plans:
            continue
        matches.append((path, trainer, plans))

    if len(matches) != 1:
        available = [path.name for path in model_root.iterdir() if path.is_dir()]
        raise RuntimeError(
            f"Expected one {configuration} training directory, found "
            f"{len(matches)}. Available={available}"
        )
    return matches[0]


def discover_folds(
    training_directory: Path,
    requested: list[str],
    checkpoint: str,
) -> list[str]:
    folds = [str(value) for value in requested]
    if not folds:
        raise ValueError("At least one fold is required")
    missing = [
        str(training_directory / f"fold_{fold}" / checkpoint)
        for fold in folds
        if not (training_directory / f"fold_{fold}" / checkpoint).is_file()
    ]
    if missing:
        raise FileNotFoundError("Missing checkpoints:\n" + "\n".join(missing))
    return folds


def find_dataset_json(training_directory: Path, model_root: Path) -> Path:
    candidates = (
        training_directory / "dataset.json",
        model_root / "dataset.json",
    )
    for path in candidates:
        if path.is_file():
            return path
    raise FileNotFoundError(
        "dataset.json not found at the training-directory or dataset root: "
        f"{training_directory}, {model_root}"
    )


def validate_single_channel(dataset: dict[str, Any], role: str) -> None:
    channels = dataset.get("channel_names", dataset.get("modality"))
    if not isinstance(channels, dict) or len(channels) != 1:
        raise RuntimeError(f"{role} must have exactly one input channel: {channels}")


def read_header(path: Path) -> dict[str, Any]:
    reader = sitk.ImageFileReader()
    reader.SetFileName(str(path))
    reader.ReadImageInformation()
    return {
        "size": tuple(int(value) for value in reader.GetSize()),
        "spacing": tuple(float(value) for value in reader.GetSpacing()),
        "origin": tuple(float(value) for value in reader.GetOrigin()),
        "direction": tuple(float(value) for value in reader.GetDirection()),
    }


def geometry_errors(
    reference: sitk.Image,
    candidate: sitk.Image,
    tolerance: float,
) -> list[str]:
    errors: list[str] = []
    if reference.GetDimension() != 3 or candidate.GetDimension() != 3:
        errors.append("both images must be 3D")
    if reference.GetSize() != candidate.GetSize():
        errors.append(f"size mismatch: {reference.GetSize()} != {candidate.GetSize()}")
    for field, first, second in (
        ("spacing", reference.GetSpacing(), candidate.GetSpacing()),
        ("origin", reference.GetOrigin(), candidate.GetOrigin()),
        ("direction", reference.GetDirection(), candidate.GetDirection()),
    ):
        if not np.allclose(first, second, atol=tolerance, rtol=0):
            errors.append(f"{field} mismatch")
    return errors


def read_integer_label(path: Path) -> tuple[sitk.Image, np.ndarray]:
    image = sitk.ReadImage(str(path))
    array = sitk.GetArrayFromImage(image)
    rounded = np.rint(array)
    if not np.allclose(array, rounded, atol=1e-5, rtol=0):
        raise ValueError(f"Non-integer label values found in {path}")
    return image, rounded.astype(np.int64, copy=False)


def write_image(image: sitk.Image, path: Path, compression_level: int) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    writer = sitk.ImageFileWriter()
    writer.SetFileName(str(path))
    writer.SetUseCompression(True)
    if hasattr(writer, "SetCompressionLevel"):
        writer.SetCompressionLevel(int(compression_level))
    writer.Execute(image)


def write_label(
    array: np.ndarray,
    reference: sitk.Image,
    path: Path,
    compression_level: int,
) -> None:
    output = sitk.GetImageFromArray(array.astype(np.uint8, copy=False))
    output.CopyInformation(reference)
    write_image(output, path, compression_level)
