#!/usr/bin/env python3
"""Run local tooth and pulp segmentation on the generated tooth ROIs."""

from __future__ import annotations

import argparse
import os
import subprocess
from pathlib import Path
from typing import Any

import numpy as np

try:
    from ._common import (
        discover_folds,
        discover_training_directory,
        find_dataset_json,
        prepare_output_root,
        read_header,
        read_integer_label,
        read_json,
        save_json,
        strip_nii_suffix,
        validate_single_channel,
    )
except ImportError:
    from _common import (  # type: ignore[no-redef]
        discover_folds,
        discover_training_directory,
        find_dataset_json,
        prepare_output_root,
        read_header,
        read_integer_label,
        read_json,
        save_json,
        strip_nii_suffix,
        validate_single_channel,
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run local tooth/pulp segmentation on all recorded tooth ROIs."
    )
    parser.add_argument("--roi-images", type=Path, required=True)
    parser.add_argument("--roi-records", type=Path, required=True)
    parser.add_argument("--model-root", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--dataset-id", default="603")
    parser.add_argument("--configuration", default="3d_fullres")
    parser.add_argument("--trainer", default=None)
    parser.add_argument("--plans", default=None)
    parser.add_argument("--folds", nargs="+", default=["all"])
    parser.add_argument("--checkpoint", default="checkpoint_best.pth")
    parser.add_argument("--device", choices=("cuda", "cpu", "mps"), default="cuda")
    parser.add_argument(
        "--disable-tta",
        action="store_true",
        help="Disable nnU-Net mirroring. TTA is enabled by default.",
    )
    parser.add_argument("--geometry-tolerance", type=float, default=1e-5)
    parser.add_argument("--overwrite", action="store_true")
    return parser.parse_args()


def load_roi_records(path: Path) -> list[dict[str, Any]]:
    document = read_json(path)
    if isinstance(document, list):
        records = document
    elif isinstance(document, dict):
        records = document.get("roi_records")
    else:
        records = None
    if not isinstance(records, list) or not records:
        raise ValueError(f"No non-empty roi_records list in {path}")

    by_id: dict[str, dict[str, Any]] = {}
    required = (
        "case_id",
        "roi_case_id",
        "tooth_class",
        "roi_bbox_start_xyz",
        "roi_bbox_end_xyz_exclusive",
        "roi_size_xyz",
        "spacing_xyz",
        "direction",
        "roi_origin_xyz",
    )
    for record in records:
        if not isinstance(record, dict):
            raise ValueError("Every ROI record must be an object")
        missing = [field for field in required if field not in record]
        if missing:
            raise ValueError(f"ROI record is missing fields {missing}: {record}")
        roi_case_id = record["roi_case_id"]
        if not isinstance(roi_case_id, str) or not roi_case_id:
            raise ValueError("Every ROI record must contain a string roi_case_id")
        if roi_case_id in by_id:
            raise RuntimeError(f"Duplicate roi_case_id: {roi_case_id}")
        tooth_class = int(record["tooth_class"])
        if not 1 <= tooth_class <= 32:
            raise ValueError(f"Invalid tooth class {tooth_class}: {roi_case_id}")
        by_id[roi_case_id] = record
    return records


def discover_roi_images(
    directory: Path,
    records: list[dict[str, Any]],
    tolerance: float,
) -> dict[str, Path]:
    if not directory.is_dir():
        raise FileNotFoundError(directory)

    images: dict[str, Path] = {}
    for path in sorted(directory.glob("*_0000.nii.gz")):
        roi_case_id = strip_nii_suffix(path.name)[:-5]
        if roi_case_id in images:
            raise RuntimeError(f"Duplicate ROI input: {roi_case_id}")
        images[roi_case_id] = path

    expected = {str(record["roi_case_id"]) for record in records}
    missing = sorted(expected - set(images))
    extra = sorted(set(images) - expected)
    if missing or extra:
        raise RuntimeError(
            "ROI image/record pairing failed. "
            f"Missing={missing[:20]}, extra={extra[:20]}"
        )

    for record in records:
        roi_case_id = str(record["roi_case_id"])
        expected_filename = record.get(
            "roi_filename",
            f"{roi_case_id}_0000.nii.gz",
        )
        image_path = images[roi_case_id]
        if image_path.name != expected_filename:
            raise RuntimeError(
                f"ROI filename mismatch for {roi_case_id}: "
                f"{image_path.name} != {expected_filename}"
            )
        header = read_header(image_path)
        checks = {
            "size": header["size"] == tuple(record["roi_size_xyz"]),
            "spacing": np.allclose(
                header["spacing"],
                record["spacing_xyz"],
                atol=tolerance,
                rtol=0,
            ),
            "origin": np.allclose(
                header["origin"],
                record["roi_origin_xyz"],
                atol=tolerance,
                rtol=0,
            ),
            "direction": np.allclose(
                header["direction"],
                record["direction"],
                atol=tolerance,
                rtol=0,
            ),
        }
        if not all(bool(value) for value in checks.values()):
            raise RuntimeError(f"{roi_case_id}: ROI metadata mismatch: {checks}")
    return images


def validate_local_dataset(path: Path) -> None:
    dataset = read_json(path)
    if not isinstance(dataset, dict):
        raise ValueError(f"Local dataset.json must contain an object: {path}")
    validate_single_channel(dataset, "Local model")
    labels = dataset.get("labels")
    if not isinstance(labels, dict):
        raise RuntimeError("Local dataset.json labels must be an object")
    normalized = {str(name).lower(): value for name, value in labels.items()}
    if normalized.get("background") != 0:
        raise RuntimeError("Local background label must be 0")
    if normalized.get("tooth") != [1, 2]:
        raise RuntimeError(f"Local Tooth region must be [1, 2]: {labels}")
    if normalized.get("pulp") != [2]:
        raise RuntimeError(f"Local Pulp region must be [2]: {labels}")
    if dataset.get("regions_class_order") != [1, 2]:
        raise RuntimeError(
            "Local regions_class_order must be [1, 2]: "
            f"{dataset.get('regions_class_order')}"
        )


def build_predict_command(
    input_directory: Path,
    output_directory: Path,
    dataset_id: str,
    configuration: str,
    trainer: str,
    plans: str,
    folds: list[str],
    checkpoint: str,
    device: str,
    tta_enabled: bool,
) -> list[str]:
    command = [
        "nnUNetv2_predict",
        "-i",
        str(input_directory),
        "-o",
        str(output_directory),
        "-d",
        dataset_id,
        "-c",
        configuration,
        "-f",
        *folds,
        "-tr",
        trainer,
        "-p",
        plans,
        "-chk",
        checkpoint,
        "-device",
        device,
    ]
    if not tta_enabled:
        command.append("--disable_tta")
    return command


def validate_predictions(
    roi_images: dict[str, Path],
    prediction_directory: Path,
    tolerance: float,
) -> tuple[dict[str, Path], list[dict[str, Any]]]:
    predictions = {
        strip_nii_suffix(path.name): path
        for path in sorted(prediction_directory.glob("*.nii.gz"))
    }
    missing = sorted(set(roi_images) - set(predictions))
    extra = sorted(set(predictions) - set(roi_images))
    if missing or extra:
        raise RuntimeError(
            "Local output pairing failed. "
            f"Missing={missing[:20]}, extra={extra[:20]}"
        )

    records: list[dict[str, Any]] = []
    for roi_case_id in sorted(roi_images):
        source = read_header(roi_images[roi_case_id])
        prediction = read_header(predictions[roi_case_id])
        if source["size"] != prediction["size"]:
            raise RuntimeError(f"{roi_case_id}: prediction size mismatch")
        for field in ("spacing", "origin", "direction"):
            if not np.allclose(
                source[field],
                prediction[field],
                atol=tolerance,
                rtol=0,
            ):
                raise RuntimeError(f"{roi_case_id}: prediction {field} mismatch")

        _, label = read_integer_label(predictions[roi_case_id])
        present = sorted(int(value) for value in np.unique(label))
        invalid = [value for value in present if value not in (0, 1, 2)]
        if invalid:
            raise RuntimeError(
                f"{roi_case_id}: local labels outside 0/1/2: {invalid}"
            )
        records.append(
            {
                "roi_case_id": roi_case_id,
                "present_labels": present,
                "tooth_voxels": int(np.count_nonzero(label == 1)),
                "pulp_voxels": int(np.count_nonzero(label == 2)),
                "prediction": str(predictions[roi_case_id]),
            }
        )
    return predictions, records


def main() -> None:
    args = parse_args()
    if args.geometry_tolerance < 0:
        raise ValueError("--geometry-tolerance must be non-negative")

    records = load_roi_records(args.roi_records)
    roi_images = discover_roi_images(
        args.roi_images,
        records,
        args.geometry_tolerance,
    )
    training_directory, trainer, plans = discover_training_directory(
        args.model_root,
        args.configuration,
        args.trainer,
        args.plans,
    )
    folds = discover_folds(training_directory, args.folds, args.checkpoint)
    dataset_json_path = find_dataset_json(training_directory, args.model_root)
    validate_local_dataset(dataset_json_path)
    prepare_output_root(
        args.output_root,
        args.overwrite,
        protected_paths=(args.roi_images, args.roi_records, args.model_root),
    )
    prediction_directory = args.output_root / "labels"
    prediction_directory.mkdir(parents=True, exist_ok=True)

    tta_enabled = not args.disable_tta
    command = build_predict_command(
        args.roi_images,
        prediction_directory,
        args.dataset_id,
        args.configuration,
        trainer,
        plans,
        folds,
        args.checkpoint,
        args.device,
        tta_enabled,
    )
    environment = os.environ.copy()
    environment["nnUNet_results"] = str(args.model_root.parent)
    print("Local model command:", " ".join(command), flush=True)
    subprocess.run(command, check=True, env=environment)

    predictions, prediction_records = validate_predictions(
        roi_images,
        prediction_directory,
        args.geometry_tolerance,
    )
    manifest = {
        "stage": "local_tooth_pulp",
        "num_rois": len(records),
        "num_predictions": len(predictions),
        "input_roi_images": str(args.roi_images),
        "roi_records": str(args.roi_records),
        "prediction_directory": str(prediction_directory),
        "postprocessing": False,
        "model": {
            "dataset_id": args.dataset_id,
            "configuration": args.configuration,
            "trainer": trainer,
            "plans": plans,
            "folds": folds,
            "checkpoint": args.checkpoint,
            "training_directory": str(training_directory),
            "dataset_json": str(dataset_json_path),
            "tta_enabled": tta_enabled,
            "command": command,
        },
        "predictions": prediction_records,
    }
    save_json(args.output_root / "manifest.json", manifest)

    print("Local tooth/pulp stage completed.")
    print(f"ROIs: {len(records)}")
    print(f"Predictions: {len(predictions)}")
    print(f"TTA enabled: {tta_enabled}")
    print(f"Output: {args.output_root}")


if __name__ == "__main__":
    main()
