#!/usr/bin/env python3
"""Run the global-to-local tooth and pulp segmentation pipeline."""

from __future__ import annotations

import argparse
import hashlib
import platform
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

try:
    from ._common import (
        discover_input_images,
        prepare_output_root,
        read_json,
        save_json,
        strip_nii_suffix,
    )
except ImportError:
    from _common import (  # type: ignore[no-redef]
        discover_input_images,
        prepare_output_root,
        read_json,
        save_json,
        strip_nii_suffix,
    )


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Run global tooth segmentation, local tooth/pulp segmentation, "
            "and full-volume merging."
        )
    )
    parser.add_argument("--input-images", type=Path, required=True)
    parser.add_argument("--global-model-root", type=Path, required=True)
    parser.add_argument("--local-model-root", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--device", choices=("cuda", "cpu", "mps"), default="cuda")

    parser.add_argument("--global-dataset-id", default="602")
    parser.add_argument("--global-configuration", default="3d_lowres")
    parser.add_argument("--global-trainer", default=None)
    parser.add_argument("--global-plans", default=None)
    parser.add_argument("--global-folds", nargs="+", default=["all"])
    parser.add_argument("--global-checkpoint", default="checkpoint_best.pth")

    parser.add_argument("--local-dataset-id", default="603")
    parser.add_argument("--local-configuration", default="3d_fullres")
    parser.add_argument("--local-trainer", default=None)
    parser.add_argument("--local-plans", default=None)
    parser.add_argument("--local-folds", nargs="+", default=["all"])
    parser.add_argument("--local-checkpoint", default="checkpoint_best.pth")

    parser.add_argument("--fragment-distance-mm", type=float, default=3.0)
    parser.add_argument("--padding-voxels", type=int, default=10)
    parser.add_argument("--roi-write-workers", type=int, default=4)
    parser.add_argument("--compression-level", type=int, default=1)
    parser.add_argument("--geometry-tolerance", type=float, default=1e-5)
    parser.add_argument("--merge-geometry-tolerance", type=float, default=1e-4)
    parser.add_argument(
        "--disable-tta",
        action="store_true",
        help="Disable mirroring for both models. TTA is enabled by default.",
    )
    parser.add_argument("--overwrite", action="store_true")
    return parser.parse_args(argv)


def add_optional(command: list[str], flag: str, value: str | None) -> None:
    if value is not None:
        command.extend((flag, value))


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def run_stage(name: str, command: list[str]) -> dict[str, Any]:
    print(f"[{name}] command: {' '.join(command)}", flush=True)
    started = time.perf_counter()
    subprocess.run(command, check=True)
    return {
        "name": name,
        "command": command,
        "elapsed_seconds": time.perf_counter() - started,
    }


def index_final_labels(directory: Path) -> dict[str, Path]:
    if not directory.is_dir():
        raise FileNotFoundError(directory)
    labels: dict[str, Path] = {}
    for path in sorted(directory.glob("*.nii.gz")):
        case_id = strip_nii_suffix(path.name)
        if case_id in labels:
            raise RuntimeError(f"Duplicate final label: {case_id}")
        labels[case_id] = path
    return labels


def validate_arguments(args: argparse.Namespace) -> None:
    if args.fragment_distance_mm < 0:
        raise ValueError("--fragment-distance-mm must be non-negative")
    if args.padding_voxels < 0:
        raise ValueError("--padding-voxels must be non-negative")
    if args.roi_write_workers < 1:
        raise ValueError("--roi-write-workers must be at least 1")
    if not 0 <= args.compression_level <= 9:
        raise ValueError("--compression-level must be between 0 and 9")
    if args.geometry_tolerance < 0 or args.merge_geometry_tolerance < 0:
        raise ValueError("Geometry tolerances must be non-negative")


def discover_scripts() -> tuple[Path, ...]:
    script_directory = Path(__file__).resolve().parent
    scripts = (
        script_directory / "_common.py",
        script_directory / "global_tooth_and_roi.py",
        script_directory / "local_tooth_pulp.py",
        script_directory / "merge_to_full_volume.py",
        Path(__file__).resolve(),
    )
    for script in scripts:
        if not script.is_file():
            raise FileNotFoundError(script)
    return scripts


def build_global_command(
    args: argparse.Namespace,
    output_root: Path,
    script: Path,
) -> list[str]:
    command = [
        sys.executable,
        "-u",
        str(script),
        "--input-images",
        str(args.input_images),
        "--model-root",
        str(args.global_model_root),
        "--output-root",
        str(output_root),
        "--dataset-id",
        args.global_dataset_id,
        "--configuration",
        args.global_configuration,
        "--folds",
        *args.global_folds,
        "--checkpoint",
        args.global_checkpoint,
        "--device",
        args.device,
        "--fragment-distance-mm",
        str(args.fragment_distance_mm),
        "--padding-voxels",
        str(args.padding_voxels),
        "--roi-write-workers",
        str(args.roi_write_workers),
        "--compression-level",
        str(args.compression_level),
        "--geometry-tolerance",
        str(args.geometry_tolerance),
    ]
    add_optional(command, "--trainer", args.global_trainer)
    add_optional(command, "--plans", args.global_plans)
    if args.disable_tta:
        command.append("--disable-tta")
    return command


def build_local_command(
    args: argparse.Namespace,
    global_root: Path,
    output_root: Path,
    script: Path,
) -> list[str]:
    command = [
        sys.executable,
        "-u",
        str(script),
        "--roi-images",
        str(global_root / "roi_images"),
        "--roi-records",
        str(global_root / "roi_records.json"),
        "--model-root",
        str(args.local_model_root),
        "--output-root",
        str(output_root),
        "--dataset-id",
        args.local_dataset_id,
        "--configuration",
        args.local_configuration,
        "--folds",
        *args.local_folds,
        "--checkpoint",
        args.local_checkpoint,
        "--device",
        args.device,
        "--geometry-tolerance",
        str(args.geometry_tolerance),
    ]
    add_optional(command, "--trainer", args.local_trainer)
    add_optional(command, "--plans", args.local_plans)
    if args.disable_tta:
        command.append("--disable-tta")
    return command


def build_merge_command(
    args: argparse.Namespace,
    global_root: Path,
    local_root: Path,
    output_root: Path,
    script: Path,
) -> list[str]:
    return [
        sys.executable,
        "-u",
        str(script),
        "--reference-images",
        str(args.input_images),
        "--localization-dir",
        str(global_root / "localization"),
        "--roi-records",
        str(global_root / "roi_records.json"),
        "--raw-labels",
        str(local_root / "labels"),
        "--output-root",
        str(output_root),
        "--geometry-tolerance",
        str(args.merge_geometry_tolerance),
        "--compression-level",
        str(args.compression_level),
    ]


def common_parameters(args: argparse.Namespace) -> dict[str, Any]:
    return {
        "fragment_distance_mm": args.fragment_distance_mm,
        "padding_voxels": args.padding_voxels,
        "global_folds": args.global_folds,
        "local_folds": args.local_folds,
        "global_checkpoint": args.global_checkpoint,
        "local_checkpoint": args.local_checkpoint,
        "device": args.device,
    }


def run_pipeline(
    args: argparse.Namespace,
    input_cases: dict[str, Path],
    scripts: tuple[Path, ...],
) -> None:
    prepare_output_root(
        args.output_root,
        args.overwrite,
        protected_paths=(
            args.input_images,
            args.global_model_root,
            args.local_model_root,
        ),
    )
    script_directory = Path(__file__).resolve().parent
    global_root = args.output_root / "global"
    local_root = args.output_root / "local"
    final_root = args.output_root / "final"
    tta_enabled = not args.disable_tta
    started_utc = datetime.now(timezone.utc)
    pipeline_started = time.perf_counter()

    stage_records = [
        run_stage(
            "global_tooth_and_roi",
            build_global_command(
                args,
                global_root,
                script_directory / "global_tooth_and_roi.py",
            ),
        ),
        run_stage(
            "local_tooth_pulp",
            build_local_command(
                args,
                global_root,
                local_root,
                script_directory / "local_tooth_pulp.py",
            ),
        ),
        run_stage(
            "merge_to_full_volume",
            build_merge_command(
                args,
                global_root,
                local_root,
                final_root,
                script_directory / "merge_to_full_volume.py",
            ),
        ),
    ]

    global_manifest = read_json(global_root / "manifest.json")
    local_manifest = read_json(local_root / "manifest.json")
    final_manifest = read_json(final_root / "manifest.json")
    if global_manifest.get("model", {}).get("tta_enabled") != tta_enabled:
        raise RuntimeError("Global manifest TTA state does not match the request")
    if local_manifest.get("model", {}).get("tta_enabled") != tta_enabled:
        raise RuntimeError("Local manifest TTA state does not match the request")

    final_labels = index_final_labels(final_root / "labels")
    missing_outputs = sorted(set(input_cases) - set(final_labels))
    extra_outputs = sorted(set(final_labels) - set(input_cases))
    if missing_outputs or extra_outputs:
        raise RuntimeError(
            "Final output pairing failed. "
            f"Missing={missing_outputs[:20]}, extra={extra_outputs[:20]}"
        )

    manifest = {
        "pipeline": "global_to_local_tooth_pulp",
        "status": "completed",
        "num_input_cases": len(input_cases),
        "num_output_cases": len(final_labels),
        "tta_enabled": tta_enabled,
        "started_utc": started_utc.isoformat(),
        "finished_utc": datetime.now(timezone.utc).isoformat(),
        "elapsed_seconds": time.perf_counter() - pipeline_started,
        "python": sys.version,
        "platform": platform.platform(),
        "inputs": {
            "images": str(args.input_images),
            "global_model_root": str(args.global_model_root),
            "local_model_root": str(args.local_model_root),
        },
        "outputs": {
            "root": str(args.output_root),
            "global": str(global_root),
            "local": str(local_root),
            "final_labels": str(final_root / "labels"),
        },
        "parameters": common_parameters(args),
        "source_sha256": {
            str(script.relative_to(script_directory)): file_sha256(script)
            for script in scripts
        },
        "stages": stage_records,
        "stage_summaries": {
            "global": {
                "num_cases": global_manifest.get("num_cases"),
                "num_rois": global_manifest.get("num_rois"),
            },
            "local": {
                "num_rois": local_manifest.get("num_rois"),
                "num_predictions": local_manifest.get("num_predictions"),
            },
            "merge": {
                "num_cases": final_manifest.get("num_generated_cases"),
                "num_rois": final_manifest.get("num_rois"),
            },
        },
    }
    save_json(args.output_root / "pipeline_manifest.json", manifest)

    print("Global-to-local pipeline completed.")
    print(f"Cases: {len(final_labels)}")
    print(f"TTA enabled: {tta_enabled}")
    print(f"Final labels: {final_root / 'labels'}")


def main() -> None:
    args = parse_args()
    validate_arguments(args)
    scripts = discover_scripts()
    for model_root in (args.global_model_root, args.local_model_root):
        if not model_root.is_dir():
            raise FileNotFoundError(model_root)
    input_cases = discover_input_images(args.input_images)
    run_pipeline(args, input_cases, scripts)


if __name__ == "__main__":
    main()
