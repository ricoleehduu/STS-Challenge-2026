#!/usr/bin/env python3
"""Merge local tooth and pulp predictions into full-volume label maps."""

from __future__ import annotations

import argparse
from collections import defaultdict
from pathlib import Path
from typing import Any

import numpy as np
import SimpleITK as sitk

try:
    from ._common import (
        discover_input_images,
        prepare_output_root,
        read_header,
        read_integer_label,
        read_json,
        save_json,
        strip_nii_suffix,
    )
except ImportError:
    from _common import (  # type: ignore[no-redef]
        discover_input_images,
        prepare_output_root,
        read_header,
        read_integer_label,
        read_json,
        save_json,
        strip_nii_suffix,
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Merge local ROI predictions into full-volume label maps."
    )
    parser.add_argument("--reference-images", type=Path, required=True)
    parser.add_argument("--localization-dir", type=Path, required=True)
    parser.add_argument("--roi-records", type=Path, required=True)
    parser.add_argument("--raw-labels", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--geometry-tolerance", type=float, default=1e-4)
    parser.add_argument("--compression-level", type=int, default=1)
    parser.add_argument("--overwrite", action="store_true")
    return parser.parse_args()


def extract_roi_records(path: Path) -> list[dict[str, Any]]:
    document = read_json(path)
    if isinstance(document, list):
        records = document
    elif isinstance(document, dict):
        records = document.get("roi_records", document.get("records"))
    else:
        records = None
    if not isinstance(records, list) or not records:
        raise ValueError(f"No non-empty ROI records in {path}")

    required = (
        "case_id",
        "roi_case_id",
        "tooth_class",
        "roi_bbox_start_xyz",
        "roi_bbox_end_xyz_exclusive",
        "roi_size_xyz",
    )
    seen: set[str] = set()
    for record in records:
        if not isinstance(record, dict):
            raise ValueError("Every ROI record must be an object")
        missing = [field for field in required if field not in record]
        if missing:
            raise ValueError(f"ROI record is missing fields {missing}: {record}")
        roi_case_id = str(record["roi_case_id"])
        if not roi_case_id:
            raise ValueError("roi_case_id must not be empty")
        if roi_case_id in seen:
            raise RuntimeError(f"Duplicate roi_case_id: {roi_case_id}")
        seen.add(roi_case_id)
        tooth_class = int(record["tooth_class"])
        if not 1 <= tooth_class <= 32:
            raise ValueError(f"Invalid tooth class {tooth_class}: {roi_case_id}")
    return records


def index_labels(directory: Path, role: str) -> dict[str, Path]:
    if not directory.is_dir():
        raise FileNotFoundError(directory)
    result: dict[str, Path] = {}
    for path in sorted(directory.glob("*.nii.gz")):
        case_id = strip_nii_suffix(path.name)
        if case_id.endswith("_0000"):
            case_id = case_id[:-5]
        if case_id in result:
            raise RuntimeError(f"Duplicate {role} ID: {case_id}")
        result[case_id] = path
    if not result:
        raise RuntimeError(f"No {role} NIfTI files found in {directory}")
    return result


def expected_roi_origin(
    reference: dict[str, Any],
    start_xyz: list[int],
) -> tuple[float, float, float]:
    direction = np.asarray(reference["direction"], dtype=np.float64).reshape(3, 3)
    origin = np.asarray(reference["origin"], dtype=np.float64)
    spacing = np.asarray(reference["spacing"], dtype=np.float64)
    index = np.asarray(start_xyz, dtype=np.float64)
    point = origin + direction @ (index * spacing)
    return tuple(float(value) for value in point)


def same_grid(
    reference: dict[str, Any],
    image: sitk.Image,
    tolerance: float,
) -> bool:
    return (
        reference["size"] == tuple(image.GetSize())
        and np.allclose(
            reference["spacing"],
            image.GetSpacing(),
            atol=tolerance,
            rtol=0,
        )
        and np.allclose(
            reference["origin"],
            image.GetOrigin(),
            atol=tolerance,
            rtol=0,
        )
        and np.allclose(
            reference["direction"],
            image.GetDirection(),
            atol=tolerance,
            rtol=0,
        )
    )


def validate_roi_geometry(
    roi_image: sitk.Image,
    reference: dict[str, Any],
    start_xyz: list[int],
    size_xyz: list[int],
    tolerance: float,
) -> None:
    checks = {
        "size": tuple(roi_image.GetSize()) == tuple(size_xyz),
        "spacing": np.allclose(
            roi_image.GetSpacing(),
            reference["spacing"],
            atol=tolerance,
            rtol=0,
        ),
        "origin": np.allclose(
            roi_image.GetOrigin(),
            expected_roi_origin(reference, start_xyz),
            atol=tolerance,
            rtol=0,
        ),
        "direction": np.allclose(
            roi_image.GetDirection(),
            reference["direction"],
            atol=tolerance,
            rtol=0,
        ),
    }
    if not all(bool(value) for value in checks.values()):
        raise RuntimeError(f"ROI geometry mismatch: {checks}")


def write_label_from_header(
    array: np.ndarray,
    reference: dict[str, Any],
    path: Path,
    compression_level: int,
) -> None:
    image = sitk.GetImageFromArray(array.astype(np.uint8, copy=False))
    image.SetSpacing(reference["spacing"])
    image.SetOrigin(reference["origin"])
    image.SetDirection(reference["direction"])
    writer = sitk.ImageFileWriter()
    writer.SetFileName(str(path))
    writer.SetUseCompression(True)
    if hasattr(writer, "SetCompressionLevel"):
        writer.SetCompressionLevel(compression_level)
    writer.Execute(image)


def integer_bbox(record: dict[str, Any]) -> tuple[np.ndarray, np.ndarray]:
    start_values = np.asarray(record["roi_bbox_start_xyz"], dtype=np.float64)
    end_values = np.asarray(
        record["roi_bbox_end_xyz_exclusive"],
        dtype=np.float64,
    )
    if start_values.shape != (3,) or end_values.shape != (3,):
        raise RuntimeError(f"{record['roi_case_id']}: ROI bbox must have 3 axes")
    start = np.rint(start_values).astype(np.int64)
    end = np.rint(end_values).astype(np.int64)
    if not np.allclose(start_values, start, atol=1e-6, rtol=0):
        raise RuntimeError(f"{record['roi_case_id']}: ROI start is not integral")
    if not np.allclose(end_values, end, atol=1e-6, rtol=0):
        raise RuntimeError(f"{record['roi_case_id']}: ROI end is not integral")
    return start, end


def encode_local_labels(raw: np.ndarray, tooth_class: int) -> np.ndarray:
    unique_values = np.unique(raw)
    if np.any((unique_values < 0) | (unique_values > 2)):
        raise RuntimeError(f"Invalid local labels: {unique_values.tolist()}")
    encoded = np.zeros(raw.shape, dtype=np.uint8)
    encoded[raw == 1] = tooth_class
    encoded[raw == 2] = tooth_class + 32
    return encoded


def merge_candidate(
    output_view: np.ndarray,
    rank_view: np.ndarray,
    encoded: np.ndarray,
    global_support: np.ndarray,
) -> tuple[int, int, int]:
    foreground = encoded > 0
    candidate_rank = np.zeros(encoded.shape, dtype=np.int8)
    candidate_rank[global_support] = 1
    different_conflict = foreground & (output_view > 0) & (output_view != encoded)
    tied_conflict = different_conflict & (candidate_rank == rank_view)
    take_candidate = foreground & (
        (output_view == 0) | (candidate_rank > rank_view)
    )
    written = int(np.count_nonzero(take_candidate))
    conflicts = int(np.count_nonzero(different_conflict))
    ties = int(np.count_nonzero(tied_conflict))
    output_view[take_candidate] = encoded[take_candidate]
    rank_view[take_candidate] = candidate_rank[take_candidate]
    return written, conflicts, ties


def validate_record_reference(
    record: dict[str, Any],
    reference: dict[str, Any],
    tolerance: float,
) -> None:
    checks: dict[str, bool] = {}
    if "original_size_xyz" in record:
        checks["original_size"] = (
            tuple(record["original_size_xyz"]) == reference["size"]
        )
    if "spacing_xyz" in record:
        checks["spacing"] = bool(
            np.allclose(
                record["spacing_xyz"],
                reference["spacing"],
                atol=tolerance,
                rtol=0,
            )
        )
    if "original_origin_xyz" in record:
        checks["origin"] = bool(
            np.allclose(
                record["original_origin_xyz"],
                reference["origin"],
                atol=tolerance,
                rtol=0,
            )
        )
    if "direction" in record:
        checks["direction"] = bool(
            np.allclose(
                record["direction"],
                reference["direction"],
                atol=tolerance,
                rtol=0,
            )
        )
    if not all(checks.values()):
        raise RuntimeError(
            f"{record['roi_case_id']}: record/reference mismatch: {checks}"
        )


def main() -> None:
    args = parse_args()
    if args.geometry_tolerance < 0:
        raise ValueError("--geometry-tolerance must be non-negative")
    if not 0 <= args.compression_level <= 9:
        raise ValueError("--compression-level must be between 0 and 9")

    reference_images = discover_input_images(args.reference_images)
    roi_records = extract_roi_records(args.roi_records)
    localizations = index_labels(args.localization_dir, "localization")
    raw_labels = index_labels(args.raw_labels, "raw local label")

    missing_localizations = sorted(set(reference_images) - set(localizations))
    extra_localizations = sorted(set(localizations) - set(reference_images))
    if missing_localizations or extra_localizations:
        raise RuntimeError(
            "Localization/reference pairing failed. "
            f"Missing={missing_localizations[:20]}, "
            f"extra={extra_localizations[:20]}"
        )

    expected_roi_ids = {str(record["roi_case_id"]) for record in roi_records}
    missing_labels = sorted(expected_roi_ids - set(raw_labels))
    extra_labels = sorted(set(raw_labels) - expected_roi_ids)
    if missing_labels or extra_labels:
        raise RuntimeError(
            "Raw local label pairing failed. "
            f"Missing={missing_labels[:20]}, extra={extra_labels[:20]}"
        )

    prepare_output_root(
        args.output_root,
        args.overwrite,
        protected_paths=(
            args.reference_images,
            args.localization_dir,
            args.roi_records,
            args.raw_labels,
        ),
    )
    output_labels = args.output_root / "labels"
    output_labels.mkdir(parents=True, exist_ok=True)

    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for record in roi_records:
        case_id = str(record["case_id"])
        if case_id not in reference_images:
            raise RuntimeError(f"ROI refers to an unknown case: {case_id}")
        grouped[case_id].append(record)

    case_summaries: list[dict[str, Any]] = []
    total_conflicts = 0
    total_ties = 0
    total_written = 0
    for case_index, (case_id, reference_path) in enumerate(
        sorted(reference_images.items()),
        start=1,
    ):
        print(f"[{case_index}/{len(reference_images)}] Merging {case_id}", flush=True)
        reference = read_header(reference_path)
        size_xyz = np.asarray(reference["size"], dtype=np.int64)
        shape_zyx = tuple(int(value) for value in size_xyz[::-1])
        merged = np.zeros(shape_zyx, dtype=np.uint8)
        rank_map = np.full(shape_zyx, -1, dtype=np.int8)

        localization_image, localization = read_integer_label(
            localizations[case_id]
        )
        if not same_grid(reference, localization_image, args.geometry_tolerance):
            raise RuntimeError(f"{case_id}: localization/reference grid mismatch")
        invalid_localization = sorted(
            {int(value) for value in np.unique(localization)} - set(range(33))
        )
        if invalid_localization:
            raise RuntimeError(
                f"{case_id}: localization labels outside 0-32: "
                f"{invalid_localization}"
            )

        case_conflicts = 0
        case_ties = 0
        case_written = 0
        case_rois = sorted(
            grouped.get(case_id, []),
            key=lambda record: (
                int(record["tooth_class"]),
                str(record["roi_case_id"]),
            ),
        )
        for record in case_rois:
            roi_case_id = str(record["roi_case_id"])
            tooth_class = int(record["tooth_class"])
            validate_record_reference(record, reference, args.geometry_tolerance)
            start, end = integer_bbox(record)
            if np.any(start < 0) or np.any(end <= start) or np.any(end > size_xyz):
                raise RuntimeError(f"{roi_case_id}: ROI bbox is outside the volume")

            roi_size_xyz = [int(value) for value in end - start]
            if tuple(roi_size_xyz) != tuple(record["roi_size_xyz"]):
                raise RuntimeError(f"{roi_case_id}: ROI size record is inconsistent")
            raw_image, raw = read_integer_label(raw_labels[roi_case_id])
            expected_shape = tuple(roi_size_xyz[::-1])
            if raw.shape != expected_shape:
                raise RuntimeError(
                    f"{roi_case_id}: shape {raw.shape} != {expected_shape}"
                )
            validate_roi_geometry(
                raw_image,
                reference,
                start.tolist(),
                roi_size_xyz,
                args.geometry_tolerance,
            )
            encoded = encode_local_labels(raw, tooth_class)
            if not np.any(encoded):
                continue

            start_zyx = start[::-1]
            end_zyx = end[::-1]
            slices = tuple(
                slice(int(first), int(last))
                for first, last in zip(start_zyx, end_zyx)
            )
            written, conflicts, ties = merge_candidate(
                merged[slices],
                rank_map[slices],
                encoded,
                localization[slices] == tooth_class,
            )
            case_written += written
            case_conflicts += conflicts
            case_ties += ties

        output_path = output_labels / f"{case_id}.nii.gz"
        write_label_from_header(
            merged,
            reference,
            output_path,
            args.compression_level,
        )
        case_summaries.append(
            {
                "case_id": case_id,
                "num_rois": len(case_rois),
                "written_voxels": case_written,
                "different_label_conflict_voxels": case_conflicts,
                "tied_conflict_voxels": case_ties,
                "output_label": str(output_path),
            }
        )
        total_written += case_written
        total_conflicts += case_conflicts
        total_ties += case_ties

    manifest = {
        "stage": "merge_to_full_volume",
        "num_cases": len(reference_images),
        "num_rois": len(roi_records),
        "num_generated_cases": len(case_summaries),
        "output_labels": str(output_labels),
        "label_encoding": {
            "background": 0,
            "tooth": "tooth_class, range 1-32",
            "pulp": "tooth_class + 32, range 33-64",
        },
        "merge_policy": {
            "roi_order": "ascending tooth_class, then roi_case_id",
            "base_rank": 0,
            "global_support_rank": 1,
            "equal_rank_tie": "retain existing voxel",
            "local_prediction_postprocessing": False,
        },
        "total_written_voxels": total_written,
        "total_different_label_conflict_voxels": total_conflicts,
        "total_tied_conflict_voxels": total_ties,
        "cases": case_summaries,
    }
    save_json(args.output_root / "manifest.json", manifest)

    print("Full-volume merge completed.")
    print(f"Cases: {len(case_summaries)}")
    print(f"ROIs: {len(roi_records)}")
    print(f"Output: {args.output_root}")


if __name__ == "__main__":
    main()
