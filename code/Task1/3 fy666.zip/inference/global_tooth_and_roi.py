#!/usr/bin/env python3
"""Run global tooth segmentation, clean fragments, and create tooth ROIs."""

from __future__ import annotations

import argparse
import math
import os
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any

import numpy as np
import SimpleITK as sitk
from scipy import ndimage

try:
    from ._common import (
        discover_folds,
        discover_input_images,
        discover_training_directory,
        find_dataset_json,
        geometry_errors,
        prepare_output_root,
        read_integer_label,
        read_json,
        save_json,
        strip_nii_suffix,
        validate_single_channel,
        write_image,
        write_label,
    )
except ImportError:
    from _common import (  # type: ignore[no-redef]
        discover_folds,
        discover_input_images,
        discover_training_directory,
        find_dataset_json,
        geometry_errors,
        prepare_output_root,
        read_integer_label,
        read_json,
        save_json,
        strip_nii_suffix,
        validate_single_channel,
        write_image,
        write_label,
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Run global tooth segmentation, retain fragments within a physical "
            "distance of the main component, and create padded tooth ROIs."
        )
    )
    parser.add_argument("--input-images", type=Path, required=True)
    parser.add_argument("--model-root", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--dataset-id", default="602")
    parser.add_argument("--configuration", default="3d_lowres")
    parser.add_argument("--trainer", default=None)
    parser.add_argument("--plans", default=None)
    parser.add_argument("--folds", nargs="+", default=["all"])
    parser.add_argument("--checkpoint", default="checkpoint_best.pth")
    parser.add_argument("--device", choices=("cuda", "cpu", "mps"), default="cuda")
    parser.add_argument(
        "--disable-tta",
        action="store_true",
        help="Disable nnU-Net mirroring. TTA is enabled by default.",
    )
    parser.add_argument("--fragment-distance-mm", type=float, default=3.0)
    parser.add_argument("--padding-voxels", type=int, default=10)
    parser.add_argument("--roi-write-workers", type=int, default=4)
    parser.add_argument("--compression-level", type=int, default=1)
    parser.add_argument("--geometry-tolerance", type=float, default=1e-5)
    parser.add_argument("--overwrite", action="store_true")
    return parser.parse_args()


def validate_global_dataset(path: Path) -> None:
    dataset = read_json(path)
    if not isinstance(dataset, dict):
        raise ValueError(f"Global dataset.json must contain an object: {path}")
    validate_single_channel(dataset, "Global model")
    labels = dataset.get("labels")
    if not isinstance(labels, dict):
        raise RuntimeError("Global dataset.json labels must be an object")
    values = list(labels.values())
    if not all(isinstance(value, int) for value in values):
        raise RuntimeError("Global labels must all be scalar integers")
    if set(values) != set(range(33)):
        raise RuntimeError("Global dataset.json label values must be exactly 0-32")


def build_predict_command(
    input_directory: Path,
    output_directory: Path,
    dataset_id: str,
    configuration: str,
    trainer: str,
    plans: str,
    folds: list[str],
    checkpoint: str,
    device: str,
    tta_enabled: bool,
) -> list[str]:
    command = [
        "nnUNetv2_predict",
        "-i",
        str(input_directory),
        "-o",
        str(output_directory),
        "-d",
        dataset_id,
        "-c",
        configuration,
        "-f",
        *folds,
        "-tr",
        trainer,
        "-p",
        plans,
        "-chk",
        checkpoint,
        "-device",
        device,
    ]
    if not tta_enabled:
        command.append("--disable_tta")
    return command


def clean_one_class(
    mask: np.ndarray,
    spacing_zyx: np.ndarray,
    threshold_mm: float,
) -> tuple[np.ndarray, int, int]:
    coordinates = np.argwhere(mask)
    if coordinates.size == 0:
        return np.zeros_like(mask, dtype=bool), 0, 0

    start = coordinates.min(axis=0)
    end = coordinates.max(axis=0) + 1
    slices = tuple(slice(int(start[axis]), int(end[axis])) for axis in range(3))
    crop = mask[slices]
    components, count = ndimage.label(
        crop,
        structure=np.ones((3, 3, 3), dtype=np.uint8),
    )
    sizes = np.bincount(components.ravel(), minlength=count + 1)[1:]
    main_id = int(np.argmax(sizes) + 1)
    keep_ids = [main_id]

    if count > 1:
        padding = tuple(
            int(math.ceil(threshold_mm / float(spacing))) + 1
            for spacing in spacing_zyx
        )
        padded_non_main = np.pad(
            components != main_id,
            tuple((value, value) for value in padding),
            mode="constant",
            constant_values=True,
        )
        padded_distances = ndimage.distance_transform_edt(
            padded_non_main,
            sampling=spacing_zyx,
        )
        original_slices = tuple(
            slice(padding[axis], padding[axis] + components.shape[axis])
            for axis in range(3)
        )
        distances_to_main = padded_distances[original_slices]
        for component_id in range(1, count + 1):
            if component_id == main_id:
                continue
            minimum_distance = float(
                np.min(distances_to_main[components == component_id])
            )
            if minimum_distance <= threshold_mm:
                keep_ids.append(component_id)

    cleaned_crop = np.isin(components, keep_ids)
    cleaned = np.zeros_like(mask, dtype=bool)
    cleaned[slices] = cleaned_crop
    return cleaned, int(count), int(len(keep_ids))


def pad_bbox(
    start_xyz: list[int],
    end_xyz: list[int],
    image_size_xyz: list[int],
    padding: int,
) -> tuple[list[int], list[int], dict[str, int]]:
    padded_start = [max(0, start_xyz[axis] - padding) for axis in range(3)]
    padded_end = [
        min(image_size_xyz[axis], end_xyz[axis] + padding) for axis in range(3)
    ]
    actual = {
        "x_min": start_xyz[0] - padded_start[0],
        "x_max": padded_end[0] - end_xyz[0],
        "y_min": start_xyz[1] - padded_start[1],
        "y_max": padded_end[1] - end_xyz[1],
        "z_min": start_xyz[2] - padded_start[2],
        "z_max": padded_end[2] - end_xyz[2],
    }
    return padded_start, padded_end, {
        key: int(value) for key, value in actual.items()
    }


def process_case(
    case_id: str,
    image_path: Path,
    raw_label_path: Path,
    selected_label_path: Path,
    roi_images_directory: Path,
    threshold_mm: float,
    padding_voxels: int,
    geometry_tolerance: float,
    roi_write_workers: int,
    compression_level: int,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    image = sitk.ReadImage(str(image_path))
    raw_label, raw = read_integer_label(raw_label_path)
    errors = geometry_errors(image, raw_label, geometry_tolerance)
    if errors:
        raise RuntimeError(f"{case_id}: global prediction geometry errors: {errors}")

    present_values = {int(value) for value in np.unique(raw)}
    invalid_values = sorted(present_values - set(range(33)))
    if invalid_values:
        raise ValueError(f"{case_id}: global labels outside 0-32: {invalid_values}")

    spacing_zyx = np.asarray(image.GetSpacing(), dtype=np.float64)[::-1]
    selected = np.zeros(raw.shape, dtype=np.uint8)
    cleanup_records: list[dict[str, Any]] = []
    object_slices = ndimage.find_objects(raw, max_label=32)
    for tooth_class, source_slices in enumerate(object_slices, start=1):
        if source_slices is None:
            continue
        raw_crop = raw[source_slices]
        raw_mask = raw_crop == tooth_class
        cleaned_mask, component_count, retained_count = clean_one_class(
            raw_mask,
            spacing_zyx,
            threshold_mm,
        )
        selected_crop = selected[source_slices]
        selected_crop[cleaned_mask] = tooth_class
        cleaned_coordinates = np.argwhere(cleaned_mask)
        if cleaned_coordinates.size == 0:
            raise RuntimeError(
                f"{case_id}: class {tooth_class} became empty after cleanup"
            )
        offset_zyx = np.asarray(
            [int(axis_slice.start or 0) for axis_slice in source_slices],
            dtype=np.int64,
        )
        cleaned_start_zyx = cleaned_coordinates.min(axis=0) + offset_zyx
        cleaned_end_zyx = cleaned_coordinates.max(axis=0) + 1 + offset_zyx
        cleanup_records.append(
            {
                "tooth_class": tooth_class,
                "raw_voxels": int(np.count_nonzero(raw_mask)),
                "cleaned_voxels": int(np.count_nonzero(cleaned_mask)),
                "component_count": component_count,
                "retained_component_count": retained_count,
                "cleaned_bbox_start_xyz": cleaned_start_zyx[::-1].tolist(),
                "cleaned_bbox_end_xyz_exclusive": (
                    cleaned_end_zyx[::-1].tolist()
                ),
            }
        )

    write_label(selected, raw_label, selected_label_path, compression_level)
    image_size_xyz = [int(value) for value in image.GetSize()]
    roi_records: list[dict[str, Any]] = []
    write_jobs: list[tuple[sitk.Image, Path]] = []
    for cleanup in cleanup_records:
        tooth_class = int(cleanup["tooth_class"])
        clean_start = cleanup["cleaned_bbox_start_xyz"]
        clean_end = cleanup["cleaned_bbox_end_xyz_exclusive"]
        roi_start, roi_end, actual_padding = pad_bbox(
            clean_start,
            clean_end,
            image_size_xyz,
            padding_voxels,
        )
        roi_size = [roi_end[axis] - roi_start[axis] for axis in range(3)]
        roi_case_id = f"{case_id}__tooth_{tooth_class:02d}"
        roi_filename = f"{roi_case_id}_0000.nii.gz"
        roi_image = sitk.RegionOfInterest(image, size=roi_size, index=roi_start)
        write_jobs.append((roi_image, roi_images_directory / roi_filename))
        roi_records.append(
            {
                "case_id": case_id,
                "tooth_class": tooth_class,
                "roi_case_id": roi_case_id,
                "roi_filename": roi_filename,
                "source_threshold_mm": float(threshold_mm),
                "raw_voxels": cleanup["raw_voxels"],
                "cleaned_voxels": cleanup["cleaned_voxels"],
                "deleted_voxels": (
                    cleanup["raw_voxels"] - cleanup["cleaned_voxels"]
                ),
                "cleaned_bbox_start_xyz": clean_start,
                "cleaned_bbox_end_xyz_exclusive": clean_end,
                "roi_bbox_start_xyz": roi_start,
                "roi_bbox_end_xyz_exclusive": roi_end,
                "roi_size_xyz": roi_size,
                "original_size_xyz": image_size_xyz,
                "spacing_xyz": [float(value) for value in image.GetSpacing()],
                "direction": [float(value) for value in image.GetDirection()],
                "original_origin_xyz": [
                    float(value) for value in image.GetOrigin()
                ],
                "roi_origin_xyz": [float(value) for value in roi_image.GetOrigin()],
                "actual_padding_voxels": actual_padding,
            }
        )

    with ThreadPoolExecutor(max_workers=roi_write_workers) as executor:
        futures = [
            executor.submit(write_image, image_to_write, path, compression_level)
            for image_to_write, path in write_jobs
        ]
        for future in futures:
            future.result()

    case_record = {
        "case_id": case_id,
        "num_rois": len(roi_records),
        "present_tooth_classes": [
            int(record["tooth_class"]) for record in cleanup_records
        ],
        "cleanup": cleanup_records,
    }
    return roi_records, case_record


def main() -> None:
    args = parse_args()
    if args.fragment_distance_mm < 0:
        raise ValueError("--fragment-distance-mm must be non-negative")
    if args.padding_voxels < 0:
        raise ValueError("--padding-voxels must be non-negative")
    if args.roi_write_workers < 1:
        raise ValueError("--roi-write-workers must be at least 1")
    if not 0 <= args.compression_level <= 9:
        raise ValueError("--compression-level must be between 0 and 9")
    if args.geometry_tolerance < 0:
        raise ValueError("--geometry-tolerance must be non-negative")

    cases = discover_input_images(args.input_images)
    training_directory, trainer, plans = discover_training_directory(
        args.model_root,
        args.configuration,
        args.trainer,
        args.plans,
    )
    folds = discover_folds(training_directory, args.folds, args.checkpoint)
    dataset_json_path = find_dataset_json(training_directory, args.model_root)
    validate_global_dataset(dataset_json_path)
    prepare_output_root(
        args.output_root,
        args.overwrite,
        protected_paths=(args.input_images, args.model_root),
    )

    raw_labels_directory = args.output_root / "global_raw"
    localization_directory = args.output_root / "localization"
    roi_images_directory = args.output_root / "roi_images"
    for directory in (
        raw_labels_directory,
        localization_directory,
        roi_images_directory,
    ):
        directory.mkdir(parents=True, exist_ok=True)

    tta_enabled = not args.disable_tta
    command = build_predict_command(
        args.input_images,
        raw_labels_directory,
        args.dataset_id,
        args.configuration,
        trainer,
        plans,
        folds,
        args.checkpoint,
        args.device,
        tta_enabled,
    )
    environment = os.environ.copy()
    environment["nnUNet_results"] = str(args.model_root.parent)
    print("Global model command:", " ".join(command), flush=True)
    subprocess.run(command, check=True, env=environment)

    predictions = {
        strip_nii_suffix(path.name): path
        for path in sorted(raw_labels_directory.glob("*.nii.gz"))
    }
    missing = sorted(set(cases) - set(predictions))
    extra = sorted(set(predictions) - set(cases))
    if missing or extra:
        raise RuntimeError(
            "Global output pairing failed. "
            f"Missing={missing[:20]}, extra={extra[:20]}"
        )

    all_roi_records: list[dict[str, Any]] = []
    case_records: list[dict[str, Any]] = []
    for index, (case_id, image_path) in enumerate(sorted(cases.items()), start=1):
        print(f"[{index}/{len(cases)}] Cleaning and cropping {case_id}", flush=True)
        roi_records, case_record = process_case(
            case_id,
            image_path,
            predictions[case_id],
            localization_directory / f"{case_id}.nii.gz",
            roi_images_directory,
            args.fragment_distance_mm,
            args.padding_voxels,
            args.geometry_tolerance,
            args.roi_write_workers,
            args.compression_level,
        )
        all_roi_records.extend(roi_records)
        case_records.append(case_record)

    if not all_roi_records:
        raise RuntimeError("Global model produced no tooth ROI in the input set")

    manifest = {
        "stage": "global_tooth_and_roi",
        "num_cases": len(cases),
        "num_rois": len(all_roi_records),
        "input_images": str(args.input_images),
        "global_raw": str(raw_labels_directory),
        "localization": str(localization_directory),
        "roi_images": str(roi_images_directory),
        "fragment_distance_mm": args.fragment_distance_mm,
        "padding_voxels": args.padding_voxels,
        "processing_policy": {
            "connectivity": 26,
            "main_component": "largest_voxel_count",
            "secondary_component_rule": (
                "minimum_distance_to_main_mm <= fragment_distance_mm"
            ),
            "distance_backend": "scipy_edt",
            "volume_filtering": False,
            "tooth_reassignment": False,
        },
        "model": {
            "dataset_id": args.dataset_id,
            "configuration": args.configuration,
            "trainer": trainer,
            "plans": plans,
            "folds": folds,
            "checkpoint": args.checkpoint,
            "training_directory": str(training_directory),
            "dataset_json": str(dataset_json_path),
            "tta_enabled": tta_enabled,
            "command": command,
        },
        "case_records": case_records,
        "roi_records": all_roi_records,
    }
    save_json(args.output_root / "roi_records.json", manifest)
    save_json(args.output_root / "manifest.json", manifest)

    print("Global tooth and ROI stage completed.")
    print(f"Cases: {len(cases)}")
    print(f"ROIs: {len(all_roi_records)}")
    print(f"TTA enabled: {tta_enabled}")
    print(f"Output: {args.output_root}")


if __name__ == "__main__":
    main()
