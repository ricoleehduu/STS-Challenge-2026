#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np
import SimpleITK as sitk

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from data_preparation import build_dataset602  # noqa: E402
from data_preparation import build_dataset603  # noqa: E402
from data_preparation import validate_dataset  # noqa: E402


def run_main(main: object, *arguments: object) -> None:
    previous = sys.argv
    sys.argv = [getattr(main, "__module__", "test"), *map(str, arguments)]
    try:
        main()  # type: ignore[operator]
    finally:
        sys.argv = previous


def write_case(root: Path, case_id: str, labels: np.ndarray) -> None:
    image_array = np.linspace(
        -1000,
        3000,
        labels.size,
        dtype=np.float32,
    ).reshape(labels.shape)
    image = sitk.GetImageFromArray(image_array)
    image.SetSpacing((0.6, 0.7, 0.8))
    image.SetOrigin((10.0, 20.0, 30.0))
    label = sitk.GetImageFromArray(labels.astype(np.uint8, copy=False))
    label.CopyInformation(image)

    images_dir = root / "imagesTr"
    labels_dir = root / "labelsTr"
    images_dir.mkdir(parents=True, exist_ok=True)
    labels_dir.mkdir(parents=True, exist_ok=True)
    sitk.WriteImage(image, str(images_dir / f"{case_id}_0000.nii.gz"), True)
    sitk.WriteImage(label, str(labels_dir / f"{case_id}.nii.gz"), True)


class DataPreparationContractTest(unittest.TestCase):
    def test_dataset602_to_dataset603_contract(self) -> None:
        with tempfile.TemporaryDirectory(prefix="stsr_data_preparation_") as temp:
            root = Path(temp)
            source = root / "source"

            case_a = np.zeros((24, 24, 24), dtype=np.uint8)
            case_a[2:12, 2:12, 2:12] = 1
            case_a[5:9, 5:9, 5:9] = 33
            case_a[14:21, 14:21, 14:21] = 2
            write_case(source, "CaseA", case_a)

            case_b = np.zeros((24, 24, 24), dtype=np.uint8)
            case_b[2:10, 2:10, 2:10] = 1
            case_b[4:7, 4:7, 4:7] = 33
            case_b[12:22, 12:22, 12:22] = 2
            case_b[15:19, 15:19, 15:19] = 34
            write_case(source, "CaseB", case_b)

            dataset602 = root / "Dataset602"
            run_main(
                build_dataset602.main,
                "--input",
                source,
                "--output",
                dataset602,
            )
            run_main(
                validate_dataset.main,
                "--dataset",
                dataset602,
                "--contract",
                "dataset602",
            )

            dataset603 = root / "Dataset603"
            run_main(
                build_dataset603.main,
                "--input",
                source,
                "--output",
                dataset603,
                "--margin-voxels",
                3,
                "--min-pulp-voxels",
                50,
            )
            run_main(
                validate_dataset.main,
                "--dataset",
                dataset603,
                "--contract",
                "dataset603",
            )

            kept = json.loads(
                (dataset603 / "crop_info.json").read_text(encoding="utf-8")
            )
            removed = json.loads(
                (dataset603 / "removed_samples.json").read_text(encoding="utf-8")
            )
            self.assertEqual(len(kept), 2)
            self.assertEqual(len(removed), 1)
            self.assertEqual(removed[0]["pulp_voxels_checked"], 27)
            self.assertEqual(removed[0]["source_case_id"], "CaseB")
            self.assertEqual(removed[0]["tooth_label"], 1)
            self.assertTrue(
                all(record["pulp_voxels_checked"] == 64 for record in kept)
            )
            self.assertEqual(
                [
                    (record["source_case_id"], record["tooth_label"])
                    for record in kept
                ],
                [("CaseA", 1), ("CaseB", 2)],
            )
            self.assertEqual(
                sorted(path.name for path in (dataset603 / "labelsTr").glob("*.nii.gz")),
                ["ToothPulpROI_0001.nii.gz", "ToothPulpROI_0002.nii.gz"],
            )

    def test_orphan_pulp_is_rejected(self) -> None:
        labels = np.zeros((8, 8, 8), dtype=np.uint8)
        labels[2:4, 2:4, 2:4] = 33
        with self.assertRaisesRegex(ValueError, "no corresponding tooth"):
            build_dataset602.validate_source_contract("OrphanPulp", labels)

    def test_mapping_must_be_one_to_one_and_disjoint(self) -> None:
        with tempfile.TemporaryDirectory(prefix="stsr_mapping_") as temp:
            mapping_path = Path(temp) / "mapping.json"
            mapping_path.write_text('{"33": 1, "34": 1}', encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "one-to-one"):
                build_dataset603.load_mapping(mapping_path)

            mapping_path.write_text('{"1": 1}', encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "disjoint"):
                build_dataset603.load_mapping(mapping_path)


if __name__ == "__main__":
    unittest.main()
