#!/usr/bin/env python3
from __future__ import annotations

import sys
import unittest
from pathlib import Path

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from inference import global_tooth_and_roi  # noqa: E402
from inference import local_tooth_pulp  # noqa: E402
from inference import merge_to_full_volume  # noqa: E402
from inference import run_pipeline  # noqa: E402


def prediction_arguments() -> tuple[object, ...]:
    return (
        Path("inputs"),
        Path("outputs"),
        "602",
        "3d_lowres",
        "nnUNetTrainerNoDA",
        "nnUNetPlans",
        ["all"],
        "checkpoint_best.pth",
        "cuda",
    )


def pipeline_arguments() -> list[str]:
    return [
        "--input-images",
        "inputs",
        "--global-model-root",
        "models/Dataset602_STSRStage1",
        "--local-model-root",
        "models/Dataset603_ToothPulpROI_clean",
        "--output-root",
        "outputs",
    ]


class InferenceContractTest(unittest.TestCase):
    def test_pipeline_defaults(self) -> None:
        args = run_pipeline.parse_args(pipeline_arguments())
        self.assertFalse(args.disable_tta)
        self.assertEqual(args.global_dataset_id, "602")
        self.assertEqual(args.global_configuration, "3d_lowres")
        self.assertEqual(args.local_dataset_id, "603")
        self.assertEqual(args.local_configuration, "3d_fullres")
        self.assertEqual(args.fragment_distance_mm, 3.0)
        self.assertEqual(args.padding_voxels, 10)

    def test_pipeline_builds_global_and_local_commands(self) -> None:
        args = run_pipeline.parse_args(pipeline_arguments())
        global_command = run_pipeline.build_global_command(
            args,
            Path("run/global"),
            Path("inference/global_tooth_and_roi.py"),
        )
        local_command = run_pipeline.build_local_command(
            args,
            Path("run/global"),
            Path("run/local"),
            Path("inference/local_tooth_pulp.py"),
        )

        self.assertEqual(
            global_command[global_command.index("--model-root") + 1],
            str(args.global_model_root),
        )
        self.assertEqual(
            local_command[local_command.index("--model-root") + 1],
            str(args.local_model_root),
        )
        self.assertNotIn("--disable-tta", global_command)
        self.assertNotIn("--disable-tta", local_command)

        args.disable_tta = True
        self.assertIn(
            "--disable-tta",
            run_pipeline.build_global_command(
                args,
                Path("run/global"),
                Path("inference/global_tooth_and_roi.py"),
            ),
        )
        self.assertIn(
            "--disable-tta",
            run_pipeline.build_local_command(
                args,
                Path("run/global"),
                Path("run/local"),
                Path("inference/local_tooth_pulp.py"),
            ),
        )

    def test_prediction_commands_enable_tta_by_default(self) -> None:
        global_tta = global_tooth_and_roi.build_predict_command(
            *prediction_arguments(),
            True,
        )
        global_no_tta = global_tooth_and_roi.build_predict_command(
            *prediction_arguments(),
            False,
        )
        local_tta = local_tooth_pulp.build_predict_command(
            *prediction_arguments(),
            True,
        )
        local_no_tta = local_tooth_pulp.build_predict_command(
            *prediction_arguments(),
            False,
        )

        self.assertNotIn("--disable_tta", global_tta)
        self.assertIn("--disable_tta", global_no_tta)
        self.assertNotIn("--disable_tta", local_tta)
        self.assertIn("--disable_tta", local_no_tta)

    def test_fragment_distance_rule(self) -> None:
        mask = np.zeros((16, 16, 16), dtype=bool)
        mask[2:4, 2:4, 2:4] = True
        mask[2:4, 2:4, 6:8] = True
        mask[12:14, 12:14, 12:14] = True
        cleaned, component_count, retained_count = (
            global_tooth_and_roi.clean_one_class(
                mask,
                np.ones(3, dtype=np.float64),
                3.0,
            )
        )
        self.assertEqual(component_count, 3)
        self.assertEqual(retained_count, 2)
        self.assertTrue(np.all(cleaned[2:4, 2:4, 2:4]))
        self.assertTrue(np.all(cleaned[2:4, 2:4, 6:8]))
        self.assertFalse(np.any(cleaned[12:14, 12:14, 12:14]))

    def test_local_label_encoding(self) -> None:
        raw = np.asarray([[[0, 1, 2]]], dtype=np.uint8)
        encoded = merge_to_full_volume.encode_local_labels(raw, 4)
        np.testing.assert_array_equal(
            encoded,
            np.asarray([[[0, 4, 36]]], dtype=np.uint8),
        )

    def test_global_support_wins_conflict(self) -> None:
        output = np.asarray([[[2]]], dtype=np.uint8)
        rank = np.asarray([[[0]]], dtype=np.int8)
        encoded = np.asarray([[[33]]], dtype=np.uint8)
        support = np.asarray([[[True]]])
        written, conflicts, ties = merge_to_full_volume.merge_candidate(
            output,
            rank,
            encoded,
            support,
        )
        self.assertEqual((written, conflicts, ties), (1, 1, 0))
        self.assertEqual(int(output[0, 0, 0]), 33)
        self.assertEqual(int(rank[0, 0, 0]), 1)

    def test_equal_rank_retains_existing_voxel(self) -> None:
        output = np.asarray([[[1]]], dtype=np.uint8)
        rank = np.asarray([[[1]]], dtype=np.int8)
        encoded = np.asarray([[[34]]], dtype=np.uint8)
        support = np.asarray([[[True]]])
        written, conflicts, ties = merge_to_full_volume.merge_candidate(
            output,
            rank,
            encoded,
            support,
        )
        self.assertEqual((written, conflicts, ties), (0, 1, 1))
        self.assertEqual(int(output[0, 0, 0]), 1)


if __name__ == "__main__":
    unittest.main()
