#!/usr/bin/env python3
"""Launch or resume an SSL trainer (phase B/C) run, checkpoint-safe.

Resumes automatically from checkpoint_latest.pth (falling back to
checkpoint_best.pth) if one exists for the given dataset/trainer/fold,
otherwise starts fresh. Meant to survive GPU-instance restarts (disk
resizes, hyperparameter/env-var changes) without losing training progress
or needing a one-off script each time.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import torch
from nnunetv2.paths import nnUNet_preprocessed, nnUNet_results, nnUNet_raw  # noqa: F401  (env-var validation)

from stsr2026.training.ssl_trainer import nnUNetTrainer_STSR_PhaseB, nnUNetTrainer_STSR_PhaseC


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", choices=["B", "C"], required=True)
    parser.add_argument("--dataset-name", default="Dataset002_STSR")
    parser.add_argument("--fold", type=int, default=0)
    parser.add_argument("--unlabeled-image-dir", type=Path, required=True)
    parser.add_argument(
        "--unlabeled-case-list",
        type=Path,
        required=True,
        help="text file, one case_id per line (without extension)",
    )
    parser.add_argument("--unlabeled-cache-dir", type=Path, required=True)
    parser.add_argument("--unlabeled-num-workers", type=int, default=4)
    args = parser.parse_args()

    trainer_cls = nnUNetTrainer_STSR_PhaseB if args.phase == "B" else nnUNetTrainer_STSR_PhaseC
    plans = json.load(open(f"{nnUNet_preprocessed}/{args.dataset_name}/nnUNetPlans.json"))
    dataset_json = json.load(open(f"{nnUNet_preprocessed}/{args.dataset_name}/dataset.json"))

    trainer_dir_name = f"{trainer_cls.__name__}__nnUNetPlans__3d_fullres"
    ckpt = (
        Path(nnUNet_results)
        / args.dataset_name
        / trainer_dir_name
        / f"fold_{args.fold}"
        / "checkpoint_latest.pth"
    )
    if not ckpt.exists():
        ckpt = ckpt.with_name("checkpoint_best.pth")
    resuming = ckpt.exists()
    plans["continue_training"] = resuming

    trainer = trainer_cls(
        plans=plans,
        configuration="3d_fullres",
        fold=args.fold,
        dataset_json=dataset_json,
        device=torch.device("cuda"),
    )
    trainer.initialize()

    if resuming:
        print(f"resuming from: {ckpt}")
        trainer.load_checkpoint(str(ckpt))
        print(f"resumed at epoch {trainer.current_epoch}/{trainer.num_epochs}")
    else:
        print("no checkpoint found, starting fresh")

    case_ids = [line.strip() for line in args.unlabeled_case_list.read_text().splitlines() if line.strip()]
    unlabeled_paths = [args.unlabeled_image_dir / f"{c}.nii.gz" for c in case_ids]

    loader = trainer.build_unlabeled_dataloader(
        unlabeled_paths,
        cache_dir=args.unlabeled_cache_dir,
        batch_size=trainer.configuration_manager.batch_size,
        num_workers=args.unlabeled_num_workers,
    )
    trainer.set_unlabeled_dataloader(loader)
    print(f"unlabeled dataloader attached (phase {args.phase}), {len(loader.dataset)} cases")

    print(f"=== {'resuming' if resuming else 'starting'} phase {args.phase} training ===")
    trainer.run_training()
    print(f"=== phase {args.phase} training run completed ===")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
