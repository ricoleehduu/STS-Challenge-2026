#!/usr/bin/env python
"""Report what kind of tooth-numbering errors survive the shipped post-processing chain.

Decides whether the deep-research report's section 15 arch-position DP decoding
is worth building with the remaining sprint time: it only pays if the residual
errors are actually numbering errors (ARCH_NEIGHBOR / CONTRALATERAL) rather than
detection or boundary errors (MISSING / PARTIAL), which a numbering fix cannot
touch.

    python scripts/diagnose_tooth_instance_errors.py \
        /path/to/day1_taskA/taskG_teeth/predictions \
        /path/to/holdout_labels_6
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import nibabel as nib
import numpy as np

from stsr2026.evaluation.tooth_error_diagnosis import (
    CaseDiagnosis,
    ToothError,
    diagnose_case,
    summarize,
)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("predictions_dir", type=Path)
    parser.add_argument("ground_truth_dir", type=Path)
    parser.add_argument("--json-out", type=Path, default=None)
    args = parser.parse_args()

    diagnoses: dict[str, CaseDiagnosis] = {}
    for gt_path in sorted(args.ground_truth_dir.glob("*.nii.gz")):
        case_id = gt_path.name.replace(".nii.gz", "")
        candidates = [
            args.predictions_dir / f"{case_id}.nii.gz",
            args.predictions_dir / f"{case_id}_mask.nii.gz",
        ]
        pred_path = next((p for p in candidates if p.exists()), None)
        if pred_path is None:
            print(f"  [skip] no prediction for {case_id}")
            continue

        pred = np.asarray(nib.load(str(pred_path)).dataobj).astype(np.uint8)
        gt = np.asarray(nib.load(str(gt_path)).dataobj).astype(np.uint8)
        diagnosis = diagnose_case(pred, gt)
        diagnoses[case_id] = diagnosis

        counts = summarize({case_id: diagnosis})
        n_teeth = len(diagnosis.findings)
        print(f"\n=== {case_id}  ({n_teeth} GT teeth) ===")
        for key in ToothError:
            if counts[key.value]:
                print(f"    {key.value:<24s} {counts[key.value]:>3d}")
        if diagnosis.spurious_classes:
            print(f"    SPURIOUS (extra labels)  {len(diagnosis.spurious_classes):>3d}  "
                  f"{diagnosis.spurious_classes}")
        if diagnosis.split_classes:
            print(f"    SPLIT                    {len(diagnosis.split_classes):>3d}  "
                  f"{diagnosis.split_classes}")
        for f in diagnosis.findings:
            if f.error is not ToothError.CORRECT:
                print(f"      tooth {f.gt_class:>2d}: {f.error.value:<24s} "
                      f"iou={f.iou_same_class:.3f} claimed_by={f.claimed_by} "
                      f"({f.claimed_fraction:.0%})")

    total = summarize(diagnoses)
    n_gt_teeth = sum(len(d.findings) for d in diagnoses.values())
    print("\n" + "=" * 64)
    print(f"AGGREGATE over {len(diagnoses)} cases, {n_gt_teeth} GT tooth instances")
    for key in ToothError:
        n = total[key.value]
        print(f"  {key.value:<24s} {n:>4d}  {n / max(n_gt_teeth, 1):>6.1%}")
    print(f"  {'SPURIOUS (extra labels)':<24s} {total['SPURIOUS']:>4d}")
    print(f"  {'SPLIT (multi-component)':<24s} {total['SPLIT']:>4d}")

    fixable = total[ToothError.MISLABEL_ARCH_NEIGHBOR.value] + \
        total[ToothError.MISLABEL_CONTRALATERAL.value] + \
        total[ToothError.MISLABEL_OTHER.value]
    print(f"\n  numbering errors (any MISLABEL): {fixable} "
          f"({fixable / max(n_gt_teeth, 1):.1%}) -- the only part a sequence/DP fix can address")
    print(f"  detection errors (MISSING+PARTIAL): "
          f"{total[ToothError.MISSING.value] + total[ToothError.PARTIAL.value]} "
          f"-- a numbering fix cannot help these")

    if args.json_out is not None:
        payload = {
            case_id: {
                "findings": [
                    {"gt_class": f.gt_class, "error": f.error.value,
                     "iou": f.iou_same_class, "claimed_by": f.claimed_by,
                     "claimed_fraction": f.claimed_fraction}
                    for f in d.findings
                ],
                "spurious_classes": d.spurious_classes,
                "split_classes": d.split_classes,
            }
            for case_id, d in diagnoses.items()
        }
        args.json_out.write_text(json.dumps(payload, indent=2))
        print(f"\nwrote {args.json_out}")


if __name__ == "__main__":
    main()
