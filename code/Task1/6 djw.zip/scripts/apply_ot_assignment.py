"""Apply ``ot_instance_assignment.assign_instances_to_fdi_slots`` to an
existing directory of prediction NIfTIs -- the OT-based successor to the
deprecated ``scripts/apply_hungarian_assignment.py`` (see
``docs/experiment-log.md``'s ``Day1-TaskE-Hungarian-default`` entry for why
that module was not adopted, and ``docs/research/07-ot-assignment-design.md``
/ ``src/stsr2026/inference/ot_instance_assignment.py``'s module docstring
for how this module's design addresses the two diagnosed root causes).

Like its predecessor, this script is deliberately standalone (not wired
into ``postprocessing_pipeline.py``) -- this is an exploratory real-data
validation run to be applied to an existing baseline's predictions and
re-scored with the official evaluator, not a production integration.

Usage::

    python scripts/apply_ot_assignment.py \\
        --predictions-dir /path/to/day1_taskA/taskD_gtfree_t5000/predictions \\
        --output-dir /path/to/day1_taskA/taskF_ot/predictions \\
        --order-weight 0.6 --label-mismatch-cost 0.4 --dustbin-cost 0.5 \\
        --distance-scale-quantile 0.9 --sinkhorn-reg 0.05 --sinkhorn-max-iter 200 \\
        --decisions-json /path/to/day1_taskA/taskF_ot/decisions.json

Then re-score with the existing evaluation script, e.g.::

    python scripts/evaluate_checkpoint.py \\
        --images /path/to/holdout_images_raw \\
        --labels .../labelsTr \\
        --output-dir /path/to/day1_taskA/taskF_ot \\
        --skip-inference
"""
from __future__ import annotations

import argparse
import json
from dataclasses import asdict
from pathlib import Path

import nibabel as nib
import numpy as np

from stsr2026.inference.ot_instance_assignment import (
    DEFAULT_DISTANCE_SCALE_QUANTILE,
    DEFAULT_DUSTBIN_COST,
    DEFAULT_LABEL_MISMATCH_COST,
    DEFAULT_ORDER_WEIGHT,
    DEFAULT_SINKHORN_MAX_ITER,
    DEFAULT_SINKHORN_REG,
    MIN_COMPONENT_VOXELS,
    assign_instances_to_fdi_slots,
)


def _serialize_transport_plans(transport_plans: dict) -> dict:
    return {f"{category}_{quadrant}": plan.tolist() for (category, quadrant), plan in transport_plans.items()}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--predictions-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--order-weight", type=float, default=DEFAULT_ORDER_WEIGHT)
    parser.add_argument("--label-mismatch-cost", type=float, default=DEFAULT_LABEL_MISMATCH_COST)
    parser.add_argument("--dustbin-cost", type=float, default=DEFAULT_DUSTBIN_COST)
    parser.add_argument("--distance-scale-quantile", type=float, default=DEFAULT_DISTANCE_SCALE_QUANTILE)
    parser.add_argument("--sinkhorn-reg", type=float, default=DEFAULT_SINKHORN_REG)
    parser.add_argument("--sinkhorn-max-iter", type=int, default=DEFAULT_SINKHORN_MAX_ITER)
    parser.add_argument("--min-component-voxels", type=int, default=MIN_COMPONENT_VOXELS)
    parser.add_argument("--decisions-json", type=Path, default=None)
    parser.add_argument(
        "--include-transport-plans",
        action="store_true",
        help="Include the full per-case, per-group augmented transport plans in the decisions JSON "
        "(large; off by default).",
    )
    args = parser.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)

    all_decisions: dict[str, dict] = {}
    case_files = sorted(args.predictions_dir.glob("*.nii.gz"))
    if not case_files:
        raise SystemExit(f"no .nii.gz files found under {args.predictions_dir}")

    for case_path in case_files:
        case_id = case_path.name.removesuffix(".nii.gz")
        image = nib.load(str(case_path))
        labels = np.asanyarray(image.dataobj)

        result = assign_instances_to_fdi_slots(
            labels,
            image.affine,
            order_weight=args.order_weight,
            label_mismatch_cost=args.label_mismatch_cost,
            dustbin_cost=args.dustbin_cost,
            distance_scale_quantile=args.distance_scale_quantile,
            sinkhorn_reg=args.sinkhorn_reg,
            sinkhorn_max_iter=args.sinkhorn_max_iter,
            min_component_voxels=args.min_component_voxels,
        )

        output_path = args.output_dir / case_path.name
        changed = not np.array_equal(result.output_volume, labels)
        nib.save(
            nib.Nifti1Image(result.output_volume.astype(image.get_data_dtype()), image.affine, image.header.copy()),
            str(output_path),
        )

        case_record = {
            "changed_any_voxel": changed,
            "num_matched": len(result.matched),
            "num_relabeled": sum(1 for m in result.matched if m.changed),
            "num_dustbin": len(result.dustbin),
            "num_empty_slots": len(result.empty_slots),
            "relabels": [
                {
                    "category": m.category,
                    "quadrant_index": m.quadrant_index,
                    "original_label": m.original_label,
                    "component_ids": list(m.component_ids),
                    "voxel_count": m.voxel_count,
                    "new_label": int(m.new_label),
                    "total_cost": m.total_cost,
                    "order_cost": m.order_cost,
                    "label_mismatch_cost": m.label_mismatch_cost,
                    "transport_mass": m.transport_mass,
                }
                for m in result.matched
                if m.changed
            ],
            "dustbin": [asdict(d) for d in result.dustbin],
        }
        if args.include_transport_plans:
            case_record["transport_plans"] = _serialize_transport_plans(result.transport_plans)
        all_decisions[case_id] = case_record
        print(
            f"{case_id}: {case_record['num_relabeled']} relabeled / {case_record['num_matched']} matched, "
            f"{case_record['num_dustbin']} dustbin, "
            f"{case_record['num_empty_slots']} empty slots, changed_any_voxel={changed}"
        )

    if args.decisions_json:
        args.decisions_json.parent.mkdir(parents=True, exist_ok=True)
        args.decisions_json.write_text(json.dumps(all_decisions, indent=2))
        print(f"wrote decisions to {args.decisions_json}")


if __name__ == "__main__":
    main()
