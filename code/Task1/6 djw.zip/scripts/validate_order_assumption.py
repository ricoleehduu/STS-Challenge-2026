"""Real-data check of the core anatomical hypothesis
``hungarian_instance_assignment.py``'s order-cost term relies on: does
distance-from-midline increase monotonically with FDI position-in-quadrant
(1st = central incisor nearest the midline .. 8th = third molar)?

This is diagnostic-only, using real ground-truth FDI labels purely to
VALIDATE the hypothesis -- it is not part of the GT-free production
function and must never be imported by it. See
``hungarian_instance_assignment.py``'s module docstring, which promises
this check was run before the module is trusted for anything beyond its
own synthetic test suite.

Usage::

    python scripts/validate_order_assumption.py \
        --labels-dir /path/to/nnUNet_data/nnUNet_raw/Dataset002_STSR/labelsTr \
        --split-json configs/data/holdout_split.json --split-key val
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import nibabel as nib
import numpy as np
from scipy.stats import spearmanr

from stsr2026.training.pseudo_label import (
    TOOTH_CLASS_MAX,
    TOOTH_CLASS_MIN,
    canal_class_to_fdi,
    tooth_class_to_fdi,
)


def _world_x(indices: np.ndarray, affine: np.ndarray) -> np.ndarray:
    return indices @ affine[0, :3] + affine[0, 3]


def _quadrant_and_position(fdi: int) -> tuple[int, int]:
    return fdi // 10, fdi % 10


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--labels-dir", type=Path, required=True)
    parser.add_argument("--split-json", type=Path, default=None)
    parser.add_argument("--split-key", type=str, default="val")
    parser.add_argument("--case-ids", nargs="+", default=None)
    args = parser.parse_args()

    if args.case_ids:
        case_ids = args.case_ids
    elif args.split_json:
        split = json.loads(args.split_json.read_text())
        case_ids = split[args.split_key]
    else:
        case_ids = [p.name.removesuffix(".nii.gz") for p in sorted(args.labels_dir.glob("*.nii.gz"))]

    # (quadrant, category) -> list of (position_in_quadrant, distance_from_midline)
    records: dict[tuple[int, str], list[tuple[int, float]]] = {}
    per_case_correlation: list[dict] = []

    for case_id in case_ids:
        label_path = args.labels_dir / f"{case_id}.nii.gz"
        if not label_path.is_file():
            print(f"SKIP {case_id}: {label_path} not found")
            continue
        image = nib.load(str(label_path))
        volume = np.asanyarray(image.dataobj)
        affine = image.affine

        tooth_indices = np.argwhere((volume >= TOOTH_CLASS_MIN) & (volume <= TOOTH_CLASS_MAX))
        if tooth_indices.size == 0:
            print(f"SKIP {case_id}: no tooth voxels")
            continue
        midline_x = float(np.median(_world_x(tooth_indices, affine)))

        case_points: list[tuple[int, int, float]] = []  # (quadrant, position, distance)
        for class_id in range(1, 65):
            if class_id <= TOOTH_CLASS_MAX:
                fdi = tooth_class_to_fdi(class_id)
                category = "tooth"
            else:
                fdi = canal_class_to_fdi(class_id)
                category = "canal"
            mask = volume == class_id
            if not np.any(mask):
                continue
            quadrant, position = _quadrant_and_position(fdi)
            indices = np.argwhere(mask)
            centroid_x = float(np.mean(_world_x(indices, affine)))
            distance = abs(centroid_x - midline_x)
            key = (quadrant, category)
            records.setdefault(key, []).append((position, distance))
            case_points.append((quadrant, position, distance))

        # Per-case, per-quadrant Spearman correlation (position vs distance)
        by_quadrant: dict[int, list[tuple[int, float]]] = {}
        for quadrant, position, distance in case_points:
            by_quadrant.setdefault(quadrant, []).append((position, distance))
        for quadrant, pts in sorted(by_quadrant.items()):
            if len(pts) < 3:
                continue
            positions, distances = zip(*pts)
            rho, _ = spearmanr(positions, distances)
            per_case_correlation.append(
                {"case_id": case_id, "quadrant": quadrant, "n": len(pts), "spearman_rho": rho}
            )

    print("\n=== Per (quadrant, category) pooled Spearman correlation (position_in_quadrant vs distance_from_midline) ===")
    for (quadrant, category), points in sorted(records.items()):
        if len(points) < 3:
            print(f"quadrant={quadrant} category={category}: n={len(points)} (too few for correlation)")
            continue
        positions, distances = zip(*points)
        rho, pval = spearmanr(positions, distances)
        print(f"quadrant={quadrant} category={category}: n={len(points)} spearman_rho={rho:.3f} p={pval:.4f}")

    print("\n=== Per-case, per-quadrant Spearman correlation (diagnostic detail) ===")
    for record in per_case_correlation:
        flag = "" if record["spearman_rho"] > 0.5 else "  <-- WEAK/NEGATIVE"
        print(
            f"{record['case_id']} quadrant={record['quadrant']} n={record['n']} "
            f"rho={record['spearman_rho']:.3f}{flag}"
        )

    overall_rhos = [r["spearman_rho"] for r in per_case_correlation if r["n"] >= 3]
    if overall_rhos:
        print(f"\nOverall: {len(overall_rhos)} (case, quadrant) groups, "
              f"mean rho={np.mean(overall_rhos):.3f}, median rho={np.median(overall_rhos):.3f}, "
              f"fraction with rho > 0.5: {np.mean([r > 0.5 for r in overall_rhos]):.2f}")


if __name__ == "__main__":
    main()
