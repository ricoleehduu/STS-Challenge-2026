#!/usr/bin/env python3
"""Apply clean_or_relabel_false_positive_labels to a directory of
predictions -- plan.md D7, GT-free large-false-positive relabel follow-up to
``scripts/clean_false_positive_labels.py``.

Unlike ``clean_false_positive_labels.py``, this reuses the same
GT-absent-label screening (still needs ``--gt-dir`` to decide WHICH
components are false-positive candidates -- see
``clean_or_relabel_false_positive_labels``'s docstring for why this part
still needs ground truth and what that means for real deployment), but for
components at or above ``--volume-threshold`` it tries a GT-free
neighbour-based relabel before falling back to clearing.

Mirrors ``scripts/clean_false_positive_labels.py``'s CLI shape.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import nibabel as nib
import numpy as np

from stsr2026.data.audit import find_niftis, nifti_case_id
from stsr2026.inference.false_positive_cleanup import clean_or_relabel_false_positive_labels


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--pred-dir", type=Path, required=True)
    parser.add_argument("--gt-dir", type=Path, required=True)
    parser.add_argument("--cases", nargs="+", default=None)
    parser.add_argument("--volume-threshold", type=int, required=True)
    parser.add_argument("--dilation-voxels", type=int, default=2)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--report-json", type=Path, required=True)
    args = parser.parse_args()

    pred_files = {nifti_case_id(p): p for p in find_niftis(args.pred_dir)}
    gt_files = {nifti_case_id(p): p for p in find_niftis(args.gt_dir)}
    case_ids = sorted(args.cases) if args.cases else sorted(pred_files)

    missing = [c for c in case_ids if c not in pred_files or c not in gt_files]
    if missing:
        parser.error(f"case(s) missing a prediction or GT file: {missing}")

    all_records: list[dict] = []
    args.output_dir.mkdir(parents=True, exist_ok=True)
    for case_id in case_ids:
        pred_path = pred_files[case_id]
        gt_path = gt_files[case_id]
        pred_img = nib.load(str(pred_path))
        gt_img = nib.load(str(gt_path))
        pred = np.asanyarray(pred_img.dataobj).astype(np.int64)
        gt = np.asanyarray(gt_img.dataobj).astype(np.int64)
        gt_labels = {int(label) for label in np.unique(gt) if label > 0}

        output, records = clean_or_relabel_false_positive_labels(
            pred, gt_labels, args.volume_threshold, dilation_voxels=args.dilation_voxels
        )
        for record in records:
            all_records.append(
                {
                    "case": case_id,
                    "label": record.label,
                    "component_id": record.component_id,
                    "voxel_count": record.voxel_count,
                    "action": record.action,
                    "new_label": record.new_label,
                }
            )

        out_path = args.output_dir / pred_path.name
        out_dtype = pred_img.get_data_dtype()
        nib.save(
            nib.Nifti1Image(output.astype(out_dtype), pred_img.affine, pred_img.header.copy()),
            str(out_path),
        )
        print(out_path)

    action_counts: dict[str, int] = {}
    for record in all_records:
        action_counts[record["action"]] = action_counts.get(record["action"], 0) + 1

    summary = {
        "num_cases": len(case_ids),
        "volume_threshold": args.volume_threshold,
        "dilation_voxels": args.dilation_voxels,
        "total_components": len(all_records),
        "action_counts": action_counts,
        "relabeled_records": [r for r in all_records if r["action"] == "relabeled_to_neighbor"],
    }
    args.report_json.parent.mkdir(parents=True, exist_ok=True)
    args.report_json.write_text(json.dumps({"summary": summary, "records": all_records}, indent=2))
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
