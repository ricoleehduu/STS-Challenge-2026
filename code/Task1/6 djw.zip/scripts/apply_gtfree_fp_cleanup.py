#!/usr/bin/env python3
"""Apply the GT-FREE false-positive cleanup/relabel to a directory of
prediction NIfTIs -- the production-shippable replacement for
``scripts/clean_or_relabel_false_positive_labels.py`` (which requires
``--gt-dir`` and is therefore a no-op at real Docker inference time, see
``src/stsr2026/inference/postprocessing_pipeline.py``'s module docstring and
``docs/research/08-gtfree-fp-cleanup-design.md``).

Calls ``clean_or_relabel_false_positive_labels(..., gt_labels=None,
affine=...)``, which internally derives its own candidate set via
``identify_gtfree_fp_candidates`` (duplicate same-label components,
redundant same-quadrant coverage, spatial isolation, and an optional
OT-dustbin corroboration) instead of screening against ground truth.

Usage::

    python scripts/apply_gtfree_fp_cleanup.py \\
        --predictions-dir /path/to/day1_taskA/baseline_lrfix_v2/predictions \\
        --output-dir /path/to/day1_taskA/taskG_gtfree/predictions \\
        --volume-threshold 5000 --dilation-voxels 2 \\
        --decisions-json /path/to/day1_taskA/taskG_gtfree/decisions.json

Then re-score with the existing evaluation script, e.g.::

    python scripts/evaluate_checkpoint.py \\
        --images /path/to/holdout_images_raw \\
        --labels .../labelsTr \\
        --output-dir /path/to/day1_taskA/taskG_gtfree \\
        --skip-inference

Mirrors ``scripts/apply_ot_assignment.py``'s CLI shape/decisions-JSON
convention.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import nibabel as nib
import numpy as np

from stsr2026.inference.false_positive_cleanup import (
    DEFAULT_CLEAN_CLASSES,
    DEFAULT_ISOLATION_DISTANCE_MM,
    DEFAULT_MIN_COMPONENT_VOXELS,
    DEFAULT_OVERCOUNT_DILATION_VOXELS,
    DEFAULT_OVERCOUNT_OVERLAP_FRACTION,
    MIN_PEERS_FOR_ISOLATION_CHECK,
    GTFreeOptions,
    clean_or_relabel_false_positive_labels,
    identify_gtfree_fp_candidates,
)


def _prediction_paths(input_dir: Path) -> list[Path]:
    return sorted(path for path in input_dir.iterdir() if path.name.endswith((".nii", ".nii.gz")))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--predictions-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument(
        "--volume-threshold",
        type=int,
        default=5000,
        help="Same meaning as clean_or_relabel_false_positive_labels's own volume_threshold: a "
        "GT-free candidate below this many voxels is cleared; at/above it, a tooth-class candidate "
        "attempts a dilated-neighbour relabel first. Default matches postprocessing_pipeline.py's "
        "DEFAULT_SMALL_VOLUME_THRESHOLD (the value validated in the GT-informed taskD experiment).",
    )
    parser.add_argument("--dilation-voxels", type=int, default=2)
    parser.add_argument(
        "--clean-classes",
        choices=("teeth", "all"),
        default=DEFAULT_CLEAN_CLASSES,
        help="Which classes are eligible for candidacy at all. 'teeth' (default, real-data-validated): "
        "canal-range labels (33-64) are never touched by ANY signal -- canals are legitimately thin/"
        "small/naturally fragmented, and a real 6-case holdout run with canals eligible cratered canal "
        "Dice_Instance/NSD (see docs/research/08-gtfree-fp-cleanup-design.md's 'REAL-DATA FINDING' "
        "section). 'all': canal labels become eligible ONLY via signal B (redundant same-quadrant "
        "overlap), and only as a forced relabel to the bigger neighbour -- never cleared, regardless "
        "of --volume-threshold.",
    )
    parser.add_argument("--min-component-voxels", type=int, default=DEFAULT_MIN_COMPONENT_VOXELS)
    parser.add_argument("--isolation-distance-mm", type=float, default=DEFAULT_ISOLATION_DISTANCE_MM)
    parser.add_argument("--min-peers-for-isolation-check", type=int, default=MIN_PEERS_FOR_ISOLATION_CHECK)
    parser.add_argument("--overcount-dilation-voxels", type=int, default=DEFAULT_OVERCOUNT_DILATION_VOXELS)
    parser.add_argument("--overcount-overlap-fraction", type=float, default=DEFAULT_OVERCOUNT_OVERLAP_FRACTION)
    parser.add_argument("--no-duplicate-signal", action="store_true", help="Disable signal A (duplicate components).")
    parser.add_argument(
        "--no-quadrant-overcount-signal", action="store_true", help="Disable signal B (redundant same-quadrant coverage)."
    )
    parser.add_argument(
        "--no-spatial-isolation-signal", action="store_true", help="Disable signal C (spatial isolation)."
    )
    parser.add_argument(
        "--use-ot-dustbin-signal",
        action="store_true",
        help="Enable signal D (OT-dustbin corroboration, off by default -- see "
        "docs/research/08-gtfree-fp-cleanup-design.md's limitations section before enabling on a "
        "real submission; the task brief that motivated this script found the OT module's own "
        "default tuning over-rejects on real data).",
    )
    parser.add_argument("--ot-dustbin-cost", type=float, default=0.9)
    parser.add_argument("--decisions-json", type=Path, default=None)
    args = parser.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)

    options = GTFreeOptions(
        clean_classes=args.clean_classes,
        min_component_voxels=args.min_component_voxels,
        isolation_distance_mm=args.isolation_distance_mm,
        min_peers_for_isolation_check=args.min_peers_for_isolation_check,
        overcount_dilation_voxels=args.overcount_dilation_voxels,
        overcount_overlap_fraction=args.overcount_overlap_fraction,
        use_duplicate_signal=not args.no_duplicate_signal,
        use_quadrant_overcount_signal=not args.no_quadrant_overcount_signal,
        use_spatial_isolation_signal=not args.no_spatial_isolation_signal,
        use_ot_dustbin_signal=args.use_ot_dustbin_signal,
        ot_dustbin_cost=args.ot_dustbin_cost,
    )

    case_files = _prediction_paths(args.predictions_dir)
    if not case_files:
        raise SystemExit(f"no .nii/.nii.gz files found under {args.predictions_dir}")

    all_decisions: dict[str, dict] = {}
    signal_counts: dict[str, int] = {}
    action_counts: dict[str, int] = {}

    for input_path in case_files:
        case_id = input_path.name.removesuffix(".nii.gz").removesuffix(".nii")
        image = nib.load(str(input_path))
        labels = np.asanyarray(image.dataobj).astype(np.int64)

        candidates = identify_gtfree_fp_candidates(labels, image.affine, options)
        output, records = clean_or_relabel_false_positive_labels(
            labels,
            gt_labels=None,
            volume_threshold=args.volume_threshold,
            dilation_voxels=args.dilation_voxels,
            affine=image.affine,
            gtfree_options=options,
        )

        changed = not np.array_equal(output, labels)
        output_path = args.output_dir / input_path.name
        nib.save(
            nib.Nifti1Image(output.astype(image.get_data_dtype()), image.affine, image.header.copy()),
            str(output_path),
        )

        case_signal_counts: dict[str, int] = {}
        for c in candidates:
            case_signal_counts[c.signal] = case_signal_counts.get(c.signal, 0) + 1
            signal_counts[c.signal] = signal_counts.get(c.signal, 0) + 1

        case_action_counts: dict[str, int] = {}
        for r in records:
            case_action_counts[r.action] = case_action_counts.get(r.action, 0) + 1
            action_counts[r.action] = action_counts.get(r.action, 0) + 1

        all_decisions[case_id] = {
            "changed_any_voxel": changed,
            "num_candidates": len(candidates),
            "signal_counts": case_signal_counts,
            "action_counts": case_action_counts,
            "records": [
                {
                    "label": r.label,
                    "component_id": r.component_id,
                    "voxel_count": r.voxel_count,
                    "action": r.action,
                    "new_label": r.new_label,
                }
                for r in records
            ],
        }
        print(
            f"{case_id}: {len(candidates)} GT-free candidates ({case_signal_counts}), "
            f"{len(records)} decisions ({case_action_counts}), changed_any_voxel={changed}"
        )

    summary = {
        "num_cases": len(case_files),
        "volume_threshold": args.volume_threshold,
        "dilation_voxels": args.dilation_voxels,
        "options": {
            "clean_classes": options.clean_classes,
            "min_component_voxels": options.min_component_voxels,
            "isolation_distance_mm": options.isolation_distance_mm,
            "min_peers_for_isolation_check": options.min_peers_for_isolation_check,
            "overcount_dilation_voxels": options.overcount_dilation_voxels,
            "overcount_overlap_fraction": options.overcount_overlap_fraction,
            "use_duplicate_signal": options.use_duplicate_signal,
            "use_quadrant_overcount_signal": options.use_quadrant_overcount_signal,
            "use_spatial_isolation_signal": options.use_spatial_isolation_signal,
            "use_ot_dustbin_signal": options.use_ot_dustbin_signal,
            "ot_dustbin_cost": options.ot_dustbin_cost,
        },
        "total_signal_counts": signal_counts,
        "total_action_counts": action_counts,
    }
    print(json.dumps(summary, indent=2))

    if args.decisions_json:
        args.decisions_json.parent.mkdir(parents=True, exist_ok=True)
        args.decisions_json.write_text(json.dumps({"summary": summary, "cases": all_decisions}, indent=2))
        print(f"wrote decisions to {args.decisions_json}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
