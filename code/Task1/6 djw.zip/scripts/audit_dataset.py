#!/usr/bin/env python3
"""Audit STSR image and optional label folders."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from stsr2026.data.audit import DatasetAuditError, audit_dataset


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--images", type=Path, required=True)
    parser.add_argument("--labels", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    try:
        report = audit_dataset(args.images, args.labels)
    except DatasetAuditError as exc:
        parser.error(str(exc))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(f"audited {report['num_cases']} cases: {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
