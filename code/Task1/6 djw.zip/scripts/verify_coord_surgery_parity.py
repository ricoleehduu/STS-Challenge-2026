#!/usr/bin/env python3
"""Forward-pass parity check for the coordinate-channel weight surgery
(``scripts/coord_channel_weight_surgery.py``).

Per the task brief: after zero-init surgery, the network's forward pass on
the same input should be "highly similar" to the pre-surgery checkpoint's
output -- not necessarily bit-identical (going from a 1-channel to a
2-channel convolution changes floating-point op order/reduction width),
but any large discrepancy means the surgery has a real bug, not floating
point noise.

Builds two real nnU-Net network instances directly from plans (via
``nnUNetTrainer.build_network_architecture``, the exact function nnU-Net
itself uses both for training and inference, so this uses no
homebrewed reconstruction of the architecture):

1. The original 1-channel architecture, loaded with the un-surgered
   ``--source-checkpoint``.
2. The surgically-expanded 2-channel architecture (same plans file, just
   ``num_input_channels=2``), loaded with ``--surgical-checkpoint``.

Both run in eval mode on the same random input (channel 0 identical in both
cases; network 2's channel 1 gets a random *nonzero* coordinate-like input
specifically to also confirm the new channel's zero-initialized weights
truly contribute nothing to the output -- a bug that only zeroed the wrong
half of the weight tensor, or that left the new channel's weights non-zero,
would very likely fail this if it were sensitive to channel-1 content and
pass a same-input parity check that used all-zero channel-1 input instead).

GPU-dependent (real nnU-Net network forward pass); run on the training box,
not the local sandbox.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import torch


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--source-checkpoint", type=Path, required=True, help="original 1-channel checkpoint")
    parser.add_argument("--surgical-checkpoint", type=Path, required=True, help="surgically-expanded 2-channel checkpoint")
    parser.add_argument("--plans-json", type=Path, required=True, help="plans file (2-channel architecture is identical to 1-channel except stem)")
    parser.add_argument("--dataset-json", type=Path, required=True)
    parser.add_argument("--configuration", default="3d_fullres")
    parser.add_argument("--old-in-channels", type=int, default=1)
    parser.add_argument("--new-in-channels", type=int, default=2)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--seed", type=int, default=1234)
    args = parser.parse_args()

    from nnunetv2.training.nnUNetTrainer.nnUNetTrainer import nnUNetTrainer
    from nnunetv2.utilities.plans_handling.plans_handler import PlansManager

    device = torch.device(args.device)

    plans = json.loads(args.plans_json.read_text())
    dataset_json = json.loads(args.dataset_json.read_text())
    plans_manager = PlansManager(plans)
    configuration_manager = plans_manager.get_configuration(args.configuration)
    label_manager = plans_manager.get_label_manager(dataset_json)
    num_output_channels = label_manager.num_segmentation_heads
    patch_size = configuration_manager.patch_size

    torch.manual_seed(args.seed)
    common_input = torch.randn(1, 1, *patch_size)
    coord_channel_input = torch.empty(1, 1, *patch_size).uniform_(-1.0, 1.0)

    print(f"patch_size={patch_size}, num_output_channels={num_output_channels}, device={device}")

    # --- network 1: original architecture + original checkpoint ---
    net1 = nnUNetTrainer.build_network_architecture(
        plans_manager, configuration_manager, args.old_in_channels, num_output_channels, enable_deep_supervision=False
    )
    ckpt1 = torch.load(str(args.source_checkpoint), map_location="cpu", weights_only=False)
    net1.load_state_dict(ckpt1["network_weights"])
    net1 = net1.to(device).eval()

    # --- network 2: surgically-expanded architecture + surgical checkpoint ---
    net2 = nnUNetTrainer.build_network_architecture(
        plans_manager, configuration_manager, args.new_in_channels, num_output_channels, enable_deep_supervision=False
    )
    ckpt2 = torch.load(str(args.surgical_checkpoint), map_location="cpu", weights_only=False)
    net2.load_state_dict(ckpt2["network_weights"])
    net2 = net2.to(device).eval()

    input1 = common_input.to(device)
    input2 = torch.cat([common_input, coord_channel_input], dim=1).to(device)

    with torch.no_grad():
        out1 = net1(input1)
        out2 = net2(input2)

    if isinstance(out1, (list, tuple)):
        out1 = out1[0]
    if isinstance(out2, (list, tuple)):
        out2 = out2[0]

    out1 = out1.float().cpu()
    out2 = out2.float().cpu()

    abs_diff = (out1 - out2).abs()
    max_abs_diff = float(abs_diff.max())
    mean_abs_diff = float(abs_diff.mean())
    ref_scale = float(out1.abs().mean())
    argmax1 = out1.argmax(dim=1)
    argmax2 = out2.argmax(dim=1)
    argmax_agreement = float((argmax1 == argmax2).float().mean())

    print(f"output shape: {tuple(out1.shape)}")
    print(f"max |diff|:   {max_abs_diff:.6e}")
    print(f"mean |diff|:  {mean_abs_diff:.6e}   (reference mean |logit| = {ref_scale:.6e})")
    print(f"argmax agreement (voxel-wise class prediction): {argmax_agreement * 100:.4f}%")

    # Sanity check with a SECOND random coordinate-channel input: if surgery
    # zeroed the new channel's weights correctly, network 2's output must not
    # depend on channel-1 content at all -- verify that directly rather than
    # just trusting the single-sample check above.
    coord_channel_input_b = torch.empty(1, 1, *patch_size).uniform_(-1.0, 1.0)
    input2b = torch.cat([common_input, coord_channel_input_b], dim=1).to(device)
    with torch.no_grad():
        out2b = net2(input2b)
    if isinstance(out2b, (list, tuple)):
        out2b = out2b[0]
    out2b = out2b.float().cpu()
    channel1_sensitivity = float((out2 - out2b).abs().max())
    print(f"max |diff| between two DIFFERENT random channel-1 inputs (network 2 only): {channel1_sensitivity:.6e}"
          " (should be ~0 if the new channel's weights are truly zero)")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
