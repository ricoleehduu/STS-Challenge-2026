#!/usr/bin/env python3
"""Validate predictions against input images and optionally create a Codabench zip."""
from __future__ import annotations

import argparse
from pathlib import Path

from stsr2026.submission.validator import SubmissionValidationError, create_validation_zip, validate_predictions


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--inputs", type=Path, required=True)
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--zip", type=Path)
    args = parser.parse_args()
    try:
        report = validate_predictions(args.inputs, args.predictions)
        if args.zip:
            create_validation_zip(args.predictions, args.zip, expected_cases=len(report))
    except SubmissionValidationError as exc:
        parser.error(str(exc))
    print(f"validated {len(report)} predictions")
    if args.zip:
        print(f"created {args.zip}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
