#!/usr/bin/env bash
# Run the built submission container against one or more real case sets
# (the 20 official validation cases, the 6-case local holdout, or both),
# using the EXACT official invocation from the organizers' 2026-07-14 email
# (see plan.md D5): `docker container run --gpus all -m 8G --name <team>
# --rm -v <inputs>:/inputs -v <outputs>:/outputs <image>`. Asserts:
#   - every input case produced a `<case>_mask.nii.gz` output (the official
#     naming convention plan.md D5 confirms; NOT same-name, which is only
#     the internal Codabench validation-zip convention -- see
#     stsr2026.submission.validator / docker/README.md's naming-risk note),
#   - every output has the same shape/affine as its input and integer
#     labels in [0, 64],
#   - per-case timing against the 60s/case target (soft) and hard limit,
#   - prints a pass/fail summary.
#
# NOT run by the agent that wrote this -- must run on the real GPU box with
# a working `docker` daemon, `--gpus all` support, and the real 8GB memory
# ceiling plan.md D5 documents as the actual official limit (previously
# assumed 24-28GB; see docs/experiment-log.md's memfix rows for why this
# number matters -- OOM was previously invisible at looser limits).
#
# Run this TWICE (--runs 2, the default) against EACH case set before
# trusting the result: docs/progress.md/plan.md record a real, previously
# unknown OOM failure mode that only reproduced on some runs/case
# orderings, not a single deterministic case -- one clean run is not
# sufficient evidence of no OOM. After each run this script best-effort
# greps `dmesg` for "Memory cgroup out of memory" / "Out of memory" (the
# exact strings docs/progress.md's real OOM diagnoses matched on) --
# `dmesg` may need `sudo`; if it's not readable, the script warns loudly
# rather than silently skipping the check.
#
# Usage (run at least one of --inputs-20/--outputs-20 or --inputs-6/--outputs-6):
#   scripts/validate_submission_container.sh \
#     --image djw:latest \
#     --inputs-20 /path/to/20case/test_case_data --outputs-20 /path/to/20case_outputs \
#     --inputs-6  /path/to/holdout_images_raw    --outputs-6  /path/to/holdout_outputs \
#     --runs 2
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

TEAM_NAME="djw"
IMAGE="djw:latest"
INPUTS_20="" ; OUTPUTS_20=""
INPUTS_6=""  ; OUTPUTS_6=""
RUNS=2
SOFT_TIMEOUT=60
HARD_TIMEOUT=60
PYTHON_BIN="${PYTHON_BIN:-python3}"
LOG_DIR="${REPO_ROOT}/artifacts/validate_logs"

usage() {
    cat <<EOF
Usage: $0 [options]
  --image IMAGE:TAG        Image to run (default: ${IMAGE}).
  --team-name NAME         Used for container --name and log messages (default: ${TEAM_NAME}).
  --inputs-20 DIR          20 official validation case images dir.
  --outputs-20 DIR         Where to write/inspect the 20-case outputs (created if missing).
  --inputs-6 DIR           6-case local holdout raw images dir.
  --outputs-6 DIR          Where to write/inspect the 6-case outputs (created if missing).
  --runs N                 Repeat each case set N times (default: ${RUNS}; run at least
                            twice -- see script header for why one clean run isn't enough).
  --soft-timeout SECONDS   Per-case soft target to warn about, non-fatal (default: ${SOFT_TIMEOUT}).
  --hard-timeout SECONDS   Per-case hard limit to FAIL on (default: ${HARD_TIMEOUT}).
  --log-dir DIR            Where to write per-run container logs (default: artifacts/validate_logs).
EOF
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --image) IMAGE="$2"; shift 2 ;;
        --team-name) TEAM_NAME="$2"; shift 2 ;;
        --inputs-20) INPUTS_20="$2"; shift 2 ;;
        --outputs-20) OUTPUTS_20="$2"; shift 2 ;;
        --inputs-6) INPUTS_6="$2"; shift 2 ;;
        --outputs-6) OUTPUTS_6="$2"; shift 2 ;;
        --runs) RUNS="$2"; shift 2 ;;
        --soft-timeout) SOFT_TIMEOUT="$2"; shift 2 ;;
        --hard-timeout) HARD_TIMEOUT="$2"; shift 2 ;;
        --log-dir) LOG_DIR="$2"; shift 2 ;;
        -h|--help) usage; exit 0 ;;
        *) echo "unknown argument: $1" >&2; usage; exit 1 ;;
    esac
done

if [[ -z "${INPUTS_20}" && -z "${INPUTS_6}" ]]; then
    echo "ERROR: pass at least one of --inputs-20/--outputs-20 or --inputs-6/--outputs-6." >&2
    usage
    exit 1
fi

if ! command -v docker >/dev/null 2>&1; then
    echo "ERROR: docker not found on PATH -- run this on the real GPU box." >&2
    exit 1
fi

mkdir -p "${LOG_DIR}"

OVERALL_FAIL=0

check_dmesg_for_oom() {
    local label="$1"
    local dmesg_out
    if ! dmesg_out=$(dmesg 2>&1); then
        echo "  WARNING: could not read dmesg (${label}) -- permission denied or unsupported;" \
             "manually check for OOM kills, do not assume clean." >&2
        return
    fi
    if echo "${dmesg_out}" | grep -qiE "memory cgroup out of memory|out of memory: killed process"; then
        echo "  FAIL: dmesg shows an OOM kill after ${label} -- see 'dmesg | grep -i \"out of memory\"'" >&2
        OVERALL_FAIL=1
    else
        echo "  OK: no OOM kill found in dmesg after ${label}."
    fi
}

# Runs the container once against one input/output dir pair, tees the log,
# and returns via $CONTAINER_LOG (global) the path to that run's log file.
run_once() {
    local label="$1" inputs="$2" outputs="$3" run_idx="$4"
    mkdir -p "${outputs}"
    chmod 777 "${outputs}" 2>/dev/null || true  # non-root 'algorithm' user write access, see docker/README.md
    local container_name="${TEAM_NAME}-validate-${label}-run${run_idx}"
    CONTAINER_LOG="${LOG_DIR}/${label}_run${run_idx}.log"
    echo "== [${label}] run ${run_idx}/${RUNS}: docker run --gpus all -m 8G --name ${container_name} --rm -v ${inputs}:/inputs -v ${outputs}:/outputs ${IMAGE} =="
    local start end elapsed
    start=$(date +%s)
    set +e
    docker container run --gpus all -m 8G --name "${container_name}" --rm \
        -v "${inputs}:/inputs" -v "${outputs}:/outputs" "${IMAGE}" 2>&1 | tee "${CONTAINER_LOG}"
    local docker_status=${PIPESTATUS[0]}
    set -e
    end=$(date +%s)
    elapsed=$((end - start))
    echo "  container exit status: ${docker_status}, total wall clock: ${elapsed}s"
    if [[ "${docker_status}" -ne 0 ]]; then
        echo "  FAIL: container exited non-zero (${label} run ${run_idx})." >&2
        OVERALL_FAIL=1
    fi
    check_dmesg_for_oom "${label} run ${run_idx}"
}

# Parses "wrote <path> (<seconds>s)" lines this repo's docker/run_inference.py
# / checkpoint_runner.py print per successful case (see _run_real_checkpoint /
# _run_fake_predict) against --soft-timeout/--hard-timeout.
check_timing() {
    local label="$1" log="$2"
    local any_hard_fail=0
    while IFS= read -r line; do
        # e.g. "wrote /outputs/case_006_mask.nii.gz (44.1s)"
        local secs
        secs=$(echo "${line}" | grep -oE '\([0-9.]+s\)$' | tr -d '()s')
        [[ -z "${secs}" ]] && continue
        if awk -v s="${secs}" -v h="${HARD_TIMEOUT}" 'BEGIN{exit !(s>h)}'; then
            echo "  FAIL: ${line}  -- exceeds hard limit ${HARD_TIMEOUT}s" >&2
            any_hard_fail=1
        elif awk -v s="${secs}" -v t="${SOFT_TIMEOUT}" 'BEGIN{exit !(s>t)}'; then
            echo "  WARN: ${line}  -- exceeds soft target ${SOFT_TIMEOUT}s (known issue, see plan.md D5's windowed-pipeline OOM-fix timing tradeoff note; not auto-fatal)"
        fi
    done < <(grep -E '^wrote ' "${log}" || true)
    if grep -q '^FAILED case' "${log}"; then
        echo "  FAIL: at least one case reported FAILED in ${log}:" >&2
        grep '^FAILED case' "${log}" >&2
        any_hard_fail=1
    fi
    if [[ "${any_hard_fail}" -eq 1 ]]; then
        OVERALL_FAIL=1
    fi
}

# Checks filename convention (<case>_mask.nii.gz), shape/affine match, and
# integer label range [0, 64] for every input case -- via a small inline
# Python snippet (nibabel/numpy are base pyproject.toml dependencies, see
# scripts/evaluate_checkpoint.py's same assumption).
check_outputs() {
    local label="$1" inputs="$2" outputs="$3"
    echo "-- [${label}] output contract check (naming, shape/affine, label range) --"
    set +e
    "${PYTHON_BIN}" - "${inputs}" "${outputs}" <<'PY'
import sys
from pathlib import Path
import numpy as np
import nibabel as nib

inputs_dir, outputs_dir = Path(sys.argv[1]), Path(sys.argv[2])
input_files = sorted(p for p in inputs_dir.iterdir() if p.name.endswith((".nii", ".nii.gz")))
if not input_files:
    print(f"  FAIL: no input NIfTI files found under {inputs_dir}")
    sys.exit(1)

failures = []
for input_path in input_files:
    stem = input_path.name.removesuffix(".nii.gz").removesuffix(".nii")
    expected = outputs_dir / f"{stem}_mask.nii.gz"
    if not expected.is_file():
        failures.append(f"{stem}: missing expected output {expected.name}")
        continue
    src = nib.load(str(input_path))
    pred = nib.load(str(expected))
    src_data = np.asanyarray(src.dataobj)
    pred_data = np.asanyarray(pred.dataobj)
    if pred_data.shape != src_data.shape:
        failures.append(f"{stem}: shape {pred_data.shape} != input {src_data.shape}")
        continue
    if not np.allclose(pred.affine, src.affine, atol=1e-4):
        failures.append(f"{stem}: affine differs from input")
        continue
    if not np.isfinite(pred_data).all() or not np.array_equal(pred_data, np.rint(pred_data)):
        failures.append(f"{stem}: non-integer or non-finite values in prediction")
        continue
    classes = np.unique(pred_data.astype(np.int64, copy=False))
    if classes.size and (classes.min() < 0 or classes.max() > 64):
        failures.append(f"{stem}: labels outside [0, 64]: {classes.tolist()}")
        continue
    print(f"  OK: {stem} -> {expected.name}, shape={pred_data.shape}, labels={classes.tolist()}")

if failures:
    print(f"  FAIL: {len(failures)}/{len(input_files)} case(s) failed the output contract check:")
    for f in failures:
        print(f"    - {f}")
    sys.exit(1)
print(f"  PASS: all {len(input_files)} case(s) match the <case>_mask.nii.gz / shape / affine / [0,64] contract.")
PY
    local py_status=$?
    set -e
    if [[ "${py_status}" -ne 0 ]]; then
        OVERALL_FAIL=1
    fi
}

run_case_set() {
    local label="$1" inputs="$2" outputs="$3"
    echo ""
    echo "########## Case set: ${label} (inputs=${inputs}) ##########"
    for run_idx in $(seq 1 "${RUNS}"); do
        run_once "${label}" "${inputs}" "${outputs}" "${run_idx}"
        check_timing "${label}" "${CONTAINER_LOG}"
    done
    # Output-contract check only needs to run once, against the LAST run's
    # outputs (each run overwrites the same --outputs dir by design, so this
    # is also an implicit determinism sanity check across runs if you diff
    # the two runs' logs by hand -- see docs/progress.md's note on GPU
    # inference non-determinism, ~0.0001% of voxels, expected and harmless).
    check_outputs "${label}" "${inputs}" "${outputs}"
}

[[ -n "${INPUTS_20}" ]] && run_case_set "20case" "${INPUTS_20}" "${OUTPUTS_20}"
[[ -n "${INPUTS_6}"  ]] && run_case_set "6case"  "${INPUTS_6}"  "${OUTPUTS_6}"

echo ""
if [[ "${OVERALL_FAIL}" -eq 0 ]]; then
    echo "== SUMMARY: PASS =="
    echo "Next: scripts/check_scoring_parity.sh against the 6-case outputs (needs known GT)."
    exit 0
else
    echo "== SUMMARY: FAIL -- see FAIL lines above =="
    exit 1
fi
