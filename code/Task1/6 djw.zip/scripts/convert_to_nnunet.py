#!/usr/bin/env python3
"""Build an nnU-Net v2 raw dataset and a fixed hold-out split from an audit report."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from stsr2026.data.audit import DatasetAuditError, audit_dataset
from stsr2026.data.convert import convert_labeled_dataset
from stsr2026.data.split import build_holdout_split


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--images", type=Path, required=True)
    parser.add_argument("--labels", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True, help="nnU-Net raw dataset directory")
    parser.add_argument("--split-output", type=Path, required=True, help="where to write train/val split JSON")
    parser.add_argument("--val-fraction", type=float, default=0.2)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument(
        "--case-ids",
        nargs="+",
        default=None,
        help="convert only these case IDs (e.g. for a single-case smoke test)",
    )
    args = parser.parse_args()

    try:
        report = audit_dataset(args.images, args.labels)
    except DatasetAuditError as exc:
        parser.error(str(exc))

    convert_labeled_dataset(args.images, args.labels, args.output_dir, case_ids=args.case_ids)

    cases = report["cases"]
    if args.case_ids is not None:
        selected = set(args.case_ids)
        cases = [c for c in cases if c["case_id"] in selected]
    split = build_holdout_split(cases, val_fraction=args.val_fraction, seed=args.seed)
    args.split_output.parent.mkdir(parents=True, exist_ok=True)
    args.split_output.write_text(json.dumps(split, indent=2) + "\n")

    print(f"converted {report['num_cases'] if args.case_ids is None else len(cases)} cases to {args.output_dir}")
    print(f"split: {len(split['train'])} train / {len(split['val'])} val -> {args.split_output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
