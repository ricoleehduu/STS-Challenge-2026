#!/usr/bin/env python3
"""Count parameters and FLOPs of the nnU-Net configuration described by a plans.json.

Reproduces the three cost figures reported in the STSR 2026 Task 1 paper's
training-configuration table. The network is instantiated from the plan alone,
so no checkpoint or GPU is required; pass ``--checkpoint`` to additionally
cross-check the architecture against a trained checkpoint's ``network_weights``
and to print why a naive state-dict sum overstates the parameter count.

FLOPs are accumulated over convolution and transposed-convolution layers for one
forward pass at the training patch size with batch size 1, counting each
multiply-accumulate as two FLOPs. The forward pass runs on the ``meta`` device,
so shapes propagate without allocating any activations.

Example::

    python scripts/count_model_cost.py \\
        --plans configs/training/nnUNetPlansBigMem_3d_fullres_architecture.json

The bundled plan extract carries only the architecture and patch size, which is
all this script reads; the dataset-derived fields of the full nnU-Net plan are
omitted because the challenge data is not redistributed. Point ``--plans`` at a
full ``plans.json`` instead if you have one.
"""
from __future__ import annotations

import argparse
import importlib
import json
from pathlib import Path

import torch
import torch.nn as nn


def _resolve(dotted: str):
    module, _, name = dotted.rpartition(".")
    return getattr(importlib.import_module(module), name)


def build_network(plans: dict, configuration: str, input_channels: int, num_classes: int):
    """Instantiate the architecture exactly as nnU-Net does for this plan."""
    config = plans["configurations"][configuration]
    architecture = config["architecture"]
    kwargs = dict(architecture["arch_kwargs"])
    for key in architecture.get("_kw_requires_import", []):
        value = kwargs.get(key)
        kwargs[key] = _resolve(value) if isinstance(value, str) else value
    kwargs.pop("_kw_requires_import", None)
    network_class = _resolve(architecture["network_class_name"])
    network = network_class(
        input_channels=input_channels,
        num_classes=num_classes,
        deep_supervision=True,
        **kwargs,
    )
    return network, config["patch_size"]


def count_macs(network: nn.Module, patch_size, input_channels: int) -> dict[str, int]:
    """Multiply-accumulate counts per forward pass, measured on the meta device."""
    macs = {"conv": 0, "conv_transpose": 0}

    def hook(module, inputs, output):
        kernel = 1
        for k in module.kernel_size:
            kernel *= k
        if isinstance(module, nn.Conv3d):
            voxels = 1
            for s in output.shape[2:]:
                voxels *= s
            macs["conv"] += kernel * (module.in_channels // module.groups) * module.out_channels * voxels
        else:
            voxels = 1
            for s in inputs[0].shape[2:]:
                voxels *= s
            macs["conv_transpose"] += (
                kernel * module.in_channels * (module.out_channels // module.groups) * voxels
            )

    handles = [
        m.register_forward_hook(hook)
        for m in network.modules()
        if isinstance(m, (nn.Conv3d, nn.ConvTranspose3d))
    ]
    meta_network = network.to("meta")
    with torch.no_grad():
        meta_network(torch.empty(1, input_channels, *patch_size, device="meta"))
    for handle in handles:
        handle.remove()
    return macs


def report_state_dict_aliasing(reference: dict[str, torch.Tensor], unique: int) -> None:
    """Explain the gap between a naive state-dict sum and the real parameter count."""
    total = sum(v.numel() for v in reference.values())
    encoder = sum(v.numel() for k, v in reference.items() if k.startswith("encoder."))
    decoder_encoder = sum(v.numel() for k, v in reference.items() if k.startswith("decoder.encoder."))
    decoder_own = sum(
        v.numel()
        for k, v in reference.items()
        if k.startswith("decoder.") and not k.startswith("decoder.encoder.")
    )
    single = sum(
        v.numel()
        for k, v in reference.items()
        if k.startswith("decoder.transpconvs.") or k.startswith("decoder.seg_layers.")
    )
    print("\nstate-dict aliasing")
    print(f"  naive sum over state_dict keys : {total:,} ({total / unique:.3f}x the real count)")
    print(f"    encoder.*                    : {encoder:,}")
    print(f"    decoder.encoder.*            : {decoder_encoder:,}  (encoder re-registered under the decoder)")
    print(f"    decoder.* (own)              : {decoder_own:,}")
    print(f"      of which counted once      : {single:,}  (transposed convolutions + deep-supervision heads)")
    encoder_unique = encoder // 2
    decoder_twice = (decoder_own - single) // 2
    print("  every convolution and normalization layer is registered both directly and inside a")
    print("  container module, and the encoder is registered again as a decoder submodule, so")
    print("  encoder parameters are counted four times, decoder convolution blocks twice, and")
    print("  transposed convolutions and deep-supervision heads once:")
    print(f"    4 x {encoder_unique:,} + 2 x {decoder_twice:,} + {single:,} = "
          f"{4 * encoder_unique + 2 * decoder_twice + single:,}")
    print(f"    {encoder_unique:,} + {decoder_twice:,} + {single:,} = "
          f"{encoder_unique + decoder_twice + single:,} distinct parameters")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--plans", type=Path, required=True, help="nnU-Net plans.json")
    parser.add_argument("--configuration", default="3d_fullres")
    parser.add_argument("--input-channels", type=int, default=1)
    parser.add_argument("--num-classes", type=int, default=65)
    parser.add_argument("--checkpoint", type=Path, help="optional checkpoint to cross-check against")
    args = parser.parse_args()

    plans = json.loads(args.plans.read_text())
    network, patch_size = build_network(
        plans, args.configuration, args.input_channels, args.num_classes
    )
    unique = sum(p.numel() for p in network.parameters())

    reference = None
    if args.checkpoint is not None:
        checkpoint = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
        reference = checkpoint["network_weights"]
        built = network.state_dict()
        if set(built) != set(reference):
            parser.error("checkpoint parameter names do not match the architecture built from --plans")
        mismatched = [k for k in built if built[k].shape != reference[k].shape]
        if mismatched:
            parser.error(f"shape mismatch against the checkpoint: {mismatched[:5]}")

    macs = count_macs(network, patch_size, args.input_channels)
    total_macs = macs["conv"] + macs["conv_transpose"]

    print(f"plan            : {plans.get('plans_name')} / {args.configuration}")
    print(f"patch size      : {patch_size}  (batch size 1)")
    print(f"parameters      : {unique:,}")
    print(f"MACs            : {total_macs / 1e9:.1f} G"
          f"  (conv {macs['conv'] / 1e9:.1f} G, transposed {macs['conv_transpose'] / 1e9:.1f} G)")
    print(f"FLOPs           : {2 * total_macs / 1e9:.0f} G  (2 FLOPs per multiply-accumulate)")
    if reference is not None:
        print("checkpoint      : parameter names and shapes match the architecture")
        report_state_dict_aliasing(reference, unique)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
