# Command-line scripts

计划中的首批命令入口：

- `audit_dataset.py`
- `convert_to_nnunet.py`
- `predict.py`
- `validate_submission.py`
- `benchmark_inference.py`
- `notify.py`
- `count_model_cost.py`：从 plans 重建网络并输出参数量与 FLOPs（论文训练配置表里的数字：30,836,709 参数、1321 GFLOPs/前向，patch 160×112×160、batch 1、每次乘加计 2 FLOPs）。不需要 GPU、checkpoint 或挑战赛数据——直接跑 `--plans configs/training/nnUNetPlansBigMem_3d_fullres_architecture.json` 即可复现。FLOPs 用 forward hook 在 `meta` 设备上统计，不分配任何激活。传 `--checkpoint` 会额外逐 key 逐 shape 校验架构与权重一致，并解释为什么直接对 state_dict 求和会得到 88,261,509 而不是真实的 30,836,709（卷积/归一化层被注册两次，encoder 又作为 decoder 子模块再注册一次）。
- `evaluate_checkpoint.py`：跑真实 nnU-Net 推理 + 官方口径本地打分（`src/stsr2026/evaluation/`），牙体/根管、image/instance 分开输出，可直接粘贴进 `docs/experiment-log.md`。推理部分依赖 GPU 上安装的 `nnunetv2`；`--skip-inference` 可只跑打分部分（不需要 GPU）。对大病例，使用 `--streaming-export` 使推理走与最终 Docker 相同的逐通道导出路径，避免普通 nnU-Net 65 通道全量导出造成的主机内存峰值。

脚本应保持轻量，核心逻辑放在 `src/stsr2026/` 并由测试覆盖。
