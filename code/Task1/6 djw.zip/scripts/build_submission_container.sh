#!/usr/bin/env bash
# Build the real submission Docker image, save it to artifacts/djw.tar.gz,
# and (re)write artifacts/SHA256SUMS.txt.
#
# NOT run by the agent that wrote this -- this repo's worktree rules
# forbid running Docker/SSH from a sandbox agent (see plan.md D7 Day 2 /
# the task brief this script was written against). Run this on the real
# GPU box (the one with a working `docker` daemon + nvidia-container-toolkit,
# e.g. the A10 instance docs/progress.md and docs/experiment-log.md refer to
# as "A10" -- see docs/reference_gpu_boxes.md-equivalent notes for current
# connection details) after `docker/checkpoint/` has the real checkpoint
# baked in (see docker/README.md's "已知与主办方待确认的差异" section and
# docker/Dockerfile.modern's COPY of docker/checkpoint/).
#
# Builds from docker/Dockerfile.modern by default -- NOT docker/Dockerfile
# (the D0 CUDA-11.3 skeleton with no checkpoint baked in; docker/README.md
# and docs/experiment-log.md confirm Dockerfile.modern is what every real
# `docker build && docker run` validation pass and the current
# artifacts/djw.tar.gz were actually built from). Override with
# --dockerfile if that ever changes.
#
# Usage:
#   scripts/build_submission_container.sh
#   scripts/build_submission_container.sh --dockerfile docker/Dockerfile.modern \
#       --team-name djw --tag djw:latest --output artifacts/djw.tar.gz
#
# Exit codes: non-zero on any build/save/size failure (set -e), so a CI-style
# caller can trust a zero exit means "artifacts/djw.tar.gz + SHA256SUMS.txt
# are both fresh and under the 10GB official limit" (plan.md D5's corrected
# limit, from the organizers' 2026-07-14 email -- NOT the earlier-assumed
# 5GB docker/export.sh still checks; that script predates the corrected
# limit and was not touched here per this task's scope).
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

TEAM_NAME="djw"
DOCKERFILE="${REPO_ROOT}/docker/Dockerfile.modern"
IMAGE_TAG="djw:latest"
OUTPUT_TAR="${REPO_ROOT}/artifacts/djw.tar.gz"
SHA_FILE="${REPO_ROOT}/artifacts/SHA256SUMS.txt"
MAX_SIZE_GB=10
NO_CACHE=0

usage() {
    cat <<EOF
Usage: $0 [--team-name NAME] [--dockerfile PATH] [--tag IMAGE:TAG]
          [--output PATH] [--sha-file PATH] [--max-size-gb N] [--no-cache]

  --team-name    Team name used only for log messages (default: ${TEAM_NAME}).
  --dockerfile   Dockerfile to build from (default: docker/Dockerfile.modern).
  --tag          Image tag to build and save (default: ${IMAGE_TAG}).
  --output       Output .tar.gz path (default: artifacts/djw.tar.gz).
  --sha-file     SHA256SUMS.txt path to (re)write (default: artifacts/SHA256SUMS.txt).
  --max-size-gb  Hard size ceiling to enforce, matches the official limit
                 (default: ${MAX_SIZE_GB}, per plan.md D5's 2026-07-14
                 organizer-email correction -- the container may currently
                 be far smaller, e.g. 3.35GB, so this is a ceiling, not a
                 target).
  --no-cache     Pass --no-cache to 'docker build' (use for a from-scratch
                 rebuild if you suspect stale layers; slower).
EOF
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --team-name) TEAM_NAME="$2"; shift 2 ;;
        --dockerfile) DOCKERFILE="$2"; shift 2 ;;
        --tag) IMAGE_TAG="$2"; shift 2 ;;
        --output) OUTPUT_TAR="$2"; shift 2 ;;
        --sha-file) SHA_FILE="$2"; shift 2 ;;
        --max-size-gb) MAX_SIZE_GB="$2"; shift 2 ;;
        --no-cache) NO_CACHE=1; shift ;;
        -h|--help) usage; exit 0 ;;
        *) echo "unknown argument: $1" >&2; usage; exit 1 ;;
    esac
done

if ! command -v docker >/dev/null 2>&1; then
    echo "ERROR: docker not found on PATH -- this script must run on a real Docker host, not this sandbox." >&2
    exit 1
fi

if [[ ! -f "${DOCKERFILE}" ]]; then
    echo "ERROR: Dockerfile not found: ${DOCKERFILE}" >&2
    exit 1
fi

if [[ ! -d "${REPO_ROOT}/docker/checkpoint" ]]; then
    echo "WARNING: ${REPO_ROOT}/docker/checkpoint/ does not exist (docker/checkpoint/ is gitignored," >&2
    echo "  see docker/README.md). Building without a real checkpoint baked in produces a fake_predict-only" >&2
    echo "  image (STSR_CHECKPOINT_DIR would point at a directory with nothing in it) -- confirm this is" >&2
    echo "  intentional (e.g. a D0 I/O smoke test) before proceeding." >&2
fi

mkdir -p "$(dirname "${OUTPUT_TAR}")"

echo "== Building ${IMAGE_TAG} from ${DOCKERFILE} (context: ${REPO_ROOT}) =="
BUILD_ARGS=(build -t "${IMAGE_TAG}" -f "${DOCKERFILE}")
[[ "${NO_CACHE}" -eq 1 ]] && BUILD_ARGS+=(--no-cache)
BUILD_ARGS+=("${REPO_ROOT}")
docker "${BUILD_ARGS[@]}"

echo "== Saving ${IMAGE_TAG} -> ${OUTPUT_TAR} =="
docker save "${IMAGE_TAG}" | gzip -c > "${OUTPUT_TAR}"

size_bytes=$(stat -f%z "${OUTPUT_TAR}" 2>/dev/null || stat -c%s "${OUTPUT_TAR}")
size_gb=$(awk -v b="${size_bytes}" 'BEGIN { printf "%.2f", b / 1073741824 }')
echo "== Export complete: ${OUTPUT_TAR} (${size_gb} GB) =="

if awk -v b="${size_bytes}" -v max="${MAX_SIZE_GB}" 'BEGIN { exit !(b >= max*1073741824) }'; then
    echo "ERROR: ${OUTPUT_TAR} is ${size_gb}GB, at or above the ${MAX_SIZE_GB}GB official submission limit." >&2
    exit 1
fi

echo "== Recomputing ${SHA_FILE} =="
mkdir -p "$(dirname "${SHA_FILE}")"
(
    cd "$(dirname "${OUTPUT_TAR}")"
    if command -v sha256sum >/dev/null 2>&1; then
        sha256sum "$(basename "${OUTPUT_TAR}")" > "${SHA_FILE}"
    else
        # macOS has no sha256sum by default; shasum -a 256 is the equivalent
        # and produces the same "<hash>  <filename>" line format.
        shasum -a 256 "$(basename "${OUTPUT_TAR}")" > "${SHA_FILE}"
    fi
)
echo "== SHA256SUMS.txt =="
cat "${SHA_FILE}"

echo ""
echo "Build+save+checksum done. Team: ${TEAM_NAME}. Next: scripts/validate_submission_container.sh"
