"""Apply ``hungarian_instance_assignment.assign_instances_to_fdi_slots`` to an
existing directory of prediction NIfTIs, as the exploratory 4th post-processing
step layered on top of the already-adopted
``LineA-PhaseB-LRfix-v2 + FP-cleanup(threshold=5000)`` baseline
(``taskD_gtfree_t5000/predictions`` on the GPU box).

This script is deliberately standalone (not wired into
``postprocessing_pipeline.py``) -- this is an exploratory real-data
validation run, not a production integration; see
``docs/research/06-2026-improvement-survey.md`` section 3 and
``plan.md``'s Task E instructions for context.

Usage::

    python scripts/apply_hungarian_assignment.py \
        --predictions-dir /path/to/day1_taskA/taskD_gtfree_t5000/predictions \
        --output-dir /path/to/day1_taskA/taskE_hungarian/predictions \
        --order-weight 0.6 --label-mismatch-cost 0.4 --reject-cost-threshold 0.5 \
        --decisions-json /path/to/day1_taskA/taskE_hungarian/decisions.json
"""
from __future__ import annotations

import argparse
import json
from dataclasses import asdict
from pathlib import Path

import nibabel as nib
import numpy as np

from stsr2026.inference.hungarian_instance_assignment import (
    DEFAULT_LABEL_MISMATCH_COST,
    DEFAULT_ORDER_WEIGHT,
    DEFAULT_REJECT_COST_THRESHOLD,
    assign_instances_to_fdi_slots,
)


def _serialize_cost_matrices(cost_matrices: dict) -> dict:
    return {f"{category}_{quadrant}": matrix.tolist() for (category, quadrant), matrix in cost_matrices.items()}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--predictions-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--order-weight", type=float, default=DEFAULT_ORDER_WEIGHT)
    parser.add_argument("--label-mismatch-cost", type=float, default=DEFAULT_LABEL_MISMATCH_COST)
    parser.add_argument("--reject-cost-threshold", type=float, default=DEFAULT_REJECT_COST_THRESHOLD)
    parser.add_argument("--decisions-json", type=Path, default=None)
    parser.add_argument(
        "--include-cost-matrices",
        action="store_true",
        help="Include the full per-case, per-group cost matrices in the decisions JSON (large; off by default).",
    )
    args = parser.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)

    all_decisions: dict[str, dict] = {}
    case_files = sorted(args.predictions_dir.glob("*.nii.gz"))
    if not case_files:
        raise SystemExit(f"no .nii.gz files found under {args.predictions_dir}")

    for case_path in case_files:
        case_id = case_path.name.removesuffix(".nii.gz")
        image = nib.load(str(case_path))
        labels = np.asanyarray(image.dataobj)

        result = assign_instances_to_fdi_slots(
            labels,
            image.affine,
            order_weight=args.order_weight,
            label_mismatch_cost=args.label_mismatch_cost,
            reject_cost_threshold=args.reject_cost_threshold,
        )

        output_path = args.output_dir / case_path.name
        changed = not np.array_equal(result.output_volume, labels)
        nib.save(
            nib.Nifti1Image(result.output_volume.astype(image.get_data_dtype()), image.affine, image.header.copy()),
            str(output_path),
        )

        case_record = {
            "changed_any_voxel": changed,
            "num_matched": len(result.matched),
            "num_relabeled": sum(1 for m in result.matched if m.changed),
            "num_unmatched_candidates": len(result.unmatched_candidates),
            "num_empty_slots": len(result.empty_slots),
            "relabels": [
                {
                    "category": m.category,
                    "quadrant_index": m.quadrant_index,
                    "original_label": m.original_label,
                    "component_id": m.component_id,
                    "voxel_count": m.voxel_count,
                    "new_label": int(m.new_label),
                    "total_cost": m.total_cost,
                    "order_cost": m.order_cost,
                    "label_mismatch_cost": m.label_mismatch_cost,
                }
                for m in result.matched
                if m.changed
            ],
            "unmatched_candidates": [asdict(u) for u in result.unmatched_candidates],
        }
        if args.include_cost_matrices:
            case_record["cost_matrices"] = _serialize_cost_matrices(result.cost_matrices)
        all_decisions[case_id] = case_record
        print(
            f"{case_id}: {case_record['num_relabeled']} relabeled / {case_record['num_matched']} matched, "
            f"{case_record['num_unmatched_candidates']} unmatched candidates, "
            f"{case_record['num_empty_slots']} empty slots, changed_any_voxel={changed}"
        )

    if args.decisions_json:
        args.decisions_json.parent.mkdir(parents=True, exist_ok=True)
        args.decisions_json.write_text(json.dumps(all_decisions, indent=2))
        print(f"wrote decisions to {args.decisions_json}")


if __name__ == "__main__":
    main()
