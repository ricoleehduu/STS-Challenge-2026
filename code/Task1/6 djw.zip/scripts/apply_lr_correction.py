#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import nibabel as nib
import numpy as np

from stsr2026.inference.lr_correction import correct_lr_confusion


def _prediction_paths(input_dir: Path) -> list[Path]:
    return sorted(path for path in input_dir.iterdir() if path.name.endswith((".nii", ".nii.gz")))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_dir", type=Path)
    parser.add_argument("output_dir", type=Path)
    args = parser.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)
    for input_path in _prediction_paths(args.input_dir):
        image = nib.load(str(input_path))
        labels = np.asanyarray(image.dataobj)
        corrected = correct_lr_confusion(labels, image.affine)
        output_path = args.output_dir / input_path.name
        nib.save(nib.Nifti1Image(corrected, image.affine, image.header.copy()), str(output_path))
        print(output_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
