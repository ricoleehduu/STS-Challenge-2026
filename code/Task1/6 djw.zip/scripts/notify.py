#!/usr/bin/env python3
"""Send an ad-hoc WeChat status notification via AutoDL."""
from __future__ import annotations

import argparse

from stsr2026.utils.notify import NotifyError, send_wechat_notification


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--title", required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--content", required=True)
    args = parser.parse_args()
    try:
        response = send_wechat_notification(args.title, args.name, args.content)
    except NotifyError as exc:
        parser.error(str(exc))
    print(response)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
