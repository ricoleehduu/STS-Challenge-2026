#!/usr/bin/env python3
"""Run real nnU-Net inference for one checkpoint against a hold-out case set
and score it with the official STSR metrics, tooth/canal and
image/instance kept separate (plan.md section 0 / section 6).

This is the "highest-leverage single task" plan.md section 0 calls out:
without it, the P0/Line-A-phase-B/Line-A-phase-C checkpoints already
training in parallel on the training GPUs can only be compared by eyeballing
loss curves.

GPU-DEPENDENT: the inference half of this script
(``stsr2026.evaluation.nnunet_inference``) has never run against a real
checkpoint (no GPU/nnunetv2 in this sandbox -- see that module's
docstring). The scoring half (``stsr2026.evaluation.metrics``) has been
unit-tested against synthetic NIfTI volumes with the real vendored official
scorer, so it is not GPU-dependent -- see the ``--skip-inference`` flag to
run only the scoring half if predictions already exist.

Hold-out case IDs are NOT hardcoded in the evaluation logic itself (see
``stsr2026.evaluation.metrics``/``nnunet_inference``) -- this CLI defaults
``--split-json`` to ``configs/data/holdout_split.json`` (committed to the
repo: the exact 24-train/6-val split, seed=42, that both P0 and Line A
phase B/C are actually training against on the remote GPU boxes -- see
that file's ``_comment`` field and plan.md D1), and ``--split-key`` to
``val``. Override either, or pass ``--case-ids`` explicitly, for a
different split file or subset. Without any of the three, every case found
under ``--labels`` is scored and the script prints a loud warning that
this is NOT necessarily the confirmed hold-out split.
"""
from __future__ import annotations

import argparse
import json
import statistics
import subprocess
import sys
from dataclasses import asdict
from datetime import date
from pathlib import Path

from stsr2026.evaluation.metrics import EvaluationError, evaluate_predictions
from stsr2026.evaluation.nnunet_inference import (
    CaseInferenceResult,
    InferenceError,
    find_case_images,
    run_checkpoint_inference,
)
from stsr2026.data.audit import nifti_case_id
from stsr2026.inference.checkpoint_runner import run_checkpoint_inference_for_docker
from stsr2026.submission.validator import SubmissionValidationError, validate_predictions

# Repo root is scripts/'s parent. configs/data/holdout_split.json is the
# committed, real 24-train/6-val split (seed=42) both P0 and Line A phase
# B/C are actually training against on the GPU boxes -- see that file's
# _comment field.
_DEFAULT_SPLIT_JSON = Path(__file__).resolve().parent.parent / "configs" / "data" / "holdout_split.json"

# plan.md section 5's column ambiguity: the "NSD（牙体/根管分开）" column has no
# separate image/instance variant listed (unlike Dice, which does), and
# plan.md section 4/0 emphasizes NSD specifically to catch thin structures
# (canals) that voxel Dice_Image misses -- instance-level (per-class) NSD is
# used for the table row's "NSD (tooth)"/"NSD (canal)" columns below.
# Image-level NSD is still computed and included in the JSON output.
_NSD_COLUMN_IS_INSTANCE_LEVEL = True


def _git_commit() -> str:
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"], capture_output=True, text=True, check=True, timeout=5
        )
        return result.stdout.strip()
    except Exception:
        return "unknown"


def _resolve_case_ids(args: argparse.Namespace) -> tuple[list[str] | None, str]:
    """Return (case_ids, split_description)."""
    if args.case_ids:
        return sorted(args.case_ids), f"explicit --case-ids ({len(args.case_ids)} cases)"
    if args.split_json:
        if not args.split_json.is_file():
            raise SystemExit(f"--split-json {args.split_json} does not exist")
        split = json.loads(args.split_json.read_text())
        if args.split_key not in split:
            raise SystemExit(f"--split-json {args.split_json} has no key {args.split_key!r} (keys: {list(split)})")
        case_ids = sorted(split[args.split_key])
        return case_ids, f"{args.split_json.name}[{args.split_key}] ({len(case_ids)} cases)"
    print(
        "WARNING: no --split-json/--case-ids given and no default split file found "
        f"({_DEFAULT_SPLIT_JSON}); scoring every case found under --labels. This is "
        "NOT confirmed to be the actual P0/Line-A 6-case hold-out split -- results "
        "may include cases the checkpoint was trained on.",
        file=sys.stderr,
    )
    return None, "ALL cases under --labels (UNCONFIRMED hold-out)"


def _link_or_copy_subset(images_dir: Path, case_ids: list[str], dest_dir: Path) -> None:
    """Populate dest_dir with just the selected cases from images_dir, via
    symlinks where possible (large CBCT volumes; avoid copying), so
    validate_predictions (which requires input/prediction case sets to
    match exactly) can run against the hold-out subset rather than the
    full images directory.
    """
    from stsr2026.data.audit import find_niftis, nifti_case_id

    dest_dir.mkdir(parents=True, exist_ok=True)
    by_id = {nifti_case_id(p): p for p in find_niftis(images_dir)}
    for case_id in case_ids:
        source = by_id[case_id]
        target = dest_dir / source.name
        if target.exists() or target.is_symlink():
            continue
        try:
            target.symlink_to(source.resolve())
        except OSError:
            import shutil

            shutil.copyfile(source, target)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--images", type=Path, required=True, help="raw hold-out case images (no _0000 suffix)")
    parser.add_argument("--labels", type=Path, required=True, help="matching ground-truth label NIfTIs")
    parser.add_argument("--checkpoint-dir", type=Path, help="nnU-Net trainer output dir (required unless --skip-inference)")
    parser.add_argument("--folds", nargs="+", default=["0"], help="e.g. 0 1 2 3 4, or 'all'")
    parser.add_argument("--checkpoint-name", default="checkpoint_final.pth")
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--tile-step-size", type=float, default=0.5)
    parser.add_argument("--use-mirroring", action="store_true", help="enable TTA (off by default, see plan.md 3.1)")
    parser.add_argument(
        "--coord-channel-cache-dir",
        type=Path,
        default=None,
        help=(
            "opt-in, non-streaming path only: generate/cache a coordinate channel "
            "(stsr2026.training.coord_channel) per hold-out case under this directory "
            "and pass it to nnU-Net as an extra input channel, for evaluating a "
            "checkpoint trained with an extra coordinate input channel. Omit for every "
            "existing single-channel checkpoint (P0/Line A/P1) -- behavior is completely "
            "unchanged when this flag is absent."
        ),
    )
    parser.add_argument(
        "--coord-channel-axes",
        default="x",
        help="which coordinate axes the checkpoint was trained with, e.g. 'x' or 'xyz' "
        "(only used together with --coord-channel-cache-dir)",
    )
    parser.add_argument(
        "--streaming-export",
        action="store_true",
        help=(
            "use the production Docker streaming export path instead of nnU-Net's "
            "full-logit export; required for memory-safe evaluation of large cases"
        ),
    )
    parser.add_argument(
        "--split-json",
        type=Path,
        default=_DEFAULT_SPLIT_JSON if _DEFAULT_SPLIT_JSON.is_file() else None,
        help=f"path to a {{'train':[...],'val':[...]}} split file (default: {_DEFAULT_SPLIT_JSON})",
    )
    parser.add_argument("--split-key", default="val")
    parser.add_argument("--case-ids", nargs="+", default=None, help="explicit case IDs, overrides --split-json")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--skip-inference", action="store_true", help="score existing --output-dir/predictions instead of running inference")
    parser.add_argument("--official-eval-dir", type=Path, default=None)
    parser.add_argument("--config-label", required=True, help="value for the experiment-log 'Config' column, e.g. P0, LineA-phaseB")
    parser.add_argument("--experiment-id", default=None)
    parser.add_argument("--change", default=None, help="value for the experiment-log 'Change' column")
    parser.add_argument("--decision", default=None, help="value for the experiment-log 'Decision' column")
    parser.add_argument("--json-output", type=Path, default=None)
    args = parser.parse_args()

    if not args.skip_inference and args.checkpoint_dir is None:
        parser.error("--checkpoint-dir is required unless --skip-inference is given")
    if args.coord_channel_cache_dir is not None and args.streaming_export:
        parser.error(
            "--coord-channel-cache-dir is not supported together with --streaming-export "
            "(the Docker-validated streaming path is out of scope for this experiment; "
            "use the default non-streaming inference path instead)"
        )

    case_ids, split_description = _resolve_case_ids(args)
    predictions_dir = args.output_dir / "predictions"

    inference_results: list[CaseInferenceResult] = []
    if args.skip_inference:
        print(f"--skip-inference: scoring existing predictions under {predictions_dir}")
        if not predictions_dir.is_dir():
            parser.error(f"--skip-inference given but {predictions_dir} does not exist")
    else:
        try:
            image_paths = find_case_images(args.images, case_ids)
        except InferenceError as exc:
            parser.error(str(exc))
        folds: list[int | str] = [int(f) if f.isdigit() else f for f in args.folds]
        print(f"running inference: {len(image_paths)} case(s), checkpoint={args.checkpoint_dir}, folds={folds}")
        try:
            if args.streaming_export:
                # The Docker runner discovers every NIfTI under its input directory,
                # whereas this CLI may have selected only a hold-out split or an
                # explicit case subset. Stage links so both modes honor exactly the
                # same selection without copying multi-hundred-MB CBCT volumes.
                streaming_case_ids = case_ids or [nifti_case_id(path) for path in image_paths]
                streaming_inputs = args.output_dir / "_streaming_inputs"
                _link_or_copy_subset(args.images, streaming_case_ids, streaming_inputs)
                outcomes = run_checkpoint_inference_for_docker(
                    streaming_inputs,
                    predictions_dir,
                    args.checkpoint_dir,
                    folds=folds,
                    checkpoint_name=args.checkpoint_name,
                    tile_step_size=args.tile_step_size,
                    use_mirroring=args.use_mirroring,
                )
                failures = [outcome for outcome in outcomes if outcome.status != "ok"]
                if failures:
                    detail = "; ".join(
                        f"{outcome.case_id}: {outcome.status} ({outcome.message})" for outcome in failures
                    )
                    raise InferenceError(f"streaming inference failed for {len(failures)} case(s): {detail}")
                inference_results = [
                    CaseInferenceResult(
                        outcome.case_id,
                        outcome.input_path,
                        outcome.output_path or "",
                        outcome.wall_clock_seconds or 0.0,
                        None,
                    )
                    for outcome in outcomes
                ]
            else:
                extra_channel_paths_fn = None
                if args.coord_channel_cache_dir is not None:
                    from functools import partial

                    from stsr2026.training.coord_channel import coord_channel_paths_for_case

                    extra_channel_paths_fn = partial(
                        coord_channel_paths_for_case,
                        cache_dir=args.coord_channel_cache_dir,
                        axes=args.coord_channel_axes,
                    )
                inference_results = run_checkpoint_inference(
                    args.checkpoint_dir,
                    image_paths,
                    predictions_dir,
                    folds=folds,
                    checkpoint_name=args.checkpoint_name,
                    tile_step_size=args.tile_step_size,
                    use_mirroring=args.use_mirroring,
                    extra_channel_paths_fn=extra_channel_paths_fn,
                )
        except InferenceError as exc:
            parser.error(str(exc))
        if case_ids is None:
            case_ids = sorted(r.case_id for r in inference_results)

    try:
        validation_inputs = args.output_dir / "_validation_inputs"
        effective_case_ids = case_ids if case_ids is not None else sorted(
            p.stem.removesuffix(".nii") for p in predictions_dir.glob("*.nii*")
        )
        _link_or_copy_subset(args.images, effective_case_ids, validation_inputs)
        prediction_audits = validate_predictions(validation_inputs, predictions_dir)
        print(f"validated {len(prediction_audits)} prediction file(s) (shape/affine/dtype/class-range OK)")
    except (SubmissionValidationError, KeyError) as exc:
        parser.error(f"prediction validation failed: {exc}")

    try:
        summary = evaluate_predictions(
            predictions_dir, args.labels, case_ids=case_ids, official_eval_dir=args.official_eval_dir
        )
    except EvaluationError as exc:
        parser.error(str(exc))

    if inference_results:
        times = [r.wall_clock_seconds for r in inference_results]
        mem_values = [r.peak_gpu_memory_bytes for r in inference_results if r.peak_gpu_memory_bytes is not None]
        runtime_str = f"{max(times):.1f}s max / {statistics.median(times):.1f}s median"
        peak_vram_str = f"{max(mem_values) / 1e9:.2f} GB" if mem_values else "N/A (no CUDA device)"
    else:
        runtime_str = "N/A (--skip-inference)"
        peak_vram_str = "N/A (--skip-inference)"

    nsd_tooth = summary.tooth_nsd_instance if _NSD_COLUMN_IS_INSTANCE_LEVEL else summary.tooth_nsd_image
    nsd_canal = summary.canal_nsd_instance if _NSD_COLUMN_IS_INSTANCE_LEVEL else summary.canal_nsd_image

    row = {
        "ID": args.experiment_id or "TBD",
        "Date": date.today().isoformat(),
        "Git commit": _git_commit(),
        "Config": args.config_label,
        "Split": split_description,
        "Change": args.change or "TBD",
        "Dice_Image (tooth)": f"{summary.tooth_dice_image:.4f}",
        "Dice_Image (canal)": f"{summary.canal_dice_image:.4f}",
        "Dice_Instance (tooth)": f"{summary.tooth_dice_instance:.4f}",
        "Dice_Instance (canal)": f"{summary.canal_dice_instance:.4f}",
        "NSD (tooth)": f"{nsd_tooth:.4f}",
        "NSD (canal)": f"{nsd_canal:.4f}",
        "IA": f"{summary.ia:.4f}",
        "mIoU": f"{summary.miou:.4f}",
        "Runtime (max/median)": runtime_str,
        "Peak VRAM": peak_vram_str,
        "Decision": args.decision or "TBD",
    }

    header = "| " + " | ".join(row) + " |"
    separator = "|" + "|".join("---" for _ in row) + "|"
    values = "| " + " | ".join(str(v) for v in row.values()) + " |"
    print("\nPaste into docs/experiment-log.md:")
    print(header)
    print(separator)
    print(values)

    json_output = args.json_output or (args.output_dir / "result.json")
    json_output.parent.mkdir(parents=True, exist_ok=True)
    json_output.write_text(
        json.dumps(
            {
                "experiment_log_row": row,
                "summary": summary.to_json_dict(),
                "inference_results": [asdict(r) for r in inference_results],
                "num_cases": summary.num_cases,
                "case_ids": case_ids,
            },
            indent=2,
        )
        + "\n"
    )
    print(f"\nfull result written to {json_output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
