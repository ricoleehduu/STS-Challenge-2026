#!/usr/bin/env python3
"""Diagnose and (optionally) clean up hallucinated false-positive predicted
labels -- plan.md D7 Day 1, task A steps 2/3/5.

For every case, finds predicted label ids that are entirely absent from that
case's ground truth, breaks each such label into connected components
(``stsr2026.inference.false_positive_cleanup.clean_false_positive_labels``),
and reports every component's voxel size. With ``--dry-run`` this is a pure
diagnostic (writes only the size-distribution JSON, never touches
predictions) -- use it first to see the real distribution before picking a
``--volume-threshold``. Without ``--dry-run``, also writes cleaned
prediction volumes to ``--output-dir`` (components below the threshold
relabeled to background; components at/above the threshold left untouched
for separate manual review, per plan.md's instruction not to auto-delete the
handful of large false-positive candidates).

Usage (real data, run on a GPU box):

    # Step 1: diagnose only, see the real size distribution.
    python scripts/clean_false_positive_labels.py \
        --pred-dir /path/to/day1_taskA/baseline_lrfix_v2/predictions \
        --gt-dir /path/to/nnUNet_data/nnUNet_raw/Dataset002_STSR/labelsTr \
        --volume-threshold 999999999 --dry-run \
        --report-json /path/to/day1_taskA/fp_component_diagnosis.json

    # Step 2: apply cleanup at a chosen threshold.
    python scripts/clean_false_positive_labels.py \
        --pred-dir /path/to/day1_taskA/baseline_lrfix_v2/predictions \
        --gt-dir /path/to/nnUNet_data/nnUNet_raw/Dataset002_STSR/labelsTr \
        --volume-threshold 5000 \
        --output-dir /path/to/day1_taskA/cleaned/predictions \
        --report-json /path/to/day1_taskA/fp_cleanup_applied.json
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import nibabel as nib
import numpy as np

from stsr2026.data.audit import find_niftis, nifti_case_id
from stsr2026.inference.false_positive_cleanup import clean_false_positive_labels


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--pred-dir", type=Path, required=True)
    parser.add_argument("--gt-dir", type=Path, required=True)
    parser.add_argument("--cases", nargs="+", default=None, help="case IDs to process; default = every case with a prediction file")
    parser.add_argument("--volume-threshold", type=int, required=True)
    parser.add_argument("--output-dir", type=Path, default=None, help="write cleaned predictions here; ignored/unused if --dry-run")
    parser.add_argument("--dry-run", action="store_true", help="only diagnose the component-size distribution, never write cleaned volumes")
    parser.add_argument("--report-json", type=Path, required=True)
    args = parser.parse_args()

    if not args.dry_run and args.output_dir is None:
        parser.error("--output-dir is required unless --dry-run")

    pred_files = {nifti_case_id(p): p for p in find_niftis(args.pred_dir)}
    gt_files = {nifti_case_id(p): p for p in find_niftis(args.gt_dir)}
    case_ids = sorted(args.cases) if args.cases else sorted(pred_files)

    missing = [c for c in case_ids if c not in pred_files or c not in gt_files]
    if missing:
        parser.error(f"case(s) missing a prediction or GT file: {missing}")

    all_records: list[dict] = []
    for case_id in case_ids:
        pred_path = pred_files[case_id]
        gt_path = gt_files[case_id]
        pred_img = nib.load(str(pred_path))
        gt_img = nib.load(str(gt_path))
        pred = np.asanyarray(pred_img.dataobj).astype(np.int64)
        gt = np.asanyarray(gt_img.dataobj).astype(np.int64)
        gt_labels = {int(label) for label in np.unique(gt) if label > 0}

        cleaned, records = clean_false_positive_labels(pred, gt_labels, args.volume_threshold)
        for record in records:
            all_records.append(
                {
                    "case": case_id,
                    "label": record.label,
                    "component_id": record.component_id,
                    "voxel_count": record.voxel_count,
                    "removed": record.removed,
                }
            )

        if not args.dry_run:
            assert args.output_dir is not None
            args.output_dir.mkdir(parents=True, exist_ok=True)
            out_path = args.output_dir / pred_path.name
            out_dtype = pred_img.get_data_dtype()
            nib.save(
                nib.Nifti1Image(cleaned.astype(out_dtype), pred_img.affine, pred_img.header.copy()),
                str(out_path),
            )
            print(out_path)

    all_records.sort(key=lambda r: r["voxel_count"])
    removed = [r for r in all_records if r["removed"]]
    kept = [r for r in all_records if not r["removed"]]
    summary = {
        "num_cases": len(case_ids),
        "volume_threshold": args.volume_threshold,
        "dry_run": args.dry_run,
        "total_false_positive_components": len(all_records),
        "removed_count": len(removed),
        "kept_count": len(kept),
        "removed_voxel_sizes": [r["voxel_count"] for r in removed],
        "kept_voxel_sizes": [r["voxel_count"] for r in kept],
    }
    args.report_json.parent.mkdir(parents=True, exist_ok=True)
    args.report_json.write_text(json.dumps({"summary": summary, "records": all_records}, indent=2))
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
