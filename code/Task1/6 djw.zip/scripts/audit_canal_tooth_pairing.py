#!/usr/bin/env python
"""Report, per case and in aggregate, whether GT canals sit in the tooth their class implies.

Reproduces the measurement behind
``docs/research/07-canal-label-convention-inconsistency.md``.  Run against the
raw nnU-Net labels on a GPU box:

    python scripts/audit_canal_tooth_pairing.py \
        /path/to/nnUNet_data/nnUNet_raw/Dataset002_STSR/labelsTr \
        --split configs/data/holdout_split.json

The headline number is the IDENTITY rate, which upper-bounds every canal-relabel
rule of the form "the canal takes its parent tooth's identity" -- including the
deep-research report's proposed local-canal-network backfill.
"""
from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path

import nibabel as nib
import numpy as np

from stsr2026.data.canal_pairing import Pairing, audit_case


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("labels_dir", type=Path, help="directory of GT *.nii.gz label volumes")
    parser.add_argument("--split", type=Path, default=None,
                        help="holdout_split.json; if given, the holdout subset is reported separately")
    parser.add_argument("--json-out", type=Path, default=None,
                        help="write the per-case counts here")
    args = parser.parse_args()

    val_ids: set[str] = set()
    if args.split is not None:
        val_ids = set(json.loads(args.split.read_text())["val"])

    per_case: dict[str, Counter] = {}
    for path in sorted(args.labels_dir.glob("*.nii.gz")):
        case_id = path.name.replace(".nii.gz", "")
        volume = np.asarray(nib.load(str(path)).dataobj).astype(np.uint8)
        counter: Counter = Counter(p.pairing.value for p in audit_case(volume))
        per_case[case_id] = counter
        n = sum(counter.values())
        if n:
            tag = "val " if case_id in val_ids else "    "
            print(f"  {tag}{case_id:<40s} "
                  f"identity={counter[Pairing.IDENTITY.value]:>3d} "
                  f"swapped={counter[Pairing.SWAPPED.value]:>3d} "
                  f"other={counter[Pairing.OTHER.value]:>2d} "
                  f"unmatched={counter[Pairing.UNMATCHED.value]:>2d}  "
                  f"({counter[Pairing.IDENTITY.value] / n:.0%} identity)")

    def summarize(ids: set[str], title: str) -> None:
        total: Counter = Counter()
        for cid in ids:
            total.update(per_case.get(cid, Counter()))
        n = sum(total.values())
        if not n:
            return
        print(f"\n{title}  (n={n} canal instances, {len(ids)} cases)")
        for key in (Pairing.IDENTITY, Pairing.SWAPPED, Pairing.OTHER, Pairing.UNMATCHED):
            print(f"    {key.value:<10s} {total[key.value]:>4d}  {total[key.value] / n:>6.1%}")
        print(f"    -> ceiling for any tooth-consistent canal rule: "
              f"{total[Pairing.IDENTITY.value] / n:.1%}")

    all_ids = set(per_case)
    summarize(all_ids, "ALL LABELED CASES")
    if val_ids:
        summarize(val_ids & all_ids, "HOLDOUT (fixed evaluation set)")
        summarize(all_ids - val_ids, "TRAINING CASES")

    if args.json_out is not None:
        args.json_out.write_text(json.dumps(
            {cid: dict(counter) for cid, counter in per_case.items()}, indent=2))
        print(f"\nwrote {args.json_out}")


if __name__ == "__main__":
    main()
