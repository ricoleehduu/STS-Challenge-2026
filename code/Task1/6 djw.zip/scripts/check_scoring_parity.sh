#!/usr/bin/env bash
# Re-score the built container's 6-case holdout predictions with the
# official evaluator and compare against the two known reference points:
#   - baseline_lrfix_v2  : IA 0.5472  (LineA-PhaseB-LRfix-v2, L/R correction
#                           only, docs/experiment-log.md)
#   - taskG-teeth-only   : IA 0.5518  (D7 Day 1 follow-up, L/R correction +
#                           GT-free teeth-only false-positive cleanup,
#                           docs/experiment-log.md / docs/research/08-gtfree-fp-cleanup-design.md)
# The container built by scripts/build_submission_container.sh now runs
# BOTH steps by default (see checkpoint_runner.ENV_APPLY_LR_CORRECTION /
# postprocessing_pipeline.apply_postprocessing_chain), so a real container
# run against the 6-case holdout should reproduce taskG-teeth-only's IA
# (0.5518), not just baseline_lrfix_v2's (0.5472) -- landing back at 0.5472
# or lower would mean the container is NOT actually applying step 2 despite
# this task's wiring, a real regression worth catching before the container
# ships. All other reported metrics are printed for human review but only
# IA is asserted against a numeric gate (the two reference numbers this
# task's brief gave are IA-only); canal metrics are printed explicitly so a
# human can eyeball that they are unchanged (they always must be -- teeth-FP
# cleanup categorically excludes canals, see postprocessing_pipeline.py's
# module docstring).
#
# NOT run by the agent that wrote this -- run on the box with the official
# evaluator dependencies (this repo's base pyproject.toml deps: nibabel,
# numpy, scipy, simpleitk) after scripts/validate_submission_container.sh
# has produced real container output for the 6-case holdout.
#
# Usage:
#   scripts/check_scoring_parity.sh \
#     --predictions /path/to/holdout_outputs \
#     --images /path/to/holdout_images_raw \
#     --labels /path/to/holdout_labelsTr \
#     --output-dir /path/to/scratch/docker_parity_check
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

PREDICTIONS_DIR=""
IMAGES_DIR=""
LABELS_DIR=""
OUTPUT_DIR="${REPO_ROOT}/artifacts/docker_parity_check"
SPLIT_JSON="${REPO_ROOT}/configs/data/holdout_split.json"
SPLIT_KEY="val"
SUFFIX="_mask"
PYTHON_BIN="${PYTHON_BIN:-python3}"
BASELINE_LRFIX_V2_IA="0.5472"
TASKG_TEETH_ONLY_IA="0.5518"
IA_TOLERANCE="0.0005"   # slightly above this repo's established 0.0001
                        # GPU-non-determinism noise floor (docs/progress.md),
                        # since this is an aggregate over 6 cases, not a
                        # single bit-exact array comparison.

usage() {
    cat <<EOF
Usage: $0 --predictions DIR --images DIR --labels DIR [options]
  --predictions DIR   Container output dir for the 6-case holdout
                       (files named <case>${SUFFIX}.nii.gz).
  --images DIR         Raw 6-case holdout input images (no _0000 suffix).
  --labels DIR          Matching ground-truth label NIfTIs.
  --output-dir DIR     Scratch dir for staged predictions + result.json
                       (default: artifacts/docker_parity_check).
  --split-json PATH    Holdout split file (default: configs/data/holdout_split.json).
  --split-key KEY      Key within --split-json (default: val).
  --suffix SUFFIX      Output filename suffix to strip before scoring
                       (default: ${SUFFIX}, matches STSR_OUTPUT_SUFFIX in
                       docker/Dockerfile.modern).
  --ia-tolerance FLOAT Allowed downward slack off taskG-teeth-only's 0.5518
                       before this script FAILs (default: ${IA_TOLERANCE}).
EOF
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --predictions) PREDICTIONS_DIR="$2"; shift 2 ;;
        --images) IMAGES_DIR="$2"; shift 2 ;;
        --labels) LABELS_DIR="$2"; shift 2 ;;
        --output-dir) OUTPUT_DIR="$2"; shift 2 ;;
        --split-json) SPLIT_JSON="$2"; shift 2 ;;
        --split-key) SPLIT_KEY="$2"; shift 2 ;;
        --suffix) SUFFIX="$2"; shift 2 ;;
        --ia-tolerance) IA_TOLERANCE="$2"; shift 2 ;;
        -h|--help) usage; exit 0 ;;
        *) echo "unknown argument: $1" >&2; usage; exit 1 ;;
    esac
done

if [[ -z "${PREDICTIONS_DIR}" || -z "${IMAGES_DIR}" || -z "${LABELS_DIR}" ]]; then
    echo "ERROR: --predictions, --images, and --labels are all required." >&2
    usage
    exit 1
fi

STAGED_PREDICTIONS="${OUTPUT_DIR}/predictions"
mkdir -p "${STAGED_PREDICTIONS}"
rm -f "${STAGED_PREDICTIONS}"/*.nii.gz "${STAGED_PREDICTIONS}"/*.nii 2>/dev/null || true

echo "== Staging predictions from ${PREDICTIONS_DIR} (stripping '${SUFFIX}' suffix) =="
staged_count=0
for f in "${PREDICTIONS_DIR}"/*"${SUFFIX}".nii.gz; do
    [[ -e "${f}" ]] || continue
    base="$(basename "${f}")"
    stem="${base%${SUFFIX}.nii.gz}"
    cp "${f}" "${STAGED_PREDICTIONS}/${stem}.nii.gz"
    staged_count=$((staged_count + 1))
done
if [[ "${staged_count}" -eq 0 ]]; then
    echo "ERROR: no '*${SUFFIX}.nii.gz' files found under ${PREDICTIONS_DIR}." \
         "If the container was run without STSR_OUTPUT_SUFFIX=_mask, pass --suffix \"\"." >&2
    exit 1
fi
echo "  staged ${staged_count} prediction file(s) -> ${STAGED_PREDICTIONS}"

JSON_OUTPUT="${OUTPUT_DIR}/result.json"
echo "== Scoring against official evaluator (--skip-inference) =="
"${PYTHON_BIN}" "${REPO_ROOT}/scripts/evaluate_checkpoint.py" \
    --skip-inference \
    --images "${IMAGES_DIR}" \
    --labels "${LABELS_DIR}" \
    --output-dir "${OUTPUT_DIR}" \
    --split-json "${SPLIT_JSON}" \
    --split-key "${SPLIT_KEY}" \
    --config-label "docker-container-parity-check" \
    --json-output "${JSON_OUTPUT}"

echo ""
echo "== Comparing against known baselines =="
set +e
"${PYTHON_BIN}" - "${JSON_OUTPUT}" "${BASELINE_LRFIX_V2_IA}" "${TASKG_TEETH_ONLY_IA}" "${IA_TOLERANCE}" <<'PY'
import json
import sys

json_path, baseline_ia, taskg_ia, tolerance = sys.argv[1], float(sys.argv[2]), float(sys.argv[3]), float(sys.argv[4])
result = json.loads(open(json_path).read())
summary = result["summary"]

print(f"num_cases: {summary['num_cases']}  case_ids: {summary['case_ids']}")
print("")
print(f"{'metric':<22}{'value':>10}")
for key in (
    "ia", "miou",
    "tooth_dice_instance", "canal_dice_instance",
    "tooth_iou_instance", "canal_iou_instance",
    "tooth_nsd_instance", "canal_nsd_instance",
    "tooth_dice_image", "canal_dice_image",
    "tooth_nsd_image", "canal_nsd_image",
):
    print(f"{key:<22}{summary[key]:>10.4f}")

ia = summary["ia"]
print("")
print(f"container IA          = {ia:.4f}")
print(f"baseline_lrfix_v2 IA  = {baseline_ia:.4f}  (L/R correction only, no teeth-FP cleanup)")
print(f"taskG-teeth-only IA   = {taskg_ia:.4f}  (L/R correction + GT-free teeth-FP cleanup -- expected floor)")

ok = True
if ia < baseline_ia - tolerance:
    print(f"FAIL: container IA {ia:.4f} is BELOW baseline_lrfix_v2 ({baseline_ia:.4f}) by more than "
          f"tolerance {tolerance:.4f} -- this is a real regression versus even the older, already-shipped fix.")
    ok = False
elif ia < taskg_ia - tolerance:
    print(f"FAIL: container IA {ia:.4f} is below taskG-teeth-only ({taskg_ia:.4f}) by more than tolerance "
          f"{tolerance:.4f} -- the container does not appear to be applying the GT-free teeth-FP cleanup step "
          "(check STSR_APPLY_LR_CORRECTION and postprocessing_pipeline.apply_postprocessing_chain wiring).")
    ok = False
else:
    print(f"PASS: container IA {ia:.4f} reproduces taskG-teeth-only's validated gain (within tolerance {tolerance:.4f}).")

sys.exit(0 if ok else 1)
PY
status=$?
set -e

echo ""
if [[ "${status}" -eq 0 ]]; then
    echo "== SUMMARY: PASS =="
else
    echo "== SUMMARY: FAIL -- see above =="
fi
exit "${status}"
