#!/usr/bin/env python3
"""Apply :func:`stsr2026.training.coord_weight_surgery.surgically_expand_input_channels`
to a real nnU-Net checkpoint file and save the result in the same
``{'network_weights': ..., ...}`` format nnU-Net's own
``load_pretrained_weights``/``save_checkpoint`` use, so it can be passed
straight to ``nnUNetv2_train ... -pretrained_weights <output>``.

GPU-independent (pure torch checkpoint surgery, no nnunetv2/CUDA needed to
run this script itself), but the input is a real GPU-trained checkpoint, so
this is meant to be run on the training box (a training box) against the real Line A
Phase B ``checkpoint_best.pth``, not in the local sandbox.

Only ``network_weights`` is edited. Every other top-level key
(``optimizer_state``, ``grad_scaler_state``, ``logging``, ``_best_ema``,
``current_epoch``, ``init_args``, ``trainer_name``,
``inference_allowed_mirroring_axes``) is copied through unchanged --
``load_pretrained_weights`` only ever reads ``network_weights``, but keeping
the rest intact costs nothing and avoids surprises if some other tool
inspects this file.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import torch

from stsr2026.training.coord_weight_surgery import surgically_expand_input_channels


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--source-checkpoint", type=Path, required=True)
    parser.add_argument("--output-checkpoint", type=Path, required=True)
    parser.add_argument("--old-in-channels", type=int, default=1)
    parser.add_argument("--new-in-channels", type=int, required=True)
    parser.add_argument("--new-channel-init", choices=["zeros", "small_random"], default="zeros")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument(
        "--no-strict",
        action="store_true",
        help="allow surgery even if the detected stem-weight alias keys do not have "
        "byte-identical values (see coord_weight_surgery.py's strict= docstring)",
    )
    args = parser.parse_args()

    checkpoint = torch.load(str(args.source_checkpoint), map_location="cpu", weights_only=False)
    if "network_weights" not in checkpoint:
        parser.error(f"{args.source_checkpoint} has no 'network_weights' key -- is this a real nnU-Net checkpoint?")

    new_weights, report = surgically_expand_input_channels(
        checkpoint["network_weights"],
        new_in_channels=args.new_in_channels,
        old_in_channels=args.old_in_channels,
        new_channel_init=args.new_channel_init,
        seed=args.seed,
        strict=not args.no_strict,
    )

    new_checkpoint = dict(checkpoint)
    new_checkpoint["network_weights"] = new_weights

    args.output_checkpoint.parent.mkdir(parents=True, exist_ok=True)
    torch.save(new_checkpoint, str(args.output_checkpoint))

    print(f"surgery report: {report}")
    print(f"edited {len(report.stem_keys)} aliased stem-weight key(s): {report.stem_keys}")
    print(f"wrote {args.output_checkpoint}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
