#!/usr/bin/env python3
"""Apply inherit_canal_labels_from_corrected_teeth to a directory of
predictions -- plan.md D7 task C.

Expects the input predictions to already have tooth classes (1-32) in their
final, corrected state (i.e. already passed through
``correct_lr_confusion``, and ideally also through
``stsr2026.inference.false_positive_cleanup.clean_false_positive_labels`` to
reduce the risk of inheriting a hallucinated tooth label -- see
``inherit_canal_labels_from_corrected_teeth``'s docstring for why this
function has no way to detect that case on its own). Canal classes (33-64)
are relabeled to (parent tooth class + 32) based on real spatial adjacency
in the volume; teeth are only ever read, never modified by this script.

Mirrors ``scripts/apply_lr_correction.py``'s structure.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import nibabel as nib
import numpy as np

from stsr2026.inference.lr_correction import (
    DEFAULT_PARENT_TOOTH_SEARCH_DILATION_VOXELS,
    inherit_canal_labels_from_corrected_teeth,
)


def _prediction_paths(input_dir: Path) -> list[Path]:
    return sorted(path for path in input_dir.iterdir() if path.name.endswith((".nii", ".nii.gz")))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("input_dir", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("--dilation-voxels", type=int, default=DEFAULT_PARENT_TOOTH_SEARCH_DILATION_VOXELS)
    parser.add_argument("--report-json", type=Path, default=None, help="if given, write every component's decision record here")
    args = parser.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)
    all_decisions: list[dict] = []
    for input_path in _prediction_paths(args.input_dir):
        image = nib.load(str(input_path))
        labels = np.asanyarray(image.dataobj)
        corrected, decisions = inherit_canal_labels_from_corrected_teeth(labels, dilation_voxels=args.dilation_voxels)
        for decision in decisions:
            all_decisions.append(
                {
                    "case": input_path.name,
                    "original_label": decision.original_label,
                    "component_voxels": decision.component_voxels,
                    "parent_tooth_class": decision.parent_tooth_class,
                    "new_label": decision.new_label,
                    "changed": decision.changed,
                    "reason": decision.reason,
                }
            )
        output_path = args.output_dir / input_path.name
        nib.save(
            nib.Nifti1Image(corrected.astype(image.get_data_dtype()), image.affine, image.header.copy()),
            str(output_path),
        )
        print(output_path)

    if args.report_json:
        args.report_json.parent.mkdir(parents=True, exist_ok=True)
        args.report_json.write_text(json.dumps(all_decisions, indent=2))
        print(f"decisions written to {args.report_json}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
