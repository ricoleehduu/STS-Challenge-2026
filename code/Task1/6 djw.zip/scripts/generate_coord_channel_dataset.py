#!/usr/bin/env python3
"""Build the 2-channel coordinate-augmented nnU-Net v2 raw dataset
(``Dataset004_STSR_Coord`` by convention) from an already-converted
1-channel dataset (``Dataset002_STSR``'s ``imagesTr``/``labelsTr``).

Reads directly from Dataset002's already-converted ``_0000.nii.gz`` files
(not the pre-conversion raw source tree) so the 30 cases fed to this
experiment are bit-identical to what Line A Phase B was actually trained on
-- no risk of a subtly different re-conversion (orientation, dtype, etc.)
sneaking in as a confound. For each case this script:

1. Copies (via symlink where possible, matching this repo's existing
   ``evaluate_checkpoint.py:_link_or_copy_subset`` convention for large
   CBCT volumes) the original image to ``<case>_0000.nii.gz``.
2. Generates the coordinate channel(s) via
   ``stsr2026.training.coord_channel.generate_coord_channel_file`` and
   writes them as ``<case>_0001.nii.gz`` (and ``_0002``/``_0003`` if
   ``--axes xyz`` is requested -- see that function's docstring for why a
   4D file is not used here).
3. Copies (symlinks) the label file unchanged.
4. Writes ``dataset.json`` with the extra ``channel_names`` entries and the
   same 65-class label dict as Dataset002 (``stsr2026.data.convert``'s
   ``nnunet_dataset_json``, reused unmodified so the label taxonomy cannot
   drift between the two datasets).
"""
from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from stsr2026.data.convert import nnunet_dataset_json
from stsr2026.training.coord_channel import AXIS_ROW_BY_NAME, generate_coord_channel_file

_AXIS_CHANNEL_NAME = {"x": "CoordX", "y": "CoordY", "z": "CoordZ"}


def _link_or_copy(source: Path, target: Path) -> None:
    if target.exists() or target.is_symlink():
        return
    target.parent.mkdir(parents=True, exist_ok=True)
    try:
        target.symlink_to(source.resolve())
    except OSError:
        shutil.copyfile(source, target)


def _case_ids_from_dataset002_images(images002_dir: Path) -> list[str]:
    suffix = "_0000.nii.gz"
    case_ids = sorted(
        p.name[: -len(suffix)] for p in images002_dir.iterdir() if p.name.endswith(suffix)
    )
    if not case_ids:
        raise SystemExit(f"no *_0000.nii.gz files found under {images002_dir}")
    return case_ids


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--images002-dir", type=Path, required=True, help="Dataset002_STSR/imagesTr")
    parser.add_argument("--labels002-dir", type=Path, required=True, help="Dataset002_STSR/labelsTr")
    parser.add_argument("--output-dir", type=Path, required=True, help="new dataset root, e.g. .../Dataset004_STSR_Coord")
    parser.add_argument(
        "--axes",
        default="x",
        help="which coordinate axes to add as extra channels, any subset of 'xyz' "
        "in order (default: 'x' only -- see plan.md's reasoning for why the LR-axis "
        "alone is expected to have the highest signal-to-noise; pass 'xyz' for the "
        "3-axis ablation)",
    )
    parser.add_argument("--case-ids", nargs="+", default=None, help="restrict to these case IDs (e.g. smoke test)")
    args = parser.parse_args()

    for axis in args.axes:
        if axis not in AXIS_ROW_BY_NAME:
            parser.error(f"--axes contains {axis!r}, must be a subset of 'xyz'")

    case_ids = args.case_ids or _case_ids_from_dataset002_images(args.images002_dir)

    images_out = args.output_dir / "imagesTr"
    labels_out = args.output_dir / "labelsTr"
    images_out.mkdir(parents=True, exist_ok=True)
    labels_out.mkdir(parents=True, exist_ok=True)

    for case_id in case_ids:
        source_image = args.images002_dir / f"{case_id}_0000.nii.gz"
        source_label = args.labels002_dir / f"{case_id}.nii.gz"
        if not source_image.is_file():
            raise SystemExit(f"missing image for {case_id}: {source_image}")
        if not source_label.is_file():
            raise SystemExit(f"missing label for {case_id}: {source_label}")

        _link_or_copy(source_image, images_out / f"{case_id}_0000.nii.gz")
        _link_or_copy(source_label, labels_out / f"{case_id}.nii.gz")

        for channel_index, axis in enumerate(args.axes, start=1):
            out_path = images_out / f"{case_id}_{channel_index:04d}.nii.gz"
            if out_path.exists():
                continue
            generate_coord_channel_file(source_image, out_path, axes=axis)

    dataset_json = nnunet_dataset_json(num_training=len(case_ids), file_ending=".nii.gz")
    channel_names = {"0": "CBCT"}
    for channel_index, axis in enumerate(args.axes, start=1):
        channel_names[str(channel_index)] = _AXIS_CHANNEL_NAME[axis]
    dataset_json["channel_names"] = channel_names
    (args.output_dir / "dataset.json").write_text(json.dumps(dataset_json, indent=2) + "\n")

    print(f"wrote {len(case_ids)} case(s), {len(args.axes)} extra coordinate channel(s) ({args.axes}) to {args.output_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
