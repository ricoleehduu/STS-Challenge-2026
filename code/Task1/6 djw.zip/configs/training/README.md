# Training configurations

存放监督基线、伪标签微调和消融实验配置。配置中不得包含密码或远程存储凭据。

- `nnUNetPlansBigMem_3d_fullres_architecture.json`：提交所用 `nnUNetPlansBigMem` 计划的**架构部分**，供 `scripts/count_model_cost.py` 复现论文中的参数量与 FLOPs。完整 nnU-Net 计划里由数据推导出的字段（前景强度统计、中位图像尺寸与间距、归一化与重采样设置）已刻意剔除——那些来自挑战赛数据，本仓库不转发。完整计划可用 `nnUNetv2_plan_and_preprocess -gpu_memory_target 12 -overwrite_plans_name nnUNetPlansBigMem` 重新生成。
