# Inference configurations

存放滑窗、TTA、后处理、超时和资源限制配置。最终配置必须以官方 RTX 3090 24GB 环境为准。

