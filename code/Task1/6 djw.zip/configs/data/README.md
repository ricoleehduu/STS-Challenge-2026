# Data configurations

存放数据集路径映射、nnU-Net dataset JSON 模板以及固定 train/validation split。

