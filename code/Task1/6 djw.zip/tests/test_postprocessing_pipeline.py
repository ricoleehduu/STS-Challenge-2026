from __future__ import annotations

from pathlib import Path

import nibabel as nib
import numpy as np

from stsr2026.inference.postprocessing_pipeline import (
    apply_postprocessing_chain,
    apply_postprocessing_to_prediction_file,
)

AFFINE = np.eye(4)


def _volume(shape: tuple[int, int, int] = (10, 6, 4)) -> np.ndarray:
    return np.zeros(shape, dtype=np.uint8)


def _block(volume: np.ndarray, x: int, label: int, *, y: int = 1, shape: tuple[int, int, int] = (2, 2, 2)) -> None:
    volume[x : x + shape[0], y : y + shape[1], 1 : 1 + shape[2]] = label


# ---------------------------------------------------------------------------
# apply_postprocessing_chain (in-memory array)
# ---------------------------------------------------------------------------


def test_step1_always_applies_tooth_lr_correction() -> None:
    volume = _volume()
    _block(volume, 1, 1)  # Q1 (right) reference tooth
    _block(volume, 7, 9)  # Q2 (left) reference tooth
    _block(volume, 2, 11)  # mislabeled: class 11 (Q2/left) sitting on the right side

    corrected = apply_postprocessing_chain(volume, AFFINE, gt_labels=None)

    assert np.all(corrected[2:4, 1:3, 1:3] == 3)  # flipped by correct_lr_confusion


def test_step3_gt_informed_cleanup_skipped_when_gt_labels_is_none() -> None:
    """The honest default for a real Docker call site (no real GT
    available): step 3 (GT-informed false-positive cleanup/relabel) never
    runs when ``gt_labels=None``. Step 1 and step 2 (GT-free teeth-FP,
    tested separately below) still run, but this particular volume is too
    sparse to trigger any of step 2's GT-free signals (no duplicate
    sibling, no same-quadrant engulfing neighbour, and too few same-category
    peer components for the isolation check) -- so the lone small blip
    correctly survives untouched, for a different reason than "nothing ran
    at all"."""
    volume = _volume()
    _block(volume, 1, 1)
    _block(volume, 7, 9)
    volume[5, 1, 1] = 20  # tiny false-positive-looking blip, not in any gt_labels

    corrected = apply_postprocessing_chain(volume, AFFINE, gt_labels=None)

    assert corrected[5, 1, 1] == 20  # untouched -- no GT-free signal fires, step 3 never ran


def test_step3_gt_informed_cleanup_applies_when_gt_labels_given() -> None:
    volume = _volume()
    _block(volume, 1, 1)
    _block(volume, 7, 9)
    volume[5, 1, 1] = 20  # false positive: not in gt_labels, below volume_threshold

    corrected = apply_postprocessing_chain(volume, AFFINE, gt_labels={1, 9}, volume_threshold=100)

    assert corrected[5, 1, 1] == 0  # cleared by step 3


# ---------------------------------------------------------------------------
# Step 2: GT-free teeth-only false-positive cleanup (D7 Day1 follow-up,
# real-data validated as taskG-teeth-only). Always runs, even with
# gt_labels=None -- this is the new production-shippable half of the gap
# documented in this module's docstring.
# ---------------------------------------------------------------------------


def test_step2_gtfree_teeth_fp_cleanup_applies_with_gt_labels_none() -> None:
    """A duplicate same-tooth-label component (a small, spatially separated
    extra blob under a label that already has a real, much larger primary
    component) is cleared by step 2 -- WITHOUT any gt_labels at all. This is
    the exact "duplicate_component" signal pattern validated in
    tests/test_gtfree_false_positive_cleanup.py."""
    volume = np.zeros((30, 10, 10), dtype=np.uint8)
    volume[0:5, 0:5, 0:5] = 21  # primary tooth component, 125 voxels
    volume[20, 0, 0] = 21  # duplicate, 1 voxel, far away, same tooth label

    corrected = apply_postprocessing_chain(volume, AFFINE, gt_labels=None, volume_threshold=50)

    assert np.all(corrected[0:5, 0:5, 0:5] == 21)  # primary untouched
    assert corrected[20, 0, 0] == 0  # duplicate cleared by step 2, no GT needed


def test_step2_gtfree_cleanup_never_touches_canal_labels() -> None:
    """The exact same duplicate-component pattern, but under a CANAL label
    (33-64) instead of a tooth label, must survive completely untouched --
    step 2 is pinned to clean_classes="teeth" specifically because a real
    6-case holdout run with canals eligible cratered canal Dice_Instance/NSD
    (see postprocessing_pipeline's module docstring and
    docs/research/08-gtfree-fp-cleanup-design.md's "REAL-DATA FINDING")."""
    volume = np.zeros((30, 10, 10), dtype=np.uint8)
    volume[0:5, 0:5, 0:5] = 40  # primary canal component, 125 voxels
    volume[20, 0, 0] = 40  # would-be "duplicate" under teeth-eligible rules, 1 voxel, same canal label

    corrected = apply_postprocessing_chain(volume, AFFINE, gt_labels=None, volume_threshold=50)

    assert np.all(corrected[0:5, 0:5, 0:5] == 40)  # primary untouched
    assert corrected[20, 0, 0] == 40  # canal "duplicate" NOT cleared -- canals are categorically excluded


def test_step2_applies_before_step3_when_gt_labels_also_given() -> None:
    """Composition: step 2's GT-free teeth cleanup and step 3's GT-informed
    cleanup are not mutually exclusive -- when gt_labels IS given (offline
    eval), step 2 still runs first (GT-free duplicate clearing), then step 3
    runs on the already-step-2-cleaned volume."""
    volume = np.zeros((30, 10, 10), dtype=np.uint8)
    volume[0:5, 0:5, 0:5] = 21  # primary tooth component, 125 voxels, real (in gt_labels)
    volume[20, 0, 0] = 21  # GT-free duplicate, 1 voxel -- cleared by step 2 regardless of gt_labels
    volume[25, 0, 0] = 30  # separate false positive, not in gt_labels, cleared by step 3

    corrected = apply_postprocessing_chain(volume, AFFINE, gt_labels={21}, volume_threshold=50)

    assert np.all(corrected[0:5, 0:5, 0:5] == 21)  # real primary, untouched
    assert corrected[20, 0, 0] == 0  # cleared by step 2 (GT-free duplicate signal)
    assert corrected[25, 0, 0] == 0  # cleared by step 3 (GT-informed, label 30 not in gt_labels)


def test_steps_compose_lr_correction_then_cleanup() -> None:
    """Order matters: step 2's false-positive screening must see the
    ALREADY tooth-corrected volume, not the raw one."""
    volume = _volume()
    _block(volume, 1, 1)
    _block(volume, 7, 9)
    _block(volume, 2, 11)  # mislabeled tooth, corrected by step 1 to class 3

    # gt_labels includes 3 (the corrected value) but not 11 (the original,
    # wrong value) -- if step 2 ran on the UNCORRECTED volume it would treat
    # this component as a false positive (11 not in gt_labels) and clear it;
    # since it runs after step 1, it must see class 3 (in gt_labels) and
    # leave it alone.
    corrected = apply_postprocessing_chain(volume, AFFINE, gt_labels={1, 9, 3}, volume_threshold=1)

    assert np.all(corrected[2:4, 1:3, 1:3] == 3)


# ---------------------------------------------------------------------------
# apply_postprocessing_to_prediction_file (file I/O)
# ---------------------------------------------------------------------------


def test_file_rewritten_when_something_changes(tmp_path: Path) -> None:
    volume = _volume()
    _block(volume, 1, 1)
    _block(volume, 7, 9)
    _block(volume, 2, 11)  # mislabeled, step 1 will flip it
    path = tmp_path / "case.nii.gz"
    nib.save(nib.Nifti1Image(volume, AFFINE), str(path))
    original_mtime = path.stat().st_mtime_ns

    changed = apply_postprocessing_to_prediction_file(path)

    assert changed is True
    reloaded = np.asanyarray(nib.load(str(path)).dataobj)
    assert np.all(reloaded[2:4, 1:3, 1:3] == 3)
    assert path.stat().st_mtime_ns >= original_mtime


def test_file_not_rewritten_when_nothing_changes(tmp_path: Path) -> None:
    volume = _volume()
    _block(volume, 1, 1)  # already correctly labeled, nothing for step 1 to flip
    path = tmp_path / "case.nii.gz"
    nib.save(nib.Nifti1Image(volume, AFFINE), str(path))

    changed = apply_postprocessing_to_prediction_file(path, gt_labels=None)

    assert changed is False
    reloaded = np.asanyarray(nib.load(str(path)).dataobj)
    assert np.array_equal(reloaded, volume)


def test_file_dtype_preserved(tmp_path: Path) -> None:
    volume = _volume()
    _block(volume, 1, 1)
    _block(volume, 7, 9)
    _block(volume, 2, 11)
    path = tmp_path / "case.nii.gz"
    nib.save(nib.Nifti1Image(volume, AFFINE), str(path))
    assert nib.load(str(path)).get_data_dtype() == np.uint8

    apply_postprocessing_to_prediction_file(path)

    assert nib.load(str(path)).get_data_dtype() == np.uint8


def test_file_with_gt_labels_and_threshold_passthrough(tmp_path: Path) -> None:
    volume = _volume()
    _block(volume, 1, 1)
    _block(volume, 7, 9)
    volume[5, 1, 1] = 20  # false positive
    path = tmp_path / "case.nii.gz"
    nib.save(nib.Nifti1Image(volume, AFFINE), str(path))

    changed = apply_postprocessing_to_prediction_file(path, gt_labels={1, 9}, volume_threshold=100)

    assert changed is True
    reloaded = np.asanyarray(nib.load(str(path)).dataobj)
    assert reloaded[5, 1, 1] == 0
