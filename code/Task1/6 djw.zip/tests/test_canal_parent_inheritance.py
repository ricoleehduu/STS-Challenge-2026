from __future__ import annotations

import numpy as np

from stsr2026.inference.lr_correction import (
    MIN_COMPONENT_VOXELS,
    inherit_canal_labels_from_corrected_teeth,
)


def _volume(shape: tuple[int, int, int] = (14, 6, 4)) -> np.ndarray:
    return np.zeros(shape, dtype=np.int64)


def _block(volume: np.ndarray, x: slice, label: int, y: slice = slice(1, 4), z: slice = slice(1, 3)) -> None:
    volume[x, y, z] = label


def test_inherit_canal_labels_normal_case() -> None:
    """Canal sits right next to tooth class 5 but was predicted under a
    wrong/unrelated canal class (41, which naively maps to tooth 9) -- must
    be relabeled to 5 + 32 = 37 based on real spatial adjacency, not the
    naive canal_label - 32 mapping."""
    volume = _volume()
    _block(volume, slice(0, 4), 5)  # parent tooth, class 5
    _block(volume, slice(4, 6), 41)  # canal touching it, mislabeled as class 41

    corrected, decisions = inherit_canal_labels_from_corrected_teeth(volume)

    assert np.all(corrected[4:6, 1:4, 1:3] == 37)
    assert len(decisions) == 1
    d = decisions[0]
    assert d.original_label == 41
    assert d.parent_tooth_class == 5
    assert d.new_label == 37
    assert d.changed is True


def test_inherit_canal_no_parent_found_left_unchanged() -> None:
    """A canal component with no tooth label anywhere in its dilated
    neighbourhood must be left exactly as-is (not deleted, not guessed)."""
    volume = _volume()
    _block(volume, slice(6, 8), 41)  # floating canal, nothing nearby

    corrected, decisions = inherit_canal_labels_from_corrected_teeth(volume)

    assert np.array_equal(corrected, volume)
    assert len(decisions) == 1
    d = decisions[0]
    assert d.parent_tooth_class is None
    assert d.changed is False
    assert d.new_label == 41
    assert "no tooth label found" in d.reason


def test_inherit_canal_picks_larger_overlap_when_two_teeth_nearby() -> None:
    """Canal component touching two different tooth classes in its dilated
    neighbourhood must pick whichever tooth has the larger touching voxel
    count, not an arbitrary or first-seen one."""
    volume = _volume((14, 10, 4))
    # Small tooth (class 3) on one side of the canal...
    volume[4:6, 0:1, 1:3] = 3  # 4 voxels touching
    # ...and a bigger tooth (class 20) on the other side.
    volume[4:6, 8:10, 1:3] = 20  # 4 voxels touching -- make it bigger below
    volume[4:6, 6:10, 1:3] = 20  # overwrite -> 16 voxels touching, clearly larger
    volume[6:8, 1:9, 1:3] = 41  # canal component spanning between both, touches both after dilation

    corrected, decisions = inherit_canal_labels_from_corrected_teeth(volume, dilation_voxels=2)

    assert len(decisions) == 1
    d = decisions[0]
    assert d.parent_tooth_class == 20  # the tooth with more touching voxels
    assert d.new_label == 52


def test_inherit_canal_already_matches_parent_reports_unchanged() -> None:
    volume = _volume()
    _block(volume, slice(0, 4), 5)  # tooth class 5
    _block(volume, slice(4, 6), 37)  # canal already correctly labeled (5 + 32)

    corrected, decisions = inherit_canal_labels_from_corrected_teeth(volume)

    assert np.array_equal(corrected, volume)
    d = decisions[0]
    assert d.parent_tooth_class == 5
    assert d.new_label == 37
    assert d.changed is False
    assert "already matched" in d.reason


def test_inherit_canal_component_below_min_voxels_skipped() -> None:
    volume = _volume()
    _block(volume, slice(0, 4), 5)  # real tooth right there
    volume[4, 1, 1] = 41  # 1-voxel canal noise blip, below MIN_COMPONENT_VOXELS
    assert np.count_nonzero(volume == 41) == 1 < MIN_COMPONENT_VOXELS

    corrected, decisions = inherit_canal_labels_from_corrected_teeth(volume)

    assert np.array_equal(corrected, volume)
    d = decisions[0]
    assert d.parent_tooth_class is None
    assert d.changed is False
    assert "MIN_COMPONENT_VOXELS" in d.reason


def test_inherit_canal_follows_already_corrected_tooth_label() -> None:
    """The function must only ever read whatever tooth class is ALREADY in
    the volume (i.e. post correct_lr_confusion) -- simulate a tooth that
    was flipped by the LR-correction step (e.g. from 9 to 1) and confirm the
    canal inherits the flipped value (1 -> canal 33), not the naive
    pre-correction mapping."""
    volume = _volume()
    _block(volume, slice(0, 4), 1)  # tooth already corrected from 9 -> 1
    _block(volume, slice(4, 6), 41)  # canal originally predicted as class 41 (naively -> tooth 9)

    corrected, decisions = inherit_canal_labels_from_corrected_teeth(volume)

    assert np.all(corrected[4:6, 1:4, 1:3] == 33)  # 1 + 32, not 9 + 32
    assert decisions[0].parent_tooth_class == 1


def test_inherit_canal_returns_new_array_and_multiple_components_independent() -> None:
    volume = _volume((14, 10, 4))
    _block(volume, slice(0, 4), 5, y=slice(0, 3))
    _block(volume, slice(4, 6), 41, y=slice(0, 3))  # inherits from tooth 5 -> 37
    _block(volume, slice(8, 12), 20, y=slice(6, 9))
    _block(volume, slice(12, 14), 33, y=slice(6, 9))  # already tooth 20 + 32 = 52? no -- mismatched on purpose
    # class 33 naively maps to tooth 1, but real neighbour is tooth 20 -> should become 52.

    corrected, decisions = inherit_canal_labels_from_corrected_teeth(volume)

    assert corrected is not volume
    assert np.all(corrected[4:6, 0:3, 1:3] == 37)
    assert np.all(corrected[12:14, 6:9, 1:3] == 52)
    assert len(decisions) == 2
