from __future__ import annotations

from stsr2026.data.split import build_holdout_split, stratify_key


def _case(case_id: str, max_intensity: float, n_labels: int) -> dict[str, object]:
    return {
        "case_id": case_id,
        "intensity_percentiles": (0.0, 0.0, 0.0, 0.0, max_intensity),
        "label_values": tuple(range(n_labels)),
    }


def test_stratify_key_flags_metal_and_completeness() -> None:
    metal_complete = _case("a", 4000.0, 60)
    clean_sparse = _case("b", 100.0, 5)
    assert stratify_key(metal_complete) == (True, True)
    assert stratify_key(clean_sparse) == (False, False)


def test_build_holdout_split_covers_all_cases_without_overlap() -> None:
    cases = [_case(f"case_{i:03d}", 4000.0 if i % 3 == 0 else 100.0, 60 if i % 2 == 0 else 5) for i in range(31)]
    split = build_holdout_split(cases, val_fraction=0.2, seed=42)

    assert set(split["train"]) | set(split["val"]) == {c["case_id"] for c in cases}
    assert not set(split["train"]) & set(split["val"])
    assert len(split["val"]) == 6


def test_build_holdout_split_is_deterministic() -> None:
    cases = [_case(f"case_{i:03d}", 100.0, 5) for i in range(10)]
    first = build_holdout_split(cases, seed=7)
    second = build_holdout_split(cases, seed=7)
    assert first == second


def test_build_holdout_split_handles_tiny_dataset() -> None:
    cases = [_case("only", 100.0, 5)]
    split = build_holdout_split(cases, val_fraction=0.2, seed=1)
    assert split == {"train": [], "val": ["only"]}
