"""Tests for the GT canal<->tooth pairing audit.

These use synthetic volumes with hand-placed cuboids, so the expected verdict
is known by construction -- the point is to pin the classification logic and
the quadrant-mirror mapping, not to re-measure the real dataset (that number
lives in docs/research/07-canal-label-convention-inconsistency.md).
"""
from __future__ import annotations

import numpy as np
import pytest

from stsr2026.data.canal_pairing import (
    CanalPairing,
    Pairing,
    audit_case,
    identity_rate,
    mirror_tooth_class,
)


def test_mirror_tooth_class_pairs_quadrants_by_slot():
    # Q1 (1-8) <-> Q2 (9-16), preserving slot offset
    assert mirror_tooth_class(1) == 9
    assert mirror_tooth_class(8) == 16
    assert mirror_tooth_class(9) == 1
    assert mirror_tooth_class(16) == 8
    # Q3 (17-24) <-> Q4 (25-32); polarity of the pair constant is flipped for
    # the lower jaw, which this must survive
    assert mirror_tooth_class(17) == 25
    assert mirror_tooth_class(24) == 32
    assert mirror_tooth_class(25) == 17
    assert mirror_tooth_class(32) == 24


def test_mirror_tooth_class_is_an_involution():
    for tooth in range(1, 33):
        assert mirror_tooth_class(mirror_tooth_class(tooth)) == tooth


@pytest.mark.parametrize("bad", [0, 33, 64, -1])
def test_mirror_tooth_class_rejects_non_tooth_classes(bad):
    with pytest.raises(ValueError):
        mirror_tooth_class(bad)


def _volume_with(tooth_class: int, tooth_slice, canal_class: int, canal_slice,
                 other: dict[int, tuple] | None = None) -> np.ndarray:
    volume = np.zeros((40, 40, 40), dtype=np.uint8)
    volume[tooth_slice] = tooth_class
    volume[canal_slice] = canal_class
    for cls, sl in (other or {}).items():
        volume[sl] = cls
    return volume


def test_canal_inside_its_own_parent_is_identity():
    # canal 33's assumed parent is tooth 1; put the canal inside tooth 1's bbox.
    # The canal voxels are carved out of the tooth (GT tooth masks exclude the
    # pulp cavity), so this also covers the voxel-disjoint-but-bbox-interior case.
    volume = _volume_with(1, np.s_[5:15, 5:15, 5:25], 33, np.s_[8:11, 8:11, 8:22])
    (result,) = audit_case(volume)
    assert result.pairing is Pairing.IDENTITY
    assert result.canal_class == 33
    assert result.assumed_parent == 1
    assert result.matched_tooth == 1
    assert result.containment == pytest.approx(1.0)


def test_canal_inside_the_contralateral_tooth_is_swapped():
    # canal 33 (assumed parent tooth 1) actually sits inside tooth 9 -- the
    # real-data failure mode this module exists to detect.
    volume = _volume_with(
        9, np.s_[25:35, 5:15, 5:25], 33, np.s_[28:31, 8:11, 8:22],
        other={1: np.s_[5:15, 5:15, 5:25]},
    )
    (result,) = audit_case(volume)
    assert result.pairing is Pairing.SWAPPED
    assert result.matched_tooth == 9


def test_canal_inside_an_unrelated_tooth_is_other():
    # tooth 5 is neither tooth 1 nor its mirror (tooth 9)
    volume = _volume_with(
        5, np.s_[25:35, 5:15, 5:25], 33, np.s_[28:31, 8:11, 8:22],
        other={1: np.s_[5:15, 5:15, 5:25]},
    )
    (result,) = audit_case(volume)
    assert result.pairing is Pairing.OTHER
    assert result.matched_tooth == 5


def test_canal_outside_every_tooth_is_unmatched():
    volume = np.zeros((40, 40, 40), dtype=np.uint8)
    volume[5:15, 5:15, 5:15] = 1
    volume[30:35, 30:35, 30:35] = 33  # far from any tooth bbox
    (result,) = audit_case(volume)
    assert result.pairing is Pairing.UNMATCHED
    assert result.matched_tooth is None


def test_lower_jaw_swap_uses_the_flipped_quadrant_polarity():
    # canal 57 -> assumed tooth 25 (Q4); its mirror is tooth 17 (Q3). This is
    # the pair whose right/left polarity is inverted in the source constant,
    # so a naive "+8" mirror would get it wrong.
    volume = _volume_with(
        17, np.s_[25:35, 5:15, 5:25], 57, np.s_[28:31, 8:11, 8:22],
        other={25: np.s_[5:15, 5:15, 5:25]},
    )
    (result,) = audit_case(volume)
    assert result.assumed_parent == 25
    assert result.pairing is Pairing.SWAPPED
    assert result.matched_tooth == 17


def test_audit_case_skips_absent_classes():
    volume = np.zeros((20, 20, 20), dtype=np.uint8)
    volume[2:8, 2:8, 2:8] = 1
    assert audit_case(volume) == []


def test_identity_rate_counts_only_identity():
    pairings = [
        CanalPairing(33, 1, 1, 1.0, Pairing.IDENTITY),
        CanalPairing(34, 2, 10, 1.0, Pairing.SWAPPED),
        CanalPairing(35, 3, 7, 1.0, Pairing.OTHER),
        CanalPairing(36, 4, None, 0.0, Pairing.UNMATCHED),
    ]
    assert identity_rate(pairings) == pytest.approx(0.25)


def test_identity_rate_of_nothing_is_nan():
    assert np.isnan(identity_rate([]))
