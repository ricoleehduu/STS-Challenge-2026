from __future__ import annotations

import numpy as np
import pytest

from stsr2026.inference.hungarian_instance_assignment import (
    assign_instances_to_fdi_slots,
    _category_distance_scale,
)
from stsr2026.inference.lr_correction import correct_lr_confusion

AFFINE = np.eye(4)
MID = 20
# Every position in _full_arch() is a 1-voxel-thick-along-x block, see
# _full_arch's docstring for why -- kept as a module constant so every test
# that relabels/clears a specific position's footprint uses the exact same
# shape rather than risking a silent mismatch against a hand-written slice.
_POSITION_SHAPE = (1, 3, 2)


def _block(volume: np.ndarray, x: int, label: int, *, y: int = 1, shape: tuple[int, int, int] = (2, 2, 2)) -> None:
    volume[x : x + shape[0], y : y + shape[1], 1 : 1 + shape[2]] = label


def _position_x(k: int) -> int:
    """The x placement _full_arch uses for tooth position k (1-8) of Q1
    (the +x quadrant). Q2 (the -x quadrant) mirrors this at ``MID - 2*k - 2``."""
    return MID + 2 * k


def _relabel_position(volume: np.ndarray, x: int, new_label: int) -> None:
    """Overwrite exactly one _full_arch position's footprint with a new
    label -- used to build "mislabeled" scenarios without duplicating
    ``_POSITION_SHAPE`` bounds at every call site."""
    _block(volume, x, new_label, shape=_POSITION_SHAPE)


def _full_arch(shape: tuple[int, int, int] = (70, 8, 6)) -> np.ndarray:
    """A symmetric, fully-populated two-quadrant arch (Q1 = tooth classes
    1-8 on the +x side of MID, Q2 = classes 9-16 mirrored on the -x side),
    each position k placed at distance 2*k from MID -- i.e. every
    connected component already sits at its own geometrically-correct,
    linearly-spaced position. This is the "everything already correct, no
    changes expected" reference volume most tests start from.

    Blocks are 1-voxel-thick along x (``_POSITION_SHAPE`` = (1, 3, 2), 6
    voxels total, above ``MIN_COMPONENT_VOXELS``) so each component's
    centroid_x lands exactly on its placement coordinate with no +0.5
    offset -- an earlier version used a symmetric (2, 2, 2) block, whose
    centroid sits half a voxel off its nominal x, which combined with the
    distance scale being computed from the single farthest raw voxel (not a
    centroid) produced small but nonzero costs even for an
    "everything already correct" arch. That turned out to be a test-fixture
    precision artifact, not an algorithm bug, but this shape avoids it so
    the exact-zero-cost assertions below are clean.
    """
    volume = np.zeros(shape, dtype=np.uint8)
    for k in range(1, 9):
        _relabel_position(volume, _position_x(k), k)
    for k in range(1, 9):
        _relabel_position(volume, MID - 2 * k - 2, 8 + k)
    return volume


def _tooth_matches(result, quadrant_index: int = 0):
    return [m for m in result.matched if m.category == "tooth" and m.quadrant_index == quadrant_index]


# ---------------------------------------------------------------------------
# Baseline: everything already correctly ordered and labeled -> no-op.
# ---------------------------------------------------------------------------


def test_no_op_when_already_correctly_ordered_and_labeled() -> None:
    """Every position in ``_full_arch()`` already sits at its own linearly-
    spaced, correctly-labeled spot. The costs are not exactly 0 (the
    discrete 2-voxel-per-step spacing this fixture uses doesn't land
    exactly on the (p-1)/7 canonical slot grid for every position -- a
    fixture-geometry artifact, not an algorithm property), but the real
    invariant this module must guarantee -- nothing gets relabeled when
    nothing is actually wrong -- must hold regardless.
    """
    volume = _full_arch()
    result = assign_instances_to_fdi_slots(volume, AFFINE)

    assert all(not m.changed for m in result.matched)
    assert all(m.new_label == m.original_label for m in result.matched)
    assert result.unmatched_candidates == ()
    assert np.array_equal(result.output_volume, volume)
    assert result.output_volume is not volume  # always a new array, even when unchanged


# ---------------------------------------------------------------------------
# Normal optimal matching: a severe order violation gets corrected.
# ---------------------------------------------------------------------------


def test_severe_order_violation_gets_corrected_with_relaxed_threshold() -> None:
    """Swap the two extreme positions (1 <-> 8) of one quadrant -- a
    displacement far larger than the "duplicate under an adjacent FDI
    position" failure mode this module targets. With a relaxed
    reject_cost_threshold (so the joint-optimum's marginal cost for this
    particular synthetic geometry clears the bar -- see the "boundary
    case" test below for what happens at the default threshold), both
    sides of the swap should be corrected by the joint solve.
    """
    volume = _full_arch()
    _relabel_position(volume, _position_x(1), 8)  # position 1's spot mislabeled as class 8
    _relabel_position(volume, _position_x(8), 1)  # position 8's spot mislabeled as class 1

    result = assign_instances_to_fdi_slots(volume, AFFINE, reject_cost_threshold=0.6)

    changed = {(m.original_label, m.new_label) for m in result.matched if m.changed}
    assert changed == {(1, 8), (8, 1)}
    assert result.unmatched_candidates == ()


def test_boundary_case_default_threshold_only_fixes_the_cheaper_side() -> None:
    """Same swapped-extremes volume as above, but at the DEFAULT
    reject_cost_threshold (0.5). This is a real, checked property of this
    synthetic geometry (not a hand-picked pass/fail): the true joint
    Hungarian optimum for this 8x8 group prices the two directions of a
    "symmetric" swap *differently* (whichever pair is cheaper "steals" the
    other's best option in the joint solve) -- close enough to the default
    threshold that exactly one direction clears it and the other doesn't.
    Rather than hardcode the exact literal costs (sensitive to this
    fixture's precise voxel spacing), this test recomputes the expected
    outcome from the audited ``cost_matrices`` the function itself returns
    and checks the accept/reject decision is consistent with them --
    i.e. it tests the *rule* (accept iff cost <= threshold, and a rejected
    pair leaves both sides unmatched), not a specific fixture-dependent
    number.
    """
    volume = _full_arch()
    _relabel_position(volume, _position_x(1), 8)
    _relabel_position(volume, _position_x(8), 1)

    result = assign_instances_to_fdi_slots(volume, AFFINE)

    changed = [m for m in result.matched if m.changed]
    assert len(changed) == 1  # exactly one direction of the swap clears the default threshold
    fixed = changed[0]
    assert {fixed.original_label, fixed.new_label} == {1, 8}
    assert fixed.total_cost <= 0.5

    cost_matrix = result.cost_matrices[("tooth", 0)]
    assert cost_matrix.min() <= 0.5  # the accepted pair really was the group's cheapest real option
    # the OTHER original label of the swap pair (whichever didn't get fixed) is left unmatched
    other_label = 8 if fixed.original_label == 1 else 1
    unmatched_labels = {u.original_label for u in result.unmatched_candidates if u.category == "tooth"}
    assert other_label in unmatched_labels
    empty_tooth_q0 = [e for e in result.empty_slots if e.category == "tooth" and e.quadrant_index == 0]
    assert len(empty_tooth_q0) == 1


def test_very_low_threshold_rejects_every_match() -> None:
    volume = _full_arch()
    _relabel_position(volume, _position_x(1), 8)
    _relabel_position(volume, _position_x(8), 1)

    result = assign_instances_to_fdi_slots(volume, AFFINE, reject_cost_threshold=0.001)

    assert all(not m.changed for m in result.matched)  # every accepted pair must have been free (cost 0)
    assert np.array_equal(result.output_volume, volume)


# ---------------------------------------------------------------------------
# Small adjacent-position swaps are NOT corrected by the default weights --
# a real, load-bearing calibration property, not an oversight.
# ---------------------------------------------------------------------------


def test_single_adjacent_position_swap_not_corrected_by_default_weights() -> None:
    """Swap only positions 3 and 4 (a single adjacent pair, the failure
    mode false_positive_cleanup.py's docstring describes as "duplicate
    under an adjacent FDI position"). With the default weights
    (order_weight=0.6, label_mismatch_cost=0.4), the label-consistency
    term dominates a single-step order perturbation (cost ~0.6 * 1/7 =~
    0.086 to relabel vs 0.4 to keep the existing, slightly-out-of-order
    label) -- so this module's default configuration deliberately does
    NOT correct a lone adjacent swap. This is checked, not assumed:
    real-data validation (see this module's development notes) is
    required before concluding whether the defaults or a more
    order-weighted configuration is the better real-world choice; this
    test documents current, exact default behaviour so a future change to
    the defaults is a conscious decision, not a silent regression.
    """
    volume = _full_arch()
    _relabel_position(volume, _position_x(3), 4)  # position 3's spot mislabeled as class 4
    _relabel_position(volume, _position_x(4), 3)  # position 4's spot mislabeled as class 3

    result = assign_instances_to_fdi_slots(volume, AFFINE)

    assert all(not m.changed for m in result.matched)
    assert np.array_equal(result.output_volume, volume)


# ---------------------------------------------------------------------------
# Slot count < instance count: extra predicted components are left as-is.
# ---------------------------------------------------------------------------


def test_more_candidates_than_slots_leaves_extra_component_untouched() -> None:
    volume = _full_arch()
    # A second, physically separate blob under class 1 -- 8 real slots, 9
    # candidates in this one quadrant/category group.
    extra_x = _position_x(1) + 30
    _relabel_position(volume, extra_x, 1)

    result = assign_instances_to_fdi_slots(volume, AFFINE)

    matches = _tooth_matches(result)
    unmatched = [u for u in result.unmatched_candidates if u.category == "tooth" and u.quadrant_index == 0]
    assert len(matches) == 8  # every slot still gets exactly one candidate
    assert len(unmatched) == 1
    assert unmatched[0].original_label == 1
    assert unmatched[0].reason == "no_slot_capacity"
    # the extra component's own voxels are untouched (still label 1, not cleared or relabeled)
    footprint = np.s_[extra_x : extra_x + 1, 1:4, 1:3]
    assert np.all(volume[footprint] == 1)
    assert np.all(result.output_volume[footprint] == 1)


# ---------------------------------------------------------------------------
# Instance count < slot count: missing positions stay empty, nothing
# fabricated, and (critically) the present candidates are NOT corrupted by
# being forced to span the full quadrant range -- this is the real bug this
# module's synthetic testing found and fixed, see _category_distance_scale.
# ---------------------------------------------------------------------------


def _blank_positions(volume: np.ndarray, positions: range) -> None:
    for k in positions:
        x = _position_x(k)
        volume[x : x + 1, 1:4, 1:3] = 0


def test_fewer_candidates_than_slots_leaves_empty_slots_and_correct_candidates_untouched() -> None:
    volume = _full_arch()
    # Blank out positions 6-8 of Q1 -- only positions 1-5 (classes 1-5)
    # remain in that quadrant, mirroring a real "missing posterior teeth"
    # case. Q2 (classes 9-16) stays fully populated. Deliberately a
    # *moderate* imbalance (5 of 8 positions present), not the more extreme
    # "only 3 of 8 present" case -- see
    # test_missing_positions_do_not_corrupt_present_candidates_via_rank_normalization's
    # docstring for why the extreme case surfaces a second, separate real
    # finding (median-midline sensitivity) that is not what this test is
    # about.
    _blank_positions(volume, range(6, 9))

    result = assign_instances_to_fdi_slots(volume, AFFINE)

    matches = _tooth_matches(result)
    assert {(m.original_label, m.new_label, m.changed) for m in matches} == {
        (1, 1, False),
        (2, 2, False),
        (3, 3, False),
        (4, 4, False),
        (5, 5, False),
    }
    empty = [e for e in result.empty_slots if e.category == "tooth" and e.quadrant_index == 0]
    assert len(empty) == 3
    assert {e.slot_position_in_quadrant for e in empty} == {6, 7, 8}
    assert all(e.reason == "no_candidate_capacity" for e in empty)


def test_missing_positions_do_not_corrupt_present_candidates_via_rank_normalization() -> None:
    """Regression test for the real bug found during this module's own
    synthetic validation phase (see _category_distance_scale's docstring):
    an earlier implementation normalized candidate order by rank among
    only the candidates present in one quadrant, which silently assumed
    nothing was missing. With positions 1-5 present (moderate imbalance,
    see the previous test), the naive rank-based version would have
    stretched their ranks to span the full [0, 1] range and relabeled
    position 5 near slot 8. This test asserts that does NOT happen.

    NOTE ON A RELATED, SEPARATE FINDING: an even more extreme imbalance
    (only 3 of 8 Q1 positions present while Q2 stays fully populated at 8
    of 8 -- i.e. a whole quadrant almost entirely missing while its mirror
    quadrant is intact) was also tried during this module's development
    and *did* reproduce a bad relabel again, but for a different reason:
    the case-wide midline (median over all currently-labeled tooth voxels,
    same formula ``correct_lr_confusion`` already uses in production) is
    itself pulled toward whichever quadrant has more voxels when the two
    sides are this unbalanced, which then distorts the distance scale for
    the sparser side. This is a real, documented limitation of a
    median-based midline under extreme quadrant asymmetry, not fixed by
    this module (nor by ``correct_lr_confusion``, which shares the same
    midline formula) -- flagged here rather than hidden, but not covered
    by a dedicated test because a whole quadrant being almost entirely
    missing while its mirror is fully intact is a far less common real
    scenario than a handful of scattered missing teeth, and reproducing it
    reliably needs real-data validation, not further synthetic tuning.
    """
    volume = _full_arch()
    _blank_positions(volume, range(6, 9))

    result = assign_instances_to_fdi_slots(volume, AFFINE)

    for label in (1, 2, 3, 4, 5):
        match = next(m for m in _tooth_matches(result) if m.original_label == label)
        assert match.new_label == label
        assert not match.changed


# ---------------------------------------------------------------------------
# Matching cost too high -> rejected, kept as-is (not forced).
# ---------------------------------------------------------------------------


def test_all_matches_rejected_when_threshold_is_zero_and_nothing_is_free() -> None:
    volume = _full_arch()
    _relabel_position(volume, _position_x(3), 4)
    _relabel_position(volume, _position_x(4), 3)

    result = assign_instances_to_fdi_slots(volume, AFFINE, reject_cost_threshold=1e-9)

    # every candidate whose own cheapest slot costs > ~0 is rejected and kept untouched
    changed_or_moved = [m for m in result.matched if m.changed]
    assert changed_or_moved == []
    assert np.array_equal(result.output_volume, volume)


# ---------------------------------------------------------------------------
# Component below the noise floor: left untouched, not considered a candidate.
# ---------------------------------------------------------------------------


def test_too_small_component_is_skipped_and_left_untouched() -> None:
    volume = _full_arch()
    blip_x = _position_x(5) + 15
    volume[blip_x, 1, 1] = 5  # a single-voxel blip, far from the real class-5 component

    result = assign_instances_to_fdi_slots(volume, AFFINE)

    too_small = [u for u in result.unmatched_candidates if u.reason == "too_small"]
    assert len(too_small) == 1
    assert too_small[0].original_label == 5
    assert too_small[0].voxel_count == 1
    assert result.output_volume[blip_x, 1, 1] == 5  # untouched, not cleared or relabeled


# ---------------------------------------------------------------------------
# Tooth and canal groups never cross.
# ---------------------------------------------------------------------------


def test_tooth_and_canal_groups_are_never_mixed() -> None:
    volume = _full_arch()
    # Canal components at the same x positions as their would-be parent
    # teeth, correctly ordered -- offset in y (y=4 instead of the tooth
    # blocks' y=1) so the canal and tooth voxels don't collide in the same
    # volume (canal/tooth are mutually-exclusive per-voxel labels in real
    # data too, see lr_correction.py's canal-inheritance docstring).
    for k in range(1, 9):
        _block(volume, _position_x(k), 32 + k, shape=_POSITION_SHAPE, y=4)  # canal Q1, classes 33-40
    for k in range(1, 9):
        _block(volume, MID - 2 * k - 2, 40 + k, shape=_POSITION_SHAPE, y=4)  # canal Q2, classes 41-48

    result = assign_instances_to_fdi_slots(volume, AFFINE)

    tooth_new_labels = {m.new_label for m in result.matched if m.category == "tooth"}
    canal_new_labels = {m.new_label for m in result.matched if m.category == "canal"}
    assert all(1 <= label <= 32 for label in tooth_new_labels)
    assert all(33 <= label <= 64 for label in canal_new_labels)


# ---------------------------------------------------------------------------
# Composition with the already-validated correct_lr_confusion step.
# ---------------------------------------------------------------------------


def test_composes_after_correct_lr_confusion_without_reverting_its_fix() -> None:
    """Reuses lr_correction.py's own confirmed test fixture/behaviour
    (test_correct_lr_confusion_flips_upper_right_component_with_left_label)
    to build a genuine LR mismatch, runs correct_lr_confusion first (as
    this module's docstring says it must), then this module second, and
    checks the LR fix survives -- this module should not "helpfully" flip
    a small, already-correct volume back.
    """
    volume = np.zeros((10, 6, 4), dtype=np.uint8)
    _block(volume, 1, 1)
    _block(volume, 7, 9)
    _block(volume, 2, 11)  # mislabeled: class 11 (Q2/left) sitting on the right side

    step1 = correct_lr_confusion(volume, AFFINE)
    assert np.all(step1[2:4, 1:3, 1:3] == 3)  # sanity: lr_correction's own documented behaviour

    result = assign_instances_to_fdi_slots(step1, AFFINE)

    assert np.all(result.output_volume[2:4, 1:3, 1:3] == 3)  # LR fix preserved, not reverted


# ---------------------------------------------------------------------------
# Input validation.
# ---------------------------------------------------------------------------


def test_rejects_non_3d_volume() -> None:
    with pytest.raises(ValueError, match="3-dimensional"):
        assign_instances_to_fdi_slots(np.zeros((4, 4)), AFFINE)


def test_rejects_bad_affine_shape() -> None:
    with pytest.raises(ValueError, match="affine"):
        assign_instances_to_fdi_slots(np.zeros((4, 4, 4)), np.eye(3))


def test_rejects_non_positive_min_component_voxels() -> None:
    with pytest.raises(ValueError, match="min_component_voxels"):
        assign_instances_to_fdi_slots(np.zeros((4, 4, 4)), AFFINE, min_component_voxels=0)


def test_rejects_non_positive_reject_cost_threshold() -> None:
    with pytest.raises(ValueError, match="reject_cost_threshold"):
        assign_instances_to_fdi_slots(np.zeros((4, 4, 4)), AFFINE, reject_cost_threshold=0.0)


# ---------------------------------------------------------------------------
# Degenerate / edge-case volumes.
# ---------------------------------------------------------------------------


def test_empty_volume_returns_all_empty_slots_and_no_matches() -> None:
    volume = np.zeros((10, 10, 10), dtype=np.uint8)

    result = assign_instances_to_fdi_slots(volume, AFFINE)

    assert result.matched == ()
    assert result.unmatched_candidates == ()
    assert len(result.empty_slots) == 8 * 4 * 2  # 8 slots x 4 quadrants x 2 categories
    assert np.array_equal(result.output_volume, volume)


def test_category_distance_scale_is_none_for_absent_category() -> None:
    volume = _full_arch()  # teeth only, no canals
    midline_x = 20.0

    tooth_scale = _category_distance_scale(volume, AFFINE, "tooth", midline_x)
    canal_scale = _category_distance_scale(volume, AFFINE, "canal", midline_x)

    assert tooth_scale is not None and tooth_scale > 0
    assert canal_scale is None


# ---------------------------------------------------------------------------
# Cost matrices are returned for auditing, with the documented shape.
# ---------------------------------------------------------------------------


def test_cost_matrices_are_returned_with_correct_shape() -> None:
    volume = _full_arch()
    result = assign_instances_to_fdi_slots(volume, AFFINE)

    assert result.cost_matrices[("tooth", 0)].shape == (8, 8)
    assert result.cost_matrices[("tooth", 1)].shape == (8, 8)
    assert ("tooth", 2) not in result.cost_matrices  # no candidates in that quadrant -> omitted
    assert ("canal", 0) not in result.cost_matrices
