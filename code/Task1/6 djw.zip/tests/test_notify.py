from __future__ import annotations

import pytest

import stsr2026.utils.notify as notify_module
from stsr2026.utils.notify import NotifyError, send_wechat_notification


class _FakeResponse:
    def __init__(self, status_code: int, body: dict | None = None, text: str = "") -> None:
        self.status_code = status_code
        self._body = body
        self.text = text or str(body)

    def json(self) -> dict:
        if self._body is None:
            raise ValueError("no JSON body")
        return self._body


def test_send_wechat_notification_builds_expected_request(monkeypatch: pytest.MonkeyPatch) -> None:
    calls = []

    def fake_post(url, json, headers):
        calls.append((url, json, headers))
        return _FakeResponse(200, {"code": 0, "msg": "success"})

    monkeypatch.setattr(notify_module.requests, "post", fake_post)

    result = send_wechat_notification("title", "name", "content", token="tok-123")

    assert result == {"code": 0, "msg": "success"}
    assert len(calls) == 1
    url, json_body, headers = calls[0]
    assert url == notify_module.NOTIFY_URL
    assert json_body == {"title": "title", "name": "name", "content": "content"}
    assert headers == {"Authorization": "tok-123"}


def test_send_wechat_notification_uses_env_var_when_token_omitted(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(notify_module.TOKEN_ENV_VAR, "env-tok")
    seen_headers = {}

    def fake_post(url, json, headers):
        seen_headers.update(headers)
        return _FakeResponse(200, {"ok": True})

    monkeypatch.setattr(notify_module.requests, "post", fake_post)

    send_wechat_notification("t", "n", "c")

    assert seen_headers == {"Authorization": "env-tok"}


def test_send_wechat_notification_missing_token_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv(notify_module.TOKEN_ENV_VAR, raising=False)

    with pytest.raises(NotifyError, match="AUTODL_API_TOKEN"):
        send_wechat_notification("t", "n", "c")


def test_send_wechat_notification_non_200_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    def fake_post(url, json, headers):
        return _FakeResponse(500, text="internal error")

    monkeypatch.setattr(notify_module.requests, "post", fake_post)

    with pytest.raises(NotifyError, match="HTTP 500"):
        send_wechat_notification("t", "n", "c", token="tok")
