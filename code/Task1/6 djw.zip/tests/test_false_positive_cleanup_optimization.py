"""Bit-identical + performance regression tests for the GT-free teeth-only
false-positive cleanup step's optimization (crop-to-bbox instead of
full-volume ``ndimage.label``/``ndimage.find_objects``/``ndimage.binary_dilation``
calls per class/component).

``tests/_reference_snapshots/false_positive_cleanup_pre_optimization.py`` is a
frozen, byte-for-byte COPY of ``false_positive_cleanup.py`` as it existed
before this optimization (see that file's own module docstring for the
profiled bottleneck: 64 full-volume ``ndimage.label`` calls + 32 full-volume
``ndimage.find_objects`` calls on one representative synthetic ~512^3 case).
Every test here asserts the CURRENT (optimized) module produces output
bit-identical (``np.array_equal`` for the array, tuple-of-fields equality for
the decision records, since the two modules' dataclasses are distinct classes
and `==` across dataclass types is always False) to the frozen reference, on
both the GT-informed (`gt_labels=<set>`) and GT-free (`gt_labels=None`,
`GTFreeOptions`) code paths, across `clean_classes="teeth"` and `"all"`,
several `volume_threshold`s, and `identify_gtfree_fp_candidates` called
directly.

Do not "fix" the reference snapshot to match the optimized module -- the
whole point of freezing it is that it must never change, so it stays a
trustworthy independent baseline. If a legitimate behavior change is ever
needed, take a NEW frozen snapshot at that point, do not edit this one.
"""
from __future__ import annotations

import importlib.util
import sys
import time
from dataclasses import astuple
from pathlib import Path

import numpy as np
import pytest

from stsr2026.inference import false_positive_cleanup as fpc

_REFERENCE_PATH = Path(__file__).parent / "_reference_snapshots" / "false_positive_cleanup_pre_optimization.py"


def _load_reference():
    spec = importlib.util.spec_from_file_location("_fpc_reference_snapshot", _REFERENCE_PATH)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    # Must be registered in sys.modules BEFORE exec: the reference module
    # defines frozen dataclasses, and Python's dataclass machinery resolves
    # forward-referenced type annotations via sys.modules[cls.__module__],
    # which fails if the module isn't registered yet.
    sys.modules["_fpc_reference_snapshot"] = module
    spec.loader.exec_module(module)
    return module


fpc_ref = _load_reference()


def _records_as_tuples(records):
    # fpc.FalsePositiveDecision and fpc_ref.FalsePositiveDecision (same for
    # GTFreeCandidate) are independently-defined dataclasses with identical
    # fields -- dataclass `__eq__` requires `other.__class__ is self.__class__`,
    # so comparing instances of the two directly is always False regardless
    # of field values. Compare field tuples instead.
    return [astuple(r) for r in records]


def _random_volume(
    rng: np.random.Generator,
    shape: tuple[int, int, int] = (50, 50, 50),
    n_components: int = 60,
    max_class: int = 40,
) -> np.ndarray:
    volume = np.zeros(shape, dtype=np.uint8)
    for _ in range(n_components):
        cls = int(rng.integers(1, max_class + 1))
        x = int(rng.integers(0, shape[0] - 4))
        y = int(rng.integers(0, shape[1] - 4))
        z = int(rng.integers(0, shape[2] - 4))
        sx, sy, sz = (int(v) for v in rng.integers(1, 5, 3))
        volume[x : x + sx, y : y + sy, z : z + sz] = cls
    return volume


def _random_affine(rng: np.random.Generator) -> np.ndarray:
    affine = np.eye(4)
    for axis in range(3):
        affine[axis, axis] = float(rng.uniform(0.2, 0.4))
        affine[axis, 3] = float(rng.uniform(-10, 10))
    return affine


@pytest.mark.parametrize("seed", range(20))
@pytest.mark.parametrize("volume_threshold", [0, 20, 5000])
def test_gt_informed_path_matches_reference(seed: int, volume_threshold: int) -> None:
    rng = np.random.default_rng(seed)
    volume = _random_volume(rng)
    gt_labels = set(int(c) for c in rng.choice(np.arange(1, 41), size=15, replace=False))

    out_ref, rec_ref = fpc_ref.clean_or_relabel_false_positive_labels(
        volume, gt_labels, volume_threshold, dilation_voxels=2
    )
    out_opt, rec_opt = fpc.clean_or_relabel_false_positive_labels(
        volume, gt_labels, volume_threshold, dilation_voxels=2
    )

    assert np.array_equal(out_ref, out_opt)
    assert _records_as_tuples(rec_ref) == _records_as_tuples(rec_opt)


@pytest.mark.parametrize("seed", range(20))
@pytest.mark.parametrize("clean_classes", ["teeth", "all"])
@pytest.mark.parametrize("volume_threshold", [0, 20, 5000])
def test_gt_free_path_matches_reference(seed: int, clean_classes: str, volume_threshold: int) -> None:
    rng = np.random.default_rng(seed + 500)
    volume = _random_volume(rng, n_components=70, max_class=64)
    affine = _random_affine(rng)

    opts_ref = fpc_ref.GTFreeOptions(clean_classes=clean_classes)
    opts_opt = fpc.GTFreeOptions(clean_classes=clean_classes)

    out_ref, rec_ref = fpc_ref.clean_or_relabel_false_positive_labels(
        volume, None, volume_threshold, dilation_voxels=2, affine=affine, gtfree_options=opts_ref
    )
    out_opt, rec_opt = fpc.clean_or_relabel_false_positive_labels(
        volume, None, volume_threshold, dilation_voxels=2, affine=affine, gtfree_options=opts_opt
    )

    assert np.array_equal(out_ref, out_opt)
    assert _records_as_tuples(rec_ref) == _records_as_tuples(rec_opt)


@pytest.mark.parametrize("seed", range(10))
@pytest.mark.parametrize("use_ot_dustbin_signal", [False, True])
def test_identify_gtfree_fp_candidates_matches_reference(seed: int, use_ot_dustbin_signal: bool) -> None:
    rng = np.random.default_rng(seed + 900)
    volume = _random_volume(rng, n_components=70, max_class=64)
    affine = _random_affine(rng)

    opts_ref = fpc_ref.GTFreeOptions(use_ot_dustbin_signal=use_ot_dustbin_signal)
    opts_opt = fpc.GTFreeOptions(use_ot_dustbin_signal=use_ot_dustbin_signal)

    cand_ref = fpc_ref.identify_gtfree_fp_candidates(volume, affine, opts_ref)
    cand_opt = fpc.identify_gtfree_fp_candidates(volume, affine, opts_opt)

    assert _records_as_tuples(cand_ref) == _records_as_tuples(cand_opt)


def test_matches_reference_with_components_touching_volume_edges() -> None:
    # Components flush against the array boundary on every axis -- exercises
    # the low_pad/high_pad clipping in the dilated-neighbour-search step,
    # which must reproduce scipy's default border_value=0 behaviour exactly.
    volume = np.zeros((12, 12, 12), dtype=np.uint8)
    volume[0:2, 0:2, 0:2] = 5
    volume[10:12, 10:12, 10:12] = 6
    volume[0:2, 5:7, 5:7] = 1
    volume[9:11, 9:11, 9:11] = 2
    gt_labels = {1, 2}

    for volume_threshold in (0, 3, 100):
        out_ref, rec_ref = fpc_ref.clean_or_relabel_false_positive_labels(
            volume, gt_labels, volume_threshold, dilation_voxels=2
        )
        out_opt, rec_opt = fpc.clean_or_relabel_false_positive_labels(
            volume, gt_labels, volume_threshold, dilation_voxels=2
        )
        assert np.array_equal(out_ref, out_opt)
        assert _records_as_tuples(rec_ref) == _records_as_tuples(rec_opt)


def test_matches_reference_on_empty_volume() -> None:
    volume = np.zeros((10, 10, 10), dtype=np.uint8)
    affine = np.eye(4)

    out_ref, rec_ref = fpc_ref.clean_or_relabel_false_positive_labels(volume, {1, 2}, 5, dilation_voxels=2)
    out_opt, rec_opt = fpc.clean_or_relabel_false_positive_labels(volume, {1, 2}, 5, dilation_voxels=2)
    assert np.array_equal(out_ref, out_opt)
    assert _records_as_tuples(rec_ref) == _records_as_tuples(rec_opt)

    out_ref, rec_ref = fpc_ref.clean_or_relabel_false_positive_labels(
        volume, None, 5, dilation_voxels=2, affine=affine
    )
    out_opt, rec_opt = fpc.clean_or_relabel_false_positive_labels(
        volume, None, 5, dilation_voxels=2, affine=affine
    )
    assert np.array_equal(out_ref, out_opt)
    assert _records_as_tuples(rec_ref) == _records_as_tuples(rec_opt)


def _dental_arch_volume(rng: np.random.Generator, shape: tuple[int, int, int]) -> np.ndarray:
    """Synthetic volume laid out like a real dental arch: each class occupies
    a small, anatomically-localized neighbourhood with a few jittered/
    duplicate components, not scattered across the whole volume -- this is
    the spatial property real CBCT predictions have and the one the
    crop-to-bbox optimization exploits."""
    volume = np.zeros(shape, dtype=np.uint8)
    center = np.array(shape) // 2
    radius = min(shape[0], shape[1]) // 3
    for i, cls in enumerate(range(1, 33)):
        theta = 2 * np.pi * i / 32
        slot = center + np.array([radius * np.cos(theta), radius * np.sin(theta), 0]).astype(int)
        for _ in range(int(rng.integers(2, 8))):
            jitter = rng.integers(-15, 15, 3)
            pos = np.clip(slot + jitter, 0, np.array(shape) - 10)
            sx, sy, sz = (int(v) for v in rng.integers(3, 10, 3))
            volume[pos[0] : pos[0] + sx, pos[1] : pos[1] + sy, pos[2] : pos[2] + sz] = cls
    return volume


@pytest.mark.slow
def test_optimized_is_well_under_budget_on_large_synthetic_volume() -> None:
    """Timing smoke test on a ~512^3-scale synthetic volume laid out like a
    real dental arch. The real per-case budget is a few seconds out of a
    ~60s total inference budget (inference itself is ~32s/case) -- 30s is a
    generous ceiling that still catches a regression back toward the
    reference implementation's much slower full-volume-scan behaviour (see
    this module's docstring: 64 full-volume ``ndimage.label`` calls alone
    measured ~9-17s on a representative synthetic case before this fix,
    dominated by scanning volume the label/component provably cannot occupy).
    """
    rng = np.random.default_rng(2026)
    volume = _dental_arch_volume(rng, (512, 512, 400))
    affine = np.eye(4)
    affine[0, 0] = affine[1, 1] = affine[2, 2] = 0.25
    affine[0, 3] = affine[1, 3] = -60.0
    affine[2, 3] = -40.0

    start = time.time()
    fpc.clean_or_relabel_false_positive_labels(
        volume, None, 5000, affine=affine, gtfree_options=fpc.GTFreeOptions(clean_classes="teeth")
    )
    elapsed = time.time() - start

    assert elapsed < 30.0, f"clean_or_relabel_false_positive_labels took {elapsed:.2f}s, expected well under 30s"
