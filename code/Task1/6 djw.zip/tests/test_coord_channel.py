"""Unit tests for stsr2026.training.coord_channel -- all synthetic data, no
GPU/nnunetv2 required (see that module's docstring for why this matters).
"""
from __future__ import annotations

from pathlib import Path

import nibabel as nib
import numpy as np
import pytest

from stsr2026.training import coord_channel as cc

# ---------------------------------------------------------------------------
# bbox_from_mask -- ported from nnU-Net's own get_bbox_from_mask; verify
# against hand-worked examples and the half-open-interval convention.
# ---------------------------------------------------------------------------


def test_bbox_from_mask_simple_blob():
    mask = np.zeros((10, 10, 10), dtype=bool)
    mask[2:5, 3:7, 1:2] = True  # a thin slab
    bbox = cc.bbox_from_mask(mask)
    assert bbox == ((2, 5), (3, 7), (1, 2))


def test_bbox_from_mask_all_false_matches_nnunet_full_extent_fallback():
    mask = np.zeros((4, 5, 6), dtype=bool)
    bbox = cc.bbox_from_mask(mask)
    assert bbox == ((0, 4), (0, 5), (0, 6))


def test_bbox_from_mask_single_voxel():
    mask = np.zeros((8, 8, 8), dtype=bool)
    mask[3, 4, 5] = True
    assert cc.bbox_from_mask(mask) == ((3, 4), (4, 5), (5, 6))


# ---------------------------------------------------------------------------
# compute_coord_channel -- core normalization logic.
# ---------------------------------------------------------------------------


def _lps_affine(spacing: float = 0.3) -> np.ndarray:
    # Matches the real dataset's verified diagonal LPS affine convention
    # (see coord_channel.py module docstring): array axis 0 is world-X,
    # increasing index moves toward negative X (patient left).
    return np.array(
        [
            [-spacing, 0.0, 0.0, 0.0],
            [0.0, -spacing, 0.0, 0.0],
            [0.0, 0.0, spacing, 0.0],
            [0.0, 0.0, 0.0, 1.0],
        ]
    )


def test_coord_channel_endpoints_hit_plus_minus_one_inside_bbox():
    image = np.zeros((20, 6, 6), dtype=np.float32)
    image[5:15, :, :] = 100.0  # foreground block along axis 0, indices [5,15)
    affine = _lps_affine()
    coord = cc.compute_coord_channel(image, affine, axis_row=0)

    # world_x is monotonically DEcreasing in i (affine[0,0] < 0), so the
    # smallest array index in the bbox (i=5) has the LARGEST world_x -> +1,
    # and the largest index (i=14) has the smallest world_x -> -1.
    assert coord[5, 3, 3] == pytest.approx(1.0)
    assert coord[14, 3, 3] == pytest.approx(-1.0, abs=1e-5)
    # constant across j, k for a fixed i (this dataset's affine has no j/k
    # contribution to world-X)
    assert np.allclose(coord[9, :, :], coord[9, 0, 0])


def test_coord_channel_zero_outside_bbox():
    image = np.zeros((20, 6, 6), dtype=np.float32)
    image[5:15, :, :] = 100.0
    affine = _lps_affine()
    coord = cc.compute_coord_channel(image, affine, axis_row=0)
    assert np.all(coord[:5] == 0.0)
    assert np.all(coord[15:] == 0.0)


def test_coord_channel_monotonic_within_bbox():
    image = np.zeros((30, 4, 4), dtype=np.float32)
    image[3:27, :, :] = 50.0
    affine = _lps_affine()
    coord = cc.compute_coord_channel(image, affine, axis_row=0)
    profile = coord[3:27, 0, 0]
    # strictly decreasing (world-X decreases as array index increases here)
    assert np.all(np.diff(profile) < 0)


def test_coord_channel_degenerate_single_voxel_thick_bbox_is_zero():
    image = np.zeros((10, 10, 10), dtype=np.float32)
    image[4, 4, 4] = 1.0  # bbox is a single voxel -> hi_val == lo_val
    affine = _lps_affine()
    coord = cc.compute_coord_channel(image, affine, axis_row=0)
    assert np.all(coord == 0.0)


def test_coord_channel_all_background_falls_back_to_full_extent_like_nnunet():
    # An all-zero image never happens for real CBCT data, but nnU-Net's own
    # get_bbox_from_mask has a defined fallback for an all-False mask: full
    # extent, not empty (see bbox_from_mask's docstring/test above) -- so
    # nnU-Net's own crop_to_nonzero would already be a no-op (crop = whole
    # volume) in this pathological case regardless of this module. Matching
    # that fallback here (rather than forcing all-zero) is intentional, not
    # a bug: the load-bearing invariant is "this channel's nonzero support
    # never exceeds channel 0's bbox" (guaranteed by construction -- see
    # test_stacking_channel_does_not_expand_crop_bbox), not "always zero
    # when the image is zero".
    image = np.zeros((10, 10, 10), dtype=np.float32)
    affine = _lps_affine()
    coord = cc.compute_coord_channel(image, affine, axis_row=0)
    assert coord[0, 0, 0] == pytest.approx(1.0)
    assert coord[9, 0, 0] == pytest.approx(-1.0, abs=1e-5)
    channel0_mask = cc.nonzero_foreground_mask(image)
    combined_mask = channel0_mask | cc.nonzero_foreground_mask(coord)
    assert cc.bbox_from_mask(channel0_mask) == cc.bbox_from_mask(combined_mask)


def test_compute_coord_channel_rejects_wrong_ndim():
    with pytest.raises(ValueError, match="3-dimensional"):
        cc.compute_coord_channel(np.zeros((5, 5)), _lps_affine())


def test_compute_coord_channel_rejects_wrong_affine_shape():
    with pytest.raises(ValueError, match="4, 4"):
        cc.compute_coord_channel(np.zeros((5, 5, 5)), np.eye(3))


# ---------------------------------------------------------------------------
# The property this module's docstring calls out as the load-bearing
# correctness requirement: stacking this channel next to the real image must
# not change nnU-Net's own crop_to_nonzero bounding box.
# ---------------------------------------------------------------------------


def test_stacking_channel_does_not_expand_crop_bbox():
    rng = np.random.default_rng(0)
    image = np.zeros((16, 12, 10), dtype=np.float32)
    image[4:12, 3:9, 2:8] = rng.uniform(1, 100, size=(8, 6, 6)).astype(np.float32)
    affine = _lps_affine()

    coord = cc.compute_coord_channel(image, affine, axis_row=0)

    channel0_mask = cc.nonzero_foreground_mask(image)
    combined_mask = channel0_mask | cc.nonzero_foreground_mask(coord)

    assert cc.bbox_from_mask(channel0_mask) == cc.bbox_from_mask(combined_mask)


def test_stacking_channel_bbox_matches_channel0_even_with_internal_zero_gaps():
    # A foreground block with a hole in the middle (e.g. an air pocket
    # between teeth) -- create_nonzero_mask's binary_fill_holes means
    # nnU-Net's bbox is still the outer block's bbox; this channel's own
    # nonzero support must not poke outside that box either.
    image = np.zeros((16, 12, 10), dtype=np.float32)
    image[4:12, 3:9, 2:8] = 50.0
    image[7:9, 5:7, 4:6] = 0.0  # interior hole
    affine = _lps_affine()

    coord = cc.compute_coord_channel(image, affine, axis_row=0)
    channel0_mask = cc.nonzero_foreground_mask(image)
    combined_mask = channel0_mask | cc.nonzero_foreground_mask(coord)
    assert cc.bbox_from_mask(channel0_mask) == cc.bbox_from_mask(combined_mask)


# ---------------------------------------------------------------------------
# generate_coord_channel_file -- NIfTI I/O round trip.
# ---------------------------------------------------------------------------


def test_generate_coord_channel_file_x_only(tmp_path: Path):
    affine = _lps_affine()
    image = np.zeros((12, 8, 8), dtype=np.float32)
    image[2:10, :, :] = 100.0
    src = tmp_path / "case_0000.nii.gz"
    nib.save(nib.Nifti1Image(image, affine), str(src))

    out = tmp_path / "case_0001.nii.gz"
    result_path = cc.generate_coord_channel_file(src, out, axes="x")
    assert result_path == out
    assert out.is_file()

    written = nib.load(str(out))
    assert written.shape == image.shape
    assert np.allclose(written.affine, affine)
    data = np.asanyarray(written.dataobj)
    assert data[2, 4, 4] == pytest.approx(1.0)
    assert data[9, 4, 4] == pytest.approx(-1.0, abs=1e-5)
    assert data[0, 4, 4] == pytest.approx(0.0)


def test_generate_coord_channel_file_xyz_produces_4d_stack(tmp_path: Path):
    affine = _lps_affine()
    image = np.zeros((10, 10, 10), dtype=np.float32)
    image[2:8, 2:8, 2:8] = 100.0
    src = tmp_path / "case_0000.nii.gz"
    nib.save(nib.Nifti1Image(image, affine), str(src))

    out = tmp_path / "case_coords.nii.gz"
    cc.generate_coord_channel_file(src, out, axes="xyz")
    written = nib.load(str(out))
    assert written.shape == (10, 10, 10, 3)


def test_generate_coord_channel_file_exactly_zero_outside_bbox_with_integer_source_header(tmp_path: Path):
    # Regression test for a real bug found running this against actual CBCT
    # data (2026-07-17): this dataset's source NIfTIs are stored on disk as
    # uint16. Naively reusing image_nii.header for the coordinate output
    # made nibabel round-trip the float coordinate data through that
    # header's integer datatype/auto-scaling, turning exact background
    # zeros into ~1.5e-5 residuals -- which would have silently expanded
    # nnU-Net's crop_to_nonzero bounding box. Build a source image with an
    # explicit uint16 header/dtype (mirroring the real dataset) and assert
    # the generated coordinate channel's background stays EXACTLY 0.0 after
    # a real save/load round trip, not just "small".
    affine = _lps_affine()
    image = np.zeros((20, 12, 12), dtype=np.uint16)
    image[5:15, :, :] = 500  # a plausible CBCT-ish intensity, not 0/1
    src = tmp_path / "case_0000.nii.gz"
    src_nii = nib.Nifti1Image(image, affine)
    src_nii.header.set_data_dtype(np.uint16)
    nib.save(src_nii, str(src))

    out = tmp_path / "case_0001.nii.gz"
    cc.generate_coord_channel_file(src, out, axes="x")

    written = nib.load(str(out))
    assert written.header.get_data_dtype() == np.dtype(np.float32)
    data = np.asanyarray(written.dataobj)
    assert np.all(data[:5] == 0.0)
    assert np.all(data[15:] == 0.0)
    assert data[5, 0, 0] == pytest.approx(1.0)
    assert data[14, 0, 0] == pytest.approx(-1.0, abs=1e-5)


def test_generate_coord_channel_file_creates_parent_dirs(tmp_path: Path):
    affine = _lps_affine()
    image = np.ones((6, 6, 6), dtype=np.float32)
    src = tmp_path / "case_0000.nii.gz"
    nib.save(nib.Nifti1Image(image, affine), str(src))

    out = tmp_path / "nested" / "dir" / "case_0001.nii.gz"
    cc.generate_coord_channel_file(src, out, axes="x")
    assert out.is_file()


# ---------------------------------------------------------------------------
# coord_channel_paths_for_case -- the extra_channel_paths_fn glue for
# nnunet_inference.run_batch_inference.
# ---------------------------------------------------------------------------


def test_coord_channel_paths_for_case_single_axis(tmp_path: Path):
    affine = _lps_affine()
    image = np.zeros((10, 6, 6), dtype=np.float32)
    image[2:8, :, :] = 100.0
    src = tmp_path / "STS26_Train-Labeled_099.nii.gz"
    nib.save(nib.Nifti1Image(image, affine), str(src))

    cache_dir = tmp_path / "cache"
    paths = cc.coord_channel_paths_for_case(src, cache_dir, axes="x")
    assert len(paths) == 1
    assert paths[0] == cache_dir / "STS26_Train-Labeled_099_0001.nii.gz"
    assert paths[0].is_file()


def test_coord_channel_paths_for_case_multi_axis_naming(tmp_path: Path):
    affine = _lps_affine()
    image = np.zeros((10, 6, 6), dtype=np.float32)
    image[2:8, :, :] = 100.0
    src = tmp_path / "case_042.nii.gz"
    nib.save(nib.Nifti1Image(image, affine), str(src))

    cache_dir = tmp_path / "cache"
    paths = cc.coord_channel_paths_for_case(src, cache_dir, axes="xyz")
    assert [p.name for p in paths] == ["case_042_0001.nii.gz", "case_042_0002.nii.gz", "case_042_0003.nii.gz"]
    for p in paths:
        assert p.is_file()


def test_coord_channel_paths_for_case_is_cached_not_regenerated(tmp_path: Path):
    affine = _lps_affine()
    image = np.zeros((10, 6, 6), dtype=np.float32)
    image[2:8, :, :] = 100.0
    src = tmp_path / "case_042.nii.gz"
    nib.save(nib.Nifti1Image(image, affine), str(src))

    cache_dir = tmp_path / "cache"
    first = cc.coord_channel_paths_for_case(src, cache_dir, axes="x")[0]
    mtime_before = first.stat().st_mtime_ns
    second = cc.coord_channel_paths_for_case(src, cache_dir, axes="x")[0]
    assert second.stat().st_mtime_ns == mtime_before
