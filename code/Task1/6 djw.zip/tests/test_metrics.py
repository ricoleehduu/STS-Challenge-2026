from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pytest
import SimpleITK as sitk

from stsr2026.evaluation.metrics import (
    EvaluationError,
    aggregate_case_scores,
    compute_case_scores,
    evaluate_predictions,
    load_official_compute_metrics,
    match_cases,
    run_official_scorer,
)


def _write_label_volume(path: Path, array: np.ndarray, spacing: tuple[float, float, float] = (1.0, 1.0, 1.0)) -> None:
    image = sitk.GetImageFromArray(array.astype(np.uint8))
    image.SetSpacing(spacing)
    sitk.WriteImage(image, str(path))


# Case A: hand-computed overlap for tooth class 5, canal class 40, and a
# tooth-range false-positive class 6 present only in the prediction (used to
# exercise the IA union-of-label-sets denominator and confirm the per-label
# instance loop walks gt_labels only, per the official script's own
# `for label_id in gt_labels` semantics).
_SHAPE = (3, 5, 5)  # z, y, x


def _case_a_arrays() -> tuple[np.ndarray, np.ndarray]:
    gt = np.zeros(_SHAPE, dtype=np.uint8)
    gt[1, 1, 1] = 5
    gt[1, 1, 2] = 5
    gt[1, 3, 3] = 40

    pred = np.zeros(_SHAPE, dtype=np.uint8)
    pred[1, 1, 1] = 5
    pred[1, 2, 1] = 5
    pred[1, 3, 3] = 40
    pred[0, 0, 0] = 6  # tooth-range false positive, absent from gt entirely
    return gt, pred


def _case_b_arrays() -> tuple[np.ndarray, np.ndarray]:
    # Perfect match, tooth-only: exercises NaN-dice aggregation for the
    # canal group (both gt and pred have zero canal voxels).
    gt = np.zeros(_SHAPE, dtype=np.uint8)
    gt[0, 0, 0] = 5
    pred = gt.copy()
    return gt, pred


@pytest.fixture()
def official():
    return load_official_compute_metrics()


def test_load_official_compute_metrics_exposes_expected_functions(official) -> None:
    assert official.NSD_TOLERANCE_MM == 2.0
    for name in ("compute_dice_coefficient", "calculate_iou", "calculate_nsd_robust", "robust_mean", "resample_to_reference_grid"):
        assert hasattr(official, name), name


def test_compute_case_scores_matches_hand_computed_values(tmp_path: Path, official) -> None:
    gt, pred = _case_a_arrays()
    gt_path, pred_path = tmp_path / "gt" / "case_a.nii.gz", tmp_path / "pred" / "case_a.nii.gz"
    gt_path.parent.mkdir()
    pred_path.parent.mkdir()
    _write_label_volume(gt_path, gt)
    _write_label_volume(pred_path, pred)

    scores = compute_case_scores(gt_path, pred_path, official)

    assert scores.case_id == "case_a"
    # tooth: gt={2 vox}, pred={2 vox, incl. 1 fp}, intersection=1
    assert scores.tooth_dice_image == pytest.approx(2 * 1 / (2 + 3))
    assert scores.tooth_iou_image == pytest.approx(1 / (2 + 3 - 1))
    # canal: exact match (1 voxel each)
    assert scores.canal_dice_image == pytest.approx(1.0)
    assert scores.canal_iou_image == pytest.approx(1.0)
    # overall: gt=3 vox, pred=4 vox, intersection=2
    assert scores.overall_dice_image == pytest.approx(2 * 2 / (3 + 4))
    assert scores.overall_iou_image == pytest.approx(2 / (3 + 4 - 2))

    # instance loop: only gt_labels (5, 40) are scored -- class 6 (pred-only)
    # must NOT appear, even though it falls in the tooth class range.
    labels = {ls.label: ls for ls in scores.label_scores}
    assert set(labels) == {5, 40}
    assert labels[5].dice == pytest.approx(0.5)
    assert labels[5].iou == pytest.approx(1 / 3)
    assert labels[5].matched is False
    assert labels[40].dice == pytest.approx(1.0)
    assert labels[40].iou == pytest.approx(1.0)
    assert labels[40].matched is True

    # IA: matched=1 (label 40 only), union of label sets = {5, 40, 6} = 3
    assert scores.ia == pytest.approx(1 / 3)

    assert scores.tooth_label_scores() == (labels[5],)
    assert scores.canal_label_scores() == (labels[40],)


def test_compute_case_scores_perfect_match_and_nan_canal(tmp_path: Path, official) -> None:
    gt, pred = _case_b_arrays()
    gt_path, pred_path = tmp_path / "gt" / "case_b.nii.gz", tmp_path / "pred" / "case_b.nii.gz"
    gt_path.parent.mkdir()
    pred_path.parent.mkdir()
    _write_label_volume(gt_path, gt)
    _write_label_volume(pred_path, pred)

    scores = compute_case_scores(gt_path, pred_path, official)

    assert scores.tooth_dice_image == pytest.approx(1.0)
    assert scores.overall_dice_image == pytest.approx(1.0)
    # both gt and pred canal masks are empty -> official compute_dice_coefficient's
    # NaN-on-both-empty semantics must be preserved, not silently coerced to 0 or 1.
    assert np.isnan(scores.canal_dice_image)
    # calculate_iou treats both-empty as a perfect match (1.0), unlike dice's NaN.
    assert scores.canal_iou_image == pytest.approx(1.0)
    assert scores.ia == pytest.approx(1.0)


def test_aggregate_case_scores_matches_hand_computed_values(tmp_path: Path, official) -> None:
    gt_a, pred_a = _case_a_arrays()
    gt_b, pred_b = _case_b_arrays()
    for name, gt, pred in (("case_a", gt_a, pred_a), ("case_b", gt_b, pred_b)):
        gt_dir, pred_dir = tmp_path / "gt", tmp_path / "pred"
        gt_dir.mkdir(exist_ok=True)
        pred_dir.mkdir(exist_ok=True)
        _write_label_volume(gt_dir / f"{name}.nii.gz", gt)
        _write_label_volume(pred_dir / f"{name}.nii.gz", pred)

    cases = [
        compute_case_scores(tmp_path / "gt" / "case_a.nii.gz", tmp_path / "pred" / "case_a.nii.gz", official),
        compute_case_scores(tmp_path / "gt" / "case_b.nii.gz", tmp_path / "pred" / "case_b.nii.gz", official),
    ]
    summary = aggregate_case_scores(cases, official)

    assert summary.num_cases == 2
    assert summary.tooth_dice_image == pytest.approx((0.4 + 1.0) / 2)
    # canal_dice_image: case A contributes 1.0, case B contributes NaN and
    # must be dropped by robust_mean, not zeroed or double-counted.
    assert summary.canal_dice_image == pytest.approx(1.0)
    assert summary.overall_dice_image == pytest.approx((4 / 7 + 1.0) / 2)
    assert summary.tooth_dice_instance == pytest.approx((0.5 + 1.0) / 2)
    assert summary.canal_dice_instance == pytest.approx(1.0)
    assert summary.ia == pytest.approx((1 / 3 + 1.0) / 2)
    assert summary.miou == pytest.approx((1 / 3 + 1.0 + 1.0) / 3)

    json_dict = summary.to_json_dict()
    assert json_dict["num_cases"] == 2
    assert set(json_dict["case_ids"]) == {"case_a", "case_b"}


def test_aggregate_case_scores_rejects_empty_list(official) -> None:
    with pytest.raises(EvaluationError):
        aggregate_case_scores([], official)


def test_match_cases_exact_stem_and_missing_detection(tmp_path: Path) -> None:
    gt_dir, pred_dir = tmp_path / "gt", tmp_path / "pred"
    gt_dir.mkdir()
    pred_dir.mkdir()
    _write_label_volume(gt_dir / "case_001.nii.gz", np.zeros(_SHAPE, dtype=np.uint8))
    _write_label_volume(gt_dir / "case_002.nii.gz", np.zeros(_SHAPE, dtype=np.uint8))
    _write_label_volume(pred_dir / "case_001.nii.gz", np.zeros(_SHAPE, dtype=np.uint8))

    matched = match_cases(pred_dir, gt_dir, case_ids=["case_001"])
    assert set(matched) == {"case_001"}

    with pytest.raises(EvaluationError, match="missing_predictions"):
        match_cases(pred_dir, gt_dir)  # case_002 has no prediction


def test_evaluate_predictions_end_to_end(tmp_path: Path) -> None:
    gt_dir, pred_dir = tmp_path / "gt", tmp_path / "pred"
    gt_dir.mkdir()
    pred_dir.mkdir()
    gt, pred = _case_a_arrays()
    _write_label_volume(gt_dir / "case_a.nii.gz", gt)
    _write_label_volume(pred_dir / "case_a.nii.gz", pred)

    summary = evaluate_predictions(pred_dir, gt_dir)
    assert summary.num_cases == 1
    assert summary.tooth_dice_image == pytest.approx(0.4)


def test_run_official_scorer_detects_filename_collision(tmp_path: Path) -> None:
    # Real STSR filenames collide under the official script's own
    # split('_')[-2] fallback matcher -- see metrics.py's module docstring.
    gt_dir, pred_dir = tmp_path / "gt", tmp_path / "pred"
    gt_dir.mkdir()
    pred_dir.mkdir()
    zeros = np.zeros(_SHAPE, dtype=np.uint8)
    _write_label_volume(gt_dir / "STS26_Train-Labeled_001.nii.gz", zeros)
    _write_label_volume(gt_dir / "STS26_Train-Labeled_002.nii.gz", zeros)

    with pytest.raises(EvaluationError, match="collides"):
        run_official_scorer(pred_dir, gt_dir, tmp_path / "scores.json")
    assert not (tmp_path / "scores.json").exists()


def test_run_official_scorer_cross_checks_single_case(tmp_path: Path) -> None:
    gt_dir, pred_dir = tmp_path / "gt", tmp_path / "pred"
    gt_dir.mkdir()
    pred_dir.mkdir()
    gt, pred = _case_a_arrays()
    # Unique-enough filename under the official script's own fallback parser.
    _write_label_volume(gt_dir / "onlycase_001.nii.gz", gt)
    _write_label_volume(pred_dir / "onlycase_001.nii.gz", pred)

    output_json = tmp_path / "scores.json"
    scores = run_official_scorer(pred_dir, gt_dir, output_json)

    assert output_json.is_file()
    assert json.loads(output_json.read_text()) == scores
    # Cross-check against this module's own overall (unsplit) computation
    # for the same case -- both must agree since both call the same
    # underlying official metric functions on the same whole-volume binary
    # masks (gt_np > 0 vs pred_np > 0).
    summary = evaluate_predictions(pred_dir, gt_dir)
    assert scores["Dice_Image"] == pytest.approx(summary.overall_dice_image)
    assert scores["IoU_Image"] == pytest.approx(summary.overall_iou_image)
    assert scores["IA"] == pytest.approx(summary.ia)
