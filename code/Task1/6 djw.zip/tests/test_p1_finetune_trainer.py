"""Unit tests for the P1 short-schedule fine-tune trainer.

This trainer has almost no logic of its own (see module docstring in
``p1_finetune_trainer.py``): it is stock ``nnUNetTrainer`` with one line
changed (``self.num_epochs``). These tests cover the one piece of real
logic -- ``_resolve_num_epochs``'s environment-variable override and
validation -- plus the same nnunetv2-availability presence/absence pattern
used by ``test_ssl_trainer.py``. They do **not** exercise the
``nnUNetTrainer`` subclass itself beyond that (no GPU/full nnunetv2 install
in this sandbox); the real end-to-end behavior (pretrained-weight loading,
short-schedule LR curve) was validated on real GPU hardware -- see
docs/experiment-log.md / docs/progress.md for the P1 fine-tune run.
"""
from __future__ import annotations

import pytest

from stsr2026.training import p1_finetune_trainer as p1


# ---------------------------------------------------------------------------
# _resolve_num_epochs
# ---------------------------------------------------------------------------


def test_resolve_num_epochs_defaults_when_env_var_unset(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv(p1._NUM_EPOCHS_ENV_VAR, raising=False)
    assert p1._resolve_num_epochs() == p1.DEFAULT_P1_NUM_EPOCHS


def test_resolve_num_epochs_defaults_when_env_var_empty(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(p1._NUM_EPOCHS_ENV_VAR, "")
    assert p1._resolve_num_epochs() == p1.DEFAULT_P1_NUM_EPOCHS


def test_resolve_num_epochs_reads_env_var_override(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(p1._NUM_EPOCHS_ENV_VAR, "100")
    assert p1._resolve_num_epochs() == 100


def test_resolve_num_epochs_rejects_non_integer(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(p1._NUM_EPOCHS_ENV_VAR, "not-a-number")
    with pytest.raises(ValueError, match="not a valid integer"):
        p1._resolve_num_epochs()


def test_resolve_num_epochs_rejects_zero(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(p1._NUM_EPOCHS_ENV_VAR, "0")
    with pytest.raises(ValueError, match="must be positive"):
        p1._resolve_num_epochs()


def test_resolve_num_epochs_rejects_negative(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(p1._NUM_EPOCHS_ENV_VAR, "-5")
    with pytest.raises(ValueError, match="must be positive"):
        p1._resolve_num_epochs()


def test_resolve_num_epochs_custom_default_argument() -> None:
    # No env var involved -- exercises the `default` parameter directly.
    import os

    assert p1._NUM_EPOCHS_ENV_VAR not in os.environ or True  # env state irrelevant here
    assert p1._resolve_num_epochs.__defaults__ == (p1.DEFAULT_P1_NUM_EPOCHS,)


# ---------------------------------------------------------------------------
# Trainer class: presence/absence depending on nnunetv2 availability
# ---------------------------------------------------------------------------


def test_trainer_class_reflects_nnunetv2_availability() -> None:
    if p1.NNUNETV2_AVAILABLE:
        assert p1.nnUNetTrainer_STSR_P1FineTune is not None
    else:
        assert p1.nnUNetTrainer_STSR_P1FineTune is None
