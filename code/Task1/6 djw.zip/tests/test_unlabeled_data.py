from __future__ import annotations

import random
from pathlib import Path

import nibabel as nib
import numpy as np
import pytest

from stsr2026.training.unlabeled_data import (
    UnlabeledPatchDataset,
    cache_preprocessed_unlabeled_case,
    ensure_lps_nifti,
    make_weak_strong_pair,
    random_patch,
    reorient_to_lps,
    strong_augment,
    weak_augment,
)


def _lps_affine() -> np.ndarray:
    return np.diag([-0.3, -0.3, 0.3, 1.0])


def _write_nifti(path: Path, values: np.ndarray, affine: np.ndarray) -> None:
    nib.save(nib.Nifti1Image(values, affine), str(path))


def test_reorient_to_lps_is_noop_when_already_lps() -> None:
    image = nib.Nifti1Image(np.arange(24, dtype=np.float32).reshape(2, 3, 4), _lps_affine())
    result = reorient_to_lps(image)
    assert nib.aff2axcodes(result.affine) == ("L", "P", "S")
    assert np.array_equal(np.asanyarray(result.dataobj), np.asanyarray(image.dataobj))


def test_reorient_to_lps_fixes_las_orientation() -> None:
    las_affine = np.diag([-0.3, 0.3, 0.3, 1.0])  # L, A, S
    data = np.arange(24, dtype=np.float32).reshape(2, 3, 4)
    image = nib.Nifti1Image(data, las_affine)
    assert nib.aff2axcodes(image.affine) == ("L", "A", "S")

    result = reorient_to_lps(image)

    assert nib.aff2axcodes(result.affine) == ("L", "P", "S")
    # Reorienting LAS->LPS flips the P/A axis; round-tripping should recover the original data.
    roundtrip_to_las = nib.orientations.apply_orientation(
        np.asanyarray(result.dataobj),
        nib.orientations.ornt_transform(
            nib.orientations.axcodes2ornt(("L", "P", "S")), nib.orientations.axcodes2ornt(("L", "A", "S"))
        ),
    )
    assert np.array_equal(roundtrip_to_las, data)


def test_ensure_lps_nifti_skips_copy_when_already_lps(tmp_path: Path) -> None:
    source = tmp_path / "case.nii.gz"
    _write_nifti(source, np.zeros((2, 2, 2), dtype=np.float32), _lps_affine())
    cache_dir = tmp_path / "cache"

    result = ensure_lps_nifti(source, cache_dir)

    assert result == source
    assert not cache_dir.exists()


def test_ensure_lps_nifti_writes_and_reuses_cached_copy(tmp_path: Path) -> None:
    source = tmp_path / "case.nii.gz"
    las_affine = np.diag([-0.3, 0.3, 0.3, 1.0])
    _write_nifti(source, np.arange(8, dtype=np.float32).reshape(2, 2, 2), las_affine)
    cache_dir = tmp_path / "cache"

    first = ensure_lps_nifti(source, cache_dir)
    assert first == cache_dir / "case.nii.gz"
    assert first.exists()
    cached_mtime = first.stat().st_mtime_ns

    second = ensure_lps_nifti(source, cache_dir)
    assert second == first
    assert second.stat().st_mtime_ns == cached_mtime  # not rewritten


def test_random_patch_exact_size_when_larger_than_patch() -> None:
    data = np.arange(2 * 10 * 10 * 10, dtype=np.float32).reshape(2, 10, 10, 10)
    patch = random_patch(data, (4, 5, 6), rng=random.Random(0))
    assert patch.shape == (2, 4, 5, 6)


def test_random_patch_pads_when_smaller_than_patch() -> None:
    data = np.ones((1, 3, 3, 3), dtype=np.float32)
    patch = random_patch(data, (5, 5, 5), rng=random.Random(0))
    assert patch.shape == (1, 5, 5, 5)
    assert np.any(patch == 0.0)  # padded region present


def test_random_patch_rejects_dim_mismatch() -> None:
    data = np.zeros((1, 4, 4, 4), dtype=np.float32)
    with pytest.raises(ValueError):
        random_patch(data, (4, 4), rng=random.Random(0))


def test_weak_augment_only_flips_no_intensity_change() -> None:
    data = np.arange(2 * 4 * 4 * 4, dtype=np.float32).reshape(2, 4, 4, 4)
    weak = weak_augment(data, rng=random.Random(1))
    assert weak.shape == data.shape
    assert sorted(weak.ravel().tolist()) == sorted(data.ravel().tolist())


def test_strong_augment_changes_intensity_and_keeps_shape() -> None:
    data = np.random.default_rng(0).normal(size=(1, 6, 6, 6)).astype(np.float32)
    strong = strong_augment(data, rng=random.Random(2))
    assert strong.shape == data.shape
    assert not np.allclose(np.sort(strong.ravel()), np.sort(data.ravel()))


def test_strong_augment_is_deterministic_given_same_rng_seed() -> None:
    data = np.random.default_rng(0).normal(size=(1, 6, 6, 6)).astype(np.float32)
    a = strong_augment(data, rng=random.Random(42))
    b = strong_augment(data, rng=random.Random(42))
    assert np.allclose(a, b)


def test_make_weak_strong_pair_shapes_match_patch_size() -> None:
    data = np.random.default_rng(0).normal(size=(1, 10, 10, 10)).astype(np.float32)
    weak, strong = make_weak_strong_pair(data, (5, 5, 5), rng=random.Random(3))
    assert weak.shape == (1, 5, 5, 5)
    assert strong.shape == (1, 5, 5, 5)


def test_cache_preprocessed_unlabeled_case_writes_and_reuses(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    import stsr2026.training.unlabeled_data as module

    calls = []

    def fake_preprocess(image_path, plans_manager, configuration_manager, dataset_json):
        calls.append(image_path)
        return np.ones((1, 2, 2, 2), dtype=np.float32)

    monkeypatch.setattr(module, "preprocess_unlabeled_case", fake_preprocess)
    image_path = tmp_path / "case_001.nii.gz"
    cache_dir = tmp_path / "cache"

    first = cache_preprocessed_unlabeled_case(image_path, cache_dir, None, None, {})
    assert first == cache_dir / "case_001.npy"
    assert first.exists()
    assert np.array_equal(np.load(first), np.ones((1, 2, 2, 2), dtype=np.float32))
    assert len(calls) == 1

    second = cache_preprocessed_unlabeled_case(image_path, cache_dir, None, None, {})
    assert second == first
    assert len(calls) == 1  # not preprocessed again


def test_unlabeled_patch_dataset_rejects_empty_case_list() -> None:
    with pytest.raises(ValueError):
        UnlabeledPatchDataset([], patch_size=(4, 4, 4))


def test_unlabeled_patch_dataset_yields_weak_strong_pairs(tmp_path: Path) -> None:
    case_paths = []
    for i in range(3):
        path = tmp_path / f"case_{i}.npy"
        np.save(path, np.random.default_rng(i).normal(size=(1, 8, 8, 8)).astype(np.float32))
        case_paths.append(path)

    dataset = UnlabeledPatchDataset(case_paths, patch_size=(4, 4, 4), seed=0)

    assert len(dataset) == 3
    item = dataset[1]
    assert set(item) == {"data", "aug_data"}
    assert item["data"].shape == (1, 4, 4, 4)
    assert item["aug_data"].shape == (1, 4, 4, 4)
