from __future__ import annotations

import os as os_module
from pathlib import Path

import nibabel as nib
import numpy as np
import pytest

from stsr2026.evaluation import nnunet_inference as ni

# This sandbox has no GPU and no working nnunetv2/torch install (see
# pyproject.toml's 'training' extra and ni's module docstring). Everything
# testable here is pure logic (file resolution, error messages) that does
# not require NNUNETV2_AVAILABLE; the nnUNetPredictor call itself is
# GPU-dependent and unverified -- see module docstring's ASSUMPTION notes,
# to be checked on a real GPU box.


def _write_nifti(path: Path, values: np.ndarray) -> None:
    nib.save(nib.Nifti1Image(values, np.diag([0.3, 0.4, 0.5, 1.0])), str(path))


def test_find_case_images_returns_sorted_paths_without_case_ids(tmp_path: Path) -> None:
    images_dir = tmp_path / "images"
    images_dir.mkdir()
    for case_id in ("b", "a", "c"):
        _write_nifti(images_dir / f"{case_id}.nii.gz", np.zeros((2, 2, 2), dtype=np.float32))

    result = ni.find_case_images(images_dir)
    assert [p.name for p in result] == ["a.nii.gz", "b.nii.gz", "c.nii.gz"]


def test_find_case_images_restricts_to_requested_case_ids(tmp_path: Path) -> None:
    images_dir = tmp_path / "images"
    images_dir.mkdir()
    for case_id in ("a", "b", "c"):
        _write_nifti(images_dir / f"{case_id}.nii.gz", np.zeros((2, 2, 2), dtype=np.float32))

    result = ni.find_case_images(images_dir, case_ids=["c", "a"])
    assert [p.name for p in result] == ["c.nii.gz", "a.nii.gz"]


def test_find_case_images_raises_on_missing_case(tmp_path: Path) -> None:
    images_dir = tmp_path / "images"
    images_dir.mkdir()
    _write_nifti(images_dir / "a.nii.gz", np.zeros((2, 2, 2), dtype=np.float32))

    with pytest.raises(ni.InferenceError, match="missing"):
        ni.find_case_images(images_dir, case_ids=["a", "missing_case"])


def test_file_ending_helper() -> None:
    assert ni._file_ending(Path("case_001.nii.gz")) == ".nii.gz"
    assert ni._file_ending(Path("case_001.nii")) == ".nii"


@pytest.mark.skipif(ni.NNUNETV2_AVAILABLE, reason="only exercises the no-nnunetv2 error path")
def test_functions_raise_informative_error_without_nnunetv2(tmp_path: Path) -> None:
    with pytest.raises(ni.InferenceError, match="nnunetv2/torch are not installed"):
        ni.load_predictor(tmp_path / "checkpoint")
    with pytest.raises(ni.InferenceError, match="nnunetv2/torch are not installed"):
        ni.predict_case(None, tmp_path / "image.nii.gz", tmp_path / "out")
    with pytest.raises(ni.InferenceError, match="nnunetv2/torch are not installed"):
        ni.run_checkpoint_inference(tmp_path / "checkpoint", [], tmp_path / "out")


def test_nnunetv2_not_available_in_this_sandbox() -> None:
    # Documents the expected sandbox state so a future dependency change
    # doesn't silently make this test suite start skipping the check above
    # without anyone noticing. If this starts failing, nnunetv2 has become
    # available and the GPU-dependent paths in this module should get a
    # real (not just logic-level) test pass.
    assert ni.NNUNETV2_AVAILABLE is False


# ---------------------------------------------------------------------------
# predict_case's new call chain (2026-07-13 refactor: no longer calls
# predict_from_files_sequential -- see module docstring for why). Real
# nnunetv2/torch-with-CUDA are still not installed in this sandbox, so this
# injects a fake predictor object (exposing exactly the attributes/methods
# predict_case now calls: configuration_manager.preprocessor_class,
# plans_manager, dataset_json, verbose, device,
# predict_logits_from_preprocessed_data) plus real CPU torch and a fake
# export_prediction_from_logits, following this repo's existing
# inject-at-the-boundary pattern (tests/test_checkpoint_runner.py injects
# predictor_factory/predict_case_fn the same way). This verifies the new
# preprocess -> predict -> export wiring/argument-passing logic; it does NOT
# verify real nnU-Net semantics (preprocessor_class's actual behavior,
# export_prediction_from_logits' actual geometry restoration) -- that still
# requires a real GPU box, per the module docstring.
# ---------------------------------------------------------------------------


def test_predict_case_replicates_single_case_loop_with_injected_nnunetv2(tmp_path: Path, monkeypatch) -> None:
    real_torch = pytest.importorskip("torch")
    monkeypatch.setattr(ni, "NNUNETV2_AVAILABLE", True)
    monkeypatch.setattr(ni, "torch", real_torch)

    calls: dict = {}

    class _FakePreprocessor:
        def __init__(self, verbose):
            calls["preprocessor_verbose"] = verbose

        def run_case(self, list_of_lists, seg_file, plans_manager, configuration_manager, dataset_json):
            calls["run_case_args"] = (list_of_lists, seg_file, plans_manager, configuration_manager, dataset_json)
            data = np.zeros((2, 3, 3, 3), dtype=np.float32)
            return data, None, {"case": "props"}

    class _FakeConfigurationManager:
        preprocessor_class = _FakePreprocessor

    class _FakePlansManager:
        pass

    class _FakePredictor:
        def __init__(self):
            self.configuration_manager = _FakeConfigurationManager()
            self.plans_manager = _FakePlansManager()
            self.dataset_json = {"file_ending": ".nii.gz"}
            self.verbose = True
            self.device = real_torch.device("cpu")

        def predict_logits_from_preprocessed_data(self, data):
            calls["predict_input"] = data
            return real_torch.zeros((2, 3, 3, 3))

    def fake_export(
        prediction,
        data_properties,
        configuration_manager,
        plans_manager,
        dataset_json,
        output_file_truncated,
        save_probabilities,
    ):
        calls["export_args"] = (
            prediction,
            data_properties,
            configuration_manager,
            plans_manager,
            dataset_json,
            output_file_truncated,
            save_probabilities,
        )
        Path(output_file_truncated + dataset_json["file_ending"]).write_bytes(b"fake-output")

    monkeypatch.setattr(ni, "export_prediction_from_logits", fake_export)

    images_dir = tmp_path / "images"
    images_dir.mkdir()
    image_path = images_dir / "case_001.nii.gz"
    _write_nifti(image_path, np.zeros((2, 2, 2), dtype=np.float32))
    output_dir = tmp_path / "out"

    result = ni.predict_case(_FakePredictor(), image_path, output_dir, gpu_resample=False)

    assert calls["preprocessor_verbose"] is True
    assert calls["run_case_args"][0] == [str(image_path)]
    assert calls["run_case_args"][1] is None  # no previous-stage seg
    assert calls["export_args"][5] == str(output_dir / "case_001")
    assert calls["export_args"][6] is False  # save_probabilities
    assert result.case_id == "case_001"
    assert result.input_path == str(image_path)
    assert result.output_path == str(output_dir / "case_001.nii.gz")
    assert Path(result.output_path).is_file()


def test_predict_case_raises_when_export_does_not_write_expected_file(tmp_path: Path, monkeypatch) -> None:
    real_torch = pytest.importorskip("torch")
    monkeypatch.setattr(ni, "NNUNETV2_AVAILABLE", True)
    monkeypatch.setattr(ni, "torch", real_torch)

    class _FakePreprocessor:
        def __init__(self, verbose):
            pass

        def run_case(self, list_of_lists, seg_file, plans_manager, configuration_manager, dataset_json):
            return np.zeros((1, 2, 2, 2), dtype=np.float32), None, {}

    class _FakeConfigurationManager:
        preprocessor_class = _FakePreprocessor

    class _FakePredictor:
        configuration_manager = _FakeConfigurationManager()
        plans_manager = object()
        dataset_json = {"file_ending": ".nii.gz"}
        verbose = False
        device = real_torch.device("cpu")

        def predict_logits_from_preprocessed_data(self, data):
            return real_torch.zeros((1, 2, 2, 2))

    monkeypatch.setattr(ni, "export_prediction_from_logits", lambda *a, **k: None)  # writes nothing

    images_dir = tmp_path / "images"
    images_dir.mkdir()
    image_path = images_dir / "case_002.nii.gz"
    _write_nifti(image_path, np.zeros((2, 2, 2), dtype=np.float32))

    with pytest.raises(ni.InferenceError, match="did not produce the expected output file"):
        ni.predict_case(_FakePredictor(), image_path, tmp_path / "out", gpu_resample=False)


# ---------------------------------------------------------------------------
# _chunked_tensor_has_inf (2026-07-13: real-hardware CRITICAL OOM fix, see
# module docstring's _memory_safe_internal_predict_sliding_window_return_logits
# and docs/progress.md). Pure logic, real CPU torch is enough (no GPU needed)
# to verify this matches torch.any(torch.isinf(...)) bit-for-bit -- the
# GPU-dependent, unverified part is only that nnU-Net's real
# _internal_predict_sliding_window_return_logits still gets patched correctly
# on a real install (see _install_memory_safe_sliding_window's docstring).
# ---------------------------------------------------------------------------


def test_chunked_tensor_has_inf_matches_naive_check_when_no_inf(monkeypatch) -> None:
    real_torch = pytest.importorskip("torch")
    monkeypatch.setattr(ni, "torch", real_torch)
    tensor = real_torch.randn(9, 4, 4, 4)
    assert ni._chunked_tensor_has_inf(tensor, channels_per_chunk=4) is False
    assert bool(real_torch.any(real_torch.isinf(tensor))) is False


def test_chunked_tensor_has_inf_detects_inf_in_first_chunk(monkeypatch) -> None:
    real_torch = pytest.importorskip("torch")
    monkeypatch.setattr(ni, "torch", real_torch)
    tensor = real_torch.randn(9, 4, 4, 4)
    tensor[0, 0, 0, 0] = float("inf")
    assert ni._chunked_tensor_has_inf(tensor, channels_per_chunk=4) is True


def test_chunked_tensor_has_inf_detects_inf_in_last_chunk_not_aligned_to_chunk_size(monkeypatch) -> None:
    real_torch = pytest.importorskip("torch")
    monkeypatch.setattr(ni, "torch", real_torch)
    tensor = real_torch.randn(9, 4, 4, 4)
    tensor[-1, -1, -1, -1] = float("-inf")
    assert ni._chunked_tensor_has_inf(tensor, channels_per_chunk=4) is True


def test_chunked_tensor_has_inf_matches_naive_check_across_random_cases(monkeypatch) -> None:
    real_torch = pytest.importorskip("torch")
    monkeypatch.setattr(ni, "torch", real_torch)
    generator = real_torch.Generator().manual_seed(0)
    for trial in range(20):
        tensor = real_torch.randn(7, 3, 3, 3, generator=generator)
        if trial % 3 == 0:
            flat_index = int(real_torch.randint(0, tensor.numel(), (1,), generator=generator))
            tensor.view(-1)[flat_index] = float("inf") if trial % 2 == 0 else float("-inf")
        expected = bool(real_torch.any(real_torch.isinf(tensor)))
        assert ni._chunked_tensor_has_inf(tensor, channels_per_chunk=2) is expected


# ---------------------------------------------------------------------------
# _skip_seg_resample / install_skip_unused_seg_resample (2026-07-13: D2
# efficiency work, see docs/progress.md). Profiled on real A10 hardware:
# DefaultPreprocessor.run_case_npy calls configuration_manager.resampling_fn_seg
# unconditionally even when seg_file=None (measured 10.43s for case_006), and
# every call site in this repo discards that return value. Pure logic, no
# GPU/nnunetv2 needed to test the replacement function's shape/dtype contract.
# ---------------------------------------------------------------------------


def test_skip_seg_resample_returns_correct_shape_and_dtype() -> None:
    seg = np.zeros((1, 10, 12, 14), dtype=np.int8)
    result = ni._skip_seg_resample(seg, [20, 24, 28], (0.3, 0.3, 0.3), (0.15, 0.15, 0.15))
    assert result.shape == (1, 20, 24, 28)
    assert result.dtype == np.int8


def test_skip_seg_resample_preserves_channel_count() -> None:
    seg = np.zeros((3, 5, 5, 5), dtype=np.float32)
    result = ni._skip_seg_resample(seg, [8, 8, 8], (1.0, 1.0, 1.0), (0.5, 0.5, 0.5))
    assert result.shape == (3, 8, 8, 8)


def test_install_skip_unused_seg_resample_is_idempotent_without_nnunetv2() -> None:
    # ConfigurationManager isn't importable in this sandbox (no real nnunetv2
    # install, see module docstring) -- this documents that calling the
    # installer without nnunetv2 available raises rather than silently
    # no-op'ing, matching _require_nnunetv2's pattern elsewhere in this module.
    if ni.NNUNETV2_AVAILABLE:
        pytest.skip("only exercises the no-nnunetv2 error path")
    with pytest.raises(ImportError):
        ni.install_skip_unused_seg_resample()


# ---------------------------------------------------------------------------
# Track A: _cgroup_cpu_quota / _default_resample_n_threads / _parallel_resample_channel
# / parallel_resample_data / install_parallel_data_resampling (2026-07-13 D2 efficiency
# work -- CPU multi-threaded parallelization of ConfigurationManager.resampling_fn_data,
# the single biggest remaining preprocessing bottleneck, 31.5s of ~37s/case
# single-threaded). Re-verified end-to-end on real production-scale CBCT data on a real
# GPU box (a GPU box, RTX 3090, 14-vCPU cgroup quota) via the REAL integrated
# install_parallel_data_resampling() monkeypatch (not just the earlier standalone
# prototype): bit-exact (np.array_equal True, max abs diff 0.0) vs. the untouched
# original resample_data_or_seg_to_shape, both for the full preprocessor.run_case()
# pipeline and for the resampling_fn_data step in isolation (40.25s -> 18.76s, 2.146x
# speedup for that step alone on case_006 -- see docs/progress.md). is_seg=True and
# anisotropic-spacing fallback branches also confirmed to route to the untouched
# original function on that same real box.
#
# _cgroup_cpu_quota, _default_resample_n_threads, _parallel_resample_channel are pure
# CPU/scipy logic with no nnunetv2 dependency -- fully exercised here, not skipped,
# even in this sandbox (no GPU, no nnunetv2 install). parallel_resample_data needs
# scikit-image (only pulled in transitively by the 'training' extra, see
# pyproject.toml) and is importorskip'd. _parallel_resample_data_to_shape and
# install_parallel_data_resampling need a real nnunetv2 install (the former imports
# nnunetv2.preprocessing.resampling.default_resampling.determine_do_sep_z_and_axis
# unconditionally, even on its is_seg=True early-return path; the latter patches the
# real ConfigurationManager class) and are skipped here, following this file's
# existing NNUNETV2_AVAILABLE convention -- their branch logic was validated for real
# on the GPU box described above.
# ---------------------------------------------------------------------------


class _FakeCgroupPath:
    """Stand-in for ``pathlib.Path`` that serves canned ``read_text()`` content for a
    fixed set of paths and raises ``OSError`` (matching a real missing/unreadable
    file) for anything else -- lets us exercise ``_cgroup_cpu_quota``'s v2/v1/missing
    parsing branches without touching the real filesystem (this dev sandbox is macOS,
    which has no ``/sys/fs/cgroup`` at all).
    """

    def __init__(self, text_by_path: dict) -> None:
        self._text_by_path = text_by_path

    def __call__(self, path_str: str) -> "_FakeCgroupPath._Instance":
        return _FakeCgroupPath._Instance(path_str, self._text_by_path)

    class _Instance:
        def __init__(self, path_str: str, text_by_path: dict) -> None:
            self._path_str = path_str
            self._text_by_path = text_by_path

        def read_text(self) -> str:
            if self._path_str not in self._text_by_path:
                raise OSError(f"no such fake file: {self._path_str}")
            return self._text_by_path[self._path_str]


def test_cgroup_cpu_quota_parses_real_cgroup_v2_format(monkeypatch) -> None:
    monkeypatch.setattr(ni, "Path", _FakeCgroupPath({"/sys/fs/cgroup/cpu.max": "1400000 100000\n"}))
    assert ni._cgroup_cpu_quota() == 14


def test_cgroup_cpu_quota_v2_unlimited_falls_back_to_v1(monkeypatch) -> None:
    monkeypatch.setattr(
        ni,
        "Path",
        _FakeCgroupPath(
            {
                "/sys/fs/cgroup/cpu.max": "max 100000\n",
                "/sys/fs/cgroup/cpu/cpu.cfs_quota_us": "500000\n",
                "/sys/fs/cgroup/cpu/cpu.cfs_period_us": "100000\n",
            }
        ),
    )
    assert ni._cgroup_cpu_quota() == 5


def test_cgroup_cpu_quota_missing_files_returns_none(monkeypatch) -> None:
    monkeypatch.setattr(ni, "Path", _FakeCgroupPath({}))
    assert ni._cgroup_cpu_quota() is None


def test_cgroup_cpu_quota_v1_unset_quota_returns_none(monkeypatch) -> None:
    # cgroup v1's convention for "no limit" is a quota of -1.
    monkeypatch.setattr(
        ni,
        "Path",
        _FakeCgroupPath(
            {
                "/sys/fs/cgroup/cpu/cpu.cfs_quota_us": "-1\n",
                "/sys/fs/cgroup/cpu/cpu.cfs_period_us": "100000\n",
            }
        ),
    )
    assert ni._cgroup_cpu_quota() is None


def test_cgroup_cpu_quota_clamps_sub_one_core_quota_to_one(monkeypatch) -> None:
    # quota // period floors to 0 when the quota is less than one full period.
    monkeypatch.setattr(ni, "Path", _FakeCgroupPath({"/sys/fs/cgroup/cpu.max": "5000 100000\n"}))
    assert ni._cgroup_cpu_quota() == 1


def test_cgroup_cpu_quota_real_sandbox_has_no_cgroup() -> None:
    # Documents this dev sandbox's actual (unmocked) behavior: macOS has no
    # /sys/fs/cgroup at all, so the real function should return None here, not
    # raise. Loosened to "None or a valid int" so this doesn't break if this test
    # suite is ever run inside a real Linux cgroup (e.g. a future CI container).
    result = ni._cgroup_cpu_quota()
    assert result is None or (isinstance(result, int) and result >= 1)


def test_default_resample_n_threads_min_of_cgroup_cpu_count_and_cap(monkeypatch) -> None:
    monkeypatch.setattr(ni, "_cgroup_cpu_quota", lambda: 20)
    monkeypatch.setattr(os_module, "cpu_count", lambda: 32)
    assert ni._default_resample_n_threads(max_threads_cap=16) == 16


def test_default_resample_n_threads_cgroup_quota_is_the_bottleneck(monkeypatch) -> None:
    monkeypatch.setattr(ni, "_cgroup_cpu_quota", lambda: 4)
    monkeypatch.setattr(os_module, "cpu_count", lambda: 32)
    assert ni._default_resample_n_threads(max_threads_cap=16) == 4


def test_default_resample_n_threads_falls_back_to_cpu_count_when_no_cgroup_quota(monkeypatch) -> None:
    monkeypatch.setattr(ni, "_cgroup_cpu_quota", lambda: None)
    monkeypatch.setattr(os_module, "cpu_count", lambda: 6)
    assert ni._default_resample_n_threads(max_threads_cap=16) == 6


def test_default_resample_n_threads_at_least_one_when_no_signals_available(monkeypatch) -> None:
    monkeypatch.setattr(ni, "_cgroup_cpu_quota", lambda: None)
    monkeypatch.setattr(os_module, "cpu_count", lambda: None)
    assert ni._default_resample_n_threads(max_threads_cap=0) == 1


def test_default_resample_n_threads_real_sandbox_returns_positive_int() -> None:
    # No mocking -- documents this actually resolves to a usable value on the real
    # dev sandbox (no cgroup, real os.cpu_count()).
    result = ni._default_resample_n_threads()
    assert isinstance(result, int) and result >= 1


# --- _parallel_resample_channel: real scipy, no nnunetv2/skimage needed ------------


def test_parallel_resample_channel_bit_exact_across_thread_counts() -> None:
    rng = np.random.RandomState(0)
    img = rng.rand(6, 7, 5).astype(np.float64)
    new_shape = (10, 9, 8)
    out1 = ni._parallel_resample_channel(img, new_shape, order=3, ndi_mode="nearest", n_threads=1)
    out4 = ni._parallel_resample_channel(img, new_shape, order=3, ndi_mode="nearest", n_threads=4)
    assert out1.shape == new_shape
    assert np.array_equal(out1, out4)


def test_parallel_resample_channel_bit_exact_against_real_scipy_zoom_reference() -> None:
    # Docstring claim under test: chunked map_coordinates evaluation over a shared,
    # fully-computed B-spline coefficient array is bit-exact BY CONSTRUCTION vs. a
    # single unchunked scipy.ndimage.zoom(..., grid_mode=True) call, for any n_threads.
    from scipy import ndimage as ndi

    rng = np.random.RandomState(1)
    img = rng.rand(8, 6, 9).astype(np.float64)
    new_shape = (12, 5, 11)
    order = 3
    ndi_mode = "nearest"

    zoom_factors = np.array(new_shape, dtype=np.float64) / np.array(img.shape, dtype=np.float64)
    reference = ndi.zoom(img, zoom_factors, order=order, mode=ndi_mode, grid_mode=True)

    for n_threads in (1, 3, 5):
        out = ni._parallel_resample_channel(img, new_shape, order=order, ndi_mode=ndi_mode, n_threads=n_threads)
        assert np.array_equal(out, reference), f"mismatch at n_threads={n_threads}"


def test_parallel_resample_channel_handles_more_threads_than_output_rows() -> None:
    # output_shape[0] == 3 but n_threads=8 -- must clamp rather than crash on an
    # empty/degenerate chunk.
    rng = np.random.RandomState(2)
    img = rng.rand(4, 4, 4).astype(np.float64)
    new_shape = (3, 5, 5)
    out1 = ni._parallel_resample_channel(img, new_shape, order=3, ndi_mode="nearest", n_threads=1)
    out8 = ni._parallel_resample_channel(img, new_shape, order=3, ndi_mode="nearest", n_threads=8)
    assert out8.shape == new_shape
    assert np.array_equal(out1, out8)


def test_parallel_resample_channel_order_one_matches_reference() -> None:
    from scipy import ndimage as ndi

    rng = np.random.RandomState(3)
    img = rng.rand(5, 5, 5).astype(np.float64)
    new_shape = (7, 6, 8)
    zoom_factors = np.array(new_shape, dtype=np.float64) / np.array(img.shape, dtype=np.float64)
    reference = ndi.zoom(img, zoom_factors, order=1, mode="reflect", grid_mode=True)
    out = ni._parallel_resample_channel(img, new_shape, order=1, ndi_mode="reflect", n_threads=3)
    assert np.array_equal(out, reference)


def test_parallel_resample_channel_chunked_matches_unchunked_reference() -> None:
    """Verify that chunked (small max_chunk_coord_bytes) and unchunked (large
    max_chunk_coord_bytes) approaches produce identical results, and both match
    the real scipy.ndimage.zoom reference. This tests the core invariant: per-chunk
    coordinate construction produces the same floating-point values as slicing a
    pre-computed full array.
    """
    from scipy import ndimage as ndi

    rng = np.random.RandomState(10)
    img = rng.rand(8, 6, 9).astype(np.float64)
    new_shape = (12, 5, 11)
    order = 3
    ndi_mode = "nearest"

    # Reference: real scipy.ndimage.zoom
    zoom_factors = np.array(new_shape, dtype=np.float64) / np.array(img.shape, dtype=np.float64)
    reference = ndi.zoom(img, zoom_factors, order=order, mode=ndi_mode, grid_mode=True)

    # Large max_chunk_coord_bytes: should fit everything in one chunk (unchunked behavior)
    out_unchunked = ni._parallel_resample_channel(
        img, new_shape, order=order, ndi_mode=ndi_mode, n_threads=3, max_chunk_coord_bytes=10**9
    )

    # Tiny max_chunk_coord_bytes: forces many small chunks (many chunks per output row)
    out_chunked = ni._parallel_resample_channel(
        img, new_shape, order=order, ndi_mode=ndi_mode, n_threads=3, max_chunk_coord_bytes=256
    )

    # All three should be identical
    assert np.array_equal(out_unchunked, reference)
    assert np.array_equal(out_chunked, reference)
    assert np.array_equal(out_unchunked, out_chunked)


def test_parallel_resample_channel_edge_case_single_output_row() -> None:
    """Verify the edge case where output_shape[0] == 1 and max_chunk_coord_bytes
    is tiny (smaller than a single row's coords). Must clamp to chunk_depth=1
    and process the single row without crashing.
    """
    from scipy import ndimage as ndi

    rng = np.random.RandomState(11)
    img = rng.rand(4, 4, 4).astype(np.float64)
    new_shape = (1, 5, 5)
    order = 3
    ndi_mode = "nearest"

    zoom_factors = np.array(new_shape, dtype=np.float64) / np.array(img.shape, dtype=np.float64)
    reference = ndi.zoom(img, zoom_factors, order=order, mode=ndi_mode, grid_mode=True)

    # Tiny max_chunk_coord_bytes, even smaller than one row
    out = ni._parallel_resample_channel(
        img, new_shape, order=order, ndi_mode=ndi_mode, n_threads=2, max_chunk_coord_bytes=1
    )

    assert out.shape == new_shape
    assert np.array_equal(out, reference)


def test_parallel_resample_channel_very_small_coords_budget_forces_chunking() -> None:
    """Verify that with a very restrictive max_chunk_coord_bytes, we still get
    the correct result (no mathematical errors, just more chunks). This indirectly
    tests the per-chunk coordinate formula equivalence.
    """
    from scipy import ndimage as ndi

    rng = np.random.RandomState(12)
    img = rng.rand(6, 8, 10).astype(np.float64)
    new_shape = (9, 7, 12)
    order = 1  # order=1 is cheaper to compute for this stress test
    ndi_mode = "reflect"

    zoom_factors = np.array(new_shape, dtype=np.float64) / np.array(img.shape, dtype=np.float64)
    reference = ndi.zoom(img, zoom_factors, order=order, mode=ndi_mode, grid_mode=True)

    # Very restrictive budget to force many chunks
    out = ni._parallel_resample_channel(
        img, new_shape, order=order, ndi_mode=ndi_mode, n_threads=4, max_chunk_coord_bytes=512
    )

    assert out.shape == new_shape
    assert np.array_equal(out, reference)


# --- parallel_resample_data: needs scikit-image (transitive 'training' extra dep) --


def test_parallel_resample_data_bit_exact_across_thread_counts() -> None:
    pytest.importorskip("skimage")
    rng = np.random.RandomState(4)
    data = rng.rand(2, 6, 7, 5).astype(np.float32)
    new_shape = (9, 11, 8)
    out1 = ni.parallel_resample_data(data, new_shape, order=3, skimage_mode="edge", n_threads=1)
    out4 = ni.parallel_resample_data(data, new_shape, order=3, skimage_mode="edge", n_threads=4)
    assert np.array_equal(out1, out4)
    assert out1.shape == (2, 9, 11, 8)
    assert out1.dtype == data.dtype


def test_parallel_resample_data_matches_real_skimage_resize_reference() -> None:
    pytest.importorskip("skimage")
    from skimage.transform import resize

    rng = np.random.RandomState(5)
    data = rng.rand(2, 6, 7, 5).astype(np.float32)
    new_shape = (9, 11, 8)
    out = ni.parallel_resample_data(data, new_shape, order=3, skimage_mode="edge", n_threads=2)
    for c in range(data.shape[0]):
        reference = resize(data[c], new_shape, order=3, mode="edge", anti_aliasing=False)
        assert np.array_equal(out[c], reference.astype(data.dtype)), f"channel {c} mismatch"


def test_parallel_resample_data_no_op_shortcut_returns_same_array() -> None:
    pytest.importorskip("skimage")
    data = np.zeros((1, 4, 4, 4), dtype=np.float32)
    result = ni.parallel_resample_data(data, (4, 4, 4), order=3, skimage_mode="edge", n_threads=2)
    assert result is data


def test_parallel_resample_data_preserves_original_dtype() -> None:
    pytest.importorskip("skimage")
    data = np.random.RandomState(6).rand(1, 5, 5, 5).astype(np.float32)
    out = ni.parallel_resample_data(data, (7, 6, 8), order=3, skimage_mode="edge", n_threads=2)
    assert out.dtype == np.float32


# --- _parallel_resample_data_to_shape / install_parallel_data_resampling: need a
# real nnunetv2 install (see comment block above) -- validated for real on a GPU box -----


@pytest.mark.skipif(not ni.NNUNETV2_AVAILABLE, reason="imports nnunetv2 unconditionally, even on the is_seg=True path")
def test_parallel_resample_data_to_shape_is_seg_falls_back_to_orig_fn() -> None:
    sentinel = np.full((1, 4, 4, 4), 999.0, dtype=np.float32)
    calls = []

    def orig_fn(data, new_shape, current_spacing, new_spacing):
        calls.append((tuple(new_shape), tuple(current_spacing), tuple(new_spacing)))
        return sentinel

    data = np.random.RandomState(7).rand(1, 8, 8, 8).astype(np.float32)
    out = ni._parallel_resample_data_to_shape(
        data, (10, 10, 10), (0.3, 0.3, 0.3), (0.3, 0.3, 0.3), orig_fn=orig_fn, is_seg=True
    )
    assert out is sentinel
    assert len(calls) == 1


@pytest.mark.skipif(not ni.NNUNETV2_AVAILABLE, reason="needs real nnunetv2.determine_do_sep_z_and_axis")
def test_parallel_resample_data_to_shape_anisotropic_spacing_falls_back_to_orig_fn() -> None:
    sentinel = np.full((1, 4, 4, 4), 999.0, dtype=np.float32)

    def orig_fn(data, new_shape, current_spacing, new_spacing):
        return sentinel

    data = np.random.RandomState(8).rand(1, 8, 8, 8).astype(np.float32)
    out = ni._parallel_resample_data_to_shape(
        data, (10, 10, 10), (0.3, 0.3, 3.0), (0.3, 0.3, 3.0), orig_fn=orig_fn, is_seg=False
    )
    assert out is sentinel


@pytest.mark.skipif(not ni.NNUNETV2_AVAILABLE, reason="needs real nnunetv2.determine_do_sep_z_and_axis")
def test_parallel_resample_data_to_shape_isotropic_data_takes_parallel_path() -> None:
    def orig_fn(*args, **kwargs):
        raise AssertionError("isotropic is_seg=False must not fall back to orig_fn")

    data = np.random.RandomState(9).rand(1, 8, 8, 8).astype(np.float32)
    out = ni._parallel_resample_data_to_shape(
        data, (10, 10, 10), (0.3, 0.3, 0.3), (0.3, 0.3, 0.3), orig_fn=orig_fn, is_seg=False, n_threads=2
    )
    assert out.shape == (1, 10, 10, 10)


@pytest.mark.skipif(not ni.NNUNETV2_AVAILABLE, reason="patches the real ConfigurationManager class")
def test_install_parallel_data_resampling_is_idempotent() -> None:
    from nnunetv2.utilities.plans_handling.plans_handler import ConfigurationManager

    ni.install_parallel_data_resampling()
    first_property = ConfigurationManager.resampling_fn_data
    assert ConfigurationManager._stsr_parallel_data_resample_installed is True

    ni.install_parallel_data_resampling()  # second call must be a no-op
    assert ConfigurationManager.resampling_fn_data is first_property


def test_install_parallel_data_resampling_without_nnunetv2_raises_importerror() -> None:
    # ConfigurationManager isn't importable in this sandbox (no real nnunetv2
    # install, see module docstring) -- matches this file's existing convention for
    # install_skip_unused_seg_resample above.
    if ni.NNUNETV2_AVAILABLE:
        pytest.skip("only exercises the no-nnunetv2 error path")
    with pytest.raises(ImportError):
        ni.install_parallel_data_resampling()
