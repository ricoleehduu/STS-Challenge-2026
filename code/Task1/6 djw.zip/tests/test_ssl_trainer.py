"""Unit tests for the phase B/C SSL trainer's pure-math pieces.

These tests exercise only the CPU-testable functions in
``stsr2026.training.ssl_trainer`` (ramp-up schedule, unlabeled-usage
probability, phase-C LR schedule, feature perturbation, pseudo-label
masking) against hand-computed expected values and mock tensors. They do
**not** exercise the ``nnUNetTrainer`` subclasses, which require a working
``nnunetv2`` + GPU install and have not been run end-to-end -- see the
module docstring in ``ssl_trainer.py``.
"""
from __future__ import annotations

import math
import random

import pytest

torch = pytest.importorskip("torch")

from stsr2026.training import ssl_trainer as ssl  # noqa: E402


# ---------------------------------------------------------------------------
# consistency_ramp_up_weight
# ---------------------------------------------------------------------------


def test_ramp_up_weight_at_start_of_window_is_near_zero() -> None:
    # s=0 -> exp(-5) * max_weight
    weight = ssl.consistency_ramp_up_weight(current_iter=0, total_iters=1000, max_weight=50.0, rampup_fraction=0.2)
    expected = 50.0 * math.exp(-5.0)
    assert weight == pytest.approx(expected)
    assert weight == pytest.approx(0.33689735, rel=1e-6)


def test_ramp_up_weight_at_end_of_window_equals_max() -> None:
    # rampup window = 0.2 * 1000 = 200 iterations; s=1 exactly at iter 200
    weight = ssl.consistency_ramp_up_weight(current_iter=200, total_iters=1000, max_weight=50.0, rampup_fraction=0.2)
    assert weight == pytest.approx(50.0)


def test_ramp_up_weight_midway_through_window() -> None:
    # s=0.5 -> max_weight * exp(-5 * 0.25) = max_weight * exp(-1.25)
    weight = ssl.consistency_ramp_up_weight(current_iter=100, total_iters=1000, max_weight=50.0, rampup_fraction=0.2)
    expected = 50.0 * math.exp(-1.25)
    assert weight == pytest.approx(expected)


def test_ramp_up_weight_holds_at_max_after_window() -> None:
    # past the rampup window, s clamps to 1 and weight stays at max_weight
    weight_at_window_end = ssl.consistency_ramp_up_weight(200, 1000, 50.0, 0.2)
    weight_past_window = ssl.consistency_ramp_up_weight(900, 1000, 50.0, 0.2)
    assert weight_past_window == pytest.approx(weight_at_window_end)
    assert weight_past_window == pytest.approx(50.0)


def test_ramp_up_weight_rejects_non_positive_total_iters() -> None:
    with pytest.raises(ValueError):
        ssl.consistency_ramp_up_weight(0, 0)


# ---------------------------------------------------------------------------
# unlabeled_usage_probability
# ---------------------------------------------------------------------------


def test_unlabeled_usage_probability_at_epoch_zero_is_start_rate() -> None:
    assert ssl.unlabeled_usage_probability(0, 100) == pytest.approx(0.1)


def test_unlabeled_usage_probability_ramps_linearly_below_cap() -> None:
    # epoch=30/100 -> 0.3 + 0.1 = 0.4, below the 0.5 cap
    assert ssl.unlabeled_usage_probability(30, 100) == pytest.approx(0.4)


def test_unlabeled_usage_probability_caps_at_half() -> None:
    # epoch=80/100 -> uncapped would be 0.9; capped at 0.5
    assert ssl.unlabeled_usage_probability(80, 100) == pytest.approx(0.5)
    # exact boundary: epoch=40/100 -> 0.4+0.1 = 0.5 (right at the cap)
    assert ssl.unlabeled_usage_probability(40, 100) == pytest.approx(0.5)


def test_unlabeled_usage_probability_phase_c_start_rate() -> None:
    # phase C raises the starting rate to 0.3
    assert ssl.unlabeled_usage_probability(0, 100, start=ssl.PHASE_C_UNLABELED_START_RATE) == pytest.approx(0.3)
    # ramps up and still caps at 0.5
    assert ssl.unlabeled_usage_probability(50, 100, start=ssl.PHASE_C_UNLABELED_START_RATE) == pytest.approx(0.5)


def test_unlabeled_usage_probability_rejects_non_positive_num_epochs() -> None:
    with pytest.raises(ValueError):
        ssl.unlabeled_usage_probability(0, 0)


# ---------------------------------------------------------------------------
# phase_c_lr_schedule
# ---------------------------------------------------------------------------


def test_phase_c_lr_schedule_starts_at_base_lr() -> None:
    lr = ssl.phase_c_lr_schedule(0, 1000, base_lr=0.001, min_fraction=0.01)
    assert lr == pytest.approx(0.001)


def test_phase_c_lr_schedule_ends_at_one_percent_of_base() -> None:
    lr = ssl.phase_c_lr_schedule(1000, 1000, base_lr=0.001, min_fraction=0.01)
    assert lr == pytest.approx(0.00001)


def test_phase_c_lr_schedule_is_linear_at_midpoint() -> None:
    lr = ssl.phase_c_lr_schedule(500, 1000, base_lr=0.001, min_fraction=0.01)
    expected = 0.001 + (0.00001 - 0.001) * 0.5
    assert lr == pytest.approx(expected)


def test_phase_c_lr_schedule_clamps_past_total_steps() -> None:
    lr_at_end = ssl.phase_c_lr_schedule(1000, 1000, base_lr=0.001, min_fraction=0.01)
    lr_past_end = ssl.phase_c_lr_schedule(5000, 1000, base_lr=0.001, min_fraction=0.01)
    assert lr_past_end == pytest.approx(lr_at_end)


def test_phase_c_lr_schedule_rejects_non_positive_total_steps() -> None:
    with pytest.raises(ValueError):
        ssl.phase_c_lr_schedule(0, 0)


# ---------------------------------------------------------------------------
# should_use_pseudo_label_branch
# ---------------------------------------------------------------------------


def test_pseudo_label_branch_probability_is_roughly_one_quarter() -> None:
    rng = random.Random(0)
    n = 20000
    hits = sum(ssl.should_use_pseudo_label_branch(rng) for _ in range(n))
    frequency = hits / n
    assert frequency == pytest.approx(0.25, abs=0.02)


def test_pseudo_label_branch_probability_is_configurable() -> None:
    rng = random.Random(0)
    n = 20000
    hits = sum(ssl.should_use_pseudo_label_branch(rng, probability=0.9) for _ in range(n))
    assert hits / n == pytest.approx(0.9, abs=0.02)


# ---------------------------------------------------------------------------
# channel_attention_mask / perturb_feature / perturb_encoder_skips
# ---------------------------------------------------------------------------


def test_channel_attention_mask_keeps_below_threshold_channels() -> None:
    # 2 channels: channel 0 has mean activation 1.0 (above threshold),
    # channel 1 has mean activation 0.0 (below threshold).
    feature = torch.zeros(1, 2, 2, 2, 2)
    feature[:, 0] = 1.0
    feature[:, 1] = 0.0
    mask = ssl.channel_attention_mask(feature, threshold=0.5)
    assert mask.shape == (1, 2, 1, 1, 1)
    # (attention < threshold): channel 0 (mean=1.0) is NOT kept, channel 1 (mean=0.0) IS kept.
    assert mask[0, 0, 0, 0, 0].item() == 0.0
    assert mask[0, 1, 0, 0, 0].item() == 1.0


def test_perturb_feature_applies_dropout_mask_and_noise_not_identity() -> None:
    torch.manual_seed(0)
    feature = torch.ones(2, 8, 4, 4, 4)
    out = ssl.perturb_feature(feature, threshold=0.9, dropout_p=0.5, training=True)
    assert out.shape == feature.shape
    # threshold=0.9 keeps every channel (mean activation 1.0 < 0.9 is False,
    # so actually excluded)... pick a threshold that demonstrably changes
    # values regardless of the attention mask: dropout3d zeroes whole
    # channels, and multiplicative noise perturbs the rest, so the output
    # must differ from the untouched input somewhere.
    assert not torch.equal(out, feature)


def test_perturb_feature_dropout3d_zeroes_whole_channels() -> None:
    torch.manual_seed(1)
    # Use a threshold high enough that the (attention < threshold) mask
    # keeps everything (mean activation of 1.0 < 2.0), isolating dropout3d's
    # effect: entire channels should become exactly zero.
    feature = torch.ones(4, 16, 3, 3, 3)
    out = ssl.perturb_feature(feature, threshold=2.0, dropout_p=1.0, training=True)
    # dropout_p=1.0 => every channel is dropped => output is all zeros
    # regardless of the mask/noise multiplying zero.
    assert torch.count_nonzero(out).item() == 0


def test_perturb_feature_no_dropout_still_applies_mask_and_noise() -> None:
    torch.manual_seed(2)
    feature = torch.ones(1, 4, 2, 2, 2)
    # dropout_p=0 disables dropout; threshold=2.0 keeps all channels (mean
    # 1.0 < 2.0), so only the multiplicative noise should change values.
    out = ssl.perturb_feature(feature, threshold=2.0, dropout_p=0.0, training=True)
    assert torch.count_nonzero(out).item() == out.numel()  # nothing dropped
    assert not torch.equal(out, feature)  # noise changed the values
    # multiplicative Uniform(-0.3, 0.3) noise: out = feature * (1 + noise),
    # so out must stay within [0.7, 1.3] given feature == 1.0 everywhere.
    assert torch.all(out >= 0.7 - 1e-6)
    assert torch.all(out <= 1.3 + 1e-6)


def test_perturb_feature_eval_mode_disables_dropout() -> None:
    torch.manual_seed(3)
    feature = torch.ones(4, 16, 3, 3, 3)
    out = ssl.perturb_feature(feature, threshold=2.0, dropout_p=1.0, training=False)
    # training=False => dropout3d is a no-op regardless of dropout_p
    assert torch.count_nonzero(out).item() == out.numel()


def test_perturb_encoder_skips_only_touches_last_five() -> None:
    torch.manual_seed(4)
    # 7 skip features; only the last 5 (index -5..-1, i.e. indices 2..6)
    # should be perturbed. Use dropout_p=0 and an extreme noise range so any
    # touched tensor is guaranteed to differ from the input.
    skips = [torch.ones(1, 4, 2, 2, 2) * (i + 1) for i in range(7)]
    out = ssl.perturb_encoder_skips(skips, num_last=5, dropout_p=0.0, noise_range=(-0.3, 0.3))
    assert len(out) == 7
    for i in range(7):
        assert out[i].shape == skips[i].shape
    # first 2 (index -7, -6 relative, i.e. absolute indices 0, 1) untouched
    assert torch.equal(out[0], skips[0])
    assert torch.equal(out[1], skips[1])
    # last 5 (absolute indices 2..6) should differ (noise applied); with an
    # extreme threshold that keeps everything (mean activation < 0.9 range
    # sampled, but values are all-positive integers so at least highly
    # likely to differ from pure multiplicative noise or masking)
    changed = any(not torch.equal(out[i], skips[i]) for i in range(2, 7))
    assert changed


def test_perturb_encoder_skips_with_fewer_than_num_last_perturbs_all() -> None:
    torch.manual_seed(5)
    skips = [torch.ones(1, 2, 2, 2, 2), torch.ones(1, 2, 2, 2, 2)]
    out = ssl.perturb_encoder_skips(skips, num_last=5, dropout_p=0.0, noise_range=(-0.3, 0.3))
    assert len(out) == 2
    # both should be candidates for perturbation (start_idx clamped to 0)
    assert out[0].shape == skips[0].shape
    assert out[1].shape == skips[1].shape


def test_perturb_encoder_skips_empty_list() -> None:
    assert ssl.perturb_encoder_skips([]) == []


# ---------------------------------------------------------------------------
# SoftmaxMSELoss / ConsistencyDeepSupervisionWrapper
# ---------------------------------------------------------------------------


def test_softmax_mse_loss_is_zero_for_identical_logits() -> None:
    loss_fn = ssl.SoftmaxMSELoss()
    logits = torch.randn(2, 5, 4, 4, 4)
    loss = loss_fn(logits, logits.clone())
    assert loss.item() == pytest.approx(0.0, abs=1e-6)


def test_softmax_mse_loss_is_positive_for_different_logits() -> None:
    torch.manual_seed(6)
    loss_fn = ssl.SoftmaxMSELoss()
    student = torch.randn(2, 5, 4, 4, 4)
    teacher = torch.randn(2, 5, 4, 4, 4)
    loss = loss_fn(student, teacher)
    assert loss.item() > 0.0


def test_softmax_mse_loss_hand_computed_two_class_case() -> None:
    # 1 batch, 2 classes, 1 voxel: student logits [0, 0] -> softmax [0.5, 0.5]
    # teacher logits [10, -10] -> softmax approx [1, 0]
    loss_fn = ssl.SoftmaxMSELoss()
    student = torch.tensor([[[[[0.0]]], [[[0.0]]]]])  # shape (1, 2, 1, 1, 1)
    teacher = torch.tensor([[[[[10.0]]], [[[-10.0]]]]])
    loss = loss_fn(student, teacher)
    teacher_probs = torch.softmax(teacher, dim=1)
    expected = torch.mean((torch.tensor([0.5, 0.5]) - teacher_probs.flatten()) ** 2)
    assert loss.item() == pytest.approx(expected.item(), rel=1e-4)


def test_default_deep_supervision_weights_sum_to_one_and_zero_last() -> None:
    weights = ssl.default_deep_supervision_weights(4)
    assert weights[-1] == 0.0
    assert sum(weights) == pytest.approx(1.0)
    # weight ratio between successive (non-excluded) scales is 2x
    assert weights[0] == pytest.approx(2 * weights[1])
    assert weights[1] == pytest.approx(2 * weights[2])


def test_default_deep_supervision_weights_single_output() -> None:
    weights = ssl.default_deep_supervision_weights(1)
    assert weights == [1.0]


def test_consistency_deep_supervision_wrapper_weights_scales_correctly() -> None:
    torch.manual_seed(7)
    base = ssl.SoftmaxMSELoss()
    wrapper = ssl.ConsistencyDeepSupervisionWrapper(base, weights=[0.7, 0.3])
    student = [torch.randn(1, 3, 2, 2, 2), torch.randn(1, 3, 2, 2, 2)]
    teacher = [torch.randn(1, 3, 2, 2, 2), torch.randn(1, 3, 2, 2, 2)]
    combined = wrapper(student, teacher)
    expected = 0.7 * base(student[0], teacher[0]) + 0.3 * base(student[1], teacher[1])
    assert combined.item() == pytest.approx(expected.item(), rel=1e-5)


def test_consistency_deep_supervision_wrapper_skips_zero_weighted_scales() -> None:
    base = ssl.SoftmaxMSELoss()
    wrapper = ssl.ConsistencyDeepSupervisionWrapper(base, weights=[1.0, 0.0])
    student = [torch.randn(1, 3, 2, 2, 2), torch.full((1, 3, 2, 2, 2), float("nan"))]
    teacher = [torch.randn(1, 3, 2, 2, 2), torch.full((1, 3, 2, 2, 2), float("nan"))]
    combined = wrapper(student, teacher)
    # the NaN-filled zero-weighted scale must not poison the result
    assert not torch.isnan(combined)


def test_consistency_deep_supervision_wrapper_mismatched_lengths_raises() -> None:
    base = ssl.SoftmaxMSELoss()
    wrapper = ssl.ConsistencyDeepSupervisionWrapper(base)
    with pytest.raises(ValueError):
        wrapper([torch.randn(1, 3, 2, 2, 2)], [torch.randn(1, 3, 2, 2, 2), torch.randn(1, 3, 2, 2, 2)])


# ---------------------------------------------------------------------------
# build_pseudo_labels
# ---------------------------------------------------------------------------


def test_build_pseudo_labels_high_confidence_voxel_keeps_argmax() -> None:
    # 1 batch, 3 classes, 1 voxel, class 2 has probability 0.9 (>= 0.75)
    probs = torch.tensor([[[[[0.05]]], [[[0.05]]], [[[0.9]]]]])  # shape (1, 3, 1, 1, 1)
    result = ssl.build_pseudo_labels(probs, confidence_threshold=0.75)
    assert result.labels.item() == 2
    assert result.ignore_mask.item() is False
    assert result.low_confidence_mask.item() is False


def test_build_pseudo_labels_low_confidence_voxel_relabeled_to_ignore() -> None:
    # class 2 has only 0.5 probability (< 0.75) -> relabeled to 0 and ignored
    probs = torch.tensor([[[[[0.3]]], [[[0.2]]], [[[0.5]]]]])
    result = ssl.build_pseudo_labels(probs, confidence_threshold=0.75)
    assert result.labels.item() == 0
    assert result.ignore_mask.item() is True
    assert result.low_confidence_mask.item() is True


def test_build_pseudo_labels_genuine_background_is_also_ignored() -> None:
    # class 0 (background) wins with high confidence -- per the champion
    # code's flat-threshold quirk, label 0 is *always* treated as ignore in
    # this branch, regardless of whether it came from low confidence or a
    # genuine high-confidence background prediction.
    probs = torch.tensor([[[[[0.95]]], [[[0.03]]], [[[0.02]]]]])
    result = ssl.build_pseudo_labels(probs, confidence_threshold=0.75)
    assert result.labels.item() == 0
    assert result.ignore_mask.item() is True
    # this voxel was NOT relabeled due to low confidence -- it was already
    # class 0 -- so low_confidence_mask must be False even though
    # ignore_mask is True.
    assert result.low_confidence_mask.item() is False


def test_build_pseudo_labels_mixed_batch_shapes_and_values() -> None:
    torch.manual_seed(8)
    batch, num_classes, d, h, w = 2, 5, 3, 3, 3
    logits = torch.randn(batch, num_classes, d, h, w)
    probs = torch.softmax(logits, dim=1)
    result = ssl.build_pseudo_labels(probs, confidence_threshold=0.75)
    assert result.labels.shape == (batch, d, h, w)
    assert result.ignore_mask.shape == (batch, d, h, w)
    assert result.low_confidence_mask.shape == (batch, d, h, w)
    # ignore_mask must exactly equal (labels == 0)
    assert torch.equal(result.ignore_mask, result.labels == 0)
    # low_confidence_mask is always a subset of ignore_mask
    assert torch.all(result.ignore_mask[result.low_confidence_mask])
    # every low-confidence voxel's max probability is indeed below threshold
    max_probs, _ = probs.max(dim=1)
    assert torch.all(max_probs[result.low_confidence_mask] < 0.75)
    assert torch.all(max_probs[~result.low_confidence_mask] >= 0.75) or not torch.any(~result.low_confidence_mask)


def test_build_pseudo_labels_custom_ignore_index() -> None:
    probs = torch.tensor([[[[[0.3]]], [[[0.2]]], [[[0.5]]]]])
    result = ssl.build_pseudo_labels(probs, confidence_threshold=0.75, ignore_index=99)
    assert result.labels.item() == 99
    assert result.ignore_mask.item() is True


# ---------------------------------------------------------------------------
# Trainer classes: presence/absence depending on nnunetv2 availability
# ---------------------------------------------------------------------------


def test_trainer_classes_reflect_nnunetv2_availability() -> None:
    if ssl.NNUNETV2_AVAILABLE:
        assert ssl.nnUNetTrainer_STSR_PhaseB is not None
        assert ssl.nnUNetTrainer_STSR_PhaseC is not None
        assert issubclass(ssl.nnUNetTrainer_STSR_PhaseC, ssl.nnUNetTrainer_STSR_PhaseB)
    else:
        assert ssl.nnUNetTrainer_STSR_PhaseB is None
        assert ssl.nnUNetTrainer_STSR_PhaseC is None
