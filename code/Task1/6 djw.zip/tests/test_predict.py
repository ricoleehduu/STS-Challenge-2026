from __future__ import annotations

from pathlib import Path

import nibabel as nib
import numpy as np

from stsr2026.inference.predict import fake_predict, run_inference


def _write_nifti(path: Path, values: np.ndarray) -> None:
    affine = np.diag([0.3, 0.4, 0.5, 1.0])
    affine[:3, 3] = [1.0, 2.0, 3.0]
    nib.save(nib.Nifti1Image(values, affine), str(path))


def test_run_inference_preserves_geometry_and_case_names(tmp_path: Path) -> None:
    input_dir, output_dir = tmp_path / "inputs", tmp_path / "outputs"
    input_dir.mkdir()
    image = (np.random.rand(4, 5, 6) * 1000).astype(np.float32)
    _write_nifti(input_dir / "STS26_Validation_001.nii.gz", image)

    written = run_inference(input_dir, output_dir, predict_fn=fake_predict)

    assert written == [output_dir / "STS26_Validation_001.nii.gz"]
    source = nib.load(str(input_dir / "STS26_Validation_001.nii.gz"))
    prediction = nib.load(str(output_dir / "STS26_Validation_001.nii.gz"))
    assert prediction.shape == source.shape
    assert np.allclose(prediction.affine, source.affine)
    data = np.asanyarray(prediction.dataobj)
    assert data.dtype == np.uint8
    assert np.array_equal(data, np.zeros(image.shape, dtype=np.uint8))


def test_run_inference_handles_multiple_cases(tmp_path: Path) -> None:
    input_dir, output_dir = tmp_path / "inputs", tmp_path / "outputs"
    input_dir.mkdir()
    for case_id in ("a", "b", "c"):
        _write_nifti(input_dir / f"{case_id}.nii.gz", np.zeros((2, 2, 2), dtype=np.float32))

    written = run_inference(input_dir, output_dir)

    assert {p.name for p in written} == {"a.nii.gz", "b.nii.gz", "c.nii.gz"}
