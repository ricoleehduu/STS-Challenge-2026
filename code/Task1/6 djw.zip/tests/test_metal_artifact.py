from __future__ import annotations

import numpy as np
import pytest

from stsr2026.data.metal_artifact import (
    DEFAULT_METAL_HU_THRESHOLD,
    detect_metal_mask,
    mitigate_metal_streaks,
)


def _volume_with_metal_and_streak(baseline: float = 800.0, dtype=np.float32) -> np.ndarray:
    """A synthetic CBCT-like volume: dense-tissue baseline, a metal blob well
    above the default threshold, and nearby "streak" voxels that are elevated
    but stay below the metal threshold on their own."""
    volume = np.full((15, 15, 15), baseline, dtype=dtype)
    volume[6:9, 6:9, 6:9] = 9000.0  # metal blob, clearly above DEFAULT_METAL_HU_THRESHOLD
    volume[4, 7, 7] = 3200.0  # streak neighbor, within dilation-2 reach of the blob
    volume[10, 7, 7] = 3200.0  # streak neighbor on the opposite side
    return volume


def test_detect_metal_mask_identifies_high_hu_voxels() -> None:
    volume = _volume_with_metal_and_streak()

    mask = detect_metal_mask(volume)

    expected = np.zeros_like(volume, dtype=bool)
    expected[6:9, 6:9, 6:9] = True
    assert np.array_equal(mask, expected)
    # the streak voxels alone are not above threshold -- only the blob is "metal"
    assert not mask[4, 7, 7]
    assert not mask[10, 7, 7]


def test_detect_metal_mask_respects_custom_threshold() -> None:
    volume = _volume_with_metal_and_streak()

    mask = detect_metal_mask(volume, hu_threshold=3000.0)

    assert mask[6:9, 6:9, 6:9].all()
    assert mask[4, 7, 7]
    assert mask[10, 7, 7]


def test_detect_metal_mask_no_metal_present() -> None:
    volume = np.random.default_rng(0).uniform(-1000, 2500, size=(8, 8, 8)).astype(np.float32)

    mask = detect_metal_mask(volume)

    assert not mask.any()


def test_detect_metal_mask_rejects_non_3d_input() -> None:
    with pytest.raises(ValueError):
        detect_metal_mask(np.zeros((4, 4), dtype=np.float32))


def test_mitigate_metal_streaks_no_metal_is_noop() -> None:
    volume = np.random.default_rng(1).uniform(-1000, 2500, size=(8, 8, 8)).astype(np.float32)

    result = mitigate_metal_streaks(volume)

    assert np.array_equal(result, volume)


def test_mitigate_metal_streaks_removes_metal_and_streak_region() -> None:
    volume = _volume_with_metal_and_streak()

    result = mitigate_metal_streaks(volume)

    assert result.shape == volume.shape
    # no residual metal-range voxels anywhere in the output
    assert not detect_metal_mask(result).any()
    # the blob itself and its dilated streak neighbors were rewritten
    assert not np.array_equal(result[6:9, 6:9, 6:9], volume[6:9, 6:9, 6:9])
    assert result[4, 7, 7] != volume[4, 7, 7]
    assert result[10, 7, 7] != volume[10, 7, 7]
    # values pulled toward the surrounding dense-tissue baseline, not left extreme
    assert result[6:9, 6:9, 6:9].max() < DEFAULT_METAL_HU_THRESHOLD


def test_mitigate_metal_streaks_leaves_far_away_voxels_untouched() -> None:
    volume = _volume_with_metal_and_streak()

    result = mitigate_metal_streaks(volume)

    # corners are far (Manhattan distance well beyond the default dilation
    # margin) from the metal blob at [6:9, 6:9, 6:9] and must be bit-exact
    far_slices = [(0, 0, 0), (0, 14, 0), (14, 0, 14), (14, 14, 14)]
    for idx in far_slices:
        assert result[idx] == volume[idx]


def test_mitigate_metal_streaks_dilation_iterations_is_tunable() -> None:
    volume = _volume_with_metal_and_streak()

    untouched = mitigate_metal_streaks(volume, dilation_iterations=0)
    # with no dilation, streak voxels below threshold are left alone
    assert untouched[4, 7, 7] == volume[4, 7, 7]
    assert untouched[10, 7, 7] == volume[10, 7, 7]
    # but the metal voxels themselves are still replaced
    assert not np.array_equal(untouched[6:9, 6:9, 6:9], volume[6:9, 6:9, 6:9])


def test_mitigate_metal_streaks_accepts_precomputed_mask() -> None:
    volume = _volume_with_metal_and_streak()
    custom_mask = np.zeros_like(volume, dtype=bool)
    custom_mask[7, 7, 7] = True  # a single voxel, unrelated to the threshold logic

    result = mitigate_metal_streaks(volume, metal_mask=custom_mask, dilation_iterations=0)

    assert result[7, 7, 7] != volume[7, 7, 7]
    # points inside the blob but outside the (tiny) custom mask are untouched
    assert result[6, 6, 6] == volume[6, 6, 6]


def test_mitigate_metal_streaks_rejects_mismatched_mask_shape() -> None:
    volume = _volume_with_metal_and_streak()
    wrong_shape_mask = np.zeros((3, 3, 3), dtype=bool)

    with pytest.raises(ValueError):
        mitigate_metal_streaks(volume, metal_mask=wrong_shape_mask)


def test_mitigate_metal_streaks_whole_volume_metal_warns_and_returns_unchanged() -> None:
    volume = np.full((3, 3, 3), 9000.0, dtype=np.float32)

    with pytest.warns(UserWarning, match="entire volume"):
        result = mitigate_metal_streaks(volume)

    assert np.array_equal(result, volume)


def test_mitigate_metal_streaks_preserves_integer_dtype() -> None:
    volume = _volume_with_metal_and_streak(dtype=np.float32).astype(np.int16)

    result = mitigate_metal_streaks(volume)

    assert result.dtype == np.int16


def test_mitigate_metal_streaks_rejects_non_3d_input() -> None:
    with pytest.raises(ValueError):
        mitigate_metal_streaks(np.zeros((4, 4), dtype=np.float32))
