from __future__ import annotations

import time

import numpy as np
import pytest

from stsr2026.inference.false_positive_cleanup import (
    GTFreeOptions,
    clean_or_relabel_false_positive_labels,
    identify_gtfree_fp_candidates,
)

AFFINE = np.eye(4)  # identity: 1 voxel == 1mm, world coords == voxel indices


def _volume(shape: tuple[int, int, int]) -> np.ndarray:
    return np.zeros(shape, dtype=np.int64)


# ---------------------------------------------------------------------------
# Signal A: duplicate same-label components.
# ---------------------------------------------------------------------------


def test_duplicate_component_flagged_primary_kept() -> None:
    """A label realized as two spatially-separated components: the larger is
    the presumed-real primary (never flagged), the smaller is a duplicate
    false-positive candidate."""
    volume = _volume((30, 10, 10))
    volume[0:5, 0:5, 0:5] = 21  # primary, 125 voxels
    volume[20, 0, 0] = 21  # duplicate, 1 voxel, far away, same label

    candidates = identify_gtfree_fp_candidates(volume, AFFINE)

    assert len(candidates) == 1
    c = candidates[0]
    assert c.label == 21
    assert c.voxel_count == 1
    assert c.signal == "duplicate_component"


def test_duplicate_component_end_to_end_cleared_via_clean_or_relabel() -> None:
    """The full gt_labels=None pipeline: the duplicate is cleared (below
    volume_threshold), the primary is left completely untouched."""
    volume = _volume((30, 10, 10))
    volume[0:5, 0:5, 0:5] = 21  # primary, 125 voxels
    volume[20, 0, 0] = 21  # duplicate, 1 voxel

    output, records = clean_or_relabel_false_positive_labels(
        volume, gt_labels=None, volume_threshold=50, affine=AFFINE
    )

    assert np.all(output[0:5, 0:5, 0:5] == 21)  # primary untouched
    assert output[20, 0, 0] == 0  # duplicate cleared
    assert len(records) == 1
    assert records[0].label == 21
    assert records[0].action == "cleared_small"


def test_lone_small_component_never_flagged_as_duplicate() -> None:
    """A label with only ONE component, however small, has nothing to be a
    'duplicate' of -- must survive untouched (protects e.g. a thin canal
    tip with no larger sibling under the same label)."""
    volume = _volume((10, 10, 10))
    volume[3, 3, 3] = 40  # a single canal voxel, no sibling component

    candidates = identify_gtfree_fp_candidates(volume, AFFINE)

    assert candidates == ()


# ---------------------------------------------------------------------------
# Signal B: redundant same-quadrant coverage ("duplicate / over-count").
# ---------------------------------------------------------------------------


def test_small_label_engulfed_by_larger_same_quadrant_neighbor_flagged() -> None:
    """A small label occupying what is essentially an internal notch inside
    a much larger same-quadrant label's territory -- the real documented
    failure mode this signal targets (a small hallucinated label sitting
    almost entirely on a real, larger neighbour's territory, per
    clean_or_relabel_false_positive_labels's own docstring example)."""
    volume = _volume((25, 15, 10))
    volume[0:20, 0:10, 0:5] = 3  # big primary, quadrant Q1 (tooth class 3)
    volume[9:11, 4:6, 2:4] = 2  # small notch carved out of label 3's block, class 2 (same quadrant)

    candidates = identify_gtfree_fp_candidates(volume, AFFINE)

    assert len(candidates) == 1
    c = candidates[0]
    assert c.label == 2
    assert c.voxel_count == 8
    assert c.signal == "quadrant_overcount"


def test_two_similar_sized_adjacent_real_teeth_not_flagged() -> None:
    """Two genuinely distinct, comparably-sized, merely-adjacent same-quadrant
    labels must NOT be flagged by the redundant-coverage signal -- neither is
    strictly larger than the other, so there is no 'who wins' verdict."""
    volume = _volume((20, 10, 10))
    volume[0:5, 0:5, 0:5] = 1  # 125 voxels
    volume[5:10, 0:5, 0:5] = 2  # 125 voxels, touching face

    candidates = identify_gtfree_fp_candidates(volume, AFFINE)

    assert candidates == ()


# ---------------------------------------------------------------------------
# Signal C: spatial isolation.
# ---------------------------------------------------------------------------


def test_spatially_isolated_component_flagged() -> None:
    """One label sitting far away (>40mm) from a cluster of same-category
    components is flagged; the clustered components are not."""
    volume = _volume((120, 20, 20))
    # Tight cluster of 5 same-sized, same-quadrant (Q1) real teeth.
    for i, label in enumerate((1, 2, 3, 4, 5)):
        start = i * 6
        volume[start : start + 3, 0:3, 0:3] = label
    # Isolated outlier, same quadrant (Q1, class 8), far away and large.
    volume[100:110, 0:10, 0:10] = 8  # 1000 voxels, ~75-100mm from the cluster

    candidates = identify_gtfree_fp_candidates(volume, AFFINE)

    signals_by_label = {c.label: c.signal for c in candidates}
    assert signals_by_label == {8: "spatially_isolated"}


def test_spatially_isolated_large_component_cleared_no_neighbor() -> None:
    """End-to-end: the isolated component is large (>= volume_threshold), is
    a tooth class, but has no real tooth neighbour within reach of the
    dilated search (the cluster is tens of mm away) -- falls back to
    clearing, exactly like the GT-informed path's own 'no neighbour found'
    behaviour."""
    volume = _volume((120, 20, 20))
    for i, label in enumerate((1, 2, 3, 4, 5)):
        start = i * 6
        volume[start : start + 3, 0:3, 0:3] = label
    volume[100:110, 0:10, 0:10] = 8  # 1000 voxels, isolated

    output, records = clean_or_relabel_false_positive_labels(
        volume, gt_labels=None, volume_threshold=500, affine=AFFINE, dilation_voxels=2
    )

    assert np.count_nonzero(output == 8) == 0  # isolated component cleared
    for label in (1, 2, 3, 4, 5):
        assert np.any(output == label)  # cluster untouched
    assert len(records) == 1
    assert records[0].label == 8
    assert records[0].action == "cleared_large_no_neighbor"


def test_isolation_signal_requires_enough_peers() -> None:
    """With too few same-category components overall, isolation is not
    evaluated at all -- there is no reliable 'arch' to be isolated from."""
    volume = _volume((120, 20, 20))
    volume[0:3, 0:3, 0:3] = 1
    volume[100:103, 0:3, 0:3] = 2  # far away, but only 2 components total

    candidates = identify_gtfree_fp_candidates(volume, AFFINE)

    assert candidates == ()


# ---------------------------------------------------------------------------
# Clean case: must be left completely untouched (no over-deletion).
# ---------------------------------------------------------------------------


def test_clean_case_with_plausible_arch_left_untouched() -> None:
    """Several distinct, similarly-sized, closely-spaced, single-component
    labels (a normal, plausible partial arch) must produce zero candidates
    and zero changes -- the core anti-over-deletion guarantee."""
    volume = _volume((60, 10, 10))
    for i, label in enumerate((1, 2, 3, 4, 5, 6)):
        start = i * 6
        volume[start : start + 3, 0:3, 0:3] = label

    candidates = identify_gtfree_fp_candidates(volume, AFFINE)
    assert candidates == ()

    output, records = clean_or_relabel_false_positive_labels(
        volume, gt_labels=None, volume_threshold=10, affine=AFFINE
    )
    assert np.array_equal(output, volume)
    assert records == ()


def test_clean_case_mixed_tooth_and_canal_left_untouched() -> None:
    """A plausible mixed tooth+canal prediction (each canal nested near its
    parent tooth, one component per label) must also be left untouched."""
    volume = _volume((60, 10, 10))
    for i, (tooth, canal) in enumerate(((1, 33), (2, 34), (3, 35), (4, 36), (5, 37))):
        start = i * 8
        volume[start : start + 4, 0:4, 0:4] = tooth
        volume[start + 1 : start + 2, 1:2, 1:2] = canal  # small, nested inside its own tooth's footprint region

    candidates = identify_gtfree_fp_candidates(volume, AFFINE)
    assert candidates == ()


# ---------------------------------------------------------------------------
# Canal-aware behaviour (real-data validation finding: canals are legitimately
# thin/small/naturally fragmented, so the aggressive tooth signals must never
# touch them by default -- see this module's "REAL-DATA FINDING" section
# header for the real measured canal-metric damage this prevents).
# ---------------------------------------------------------------------------


def test_fragmented_canal_left_intact_by_default() -> None:
    """A canal label naturally fragmented into many small, spatially
    separated components (real anatomy -- a thin root-canal centerline
    routinely breaks into several pieces) must be left COMPLETELY untouched
    by default (clean_classes='teeth') -- none of these components has a
    'primary', they're all tiny, and old (pre-fix) logic would have cleared
    every one of them as either a 'duplicate' or via small-volume tiering."""
    volume = _volume((60, 10, 10))
    volume[0:5, 0:5, 0:5] = 3  # an unrelated real tooth, so this isn't a totally empty case
    for i in range(6):  # 6 separate 1-2 voxel fragments of the SAME canal label
        x = 10 + i * 6
        volume[x : x + 1, 0, 0] = 40
        volume[x : x + 1, 1, 0] = 40  # 2 voxels per fragment, 6 disjoint fragments

    candidates = identify_gtfree_fp_candidates(volume, AFFINE)
    assert candidates == ()  # canal excluded from candidacy entirely by default

    original = volume.copy()
    output, records = clean_or_relabel_false_positive_labels(
        volume, gt_labels=None, volume_threshold=100, affine=AFFINE
    )
    assert np.array_equal(output, original)
    assert records == ()


def test_canal_all_mode_flags_only_via_redundant_overlap_never_duplicate_or_isolation() -> None:
    """With clean_classes='all', the SAME fragmented-canal scenario that must
    stay untouched by default must STILL stay untouched -- signals A
    (duplicate) and C (isolation) never fire for canals regardless of
    clean_classes; only signal B (redundant same-quadrant overlap) can ever
    flag a canal, and this fragmentation pattern doesn't trigger it (no
    fragment sits mostly inside a bigger same-quadrant canal's territory)."""
    volume = _volume((60, 10, 10))
    for i in range(6):
        x = 10 + i * 6
        volume[x : x + 1, 0, 0] = 40
        volume[x : x + 1, 1, 0] = 40

    candidates = identify_gtfree_fp_candidates(volume, AFFINE, GTFreeOptions(clean_classes="all"))
    assert candidates == ()


def test_canal_redundant_overlap_relabeled_never_cleared_in_all_mode() -> None:
    """The one canal scenario that CAN be flagged (clean_classes='all',
    signal B: a small canal component sitting almost entirely inside a
    bigger same-quadrant canal's territory, mirroring the tooth version of
    this exact geometry) must be RELABELED to the bigger neighbour, never
    cleared -- regardless of volume_threshold, since a real canal component
    like this is genuine tissue under the wrong label, not noise."""
    volume = _volume((25, 15, 10))
    volume[0:20, 0:10, 0:5] = 35  # big primary canal, quadrant Q1 (canal ids 33-40)
    volume[9:11, 4:6, 2:4] = 34  # small notch carved out of label 35's block, same quadrant

    options = GTFreeOptions(clean_classes="all")
    candidates = identify_gtfree_fp_candidates(volume, AFFINE, options)
    assert len(candidates) == 1
    c = candidates[0]
    assert c.label == 34
    assert c.signal == "quadrant_overcount"
    assert c.suggested_relabel == 35

    # Both threshold extremes must produce the identical relabel outcome --
    # proof the forced relabel bypasses the volume_threshold branch entirely.
    for threshold in (0, 1_000_000):
        output, records = clean_or_relabel_false_positive_labels(
            volume, gt_labels=None, volume_threshold=threshold, affine=AFFINE, gtfree_options=options
        )
        assert np.count_nonzero(output == 34) == 0  # no voxels left under the FP label
        assert np.all(output[9:11, 4:6, 2:4] == 35)  # relabeled, not cleared to 0
        assert len(records) == 1
        assert records[0].action == "relabeled_to_neighbor"
        assert records[0].new_label == 35


def test_clean_classes_rejects_invalid_value() -> None:
    volume = _volume((10, 10, 10))
    volume[0, 0, 0] = 1
    with pytest.raises(ValueError, match="clean_classes must be"):
        identify_gtfree_fp_candidates(volume, AFFINE, GTFreeOptions(clean_classes="bogus"))


# ---------------------------------------------------------------------------
# Performance regression: Signal B must operate on small per-component
# bounding-box crops, not full-volume dilation (a real-data run measured the
# earlier full-volume implementation at ~24 minutes PER CASE, killed after
# 1/6 -- see this module's "REAL-DATA FINDING" section header).
# ---------------------------------------------------------------------------


def test_quadrant_overcount_signal_is_fast_on_a_large_volume() -> None:
    """A volume much bigger than the earlier small-fixture tests, with a
    full 8-label quadrant group (the real worst case -- up to 8 pairwise
    comparisons per candidate), must complete in well under a second if
    Signal B is truly operating on small per-component crops rather than
    dilating a fresh full-volume mask per candidate."""
    volume = _volume((400, 400, 60))
    # 6 equal-sized, widely-spaced distractor teeth -- never flagged against
    # each other (tied sizes) or against the far-away big block (dilation
    # can't bridge the gap).
    for i in range(6):
        x = i * 35
        volume[x : x + 20, 0:20, 0:20] = i + 1
    # A big block (label 7) with a small embedded notch (label 8) -- the one
    # pair that SHOULD be flagged, exercising the real overlap computation.
    volume[210:250, 0:25, 0:15] = 7
    volume[225:227, 10:12, 5:7] = 8

    start = time.perf_counter()
    candidates = identify_gtfree_fp_candidates(volume, AFFINE, GTFreeOptions(overcount_dilation_voxels=2))
    elapsed = time.perf_counter() - start

    assert elapsed < 5.0, f"Signal B took {elapsed:.2f}s -- likely regressed back to full-volume dilation"
    signals_by_label = {c.label: c.signal for c in candidates}
    assert signals_by_label == {8: "quadrant_overcount"}


# ---------------------------------------------------------------------------
# Wiring / API-contract tests.
# ---------------------------------------------------------------------------


def test_gt_labels_none_requires_affine() -> None:
    volume = _volume((10, 10, 10))
    volume[0, 0, 0] = 1
    with pytest.raises(ValueError, match="affine is required"):
        clean_or_relabel_false_positive_labels(volume, gt_labels=None, volume_threshold=10)


def test_gt_labels_not_none_path_unchanged_bit_for_bit() -> None:
    """Passing a real gt_labels set must reproduce the exact original
    (pre-existing, already-tested) behaviour -- this GT-free extension must
    not change anything about that path."""
    volume = _volume((14, 10, 4))
    volume[0:6, 1:4, 1:3] = 21  # real, GT-present tooth
    volume[6:12, 1:4, 1:3] = 20  # false-positive, adjacent
    fp_voxels = int(np.count_nonzero(volume == 20))

    output, records = clean_or_relabel_false_positive_labels(
        volume, gt_labels={21}, volume_threshold=fp_voxels, dilation_voxels=2
    )

    assert np.all(output[6:12, 1:4, 1:3] == 21)
    assert np.all(output[0:6, 1:4, 1:3] == 21)
    assert len(records) == 1
    assert records[0].label == 20
    assert records[0].action == "relabeled_to_neighbor"
    assert records[0].new_label == 21


def test_ot_dustbin_signal_is_additive_only() -> None:
    """Enabling the (off-by-default) OT-dustbin corroboration signal can
    only ADD candidates on top of the other three signals, never remove
    one -- a monotonicity guarantee, checked against a real
    ot_instance_assignment solve rather than assumed."""
    volume = _volume((60, 15, 10))
    # A somewhat messy but not obviously-flagged-by-A/B/C prediction: 6
    # distinct, similarly-sized teeth spread across a quadrant.
    for i, label in enumerate((1, 2, 3, 4, 5, 6)):
        start = i * 8
        volume[start : start + 4, 0:4, 0:4] = label

    without_ot = identify_gtfree_fp_candidates(volume, AFFINE, GTFreeOptions(use_ot_dustbin_signal=False))
    with_ot = identify_gtfree_fp_candidates(volume, AFFINE, GTFreeOptions(use_ot_dustbin_signal=True))

    keys_without = {(c.label, c.component_id) for c in without_ot}
    keys_with = {(c.label, c.component_id) for c in with_ot}
    assert keys_without <= keys_with


def test_identify_gtfree_fp_candidates_rejects_bad_affine_shape() -> None:
    volume = _volume((5, 5, 5))
    with pytest.raises(ValueError, match="affine must have shape"):
        identify_gtfree_fp_candidates(volume, np.eye(3))
