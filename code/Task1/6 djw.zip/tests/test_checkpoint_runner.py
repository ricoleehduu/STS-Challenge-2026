from __future__ import annotations

import contextlib
import signal
import sys
import time
import types
from pathlib import Path

import nibabel as nib
import numpy as np
import pytest

from stsr2026.evaluation.nnunet_inference import CaseInferenceResult
from stsr2026.inference import checkpoint_runner as cr
from stsr2026.inference import streaming_export as se

# This sandbox has no GPU and no working nnunetv2/torch install (see
# checkpoint_runner.py's module docstring). Everything below is pure
# control-flow logic (env/config parsing, the per-case loop's exception and
# timeout handling, output bookkeeping) tested with injected fakes for
# predictor_factory/predict_case_fn -- the real nnUNetPredictor call path
# (load_predictor + predict_case_streaming) is exercised elsewhere and is
# GPU-dependent/unverified, matching the existing pattern in
# tests/test_nnunet_inference.py and tests/test_streaming_export.py.


def _write_nifti(path: Path, values: np.ndarray) -> None:
    nib.save(nib.Nifti1Image(values, np.diag([0.3, 0.4, 0.5, 1.0])), str(path))


# ---------------------------------------------------------------------------
# parse_folds / parse_bool_env / load_docker_config
# ---------------------------------------------------------------------------


def test_parse_folds_single_numeric() -> None:
    assert cr.parse_folds("0") == [0]


def test_parse_folds_comma_and_space_separated() -> None:
    assert cr.parse_folds("0,1,2") == [0, 1, 2]
    assert cr.parse_folds("0 1 2") == [0, 1, 2]
    assert cr.parse_folds(" 0 , 1 ,2 ") == [0, 1, 2]


def test_parse_folds_non_numeric_fold_name() -> None:
    assert cr.parse_folds("all") == ["all"]


def test_parse_folds_rejects_empty() -> None:
    with pytest.raises(ValueError, match="could not parse"):
        cr.parse_folds("   ")


def test_parse_bool_env_variants() -> None:
    for truthy in ("1", "true", "True", "yes", "on", " TRUE "):
        assert cr.parse_bool_env(truthy) is True
    for falsy in ("0", "false", "no", "off", ""):
        assert cr.parse_bool_env(falsy) is False
    assert cr.parse_bool_env(None) is False
    assert cr.parse_bool_env(None, default=True) is True


def test_load_docker_config_defaults_when_env_empty() -> None:
    config = cr.load_docker_config({})
    assert config.checkpoint_dir is None
    assert config.folds == [0]
    assert config.checkpoint_name == "checkpoint_final.pth"
    assert config.tile_step_size == 0.5
    assert config.use_mirroring is False
    assert config.case_timeout_seconds is None
    assert config.output_suffix == ""
    # Default ON for the 2026-07-24 submission: real, GT-free post-processing
    # (L/R correction + teeth-only FP cleanup) should apply out of the box
    # with no env var set -- see ENV_APPLY_LR_CORRECTION's comment in
    # checkpoint_runner.py for the full rationale.
    assert config.apply_lr_correction is True


def test_load_docker_config_apply_lr_correction_can_be_disabled() -> None:
    for falsy in ("0", "false", "False", "no", "off"):
        config = cr.load_docker_config({"STSR_APPLY_LR_CORRECTION": falsy})
        assert config.apply_lr_correction is False, falsy


def test_load_docker_config_apply_lr_correction_explicit_true() -> None:
    config = cr.load_docker_config({"STSR_APPLY_LR_CORRECTION": "1"})
    assert config.apply_lr_correction is True


def test_load_docker_config_reads_output_suffix() -> None:
    config = cr.load_docker_config({"STSR_OUTPUT_SUFFIX": "_mask"})
    assert config.output_suffix == "_mask"


def test_load_docker_config_reads_all_fields() -> None:
    env = {
        "STSR_CHECKPOINT_DIR": "/root/checkpoints/Dataset002_STSR/nnUNetTrainer__nnUNetPlans__3d_fullres",
        "STSR_CHECKPOINT_FOLDS": "0,1",
        "STSR_CHECKPOINT_NAME": "checkpoint_latest.pth",
        "STSR_TILE_STEP_SIZE": "0.75",
        "STSR_USE_MIRRORING": "true",
        "STSR_CASE_TIMEOUT_SECONDS": "55",
    }
    config = cr.load_docker_config(env)
    assert config.checkpoint_dir == Path(
        "/root/checkpoints/Dataset002_STSR/nnUNetTrainer__nnUNetPlans__3d_fullres"
    )
    assert config.folds == [0, 1]
    assert config.checkpoint_name == "checkpoint_latest.pth"
    assert config.tile_step_size == 0.75
    assert config.use_mirroring is True
    assert config.case_timeout_seconds == 55.0


def test_load_docker_config_blank_checkpoint_dir_treated_as_unset() -> None:
    config = cr.load_docker_config({"STSR_CHECKPOINT_DIR": "   "})
    assert config.checkpoint_dir is None


def test_predict_case_streaming_default_and_mask_suffix_names(tmp_path: Path, monkeypatch) -> None:
    class _FakeCuda:
        @staticmethod
        def is_available() -> bool:
            return False

    class _FakeTorch:
        cuda = _FakeCuda()

        @staticmethod
        def from_numpy(data):
            return data

        @staticmethod
        def get_num_threads():
            return 1

        @staticmethod
        def set_num_threads(n):
            pass

    class _FakePrediction:
        pass

    class _FakePreprocessor:
        def __init__(self, verbose):
            pass

        def run_case(self, *args):
            return np.zeros((1, 2, 2, 2), dtype=np.float32), None, {}

    class _FakeConfigurationManager:
        preprocessor_class = _FakePreprocessor

    class _FakeNetwork:
        @staticmethod
        def load_state_dict(params):
            pass

    class _FakePredictor:
        configuration_manager = _FakeConfigurationManager()
        plans_manager = object()
        dataset_json = {"file_ending": ".nii.gz"}
        verbose = False
        device = "cpu"
        list_of_parameters = [{"fake": "params"}]
        network = _FakeNetwork()

        @staticmethod
        def predict_sliding_window_return_logits(data):
            return _FakePrediction()

    def fake_windowed_export(*args, **kwargs):
        # windowed_predict_and_export's output_file_truncated is the 7th
        # positional arg (index 6) -- see test_streaming_export.py's analogous
        # fix for the full explanation of the new call boundary.
        Path(args[6] + ".nii.gz").write_bytes(b"fake-output")

    monkeypatch.setattr(se, "TORCH_AVAILABLE", True)
    monkeypatch.setattr(se, "NNUNETV2_EXPORT_AVAILABLE", True)
    monkeypatch.setattr(se, "torch", _FakeTorch())
    monkeypatch.setattr(se, "windowed_predict_and_export", fake_windowed_export)
    image_path = tmp_path / "images" / "case_001.nii.gz"

    default_result = se.predict_case_streaming(_FakePredictor(), image_path, tmp_path / "default")
    mask_result = se.predict_case_streaming(
        _FakePredictor(), image_path, tmp_path / "mask", output_suffix="_mask"
    )

    assert default_result.output_path == str(tmp_path / "default" / "case_001.nii.gz")
    assert mask_result.output_path == str(tmp_path / "mask" / "case_001_mask.nii.gz")


# ---------------------------------------------------------------------------
# _case_timeout
# ---------------------------------------------------------------------------


def test_case_timeout_noop_when_seconds_is_none() -> None:
    with cr._case_timeout(None):
        time.sleep(0.01)


def test_case_timeout_raises_when_exceeded() -> None:
    with pytest.raises(cr.CaseTimeoutError, match="soft per-case timeout"):
        with cr._case_timeout(0.05):
            time.sleep(0.3)


def test_case_timeout_does_not_raise_when_not_exceeded() -> None:
    with cr._case_timeout(1.0):
        time.sleep(0.01)


def test_case_timeout_restores_previous_signal_handler() -> None:
    sentinel_calls = []

    def sentinel_handler(signum, frame):
        sentinel_calls.append(True)

    previous = signal.signal(signal.SIGALRM, sentinel_handler)
    try:
        with cr._case_timeout(1.0):
            pass
        assert signal.getsignal(signal.SIGALRM) is sentinel_handler
    finally:
        signal.signal(signal.SIGALRM, previous)


# ---------------------------------------------------------------------------
# run_checkpoint_inference_for_docker
# ---------------------------------------------------------------------------


class _FakePredictor:
    pass


def _fake_predictor_factory_calls(calls):
    def factory(checkpoint_dir, **kwargs):
        calls.append((checkpoint_dir, kwargs))
        return _FakePredictor()

    return factory


def test_run_checkpoint_inference_returns_empty_list_when_no_inputs(tmp_path: Path) -> None:
    input_dir, output_dir = tmp_path / "inputs", tmp_path / "outputs"
    input_dir.mkdir()
    calls = []
    outcomes = cr.run_checkpoint_inference_for_docker(
        input_dir,
        output_dir,
        tmp_path / "checkpoint",
        predictor_factory=_fake_predictor_factory_calls(calls),
        predict_case_fn=lambda predictor, image_path, out_dir, output_suffix="": pytest.fail("should not be called"),
    )
    assert outcomes == []
    assert calls == []  # predictor is never loaded if there's nothing to run


def test_run_checkpoint_inference_loads_predictor_exactly_once_for_multiple_cases(tmp_path: Path) -> None:
    input_dir, output_dir = tmp_path / "inputs", tmp_path / "outputs"
    input_dir.mkdir()
    for case_id in ("a", "b", "c"):
        _write_nifti(input_dir / f"{case_id}.nii.gz", np.zeros((2, 2, 2), dtype=np.float32))

    calls = []

    def predict_case_fn(predictor, image_path, out_dir, output_suffix=""):
        assert isinstance(predictor, _FakePredictor)
        out_path = out_dir / image_path.name
        out_path.write_bytes(b"fake")
        return CaseInferenceResult(image_path.stem, str(image_path), str(out_path), 1.23, None)

    outcomes = cr.run_checkpoint_inference_for_docker(
        input_dir,
        output_dir,
        tmp_path / "checkpoint",
        predictor_factory=_fake_predictor_factory_calls(calls),
        predict_case_fn=predict_case_fn,
    )

    assert len(calls) == 1  # predictor loaded once, not per case
    assert [o.status for o in outcomes] == ["ok", "ok", "ok"]
    assert [o.case_id for o in outcomes] == ["a", "b", "c"]
    assert all(o.wall_clock_seconds == 1.23 for o in outcomes)


def test_run_checkpoint_inference_passes_config_through_to_predictor_factory(tmp_path: Path) -> None:
    input_dir, output_dir = tmp_path / "inputs", tmp_path / "outputs"
    input_dir.mkdir()
    _write_nifti(input_dir / "a.nii.gz", np.zeros((2, 2, 2), dtype=np.float32))
    calls = []

    def predict_case_fn(predictor, image_path, out_dir, output_suffix=""):
        return CaseInferenceResult("a", str(image_path), str(out_dir / "a.nii.gz"), 0.1, None)

    cr.run_checkpoint_inference_for_docker(
        input_dir,
        output_dir,
        tmp_path / "checkpoint",
        folds=[0, 1],
        checkpoint_name="checkpoint_latest.pth",
        tile_step_size=0.75,
        use_mirroring=True,
        predictor_factory=_fake_predictor_factory_calls(calls),
        predict_case_fn=predict_case_fn,
    )

    checkpoint_dir_arg, kwargs = calls[0]
    assert checkpoint_dir_arg == tmp_path / "checkpoint"
    assert kwargs["folds"] == [0, 1]
    assert kwargs["checkpoint_name"] == "checkpoint_latest.pth"
    assert kwargs["tile_step_size"] == 0.75
    assert kwargs["use_mirroring"] is True


def test_run_checkpoint_inference_passes_output_suffix_to_predict_case_fn(tmp_path: Path) -> None:
    input_dir, output_dir = tmp_path / "inputs", tmp_path / "outputs"
    input_dir.mkdir()
    _write_nifti(input_dir / "a.nii.gz", np.zeros((2, 2, 2), dtype=np.float32))
    received_suffixes = []

    def predict_case_fn(predictor, image_path, out_dir, output_suffix=""):
        received_suffixes.append(output_suffix)
        out_path = out_dir / f"a{output_suffix}.nii.gz"
        return CaseInferenceResult("a", str(image_path), str(out_path), 0.1, None)

    cr.run_checkpoint_inference_for_docker(
        input_dir,
        output_dir,
        tmp_path / "checkpoint",
        output_suffix="_mask",
        predictor_factory=_fake_predictor_factory_calls([]),
        predict_case_fn=predict_case_fn,
    )

    assert received_suffixes == ["_mask"]


# ---------------------------------------------------------------------------
# apply_postprocessing wiring (plan.md D7): post-write step, isolated by
# fake postprocess_fn so no real nibabel I/O or GPU is needed here -- the
# real apply_postprocessing_to_prediction_file itself is covered separately
# in tests/test_postprocessing_pipeline.py against synthetic NIfTI files.
# ---------------------------------------------------------------------------


def _predict_case_fn_writing(out_name: str = "a.nii.gz"):
    def predict_case_fn(predictor, image_path, out_dir, output_suffix=""):
        out_path = out_dir / out_name
        return CaseInferenceResult(image_path.stem, str(image_path), str(out_path), 0.1, None)

    return predict_case_fn


def test_postprocessing_not_called_by_default(tmp_path: Path) -> None:
    input_dir, output_dir = tmp_path / "inputs", tmp_path / "outputs"
    input_dir.mkdir()
    _write_nifti(input_dir / "a.nii.gz", np.zeros((2, 2, 2), dtype=np.float32))
    postprocess_calls = []

    cr.run_checkpoint_inference_for_docker(
        input_dir,
        output_dir,
        tmp_path / "checkpoint",
        predictor_factory=_fake_predictor_factory_calls([]),
        predict_case_fn=_predict_case_fn_writing(),
        postprocess_fn=lambda *a, **k: postprocess_calls.append((a, k)),
    )

    # apply_postprocessing defaults to False -- byte-identical behavior to
    # before this wiring existed.
    assert postprocess_calls == []


def test_postprocessing_called_once_per_successful_case_when_enabled(tmp_path: Path) -> None:
    input_dir, output_dir = tmp_path / "inputs", tmp_path / "outputs"
    input_dir.mkdir()
    for case_id in ("a", "b"):
        _write_nifti(input_dir / f"{case_id}.nii.gz", np.zeros((2, 2, 2), dtype=np.float32))
    postprocess_calls = []

    def predict_case_fn(predictor, image_path, out_dir, output_suffix=""):
        out_path = out_dir / image_path.name
        return CaseInferenceResult(image_path.stem, str(image_path), str(out_path), 0.1, None)

    outcomes = cr.run_checkpoint_inference_for_docker(
        input_dir,
        output_dir,
        tmp_path / "checkpoint",
        apply_postprocessing=True,
        predictor_factory=_fake_predictor_factory_calls([]),
        predict_case_fn=predict_case_fn,
        postprocess_fn=lambda path, gt_labels, threshold, dilation: postprocess_calls.append(
            (path, gt_labels, threshold, dilation)
        ),
    )

    assert [o.status for o in outcomes] == ["ok", "ok"]
    assert len(postprocess_calls) == 2
    called_paths = {str(call[0]) for call in postprocess_calls}
    assert called_paths == {str(output_dir / "a.nii.gz"), str(output_dir / "b.nii.gz")}


def test_postprocessing_gt_labels_looked_up_per_case_id(tmp_path: Path) -> None:
    """Cases with an entry in postprocess_gt_labels_by_case get their real
    GT label set; cases without one get None (GT-free tooth correction
    only) -- mirrors the real Docker call site, which never populates this
    mapping at all (see checkpoint_runner's docstring), and an offline
    evaluation call site, which would populate it per case."""
    input_dir, output_dir = tmp_path / "inputs", tmp_path / "outputs"
    input_dir.mkdir()
    for case_id in ("known", "unknown"):
        _write_nifti(input_dir / f"{case_id}.nii.gz", np.zeros((2, 2, 2), dtype=np.float32))
    received: dict[str, object] = {}

    def predict_case_fn(predictor, image_path, out_dir, output_suffix=""):
        out_path = out_dir / image_path.name
        return CaseInferenceResult(image_path.stem, str(image_path), str(out_path), 0.1, None)

    def postprocess_fn(path, gt_labels, threshold, dilation):
        received[Path(path).name.removesuffix(".nii.gz")] = gt_labels

    cr.run_checkpoint_inference_for_docker(
        input_dir,
        output_dir,
        tmp_path / "checkpoint",
        apply_postprocessing=True,
        postprocess_gt_labels_by_case={"known": {1, 2, 3}},
        predictor_factory=_fake_predictor_factory_calls([]),
        predict_case_fn=predict_case_fn,
        postprocess_fn=postprocess_fn,
    )

    assert received["known"] == {1, 2, 3}
    assert received["unknown"] is None


def test_postprocessing_threshold_and_dilation_passed_through(tmp_path: Path) -> None:
    input_dir, output_dir = tmp_path / "inputs", tmp_path / "outputs"
    input_dir.mkdir()
    _write_nifti(input_dir / "a.nii.gz", np.zeros((2, 2, 2), dtype=np.float32))
    received = {}

    def postprocess_fn(path, gt_labels, threshold, dilation):
        received["threshold"] = threshold
        received["dilation"] = dilation

    cr.run_checkpoint_inference_for_docker(
        input_dir,
        output_dir,
        tmp_path / "checkpoint",
        apply_postprocessing=True,
        postprocess_volume_threshold=1234,
        postprocess_dilation_voxels=7,
        predictor_factory=_fake_predictor_factory_calls([]),
        predict_case_fn=_predict_case_fn_writing(),
        postprocess_fn=postprocess_fn,
    )

    assert received == {"threshold": 1234, "dilation": 7}


def test_postprocessing_failure_isolated_like_an_inference_failure(tmp_path: Path) -> None:
    input_dir, output_dir = tmp_path / "inputs", tmp_path / "outputs"
    input_dir.mkdir()
    for case_id in ("a", "b"):
        _write_nifti(input_dir / f"{case_id}.nii.gz", np.zeros((2, 2, 2), dtype=np.float32))

    def predict_case_fn(predictor, image_path, out_dir, output_suffix=""):
        out_path = out_dir / image_path.name
        return CaseInferenceResult(image_path.stem, str(image_path), str(out_path), 0.1, None)

    def postprocess_fn(path, gt_labels, threshold, dilation):
        if "a" in Path(path).stem:
            raise RuntimeError("simulated corrupt output file for case a")

    outcomes = cr.run_checkpoint_inference_for_docker(
        input_dir,
        output_dir,
        tmp_path / "checkpoint",
        apply_postprocessing=True,
        predictor_factory=_fake_predictor_factory_calls([]),
        predict_case_fn=predict_case_fn,
        postprocess_fn=postprocess_fn,
    )

    statuses = {o.case_id: o.status for o in outcomes}
    assert statuses == {"a": "error", "b": "ok"}  # b still ran despite a's postprocessing failure
    failed = next(o for o in outcomes if o.case_id == "a")
    assert "simulated corrupt output file for case a" in failed.message


def test_run_checkpoint_inference_isolates_one_case_failure_from_the_rest(tmp_path: Path) -> None:
    input_dir, output_dir = tmp_path / "inputs", tmp_path / "outputs"
    input_dir.mkdir()
    for case_id in ("a", "b", "c"):
        _write_nifti(input_dir / f"{case_id}.nii.gz", np.zeros((2, 2, 2), dtype=np.float32))

    def predict_case_fn(predictor, image_path, out_dir, output_suffix=""):
        if image_path.name == "b.nii.gz":
            raise RuntimeError("simulated OOM on case b")
        out_path = out_dir / image_path.name
        return CaseInferenceResult(image_path.stem, str(image_path), str(out_path), 0.5, None)

    outcomes = cr.run_checkpoint_inference_for_docker(
        input_dir,
        output_dir,
        tmp_path / "checkpoint",
        predictor_factory=_fake_predictor_factory_calls([]),
        predict_case_fn=predict_case_fn,
    )

    statuses = {o.case_id: o.status for o in outcomes}
    assert statuses == {"a": "ok", "b": "error", "c": "ok"}
    failed = next(o for o in outcomes if o.case_id == "b")
    assert "simulated OOM on case b" in failed.message
    assert failed.output_path is None
    # case c still ran despite b's failure -- the whole point of isolation
    assert len(outcomes) == 3


def test_run_checkpoint_inference_records_timeout_status(tmp_path: Path) -> None:
    input_dir, output_dir = tmp_path / "inputs", tmp_path / "outputs"
    input_dir.mkdir()
    _write_nifti(input_dir / "a.nii.gz", np.zeros((2, 2, 2), dtype=np.float32))

    def slow_predict_case_fn(predictor, image_path, out_dir, output_suffix=""):
        time.sleep(0.3)
        return CaseInferenceResult("a", str(image_path), str(out_dir / "a.nii.gz"), 0.3, None)

    outcomes = cr.run_checkpoint_inference_for_docker(
        input_dir,
        output_dir,
        tmp_path / "checkpoint",
        case_timeout_seconds=0.05,
        predictor_factory=_fake_predictor_factory_calls([]),
        predict_case_fn=slow_predict_case_fn,
    )

    assert len(outcomes) == 1
    assert outcomes[0].status == "timeout"
    assert "soft per-case timeout" in outcomes[0].message


def test_run_checkpoint_inference_predictor_factory_error_propagates(tmp_path: Path) -> None:
    input_dir, output_dir = tmp_path / "inputs", tmp_path / "outputs"
    input_dir.mkdir()
    _write_nifti(input_dir / "a.nii.gz", np.zeros((2, 2, 2), dtype=np.float32))

    def broken_factory(checkpoint_dir, **kwargs):
        raise RuntimeError("checkpoint dir does not exist")

    # A broken checkpoint load is a whole-run failure, not a per-case one --
    # it must propagate, not be swallowed into a per-case "error" outcome.
    with pytest.raises(RuntimeError, match="checkpoint dir does not exist"):
        cr.run_checkpoint_inference_for_docker(
            input_dir,
            output_dir,
            tmp_path / "checkpoint",
            predictor_factory=broken_factory,
            predict_case_fn=lambda *a, **k: pytest.fail("should not be called"),
        )


def test_run_checkpoint_inference_creates_output_dir(tmp_path: Path) -> None:
    input_dir, output_dir = tmp_path / "inputs", tmp_path / "does_not_exist_yet"
    input_dir.mkdir()
    _write_nifti(input_dir / "a.nii.gz", np.zeros((2, 2, 2), dtype=np.float32))

    def predict_case_fn(predictor, image_path, out_dir, output_suffix=""):
        return CaseInferenceResult("a", str(image_path), str(out_dir / "a.nii.gz"), 0.1, None)

    cr.run_checkpoint_inference_for_docker(
        input_dir,
        output_dir,
        tmp_path / "checkpoint",
        predictor_factory=_fake_predictor_factory_calls([]),
        predict_case_fn=predict_case_fn,
    )
    assert output_dir.is_dir()


# ---------------------------------------------------------------------------
# _first_module_in_channels / _warm_up_predictor (2026-07-13 D2 margin-hardening
# follow-up -- see checkpoint_runner.py's docstrings and docs/progress.md for the
# real ~9-12s GPU/cuDNN cold-start-tax finding this warm-up absorbs). Pure control
# flow tested with duck-typed fakes, no torch/nnunetv2 needed -- matching this
# file's existing pattern for everything that doesn't need a real GPU.
# ---------------------------------------------------------------------------


class _FakeConvModule:
    def __init__(self, in_channels=None) -> None:
        if in_channels is not None:
            self.in_channels = in_channels


class _FakeNetwork:
    def __init__(self, modules) -> None:
        self._modules_list = modules

    def modules(self):
        return iter(self._modules_list)


def test_first_module_in_channels_finds_first_module_with_the_attribute() -> None:
    net = _FakeNetwork([_FakeConvModule(), _FakeConvModule(in_channels=1), _FakeConvModule(in_channels=32)])
    assert cr._first_module_in_channels(net) == 1


def test_first_module_in_channels_returns_none_when_nothing_has_it() -> None:
    net = _FakeNetwork([_FakeConvModule(), _FakeConvModule()])
    assert cr._first_module_in_channels(net) is None


class _FakeDevice:
    def __init__(self, type_: str) -> None:
        self.type = type_


def test_warm_up_predictor_skips_on_cpu_device_without_raising() -> None:
    predictor = _FakePredictor()
    predictor.device = _FakeDevice("cpu")
    cr._warm_up_predictor(predictor)  # must not raise


def test_warm_up_predictor_is_best_effort_and_never_raises_on_a_bare_fake() -> None:
    # _FakePredictor() has no .device at all -- the real failure mode this
    # function must swallow (e.g. an nnunetv2 version with a renamed attribute).
    cr._warm_up_predictor(_FakePredictor())  # must not raise


class _WarmupFakeTensor:
    def __init__(self, device) -> None:
        self.device = device


class _WarmupFakeCuda:
    @staticmethod
    def synchronize(device) -> None:  # noqa: ARG004
        pass


class _WarmupFakeTorchModule:
    """Stands in for the real ``torch`` module inside ``_warm_up_predictor``
    (which does ``import torch`` internally) via ``sys.modules`` injection --
    lets this real-hardware bug be regression-tested without a GPU: this repo's
    local sandbox has CPU-only torch, so a real ``torch.device('cuda')`` tensor
    allocation isn't available to exercise the actual CPU/CUDA mismatch here.
    """

    cuda = _WarmupFakeCuda()
    float32 = "float32"

    @staticmethod
    def zeros(shape, dtype=None, device=None):  # noqa: ARG004
        return _WarmupFakeTensor(device)

    @staticmethod
    def no_grad():
        return contextlib.nullcontext()


class _WarmupFakeNetwork:
    """Models the real bug this session found on real hardware: a network
    that starts on CPU (matching ``initialize_from_trained_model_folder``'s
    real behavior) and must be explicitly moved via ``.to(device)`` before a
    forward pass on a CUDA tensor will succeed -- mirrors real
    ``torch.nn.Module.to()`` semantics (mutates in place, returns self).
    """

    def __init__(self) -> None:
        self.device = types.SimpleNamespace(type="cpu")
        self.to_call_count = 0

    def modules(self):
        return iter([_FakeConvModule(in_channels=1)])

    def to(self, device):
        self.device = device
        self.to_call_count += 1
        return self


class _WarmupFakePredictor:
    """A predictor whose ``_internal_maybe_mirror_and_predict`` raises on a real
    CPU/CUDA device mismatch between ``self.network`` and the input tensor --
    exactly the error nnU-Net's real network layers raise, and exactly what the
    original (buggy) version of ``_warm_up_predictor`` silently swallowed. If
    this test passes, the fix (moving ``predictor.network`` to ``device`` before
    the dummy forward pass) is genuinely doing its job, not just not-crashing.
    """

    def __init__(self) -> None:
        self.device = types.SimpleNamespace(type="cuda")
        self.network = _WarmupFakeNetwork()
        self.configuration_manager = types.SimpleNamespace(patch_size=[4, 4, 4])
        self.successful_predict_calls = 0

    def _internal_maybe_mirror_and_predict(self, dummy):
        if self.network.device.type != dummy.device.type:
            raise RuntimeError(
                "Input type (torch.cuda.FloatTensor) and weight type (torch.FloatTensor) "
                "should be the same (simulated real nnU-Net device-mismatch error)"
            )
        self.successful_predict_calls += 1
        return dummy


def test_warm_up_predictor_moves_network_to_device_before_forward_pass(monkeypatch) -> None:
    # Regression test for the real bug found in the D2 margin-hardening
    # validation round (2026-07-13, see this function's docstring in
    # checkpoint_runner.py): the network is left on CPU by
    # initialize_from_trained_model_folder, and a warm-up that forgets to move
    # it to `device` first silently no-ops (the forward pass raises, gets
    # swallowed by the best-effort except, and nothing was actually warmed up).
    monkeypatch.setitem(sys.modules, "torch", _WarmupFakeTorchModule())
    predictor = _WarmupFakePredictor()

    cr._warm_up_predictor(predictor)

    assert predictor.network.to_call_count == 1
    assert predictor.network.device.type == "cuda"
    # The real, meaningful assertion: the forward pass actually ran successfully
    # (not silently swallowed by a device-mismatch exception).
    assert predictor.successful_predict_calls == 1


def test_run_checkpoint_inference_calls_warm_up_fn_once_before_any_case(tmp_path: Path) -> None:
    input_dir, output_dir = tmp_path / "inputs", tmp_path / "outputs"
    input_dir.mkdir()
    for case_id in ("a", "b"):
        _write_nifti(input_dir / f"{case_id}.nii.gz", np.zeros((2, 2, 2), dtype=np.float32))

    call_order = []

    def warm_up_fn(predictor):
        assert isinstance(predictor, _FakePredictor)
        call_order.append("warm_up")

    def predict_case_fn(predictor, image_path, out_dir, output_suffix=""):
        call_order.append(f"predict:{image_path.name}")
        return CaseInferenceResult(image_path.name, str(image_path), str(out_dir / image_path.name), 0.1, None)

    cr.run_checkpoint_inference_for_docker(
        input_dir,
        output_dir,
        tmp_path / "checkpoint",
        predictor_factory=_fake_predictor_factory_calls([]),
        predict_case_fn=predict_case_fn,
        warm_up_fn=warm_up_fn,
    )

    assert call_order == ["warm_up", "predict:a.nii.gz", "predict:b.nii.gz"]


def test_run_checkpoint_inference_skips_warm_up_when_there_are_no_cases(tmp_path: Path) -> None:
    input_dir, output_dir = tmp_path / "inputs", tmp_path / "outputs"
    input_dir.mkdir()
    calls = []
    cr.run_checkpoint_inference_for_docker(
        input_dir,
        output_dir,
        tmp_path / "checkpoint",
        predictor_factory=_fake_predictor_factory_calls([]),
        predict_case_fn=lambda *a, **k: pytest.fail("should not be called"),
        warm_up_fn=lambda predictor: calls.append(predictor),
    )
    assert calls == []  # no predictor was ever built, so nothing to warm up


def test_run_checkpoint_inference_default_warm_up_is_best_effort_with_fake_predictor(tmp_path: Path) -> None:
    # Exercises the REAL default warm_up_fn (_warm_up_predictor) against the
    # existing _FakePredictor fake (no .device attribute) -- locks in that the
    # default is safe to leave wired up even when a test (or an unexpected real
    # predictor shape) doesn't have the attributes it expects.
    input_dir, output_dir = tmp_path / "inputs", tmp_path / "outputs"
    input_dir.mkdir()
    _write_nifti(input_dir / "a.nii.gz", np.zeros((2, 2, 2), dtype=np.float32))

    def predict_case_fn(predictor, image_path, out_dir, output_suffix=""):
        return CaseInferenceResult("a", str(image_path), str(out_dir / "a.nii.gz"), 0.1, None)

    outcomes = cr.run_checkpoint_inference_for_docker(
        input_dir,
        output_dir,
        tmp_path / "checkpoint",
        predictor_factory=_fake_predictor_factory_calls([]),
        predict_case_fn=predict_case_fn,
    )
    assert [o.status for o in outcomes] == ["ok"]
