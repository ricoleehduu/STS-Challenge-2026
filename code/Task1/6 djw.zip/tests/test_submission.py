from __future__ import annotations

from pathlib import Path
from zipfile import ZipFile

import nibabel as nib
import numpy as np

from stsr2026.data.audit import audit_dataset
from stsr2026.submission.validator import create_validation_zip, validate_predictions


def _write_nifti(path: Path, values: np.ndarray) -> None:
    nib.save(nib.Nifti1Image(values, np.diag([0.3, 0.4, 0.5, 1.0])), str(path))


def test_audit_and_submission_round_trip(tmp_path: Path) -> None:
    images, labels, predictions = (tmp_path / name for name in ("images", "labels", "predictions"))
    for directory in (images, labels, predictions):
        directory.mkdir()
    image = np.arange(24, dtype=np.float32).reshape(2, 3, 4)
    label = np.zeros((2, 3, 4), dtype=np.uint8)
    label[0, 0, 0] = 64
    _write_nifti(images / "case_001.nii.gz", image)
    _write_nifti(labels / "case_001.nii.gz", label)
    _write_nifti(predictions / "case_001.nii.gz", label)

    report = audit_dataset(images, labels)
    assert report["num_labeled_cases"] == 1
    assert report["class_voxels"] == {"0": 23, "64": 1}
    validated = validate_predictions(images, predictions)
    assert validated[0].classes == (0, 64)

    output_zip = tmp_path / "submission.zip"
    create_validation_zip(predictions, output_zip, expected_cases=1)
    with ZipFile(output_zip) as archive:
        assert archive.namelist() == ["case_001.nii.gz"]
