from __future__ import annotations

import numpy as np
import pytest

from stsr2026.training import pseudo_label_generation as plg

# This sandbox has no GPU and no working nnunetv2 install (see module
# docstring). _nearest_resample_label_map is pure-ish logic (real CPU torch
# is enough, no nnunetv2 needed) -- the geometry-reversal orchestration
# (generate_pseudo_label_for_case/write_pseudo_label_nifti) is GPU-dependent
# and unverified here, same disclaimer as nnunet_inference.py/streaming_export.py.


def test_nearest_resample_label_map_is_noop_when_shape_matches(monkeypatch):
    real_torch = pytest.importorskip("torch")
    monkeypatch.setattr(plg, "torch", real_torch)
    monkeypatch.setattr(plg, "F", real_torch.nn.functional)
    labels = np.array([[[1, 2], [3, 255]]], dtype=np.int64)
    result = plg._nearest_resample_label_map(labels, labels.shape, device=real_torch.device("cpu"))
    assert result is labels


def test_nearest_resample_label_map_preserves_dtype(monkeypatch):
    real_torch = pytest.importorskip("torch")
    monkeypatch.setattr(plg, "torch", real_torch)
    monkeypatch.setattr(plg, "F", real_torch.nn.functional)
    labels = np.zeros((4, 4, 4), dtype=np.int64)
    labels[1, 1, 1] = 255
    result = plg._nearest_resample_label_map(labels, (8, 8, 8), device=real_torch.device("cpu"))
    assert result.dtype == np.int64
    assert result.shape == (8, 8, 8)


def test_nearest_resample_label_map_never_introduces_new_values(monkeypatch):
    real_torch = pytest.importorskip("torch")
    monkeypatch.setattr(plg, "torch", real_torch)
    monkeypatch.setattr(plg, "F", real_torch.nn.functional)
    generator = real_torch.Generator().manual_seed(0)
    labels_t = real_torch.randint(0, 65, (6, 6, 6), generator=generator)
    labels_t[0, 0, 0] = 255  # ignore_label sentinel mixed in with real classes
    labels = labels_t.numpy().astype(np.int64)

    upsampled = plg._nearest_resample_label_map(labels, (12, 10, 9), device=real_torch.device("cpu"))
    downsampled = plg._nearest_resample_label_map(labels, (3, 3, 3), device=real_torch.device("cpu"))

    original_values = set(np.unique(labels).tolist())
    assert set(np.unique(upsampled).tolist()) <= original_values
    assert set(np.unique(downsampled).tolist()) <= original_values


def test_nearest_resample_label_map_upsampled_voxel_matches_a_source_voxel(monkeypatch):
    # Nearest-neighbor upsampling: every output voxel must equal some real
    # source voxel value (never a blend), which is the whole point of using
    # nearest instead of linear/cubic for a label map that mixes real class
    # IDs with the ignore_label sentinel.
    real_torch = pytest.importorskip("torch")
    monkeypatch.setattr(plg, "torch", real_torch)
    monkeypatch.setattr(plg, "F", real_torch.nn.functional)
    labels = np.array([[[0, 64]]], dtype=np.int64)  # shape (1, 1, 2): background vs. max canal class
    result = plg._nearest_resample_label_map(labels, (2, 2, 4), device=real_torch.device("cpu"))
    assert set(np.unique(result).tolist()) <= {0, 64}


def test_require_nnunetv2_raises_informative_error_without_nnunetv2(tmp_path):
    if plg.NNUNETV2_AVAILABLE:
        pytest.skip("only exercises the no-nnunetv2 error path")
    with pytest.raises(plg.PseudoLabelGenerationError, match="nnunetv2/torch/acvl_utils"):
        plg.generate_pseudo_label_for_case(None, tmp_path / "image.nii.gz", tmp_path / "cache")
    with pytest.raises(plg.PseudoLabelGenerationError, match="nnunetv2/torch/acvl_utils"):
        plg.write_pseudo_label_nifti(None, np.zeros((2, 2, 2)), {}, tmp_path / "out.nii.gz")
