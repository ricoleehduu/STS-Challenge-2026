from __future__ import annotations

import numpy as np
import pytest

from stsr2026.training.pseudo_label import (
    CANAL_CLASS_MIN,
    PseudoLabelConfig,
    PseudoLabelError,
    canal_class_to_fdi,
    corresponding_tooth_class_id,
    evaluate_canal_components,
    expected_canal_count_range,
    fdi_to_position,
    filter_pseudo_labels,
    is_canal_class,
    is_tooth_class,
    labels_and_confidence_from_probabilities,
    tooth_class_to_fdi,
)

INCISOR_TOOTH_CLASS = 1  # FDI 11, maxillary central incisor, expected 1 canal
INCISOR_CANAL_CLASS = CANAL_CLASS_MIN  # class 33 -> FDI 11
MOLAR_TOOTH_CLASS = 22  # FDI 36, mandibular 1st molar, expected 3-4 canals
MOLAR_CANAL_CLASS = 32 + MOLAR_TOOTH_CLASS  # class 54 -> FDI 36


def _volume(shape: tuple[int, int, int] = (10, 10, 10)) -> np.ndarray:
    return np.zeros(shape, dtype=np.int64)


def test_fdi_mapping_round_trips_teeth_and_canals() -> None:
    assert tooth_class_to_fdi(INCISOR_TOOTH_CLASS) == 11
    assert canal_class_to_fdi(INCISOR_CANAL_CLASS) == 11
    assert tooth_class_to_fdi(MOLAR_TOOTH_CLASS) == 36
    assert canal_class_to_fdi(MOLAR_CANAL_CLASS) == 36
    assert corresponding_tooth_class_id(INCISOR_CANAL_CLASS) == INCISOR_TOOTH_CLASS
    assert is_tooth_class(INCISOR_TOOTH_CLASS) and not is_canal_class(INCISOR_TOOTH_CLASS)
    assert is_canal_class(INCISOR_CANAL_CLASS) and not is_tooth_class(INCISOR_CANAL_CLASS)


def test_fdi_to_position_reports_quadrant_and_position() -> None:
    position = fdi_to_position(36)
    assert position.quadrant == 3
    assert position.position_in_quadrant == 6


def test_expected_canal_count_range_lookup() -> None:
    assert expected_canal_count_range(11, {11: (1, 1)}) == (1, 1)


def test_labels_and_confidence_from_probabilities_picks_argmax_and_its_own_probability() -> None:
    probabilities = np.zeros((3, 2, 2, 2), dtype=np.float64)
    probabilities[0] = 0.1
    probabilities[1] = 0.7
    probabilities[2] = 0.2
    labels, confidence = labels_and_confidence_from_probabilities(probabilities)
    assert np.all(labels == 1)
    assert np.allclose(confidence, 0.7)


def _single_voxel_line(shape: tuple[int, int, int], coords: list[tuple[int, int, int]]) -> np.ndarray:
    mask = np.zeros(shape, dtype=bool)
    for z, y, x in coords:
        mask[z, y, x] = True
    return mask


def test_evaluate_canal_components_accepts_clean_single_component_for_incisor() -> None:
    shape = (10, 10, 10)
    mask = _single_voxel_line(shape, [(1, 1, 1), (1, 1, 2), (1, 1, 3), (1, 1, 4)])
    decision, kept_mask = evaluate_canal_components(mask, INCISOR_CANAL_CLASS, None, PseudoLabelConfig())
    assert decision.accepted
    assert decision.kept_component_count == 1
    assert decision.expected_range == (1, 1)
    assert np.array_equal(kept_mask, mask)


def test_evaluate_canal_components_rejects_scattered_stray_specks() -> None:
    shape = (12, 12, 12)
    stray_specks = [(2, 2, 2), (5, 7, 1), (8, 3, 9), (0, 9, 4), (11, 11, 0), (6, 6, 6)]
    mask = _single_voxel_line(shape, stray_specks)
    decision, kept_mask = evaluate_canal_components(mask, INCISOR_CANAL_CLASS, None, PseudoLabelConfig())
    assert not decision.accepted
    assert decision.raw_component_count == len(stray_specks)
    assert decision.kept_component_count == 0
    assert not kept_mask.any()


def test_evaluate_canal_components_accepts_molar_within_expected_range() -> None:
    shape = (10, 10, 10)
    components = [
        [(0, 0, 0), (0, 0, 1), (0, 0, 2)],
        [(4, 4, 4), (4, 4, 5), (4, 4, 6)],
        [(8, 8, 8), (8, 8, 7), (8, 8, 6)],
    ]
    mask = _single_voxel_line(shape, [c for comp in components for c in comp])
    decision, kept_mask = evaluate_canal_components(mask, MOLAR_CANAL_CLASS, None, PseudoLabelConfig())
    assert decision.accepted
    assert decision.kept_component_count == 3
    assert decision.expected_range == (3, 4)
    assert np.array_equal(kept_mask, mask)


def test_evaluate_canal_components_rejects_molar_clearly_outside_expected_range() -> None:
    shape = (10, 10, 10)
    single_component = [(1, 1, 1), (1, 1, 2), (1, 1, 3)]
    mask = _single_voxel_line(shape, single_component)
    decision, kept_mask = evaluate_canal_components(mask, MOLAR_CANAL_CLASS, None, PseudoLabelConfig())
    assert not decision.accepted
    # kept_mask reflects the noise/overlap filters only, independent of the
    # final range decision -- the lone component survives those filters
    # (it is not stray noise), but the class as a whole is still rejected
    # because 1 component is outside the expected (3, 4) range for a molar.
    assert decision.kept_component_count == 1
    assert decision.expected_range == (3, 4)
    assert np.array_equal(kept_mask, mask)


def test_evaluate_canal_components_closing_bridges_one_voxel_gap() -> None:
    shape = (10, 10, 10)
    # Two runs with a single missing voxel between them at (1, 1, 3): simulates a
    # thin centerline annotation/prediction with a 1-voxel gap.
    mask = _single_voxel_line(shape, [(1, 1, 1), (1, 1, 2), (1, 1, 4), (1, 1, 5)])
    no_closing, _ = evaluate_canal_components(mask, INCISOR_CANAL_CLASS, None, PseudoLabelConfig(closing_iterations=0))
    with_closing, kept_mask = evaluate_canal_components(
        mask, INCISOR_CANAL_CLASS, None, PseudoLabelConfig(closing_iterations=1)
    )
    assert no_closing.raw_component_count == 2
    assert not no_closing.accepted  # 2 components > expected (1, 1) for an incisor
    assert with_closing.raw_component_count == 1
    assert with_closing.accepted
    # Closing only changes counting; accepted voxels still come from the original mask.
    assert np.array_equal(kept_mask, mask)


def test_evaluate_canal_components_min_component_voxels_drops_single_voxel_noise() -> None:
    shape = (10, 10, 10)
    main_component = [(2, 2, 2), (2, 2, 3), (2, 2, 4)]
    speck = [(9, 9, 9)]
    mask = _single_voxel_line(shape, main_component + speck)
    decision, kept_mask = evaluate_canal_components(
        mask, INCISOR_CANAL_CLASS, None, PseudoLabelConfig(min_component_voxels=2)
    )
    assert decision.raw_component_count == 2
    assert decision.kept_component_count == 1
    assert decision.accepted
    assert kept_mask[2, 2, 2] and kept_mask[2, 2, 3] and kept_mask[2, 2, 4]
    assert not kept_mask[9, 9, 9]


def test_evaluate_canal_components_instance_overlap_filter_drops_mismatched_component() -> None:
    shape = (10, 10, 10)
    correct_tooth_component = [(1, 1, 1), (1, 1, 2), (1, 1, 3)]
    wrong_tooth_component = [(8, 8, 8), (8, 8, 7), (8, 8, 6)]
    mask = _single_voxel_line(shape, correct_tooth_component + wrong_tooth_component)

    teeth_instance_map = np.zeros(shape, dtype=np.int64)
    teeth_instance_map[0:3, 0:3, 0:5] = INCISOR_TOOTH_CLASS  # covers the correct component only

    config = PseudoLabelConfig(instance_overlap_threshold=0.5, instance_dilation_voxels=0)
    decision, kept_mask = evaluate_canal_components(mask, INCISOR_CANAL_CLASS, teeth_instance_map, config)
    assert decision.accepted
    assert decision.kept_component_count == 1
    assert kept_mask[1, 1, 1]
    assert not kept_mask[8, 8, 8]


def test_filter_pseudo_labels_keeps_high_confidence_tooth_voxels() -> None:
    class_map = _volume()
    class_map[1, 1, 1] = INCISOR_TOOTH_CLASS
    confidence = np.ones_like(class_map, dtype=np.float64)
    result = filter_pseudo_labels(class_map, confidence)
    assert result.labels[1, 1, 1] == INCISOR_TOOTH_CLASS
    assert result.ignored_voxels == 0


def test_filter_pseudo_labels_ignores_low_confidence_tooth_voxels() -> None:
    class_map = _volume()
    class_map[1, 1, 1] = INCISOR_TOOTH_CLASS
    confidence = np.ones_like(class_map, dtype=np.float64)
    confidence[1, 1, 1] = 0.4
    config = PseudoLabelConfig()
    result = filter_pseudo_labels(class_map, confidence, config=config)
    assert result.labels[1, 1, 1] == config.ignore_label


def test_filter_pseudo_labels_accepts_clean_canal_and_rejects_scattered_canal() -> None:
    shape = (12, 12, 12)
    class_map = np.zeros(shape, dtype=np.int64)
    confidence = np.full(shape, 0.9, dtype=np.float64)

    clean_component = [(1, 1, 1), (1, 1, 2), (1, 1, 3)]
    for coord in clean_component:
        class_map[coord] = INCISOR_CANAL_CLASS

    other_canal_class = CANAL_CLASS_MIN + 1  # FDI 12, also expected exactly 1 canal
    scattered = [(2, 2, 2), (5, 7, 1), (8, 3, 9), (0, 9, 4), (11, 11, 0), (6, 6, 6)]
    for coord in scattered:
        class_map[coord] = other_canal_class

    result = filter_pseudo_labels(class_map, confidence)

    for coord in clean_component:
        assert result.labels[coord] == INCISOR_CANAL_CLASS
    for coord in scattered:
        assert result.labels[coord] == PseudoLabelConfig().ignore_label

    decisions_by_class = {d.class_id: d for d in result.canal_decisions}
    assert decisions_by_class[INCISOR_CANAL_CLASS].accepted
    assert not decisions_by_class[other_canal_class].accepted


def test_filter_pseudo_labels_applies_lower_confidence_threshold_to_canals_than_teeth() -> None:
    shape = (5, 5, 5)
    class_map = np.zeros(shape, dtype=np.int64)
    # Two connected voxels so the component clears the default noise-size floor.
    class_map[1, 1, 1] = INCISOR_CANAL_CLASS
    class_map[1, 1, 2] = INCISOR_CANAL_CLASS
    confidence = np.full(shape, 0.6, dtype=np.float64)  # below tooth threshold, above canal threshold

    config = PseudoLabelConfig(tooth_confidence_threshold=0.75, canal_confidence_threshold=0.5)
    result = filter_pseudo_labels(class_map, confidence, config=config)

    assert result.labels[1, 1, 1] == INCISOR_CANAL_CLASS
    assert result.labels[1, 1, 2] == INCISOR_CANAL_CLASS


def test_filter_pseudo_labels_leaves_background_untouched() -> None:
    shape = (4, 4, 4)
    class_map = np.zeros(shape, dtype=np.int64)
    confidence = np.zeros(shape, dtype=np.float64)  # even zero-confidence background stays background
    result = filter_pseudo_labels(class_map, confidence)
    assert np.all(result.labels == 0)
    assert result.ignored_voxels == 0
    assert result.accepted_foreground_voxels == 0


def test_filter_pseudo_labels_rejects_shape_mismatch() -> None:
    class_map = _volume((4, 4, 4))
    confidence = np.zeros((3, 3, 3), dtype=np.float64)
    with pytest.raises(PseudoLabelError, match="shape"):
        filter_pseudo_labels(class_map, confidence)
