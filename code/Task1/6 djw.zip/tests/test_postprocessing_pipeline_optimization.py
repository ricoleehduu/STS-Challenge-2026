"""Bit-identical regression test for the FULL production post-processing
chain (`postprocessing_pipeline.apply_postprocessing_chain`, unmodified by
this optimization work) against a reference chain built from the frozen
pre-optimization `correct_lr_confusion`/`clean_or_relabel_false_positive_labels`
implementations.

This is the end-to-end check: `apply_postprocessing_chain` composes exactly
the two optimized hotspots (step 1: `correct_lr_confusion`, step 2: the
GT-free teeth-only `clean_or_relabel_false_positive_labels` call) plus,
optionally, step 3 (the GT-informed cleanup, when `gt_labels` is given) --
see `tests/test_lr_correction_optimization.py` and
`tests/test_false_positive_cleanup_optimization.py` for hotspot-level tests.
This file exists to catch a mistake at the COMPOSITION level (e.g. an
optimized function subtly changing how it interacts with the next step's
input) that per-function tests alone might miss.
"""
from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import numpy as np
import pytest

from stsr2026.inference.lr_correction import _correct_lr_confusion_reference
from stsr2026.inference.postprocessing_pipeline import (
    DEFAULT_DILATION_VOXELS,
    DEFAULT_SMALL_VOLUME_THRESHOLD,
    apply_postprocessing_chain,
)

_REFERENCE_PATH = (
    Path(__file__).parent / "_reference_snapshots" / "false_positive_cleanup_pre_optimization.py"
)


def _load_reference():
    spec = importlib.util.spec_from_file_location("_fpc_reference_snapshot_pp", _REFERENCE_PATH)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules["_fpc_reference_snapshot_pp"] = module
    spec.loader.exec_module(module)
    return module


fpc_ref = _load_reference()


def _reference_chain(
    label_volume: np.ndarray,
    affine: np.ndarray,
    gt_labels=None,
    volume_threshold: int = DEFAULT_SMALL_VOLUME_THRESHOLD,
    dilation_voxels: int = DEFAULT_DILATION_VOXELS,
) -> np.ndarray:
    """Same three-step composition as `apply_postprocessing_chain`, but built
    from the frozen pre-optimization reference implementations of both
    hotspots."""
    corrected = _correct_lr_confusion_reference(label_volume, affine)
    teeth_cleaned, _ = fpc_ref.clean_or_relabel_false_positive_labels(
        corrected,
        gt_labels=None,
        volume_threshold=volume_threshold,
        dilation_voxels=dilation_voxels,
        affine=affine,
        gtfree_options=fpc_ref.GTFreeOptions(clean_classes="teeth"),
    )
    if gt_labels is None:
        return teeth_cleaned
    cleaned, _ = fpc_ref.clean_or_relabel_false_positive_labels(
        teeth_cleaned, gt_labels, volume_threshold, dilation_voxels=dilation_voxels
    )
    return cleaned


def _random_volume(
    rng: np.random.Generator,
    shape: tuple[int, int, int] = (50, 50, 50),
    n_components: int = 70,
    max_class: int = 64,
) -> np.ndarray:
    volume = np.zeros(shape, dtype=np.uint8)
    for _ in range(n_components):
        cls = int(rng.integers(1, max_class + 1))
        x = int(rng.integers(0, shape[0] - 4))
        y = int(rng.integers(0, shape[1] - 4))
        z = int(rng.integers(0, shape[2] - 4))
        sx, sy, sz = (int(v) for v in rng.integers(1, 5, 3))
        volume[x : x + sx, y : y + sy, z : z + sz] = cls
    return volume


@pytest.mark.parametrize("seed", range(30))
@pytest.mark.parametrize("with_gt_labels", [False, True])
def test_full_chain_matches_reference(seed: int, with_gt_labels: bool) -> None:
    rng = np.random.default_rng(seed + 5000)
    volume = _random_volume(rng)
    affine = np.eye(4)
    for axis in range(3):
        affine[axis, axis] = float(rng.uniform(0.2, 0.4))
        affine[axis, 3] = float(rng.uniform(-10, 10))

    gt_labels = None
    if with_gt_labels:
        gt_labels = set(int(c) for c in rng.choice(np.arange(1, 41), size=15, replace=False))

    expected = _reference_chain(volume, affine, gt_labels=gt_labels)
    actual = apply_postprocessing_chain(volume, affine, gt_labels=gt_labels)

    assert np.array_equal(expected, actual)
