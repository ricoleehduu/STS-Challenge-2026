from __future__ import annotations

import json
from pathlib import Path

import nibabel as nib
import numpy as np

from stsr2026.data.convert import convert_labeled_dataset


def _write_nifti(path: Path, values: np.ndarray) -> None:
    nib.save(nib.Nifti1Image(values, np.diag([0.3, 0.4, 0.5, 1.0])), str(path))


def test_convert_labeled_dataset_writes_nnunet_layout(tmp_path: Path) -> None:
    images_dir, labels_dir = tmp_path / "images", tmp_path / "labels"
    images_dir.mkdir()
    labels_dir.mkdir()
    image = np.arange(24, dtype=np.float32).reshape(2, 3, 4)
    label = np.zeros((2, 3, 4), dtype=np.uint8)
    label[0, 0, 0] = 64
    for case_id in ("case_001", "case_002"):
        _write_nifti(images_dir / f"{case_id}.nii.gz", image)
        _write_nifti(labels_dir / f"{case_id}.nii.gz", label)

    output_dir = tmp_path / "nnunet_raw" / "Dataset001_STSR"
    convert_labeled_dataset(images_dir, labels_dir, output_dir, case_ids=["case_001"])

    assert (output_dir / "imagesTr" / "case_001_0000.nii.gz").exists()
    assert (output_dir / "labelsTr" / "case_001.nii.gz").exists()
    assert not (output_dir / "imagesTr" / "case_002_0000.nii.gz").exists()

    manifest = json.loads((output_dir / "dataset.json").read_text())
    assert manifest["numTraining"] == 1
    assert manifest["file_ending"] == ".nii.gz"
    assert manifest["labels"]["background"] == 0
    assert manifest["labels"]["class_64"] == 64
    assert len(manifest["labels"]) == 65


def test_convert_labeled_dataset_defaults_to_all_cases(tmp_path: Path) -> None:
    images_dir, labels_dir = tmp_path / "images", tmp_path / "labels"
    images_dir.mkdir()
    labels_dir.mkdir()
    image = np.zeros((2, 2, 2), dtype=np.float32)
    label = np.zeros((2, 2, 2), dtype=np.uint8)
    for case_id in ("case_001", "case_002"):
        _write_nifti(images_dir / f"{case_id}.nii.gz", image)
        _write_nifti(labels_dir / f"{case_id}.nii.gz", label)

    output_dir = tmp_path / "nnunet_raw" / "Dataset001_STSR"
    convert_labeled_dataset(images_dir, labels_dir, output_dir)

    manifest = json.loads((output_dir / "dataset.json").read_text())
    assert manifest["numTraining"] == 2
