"""Tests for mirror-canal deduplication."""
from __future__ import annotations

import numpy as np
import pytest

from stsr2026.inference.canal_mirror_dedup import (
    dedup_mirror_canals,
    mirror_canal_class,
)


def test_mirror_canal_class_maps_quadrants():
    assert mirror_canal_class(33) == 41
    assert mirror_canal_class(41) == 33
    assert mirror_canal_class(57) == 49
    assert mirror_canal_class(49) == 57


def test_mirror_canal_class_is_an_involution():
    for canal in range(33, 65):
        assert mirror_canal_class(mirror_canal_class(canal)) == canal


@pytest.mark.parametrize("bad", [1, 32, 65])
def test_mirror_canal_class_rejects_non_canal(bad):
    with pytest.raises(ValueError):
        mirror_canal_class(bad)


def _volume(assignments):
    volume = np.zeros((30, 30, 30), dtype=np.uint8)
    for cls, sl in assignments.items():
        volume[sl] = cls
    return volume


def test_smaller_member_of_a_mirror_pair_is_dropped():
    volume = _volume({
        33: np.s_[2:4, 2:4, 2:4],      # 8 voxels
        41: np.s_[10:15, 10:15, 10:15],  # 125 voxels
    })
    corrected, decisions = dedup_mirror_canals(volume)
    assert (corrected == 33).sum() == 0
    assert (corrected == 41).sum() == 125
    (decision,) = decisions
    assert decision.dropped == 33 and decision.kept == 41


def test_dropped_voxels_become_background_not_the_kept_class():
    # Relabeling instead of clearing would change the binary foreground mask and
    # move image-level metrics, which this step must leave untouched.
    volume = _volume({33: np.s_[2:4, 2:4, 2:4], 41: np.s_[10:15, 10:15, 10:15]})
    before_foreground = int((volume > 0).sum())
    corrected, _ = dedup_mirror_canals(volume)
    assert int((corrected > 0).sum()) == before_foreground - 8
    assert (corrected == 41).sum() == 125


def test_canal_without_its_mirror_is_untouched():
    volume = _volume({33: np.s_[2:6, 2:6, 2:6]})
    corrected, decisions = dedup_mirror_canals(volume)
    assert decisions == []
    assert np.array_equal(corrected, volume)


def test_equal_sized_pair_is_left_alone():
    volume = _volume({33: np.s_[2:4, 2:4, 2:4], 41: np.s_[10:12, 10:12, 10:12]})
    corrected, decisions = dedup_mirror_canals(volume)
    assert decisions == []
    assert np.array_equal(corrected, volume)


def test_teeth_are_never_touched():
    volume = _volume({
        1: np.s_[2:5, 2:5, 2:5],
        9: np.s_[20:26, 20:26, 20:26],
        33: np.s_[2:4, 2:4, 6:8],
        41: np.s_[10:15, 10:15, 10:15],
    })
    corrected, _ = dedup_mirror_canals(volume)
    assert (corrected == 1).sum() == (volume == 1).sum()
    assert (corrected == 9).sum() == (volume == 9).sum()


def test_require_same_parent_skips_pairs_with_different_parents():
    # canal 33 sits next to tooth 1; canal 41 sits next to tooth 9 -- different
    # parents, so the strict variant must decline to choose.
    volume = _volume({
        1: np.s_[2:5, 2:5, 2:5],
        9: np.s_[20:26, 20:26, 20:26],
        33: np.s_[3:4, 3:4, 3:4],
        41: np.s_[21:25, 21:25, 21:25],
    })
    _, lenient = dedup_mirror_canals(volume, require_same_parent=False)
    corrected, strict = dedup_mirror_canals(volume, require_same_parent=True)
    assert len(lenient) == 1
    assert strict == []
    assert np.array_equal(corrected, volume)


def test_require_same_parent_acts_when_parents_match():
    volume = _volume({
        1: np.s_[2:8, 2:8, 2:8],
        33: np.s_[3:4, 3:4, 3:4],
        41: np.s_[4:7, 4:7, 4:7],
    })
    _, strict = dedup_mirror_canals(volume, require_same_parent=True)
    assert len(strict) == 1
    assert strict[0].dropped == 33
    assert strict[0].same_parent is True


def test_each_pair_is_processed_once():
    volume = _volume({
        33: np.s_[2:4, 2:4, 2:4], 41: np.s_[10:15, 10:15, 10:15],
        34: np.s_[20:22, 20:22, 20:22], 42: np.s_[24:28, 24:28, 24:28],
    })
    _, decisions = dedup_mirror_canals(volume)
    assert len(decisions) == 2
    assert {d.dropped for d in decisions} == {33, 34}


def test_empty_volume_is_a_noop():
    volume = np.zeros((10, 10, 10), dtype=np.uint8)
    corrected, decisions = dedup_mirror_canals(volume)
    assert decisions == []
    assert np.array_equal(corrected, volume)
