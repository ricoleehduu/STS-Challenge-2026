"""Unit tests for the coordinate-channel fine-tune trainer -- mirrors
``test_p1_finetune_trainer.py``'s pattern exactly (see that file's
docstring for why: this trainer has almost no logic of its own beyond the
epoch-budget override, and no GPU/full nnunetv2 install is available in
this sandbox to exercise the ``nnUNetTrainer`` subclass itself).
"""
from __future__ import annotations

import pytest

from stsr2026.training import coord_finetune_trainer as cft


def test_resolve_num_epochs_defaults_when_env_var_unset(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv(cft._NUM_EPOCHS_ENV_VAR, raising=False)
    assert cft._resolve_num_epochs() == cft.DEFAULT_COORD_FINETUNE_NUM_EPOCHS


def test_resolve_num_epochs_defaults_when_env_var_empty(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(cft._NUM_EPOCHS_ENV_VAR, "")
    assert cft._resolve_num_epochs() == cft.DEFAULT_COORD_FINETUNE_NUM_EPOCHS


def test_resolve_num_epochs_reads_env_var_override(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(cft._NUM_EPOCHS_ENV_VAR, "150")
    assert cft._resolve_num_epochs() == 150


def test_resolve_num_epochs_rejects_non_integer(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(cft._NUM_EPOCHS_ENV_VAR, "nope")
    with pytest.raises(ValueError, match="not a valid integer"):
        cft._resolve_num_epochs()


def test_resolve_num_epochs_rejects_zero(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(cft._NUM_EPOCHS_ENV_VAR, "0")
    with pytest.raises(ValueError, match="must be positive"):
        cft._resolve_num_epochs()


def test_resolve_num_epochs_rejects_negative(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(cft._NUM_EPOCHS_ENV_VAR, "-1")
    with pytest.raises(ValueError, match="must be positive"):
        cft._resolve_num_epochs()


def test_env_var_name_does_not_collide_with_p1() -> None:
    from stsr2026.training import p1_finetune_trainer as p1

    assert cft._NUM_EPOCHS_ENV_VAR != p1._NUM_EPOCHS_ENV_VAR


def test_trainer_class_reflects_nnunetv2_availability() -> None:
    if cft.NNUNETV2_AVAILABLE:
        assert cft.nnUNetTrainer_STSR_CoordFineTune is not None
    else:
        assert cft.nnUNetTrainer_STSR_CoordFineTune is None
