from __future__ import annotations

from pathlib import Path

import numpy as np
import pytest

from stsr2026.inference import streaming_export as se

# This sandbox has CPU torch (no CUDA) but no nnunetv2/acvl_utils install (see
# streaming_export.py's module docstring). The streaming-argmax core (layer 1)
# needs neither and is fully tested below against synthetic arrays, including
# tie cases. The GPU channel-resample building block is tested against real CPU
# torch (bit-exact vs. a naive batched reference). The nnU-Net integration
# layer (layer 2) is GPU/nnunetv2-dependent and only logic-tested here (error
# paths), matching tests/test_nnunet_inference.py's existing pattern.


# ---------------------------------------------------------------------------
# StreamingArgmax
# ---------------------------------------------------------------------------


def test_streaming_argmax_matches_numpy_argmax_no_ties() -> None:
    rng = np.random.default_rng(0)
    channels = rng.normal(size=(5, 4, 3, 2)).astype(np.float32)
    expected = np.argmax(channels, axis=0).astype(np.uint8)

    acc = se.StreamingArgmax(channels.shape[1:])
    for c in range(channels.shape[0]):
        acc.update(c, channels[c])
    result = acc.finalize()

    assert np.array_equal(result, expected)


def test_streaming_argmax_tie_breaks_to_lowest_label() -> None:
    # voxel 0: channel 0 and channel 2 both have the max value 5.0 -> argmax
    # picks the *first* occurrence, i.e. label 0, not label 2.
    channels = np.array(
        [
            [5.0, 1.0],
            [3.0, 1.0],
            [5.0, 9.0],
        ],
        dtype=np.float32,
    )
    expected = np.argmax(channels, axis=0)
    assert expected.tolist() == [0, 2]  # sanity check on the hand-built fixture

    acc = se.StreamingArgmax(channels.shape[1:])
    for c in range(channels.shape[0]):
        acc.update(c, channels[c])
    result = acc.finalize()

    assert result.tolist() == [0, 2]


def test_streaming_argmax_all_equal_values_picks_label_zero() -> None:
    channels = np.ones((4, 3, 3), dtype=np.float32) * 7.0
    acc = se.StreamingArgmax(channels.shape[1:])
    for c in range(channels.shape[0]):
        acc.update(c, channels[c])
    result = acc.finalize()
    assert np.all(result == 0)


def test_streaming_argmax_rejects_out_of_order_labels() -> None:
    acc = se.StreamingArgmax((2, 2))
    acc.update(0, np.zeros((2, 2), dtype=np.float32))
    with pytest.raises(ValueError, match="strictly increasing"):
        acc.update(0, np.ones((2, 2), dtype=np.float32))
    # first call on a fresh accumulator never raises, regardless of label value
    se.StreamingArgmax((2, 2)).update(5, np.zeros((2, 2), dtype=np.float32))
    acc2 = se.StreamingArgmax((2, 2))
    acc2.update(5, np.zeros((2, 2), dtype=np.float32))
    with pytest.raises(ValueError, match="strictly increasing"):
        acc2.update(3, np.ones((2, 2), dtype=np.float32))


def test_streaming_argmax_rejects_wrong_channel_shape() -> None:
    acc = se.StreamingArgmax((2, 2))
    with pytest.raises(ValueError, match="!="):
        acc.update(0, np.zeros((3, 3), dtype=np.float32))


def test_streaming_argmax_finalize_before_update_raises() -> None:
    acc = se.StreamingArgmax((2, 2))
    with pytest.raises(RuntimeError, match="before any update"):
        acc.finalize()


# ---------------------------------------------------------------------------
# streaming_resample_and_argmax
# ---------------------------------------------------------------------------


def _identity_resample(channel_index: int, channel: np.ndarray, target_shape) -> np.ndarray:
    assert tuple(channel.shape) == tuple(target_shape)
    return channel


def test_streaming_resample_and_argmax_matches_full_materialize_reference() -> None:
    rng = np.random.default_rng(1)
    logits = rng.normal(size=(6, 5, 4, 3)).astype(np.float32)
    expected = np.argmax(logits, axis=0).astype(np.uint8)

    result = se.streaming_resample_and_argmax(logits, target_shape=(5, 4, 3), resample_channel=_identity_resample)

    assert np.array_equal(result, expected)


def test_streaming_resample_and_argmax_never_materializes_all_channels_at_once() -> None:
    seen_shapes = []

    def spy_resample(channel_index, channel, target_shape):
        seen_shapes.append(channel.shape)
        return channel

    logits = np.zeros((7, 2, 2, 2), dtype=np.float32)
    se.streaming_resample_and_argmax(logits, target_shape=(2, 2, 2), resample_channel=spy_resample)

    # resample_channel is called once per channel, each time with a *single*
    # channel's worth of data (shape (2,2,2), not (7,2,2,2)) -- this is the
    # actual memory-bound property under test.
    assert len(seen_shapes) == 7
    assert all(shape == (2, 2, 2) for shape in seen_shapes)


def test_streaming_resample_and_argmax_custom_channel_to_label_mapping() -> None:
    # channel 0 -> label 10, channel 1 -> label 20, channel 2 -> label 30
    logits = np.array(
        [
            [1.0, 9.0],
            [5.0, 2.0],
            [3.0, 8.0],
        ],
        dtype=np.float32,
    )
    result = se.streaming_resample_and_argmax(
        logits, target_shape=(2,), resample_channel=_identity_resample, channel_to_label=[10, 20, 30]
    )
    # voxel 0: max is channel 1 (5.0) -> label 20; voxel 1: max is channel 0 (9.0) -> label 10
    assert result.tolist() == [20, 10]


def test_streaming_resample_and_argmax_rejects_non_increasing_channel_to_label() -> None:
    logits = np.zeros((2, 2), dtype=np.float32)
    with pytest.raises(ValueError, match="strictly increasing"):
        se.streaming_resample_and_argmax(
            logits, target_shape=(2,), resample_channel=_identity_resample, channel_to_label=[5, 3]
        )
    with pytest.raises(ValueError, match="strictly increasing"):
        se.streaming_resample_and_argmax(
            logits, target_shape=(2,), resample_channel=_identity_resample, channel_to_label=[1, 1]
        )


def test_streaming_resample_and_argmax_rejects_mismatched_channel_to_label_length() -> None:
    logits = np.zeros((3, 2), dtype=np.float32)
    with pytest.raises(ValueError, match="channels"):
        se.streaming_resample_and_argmax(
            logits, target_shape=(2,), resample_channel=_identity_resample, channel_to_label=[0, 1]
        )


# ---------------------------------------------------------------------------
# Output naming (dependency-free injected boundary)
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("output_suffix", "expected_name"),
    [("", "case_001.nii.gz"), ("_mask", "case_001_mask.nii.gz")],
)
def test_predict_case_streaming_output_suffix_naming_without_nnunet(
    tmp_path: Path, monkeypatch, output_suffix: str, expected_name: str
) -> None:
    class _FakeCuda:
        @staticmethod
        def is_available() -> bool:
            return False

    class _FakeTorch:
        cuda = _FakeCuda()

        @staticmethod
        def from_numpy(data):
            return data

        @staticmethod
        def get_num_threads():
            return 1

        @staticmethod
        def set_num_threads(n):
            pass

    class _FakePrediction:
        pass

    class _FakePreprocessor:
        def __init__(self, verbose):
            pass

        def run_case(self, *args):
            return np.zeros((1, 2, 2, 2), dtype=np.float32), None, {}

    class _FakeConfigurationManager:
        preprocessor_class = _FakePreprocessor

    class _FakeNetwork:
        @staticmethod
        def load_state_dict(params):
            pass

    class _FakePredictor:
        configuration_manager = _FakeConfigurationManager()
        plans_manager = object()
        dataset_json = {"file_ending": ".nii.gz"}
        verbose = False
        device = "cpu"
        list_of_parameters = [{"fake": "params"}]
        network = _FakeNetwork()

        @staticmethod
        def predict_sliding_window_return_logits(data):
            return _FakePrediction()

    def fake_windowed_export(*args, **kwargs):
        # windowed_predict_and_export(predictor, data, properties_dict,
        # configuration_manager, plans_manager, dataset_json_dict_or_file,
        # output_file_truncated, *, device=...) -- output_file_truncated is
        # the 7th positional arg (index 6), unlike the old
        # streaming_export_prediction_from_logits(predicted_array_or_file, ...)
        # boundary this test used to mock (index 5 there).
        output_file_truncated = args[6]
        Path(output_file_truncated + ".nii.gz").write_bytes(b"fake-output")

    monkeypatch.setattr(se, "TORCH_AVAILABLE", True)
    monkeypatch.setattr(se, "NNUNETV2_EXPORT_AVAILABLE", True)
    monkeypatch.setattr(se, "torch", _FakeTorch())
    monkeypatch.setattr(se, "windowed_predict_and_export", fake_windowed_export)

    image_path = tmp_path / "images" / "case_001.nii.gz"
    suffix_kwargs = {"output_suffix": output_suffix} if output_suffix else {}
    result = se.predict_case_streaming(_FakePredictor(), image_path, tmp_path / "out", **suffix_kwargs)

    assert result.output_path == str(tmp_path / "out" / expected_name)
    assert Path(result.output_path).is_file()


# ---------------------------------------------------------------------------
# GPU channel-resample building block (real CPU torch, no CUDA needed)
# ---------------------------------------------------------------------------

torch = pytest.importorskip("torch")


def test_gpu_resample_channel_matches_naive_batched_interpolate_bit_exact() -> None:
    import torch.nn.functional as F

    rng = np.random.default_rng(2)
    logits_np = rng.normal(size=(4, 3, 4, 5)).astype(np.float32)
    target = (6, 8, 10)
    device = torch.device("cpu")

    # naive reference: resample the whole channel stack at once, then argmax
    logits_t = torch.from_numpy(logits_np)
    batched = F.interpolate(logits_t.unsqueeze(0), size=target, mode="trilinear", align_corners=False)[0]
    expected_label = torch.argmax(batched, dim=0).numpy().astype(np.uint8)

    # streaming: resample + fold one channel at a time
    def resample_channel(channel_index, channel, target_shape):
        return se._gpu_resample_channel_to_shape(channel, target_shape, device=device)

    result = se.streaming_resample_and_argmax(logits_np, target_shape=target, resample_channel=resample_channel)

    assert np.array_equal(result, expected_label)
    # and the per-channel resampled values are themselves bit-exact vs. the
    # batched reference (independent per channel -- no cross-channel interaction
    # in trilinear interpolation, so batching should not change the numbers)
    for c in range(4):
        one = se._gpu_resample_channel_to_shape(logits_np[c], target, device=device)
        assert np.array_equal(one, batched[c].numpy())


def test_gpu_resample_channel_no_op_when_already_target_shape() -> None:
    channel = np.random.default_rng(3).normal(size=(4, 5, 6)).astype(np.float32)
    result = se._gpu_resample_channel_to_shape(channel, (4, 5, 6), device=torch.device("cpu"))
    assert np.array_equal(result, channel)


# ---------------------------------------------------------------------------
# gpu_resample_and_argmax: GPU-resident fold == CPU-callback fold, bit-exact
# (real CPU torch; the same trilinear kernel path, no CUDA needed to prove the
# fold logic matches -- the CUDA cross-check on real Ampere is a separate script,
# tmp/verify_gpu_argmax_bitexact.py, per the task's 4090D-vs-target caveat)
# ---------------------------------------------------------------------------


def test_gpu_resample_and_argmax_matches_cpu_callback_fold_bit_exact() -> None:
    rng = np.random.default_rng(7)
    # fp16 source to exercise the fp16-upload / GPU-side fp32-cast path used in prod
    logits = rng.normal(size=(6, 3, 4, 5)).astype(np.float16)
    target = (6, 8, 10)
    device = torch.device("cpu")

    def resample_channel(channel_index, channel, target_shape):
        return se._gpu_resample_channel_to_shape(channel, target_shape, device=device)

    reference = se.streaming_resample_and_argmax(logits, target_shape=target, resample_channel=resample_channel)
    result = se.gpu_resample_and_argmax(logits, target_shape=target, device=device)

    assert result.dtype == reference.dtype
    assert np.array_equal(result, reference)


def test_gpu_resample_and_argmax_no_resample_when_already_target_shape() -> None:
    rng = np.random.default_rng(8)
    logits = rng.normal(size=(4, 3, 3, 3)).astype(np.float32)
    target = (3, 3, 3)
    expected = np.argmax(logits, axis=0).astype(np.uint8)
    result = se.gpu_resample_and_argmax(logits, target_shape=target, device=torch.device("cpu"))
    assert np.array_equal(result, expected)


def test_gpu_resample_and_argmax_tie_breaks_to_lowest_label() -> None:
    # two channels tie at the max on voxel 0 -> lowest label wins (first-max-wins),
    # matching np.argmax and the CPU StreamingArgmax path.
    logits = np.array(
        [
            [[[5.0]]],
            [[[3.0]]],
            [[[5.0]]],
        ],
        dtype=np.float32,
    )  # shape (3,1,1,1)
    result = se.gpu_resample_and_argmax(logits, target_shape=(1, 1, 1), device=torch.device("cpu"))
    assert result.tolist() == [[[0]]]


def test_gpu_resample_and_argmax_custom_channel_to_label() -> None:
    logits = np.array([[[[1.0]]], [[[9.0]]], [[[3.0]]]], dtype=np.float32)  # (3,1,1,1)
    result = se.gpu_resample_and_argmax(
        logits, target_shape=(1, 1, 1), device=torch.device("cpu"), channel_to_label=[10, 20, 30]
    )
    assert result.tolist() == [[[20]]]  # channel 1 is max -> label 20


def test_gpu_resample_and_argmax_rejects_non_increasing_channel_to_label() -> None:
    logits = np.zeros((2, 2, 2, 2), dtype=np.float32)
    with pytest.raises(ValueError, match="strictly increasing"):
        se.gpu_resample_and_argmax(
            logits, target_shape=(2, 2, 2), device=torch.device("cpu"), channel_to_label=[5, 3]
        )


# ---------------------------------------------------------------------------
# make_gpu_channel_resampler routing (isotropic -> GPU, anisotropic -> fallback/raise)
# ---------------------------------------------------------------------------


def test_make_gpu_channel_resampler_uses_gpu_path_when_isotropic() -> None:
    resample = se.make_gpu_channel_resampler(
        device=torch.device("cpu"), current_spacing=(0.3, 0.3, 0.3), new_spacing=(0.3, 0.3, 0.3)
    )
    channel = np.zeros((2, 2, 2), dtype=np.float32)
    result = resample(0, channel, (2, 2, 2))
    assert result.shape == (2, 2, 2)


def test_make_gpu_channel_resampler_routes_to_fallback_when_anisotropic() -> None:
    calls = []

    def fallback(channel_index, channel, target_shape):
        calls.append((channel_index, channel.shape, tuple(target_shape)))
        return np.zeros(target_shape, dtype=np.float32)

    resample = se.make_gpu_channel_resampler(
        device=torch.device("cpu"),
        current_spacing=(0.3, 0.3, 5.0),  # z spacing >> 3x the others
        new_spacing=(0.3, 0.3, 5.0),
        cpu_fallback_resample_channel=fallback,
    )
    channel = np.ones((2, 2, 2), dtype=np.float32)
    resample(0, channel, (2, 2, 2))

    assert calls == [(0, (2, 2, 2), (2, 2, 2))]


def test_make_gpu_channel_resampler_raises_when_anisotropic_and_no_fallback() -> None:
    resample = se.make_gpu_channel_resampler(
        device=torch.device("cpu"), current_spacing=(0.3, 0.3, 5.0), new_spacing=(0.3, 0.3, 5.0)
    )
    with pytest.raises(se.InferenceError, match="anisotropic"):
        resample(0, np.zeros((2, 2, 2), dtype=np.float32), (2, 2, 2))


# ---------------------------------------------------------------------------
# nnU-Net integration layer: logic-only (no nnunetv2 in this sandbox)
# ---------------------------------------------------------------------------


def test_nnunetv2_export_not_available_in_this_sandbox() -> None:
    # Mirrors tests/test_nnunet_inference.py's analogous assertion: documents
    # the expected sandbox state so a future dependency change doesn't
    # silently make the skip-guarded tests below stop running without anyone
    # noticing.
    assert se.NNUNETV2_EXPORT_AVAILABLE is False


@pytest.mark.skipif(se.NNUNETV2_EXPORT_AVAILABLE, reason="only exercises the no-nnunetv2 error path")
def test_functions_raise_informative_error_without_nnunetv2(tmp_path: Path) -> None:
    with pytest.raises(se.InferenceError, match="nnunetv2/acvl_utils are not installed"):
        se.predict_case_streaming(None, tmp_path / "image.nii.gz", tmp_path / "out")


def test_install_streaming_export_removed() -> None:
    # install_streaming_export's monkeypatch machinery was removed 2026-07-13:
    # predict_case_streaming now calls streaming_export_prediction_from_logits
    # directly (it owns the whole preprocess/predict/export call chain itself,
    # replicating predict_from_files_sequential's single-case loop rather than
    # calling that nnunetv2>=2.6.0-only method), so there is no nnU-Net
    # orchestration call site left to intercept. This test documents the
    # removal so it isn't silently reintroduced.
    assert not hasattr(se, "install_streaming_export")


def test_streaming_export_prediction_from_logits_raises_without_fallback_when_probabilities_requested() -> None:
    with pytest.raises(se.InferenceError, match="save_probabilities"):
        se.streaming_export_prediction_from_logits(
            predicted_array_or_file=None,
            properties_dict={},
            configuration_manager=None,
            plans_manager=None,
            dataset_json_dict_or_file={},
            output_file_truncated="unused",
            save_probabilities=True,
            original_export_fn=None,
        )


def test_streaming_export_prediction_from_logits_falls_back_when_probabilities_requested_with_fallback() -> None:
    calls = []

    def fake_original(*args):
        calls.append(args)

    se.streaming_export_prediction_from_logits(
        predicted_array_or_file="logits",
        properties_dict={"a": 1},
        configuration_manager="cm",
        plans_manager="pm",
        dataset_json_dict_or_file={"b": 2},
        output_file_truncated="out",
        save_probabilities=True,
        num_threads_torch=4,
        original_export_fn=fake_original,
    )

    assert len(calls) == 1
    assert calls[0] == ("logits", {"a": 1}, "cm", "pm", {"b": 2}, "out", True, 4)


class _FakeLabelManager:
    def __init__(self, has_regions: bool, all_labels: list[int]) -> None:
        self.has_regions = has_regions
        self._all_labels = all_labels

    @property
    def all_labels(self):
        return self._all_labels


def test_streaming_convert_rejects_region_based_label_manager() -> None:
    label_manager = _FakeLabelManager(has_regions=True, all_labels=[0, 1])
    with pytest.raises(se.InferenceError, match="region-based"):
        se.streaming_convert_predicted_logits_to_segmentation_with_correct_shape(
            predicted_logits=None,
            plans_manager=None,
            configuration_manager=None,
            label_manager=label_manager,
            properties_dict={},
            device=None,
        )


@pytest.mark.parametrize(
    ("output_suffix", "expected_name"),
    [("", "case_001.nii.gz"), ("_mask", "case_001_mask.nii.gz")],
)
def test_predict_case_streaming_replicates_single_case_loop_with_injected_nnunetv2(
    tmp_path: Path, monkeypatch, output_suffix: str, expected_name: str
) -> None:
    # 2026-07-15 refactor: predict_case_streaming now calls
    # windowed_predict_and_export (fuses sliding-window tile accumulation +
    # resample + argmax fold so the full logits array is never materialized,
    # see that function's docstring and this module's "Windowed..." section
    # comment) instead of _predict_logits_keep_on_device + streaming_export_
    # prediction_from_logits. windowed_predict_and_export's OWN internals are
    # covered by tests/test_windowed_prediction.py (pure algorithmic core) and
    # this file's fallback-path tests below; this test verifies
    # predict_case_streaming's preprocess -> export wiring/argument-passing
    # logic only, following this repo's existing inject-at-the-boundary
    # pattern (mock everything past the boundary being tested).
    real_torch = pytest.importorskip("torch")
    monkeypatch.setattr(se, "NNUNETV2_EXPORT_AVAILABLE", True)
    monkeypatch.setattr(se, "torch", real_torch)

    calls: dict = {}

    class _FakePreprocessor:
        def __init__(self, verbose):
            calls["preprocessor_verbose"] = verbose

        def run_case(self, list_of_lists, seg_file, plans_manager, configuration_manager, dataset_json):
            calls["run_case_args"] = (list_of_lists, seg_file, plans_manager, configuration_manager, dataset_json)
            data = np.zeros((2, 3, 3, 3), dtype=np.float32)
            return data, None, {"case": "props"}

    class _FakeConfigurationManager:
        preprocessor_class = _FakePreprocessor

    class _FakePlansManager:
        pass

    class _FakePredictor:
        def __init__(self):
            self.configuration_manager = _FakeConfigurationManager()
            self.plans_manager = _FakePlansManager()
            self.dataset_json = {"file_ending": ".nii.gz"}
            self.verbose = True
            self.device = real_torch.device("cpu")

    def fake_windowed_export(
        predictor,
        data,
        properties_dict,
        configuration_manager,
        plans_manager,
        dataset_json_dict_or_file,
        output_file_truncated,
        *,
        device=None,
        target_chunk_depth=None,
        max_chunk_logits_bytes=None,
    ):
        calls["export_args"] = (
            predictor,
            data,
            properties_dict,
            configuration_manager,
            plans_manager,
            dataset_json_dict_or_file,
            output_file_truncated,
            device,
        )
        Path(output_file_truncated + dataset_json_dict_or_file["file_ending"]).write_bytes(b"fake-output")

    monkeypatch.setattr(se, "windowed_predict_and_export", fake_windowed_export)

    image_path = tmp_path / "images" / "case_001.nii.gz"
    output_dir = tmp_path / "out"

    suffix_kwargs = {"output_suffix": output_suffix} if output_suffix else {}
    predictor = _FakePredictor()
    result = se.predict_case_streaming(predictor, image_path, output_dir, **suffix_kwargs)

    assert calls["preprocessor_verbose"] is True
    assert calls["run_case_args"][0] == [str(image_path)]
    assert calls["run_case_args"][1] is None  # no previous-stage seg
    expected_truncated_output = output_dir / expected_name.removesuffix(".nii.gz")
    assert calls["export_args"][6] == str(expected_truncated_output)
    assert calls["export_args"][7] == real_torch.device("cpu")  # device threaded through explicitly
    # data is passed as a torch.Tensor (preprocessed input, not yet predicted --
    # windowed_predict_and_export owns tile accumulation itself now)
    assert isinstance(calls["export_args"][1], real_torch.Tensor)
    assert result.case_id == "case_001"
    assert result.input_path == str(image_path)
    assert result.output_path == str(output_dir / expected_name)
    assert Path(result.output_path).is_file()


def test_predict_case_streaming_raises_when_export_does_not_write_expected_file(
    tmp_path: Path, monkeypatch
) -> None:
    real_torch = pytest.importorskip("torch")
    monkeypatch.setattr(se, "NNUNETV2_EXPORT_AVAILABLE", True)
    monkeypatch.setattr(se, "torch", real_torch)

    class _FakePreprocessor:
        def __init__(self, verbose):
            pass

        def run_case(self, list_of_lists, seg_file, plans_manager, configuration_manager, dataset_json):
            return np.zeros((1, 2, 2, 2), dtype=np.float32), None, {}

    class _FakeConfigurationManager:
        preprocessor_class = _FakePreprocessor

    class _FakeNetwork:
        @staticmethod
        def load_state_dict(params):
            pass

    class _FakePredictor:
        configuration_manager = _FakeConfigurationManager()
        plans_manager = object()
        dataset_json = {"file_ending": ".nii.gz"}
        verbose = False
        device = real_torch.device("cpu")
        list_of_parameters = [{"fake": "params"}]
        network = _FakeNetwork()

        def predict_sliding_window_return_logits(self, data):
            return real_torch.zeros((1, 2, 2, 2))

    monkeypatch.setattr(se, "windowed_predict_and_export", lambda *a, **k: None)  # writes nothing

    image_path = tmp_path / "images" / "case_002.nii.gz"

    with pytest.raises(se.InferenceError, match="did not produce the expected output file"):
        se.predict_case_streaming(_FakePredictor(), image_path, tmp_path / "out")


def test_streaming_convert_rejects_non_contiguous_all_labels() -> None:
    label_manager = _FakeLabelManager(has_regions=False, all_labels=[0, 2, 5])
    with pytest.raises(se.InferenceError, match="channel index == label value"):
        se.streaming_convert_predicted_logits_to_segmentation_with_correct_shape(
            predicted_logits=None,
            plans_manager=None,
            configuration_manager=None,
            label_manager=label_manager,
            properties_dict={},
            device=None,
        )
