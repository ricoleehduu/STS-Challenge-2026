"""Synthetic tests for ``ot_instance_assignment.py``.

These tests deliberately include the scenarios the *Hungarian* module's own
19-test synthetic suite did NOT cover -- and whose absence is exactly why
that module's real-data failure (``docs/experiment-log.md``,
``Day1-TaskE-Hungarian-default``) went undetected until a real 6-case
official-scorer run: an outlier fragment component just above the noise
floor, multiple same-label fragments of one true instance, and a genuine
false positive that should be rejected rather than force-fit. See each
test's docstring for how it targets one specific diagnosed root cause.

All of the "clean" behavioural assertions below (no-op, single-adjacent-
swap-not-corrected, missing-tooth, category/quadrant isolation, validation
errors) were checked empirically against this module during development,
not assumed by analogy with the Hungarian module's fixtures -- the two
modules' cost mechanics differ (entropic OT + dustbin vs. exact rectangular
Hungarian + post-hoc threshold), so a scenario tuned for one does not
transfer numerically to the other; several were reworked after an initial
guess produced different real behaviour (see ``test_same_label_merge_can_
conflate_two_unrelated_components`` for a limitation found exactly this way).
"""
from __future__ import annotations

import numpy as np
import pytest

from stsr2026.inference.ot_instance_assignment import (
    Candidate,
    _category_distance_scale,
    _merge_same_label_components,
    _RawComponent,
    _solve_group,
    _weighted_quantile,
    assign_instances_to_fdi_slots,
    sinkhorn_log_domain,
)

AFFINE = np.eye(4)
MID = 20
_POSITION_SHAPE = (1, 3, 2)  # 6 voxels, matching MIN_COMPONENT_VOXELS=5 with margin


def _block(volume: np.ndarray, x: int, label: int, *, y: int = 1, shape=_POSITION_SHAPE) -> None:
    volume[x : x + shape[0], y : y + shape[1], 1 : 1 + shape[2]] = label


def _position_x(k: int) -> int:
    """x placement for Q1 (tooth classes 1-8) position k, matching the
    Hungarian module's test fixture convention."""
    return MID + 2 * k


def _full_arch(shape: tuple[int, int, int] = (70, 8, 6)) -> np.ndarray:
    """Q1 (classes 1-8, +x side) and Q2 (classes 9-16, -x side), every
    position already at its own correctly-ordered, correctly-labeled spot."""
    volume = np.zeros(shape, dtype=np.uint8)
    for k in range(1, 9):
        _block(volume, _position_x(k), k)
    for k in range(1, 9):
        _block(volume, MID - 2 * k - 2, 8 + k)
    return volume


# ---------------------------------------------------------------------------
# sinkhorn_log_domain: the self-contained solver, tested in isolation first.
# ---------------------------------------------------------------------------


def test_sinkhorn_log_domain_respects_row_and_column_marginals() -> None:
    """Basic correctness of the from-scratch log-domain Sinkhorn solve: for
    a well-posed balanced problem, the converged plan's row and column sums
    must match the supplied marginals (mass conservation) -- this is the
    defining property of the transportation polytope the algorithm is
    supposed to be sampling from, not an incidental detail.
    """
    rng = np.random.default_rng(0)
    cost = rng.uniform(0.0, 1.0, size=(5, 7))
    a = rng.uniform(0.5, 2.0, size=5)
    b = rng.uniform(0.5, 2.0, size=7)
    b *= a.sum() / b.sum()  # rebalance so sum(a) == sum(b)

    plan = sinkhorn_log_domain(cost, a, b, reg=0.05, max_iter=2000, tol=1e-12)

    assert plan.shape == (5, 7)
    assert np.all(plan >= 0.0)
    np.testing.assert_allclose(plan.sum(axis=1), a, atol=1e-4)
    np.testing.assert_allclose(plan.sum(axis=0), b, atol=1e-4)


def test_sinkhorn_log_domain_favors_low_cost_pairs() -> None:
    """Sanity check that the solver actually minimizes cost, not just any
    plan satisfying the marginals: for a diagonal-cheap 2x2 problem, mass
    should concentrate on the diagonal."""
    cost = np.array([[0.0, 1.0], [1.0, 0.0]])
    plan = sinkhorn_log_domain(cost, a=np.array([1.0, 1.0]), b=np.array([1.0, 1.0]), reg=0.02, max_iter=2000)
    assert plan[0, 0] > plan[0, 1]
    assert plan[1, 1] > plan[1, 0]


def test_sinkhorn_log_domain_rejects_unbalanced_marginals() -> None:
    with pytest.raises(ValueError, match="sum"):
        sinkhorn_log_domain(np.zeros((2, 2)), a=np.array([1.0, 1.0]), b=np.array([1.0, 0.5]))


def test_sinkhorn_log_domain_rejects_non_positive_reg() -> None:
    with pytest.raises(ValueError, match="reg"):
        sinkhorn_log_domain(np.zeros((2, 2)), a=np.array([1.0, 1.0]), b=np.array([1.0, 1.0]), reg=0.0)


# ---------------------------------------------------------------------------
# _weighted_quantile: the primitive behind the robust distance scale.
# ---------------------------------------------------------------------------


def test_weighted_quantile_matches_unweighted_median_for_equal_weights() -> None:
    values = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
    weights = np.ones(5)
    assert _weighted_quantile(values, weights, 0.5) == pytest.approx(3.0, abs=0.5)


def test_weighted_quantile_downweights_a_low_mass_outlier() -> None:
    """The exact property this module relies on to replace ``np.max()``: a
    single low-weight point far in the tail should barely move a high
    (p90) quantile, unlike ``np.max()`` which any single point dominates
    regardless of its weight.
    """
    values = np.array([1.0] * 9 + [100.0])
    weights = np.array([10.0] * 9 + [1.0])  # outlier: 1/91 of total mass
    q90 = _weighted_quantile(values, weights, 0.9)
    assert q90 == pytest.approx(1.0)  # 90% of mass is reached before the outlier
    assert np.max(values) == 100.0  # contrast: max() would have been dominated by it


# ---------------------------------------------------------------------------
# STRUCTURAL FIX 2 -- robust distance scale vs. a single outlier component
# just above the noise floor (the exact Hungarian root cause: case_002's
# 180-voxel component at 52.9mm blew up np.max() and compressed every real
# candidate's normalized position toward 0).
# ---------------------------------------------------------------------------


def test_category_distance_scale_robust_to_outlier_just_above_noise_floor() -> None:
    real = [
        _RawComponent("tooth", quadrant_index=k % 4, original_label=k, component_id=1, voxel_count=2000, centroid_world_x=float(k))
        for k in range(1, 9)
    ]  # 8 real, well-populated components spanning 1..8mm from midline
    outlier = _RawComponent(
        "tooth", quadrant_index=1, original_label=14, component_id=2, voxel_count=6, centroid_world_x=500.0
    )  # tiny, just above MIN_COMPONENT_VOXELS=5, anatomically-impossible distance

    scale_with_outlier = _category_distance_scale(real + [outlier], midline_x=0.0, quantile=0.9)
    scale_without_outlier = _category_distance_scale(real, midline_x=0.0, quantile=0.9)

    assert scale_with_outlier == pytest.approx(scale_without_outlier, rel=0.2)
    assert scale_with_outlier < 20.0  # nowhere near the outlier's 500mm
    # contrast: what the FAILED np.max()-based Hungarian version computed
    naive_max_scale = max(abs(c.centroid_world_x) for c in real + [outlier])
    assert naive_max_scale == 500.0
    assert scale_with_outlier < naive_max_scale / 10


def test_category_distance_scale_none_when_uninformative() -> None:
    assert _category_distance_scale([], midline_x=0.0, quantile=0.9) is None
    assert _category_distance_scale(
        [_RawComponent("tooth", 0, 1, 1, 200, 0.0)], midline_x=None, quantile=0.9
    ) is None


# ---------------------------------------------------------------------------
# STRUCTURAL FIX 1 -- same-label fragment merging (case_021: one canal
# shattered into 9 components under one label, scattered by Hungarian to
# 4-5 different final slots instead of being consolidated).
# ---------------------------------------------------------------------------


def test_merge_same_label_components_pools_voxel_count_and_weighted_centroid() -> None:
    fragments = [
        _RawComponent("canal", 0, 39, component_id=1, voxel_count=10, centroid_world_x=0.0),
        _RawComponent("canal", 0, 39, component_id=2, voxel_count=20, centroid_world_x=3.0),
        _RawComponent("canal", 0, 39, component_id=3, voxel_count=30, centroid_world_x=6.0),
    ]
    merged = _merge_same_label_components(fragments)
    assert len(merged) == 1
    candidate = merged[0]
    assert candidate.original_label == 39
    assert candidate.component_ids == (1, 2, 3)
    assert candidate.voxel_count == 60
    # voxel-count-weighted mean: (10*0 + 20*3 + 30*6) / 60 = 4.0
    assert candidate.centroid_world_x == pytest.approx(4.0)


def test_merge_same_label_components_keeps_distinct_labels_separate() -> None:
    components = [
        _RawComponent("tooth", 0, 3, 1, 200, 1.0),
        _RawComponent("tooth", 0, 4, 1, 200, 2.0),
    ]
    merged = _merge_same_label_components(components)
    assert {c.original_label for c in merged} == {3, 4}
    assert all(len(c.component_ids) == 1 for c in merged)


def test_fragments_of_one_instance_merge_into_a_single_matched_slot() -> None:
    """End-to-end version of the merge property: three disconnected, same-
    label fragments (simulating a canal/tooth shattered by segmentation)
    become exactly ONE candidate and ONE matched slot -- not scattered
    across multiple slots the way the pre-merge Hungarian design would.
    """
    volume = np.zeros((70, 8, 6), dtype=np.uint8)
    frag_xs = [_position_x(5) - 2, _position_x(5), _position_x(5) + 2]
    for x in frag_xs:
        _block(volume, x, 6)  # all three fragments share label 6

    result = assign_instances_to_fdi_slots(volume, AFFINE)

    tooth_matches = [m for m in result.matched if m.category == "tooth"]
    assert len(tooth_matches) == 1  # not 3 separate matches
    match = tooth_matches[0]
    assert len(match.component_ids) == 3
    assert match.voxel_count == 3 * 6
    # every fragment's voxels carry the SAME final label -- none left orphaned
    nonzero_labels = np.unique(result.output_volume[result.output_volume > 0])
    assert nonzero_labels.tolist() == [match.new_label]


# ---------------------------------------------------------------------------
# STRUCTURAL FIX 2 (continued) -- dustbin: a genuine false positive should
# be rejected rather than force-fit into a real slot. This is the scenario
# a plain (non-rejecting) assignment structurally cannot handle. Tested
# directly against _solve_group (the internal function the full pipeline
# calls) with 9 distinct candidates for 8 slots -- mirroring the classic
# "more predicted components than slots" case, achieved here by having one
# candidate lose competitive bids for BOTH of its two viable slots. Direct
# testing was necessary because empirically (see module docstring's honest
# note on dustbin economics -- discovered during this module's own
# development) an isolated single bad candidate rarely reaches dustbin
# under default weights: with only 8 real slots and a spare-capacity
# dustbin row/column, the joint transport almost always finds it a
# cheap-enough uncontested real slot instead. True dustbin rejection
# requires genuine competition with no fallback, which is exactly the
# real-world "duplicate under an adjacent FDI position" failure mode this
# module targets.
# ---------------------------------------------------------------------------


def test_solve_group_routes_doubly_outcompeted_candidate_to_dustbin() -> None:
    labels_ranks = {2: 1 / 7, 3: 2 / 7, 4: 3 / 7, 6: 5 / 7, 7: 6 / 7, 8: 1.0}
    candidates = [
        Candidate("tooth", 0, label, (label,), 200, 0.0) for label in labels_ranks
    ]
    ranks = list(labels_ranks.values())
    candidates.append(Candidate("tooth", 0, 1, (10,), 200, 0.0))
    ranks.append(0.0)  # real label1, correctly at slot1
    candidates.append(Candidate("tooth", 0, 5, (11,), 200, 0.0))
    ranks.append(4 / 7)  # real label5, correctly at slot5
    candidates.append(Candidate("tooth", 0, 5, (99,), 30, 0.0))
    ranks.append(0.0)  # candidateH: mislabeled 5, physically at slot1's spot
    # -> contests slot1 (loses to real label1) AND slot5 (loses to real label5)

    normalized_rank = np.array(ranks)
    real_cost, plan = _solve_group(
        candidates,
        "tooth",
        0,
        normalized_rank,
        order_weight=0.6,
        label_mismatch_cost=0.4,
        dustbin_cost=0.35,
        sinkhorn_reg=0.005,
        sinkhorn_max_iter=3000,
    )

    assert len(candidates) == 9
    candidate_h_row = len(candidates) - 1
    dustbin_col = real_cost.shape[1]  # column index QUADRANT_SIZE
    row_argmax = plan.argmax(axis=1)
    assert row_argmax[candidate_h_row] == dustbin_col
    assert plan[candidate_h_row, dustbin_col] > 0.99  # mass overwhelmingly concentrated there
    # the two real candidates it contested are NOT disturbed
    assert row_argmax[6] == 0  # real label1 -> slot1 (index 0)
    assert row_argmax[7] == 4  # real label5 -> slot5 (index 4)


# ---------------------------------------------------------------------------
# End-to-end behaviour via assign_instances_to_fdi_slots.
# ---------------------------------------------------------------------------


def test_no_op_when_already_correctly_ordered_and_labeled() -> None:
    result = assign_instances_to_fdi_slots(_full_arch(), AFFINE)
    tooth_matches = [m for m in result.matched if m.category == "tooth"]
    assert len(tooth_matches) == 16
    assert all(not m.changed for m in tooth_matches)
    assert result.dustbin == ()
    assert result.output_volume is not _full_arch()  # always a new array


def test_extreme_position_swap_gets_corrected() -> None:
    """Swap the two extreme positions (1 <-> 8) of one quadrant -- far
    larger a displacement than a lone adjacent-position error, so the
    order-cost benefit of fixing it clears the label-mismatch penalty."""
    volume = _full_arch()
    volume[volume == 1] = 100
    volume[volume == 8] = 1
    volume[volume == 100] = 8

    result = assign_instances_to_fdi_slots(volume, AFFINE)

    changed = {(m.original_label, m.new_label) for m in result.matched if m.changed}
    assert changed == {(1, 8), (8, 1)}


def test_single_adjacent_position_swap_not_corrected_by_default_weights() -> None:
    """Checked, documented calibration property (mirrors the equivalent
    Hungarian-module test): with default weights the label-mismatch
    penalty (0.4) dominates a single-grid-step order improvement, so a
    lone adjacent swap is deliberately left untouched rather than
    "corrected" on marginal evidence.
    """
    volume = _full_arch()
    volume[volume == 3] = 100
    volume[volume == 4] = 3
    volume[volume == 100] = 4

    result = assign_instances_to_fdi_slots(volume, AFFINE)

    assert all(not m.changed for m in result.matched)
    assert np.array_equal(result.output_volume, volume)


def test_missing_tooth_leaves_empty_slot_without_fabrication() -> None:
    volume = _full_arch()
    volume[volume == 5] = 0

    result = assign_instances_to_fdi_slots(volume, AFFINE)

    q1_matches = [m for m in result.matched if m.category == "tooth" and m.quadrant_index == 0]
    assert len(q1_matches) == 7
    assert {m.original_label for m in q1_matches} == {1, 2, 3, 4, 6, 7, 8}
    empty_q1 = [
        e for e in result.empty_slots if e.category == "tooth" and e.quadrant_index == 0
    ]
    assert len(empty_q1) == 1
    assert empty_q1[0].slot_position_in_quadrant == 5
    assert empty_q1[0].reason == "no_accepted_candidate"


def test_outlier_in_one_quadrant_does_not_corrupt_a_different_quadrants_assignment() -> None:
    """Integration-level companion to the direct ``_category_distance_scale``
    outlier test: a small far-away component pooled into the SAME category's
    global scale calibration must not perturb an unrelated quadrant's
    already-correct assignments.
    """
    volume = _full_arch()
    _block(volume, MID + 500 if MID + 500 < 70 else 60, 20, y=5)  # Q3 tooth range, unused otherwise
    result = assign_instances_to_fdi_slots(volume, AFFINE)
    q1_matches = [m for m in result.matched if m.category == "tooth" and m.quadrant_index == 0]
    assert len(q1_matches) == 8
    assert all(not m.changed for m in q1_matches)


def test_tooth_and_canal_groups_are_never_mixed() -> None:
    volume = np.zeros((70, 8, 6), dtype=np.uint8)
    _block(volume, _position_x(3), 3)  # tooth, position 3
    _block(volume, _position_x(3), 35, y=5)  # canal, same x, position 3's canal slot

    result = assign_instances_to_fdi_slots(volume, AFFINE)

    categories = {(m.category, m.original_label, m.new_label) for m in result.matched}
    assert categories == {("tooth", 3, 3), ("canal", 35, 35)}


def test_quadrants_are_never_mixed() -> None:
    """A component currently labeled into quadrant Q1's range must never be
    reassigned a Q2 (or any other quadrant's) class id -- the load-bearing
    scope boundary that keeps this module structurally incapable of
    smearing left/right identity."""
    volume = _full_arch()
    volume[volume == 4] = 0  # remove position 4 so Q1 has a free slot
    # even with a free slot in Q1, no Q2 component should ever migrate there
    result = assign_instances_to_fdi_slots(volume, AFFINE)
    for m in result.matched:
        low = 1 if m.category == "tooth" else 33
        quadrant_low = low + m.quadrant_index * 8
        quadrant_high = quadrant_low + 7
        assert quadrant_low <= m.original_label <= quadrant_high
        assert quadrant_low <= m.new_label <= quadrant_high


def test_too_small_component_is_left_untouched() -> None:
    volume = np.zeros((70, 8, 6), dtype=np.uint8)
    volume[_position_x(3), 1, 1] = 3  # single voxel, below MIN_COMPONENT_VOXELS=5

    result = assign_instances_to_fdi_slots(volume, AFFINE)

    assert result.matched == ()
    too_small = [d for d in result.dustbin if d.reason == "too_small"]
    assert len(too_small) == 1
    assert too_small[0].voxel_count == 1
    assert np.array_equal(result.output_volume, volume)


# ---------------------------------------------------------------------------
# Known limitation, found during this module's own development and
# documented rather than hidden: merging by SAME predicted label assumes
# co-labeled components are fragments of ONE true instance. When two
# genuinely different physical structures happen to share the same wrong
# label (a rarer coincidence than plain fragmentation, but a real one), the
# merge conflates them, and the resulting weighted-centroid candidate can
# end up mis-assigned. This test documents the CURRENT behaviour so a
# future change is a conscious decision, exactly the spirit of the
# Hungarian module's "single adjacent swap not corrected" calibration test.
# ---------------------------------------------------------------------------


def test_same_label_merge_can_conflate_two_unrelated_components() -> None:
    volume = _full_arch()
    # a duplicate/artifact sharing label 8 with the real tooth 8, but
    # physically sitting at position 1's location (a different y so it
    # doesn't voxel-overlap the real tooth 1 component)
    _block(volume, _position_x(1), 8, y=5)

    result = assign_instances_to_fdi_slots(volume, AFFINE)

    label8_matches = [m for m in result.matched if m.category == "tooth" and m.original_label == 8]
    assert len(label8_matches) == 1
    merged = label8_matches[0]
    assert len(merged.component_ids) == 2  # real tooth8 + the unrelated duplicate, merged as one
    # documented consequence: this can perturb a DIFFERENT slot's outcome
    # too (not asserted precisely here, since the exact resolution is a
    # joint-solve emergent property -- see module docstring's known-
    # limitations section for the mechanism).


# ---------------------------------------------------------------------------
# Validation errors.
# ---------------------------------------------------------------------------


def test_rejects_non_3d_volume() -> None:
    with pytest.raises(ValueError, match="3-dimensional"):
        assign_instances_to_fdi_slots(np.zeros((4, 4)), AFFINE)


def test_rejects_bad_affine_shape() -> None:
    with pytest.raises(ValueError, match="affine"):
        assign_instances_to_fdi_slots(np.zeros((4, 4, 4)), np.eye(3))


def test_rejects_non_positive_min_component_voxels() -> None:
    with pytest.raises(ValueError, match="min_component_voxels"):
        assign_instances_to_fdi_slots(np.zeros((4, 4, 4)), AFFINE, min_component_voxels=0)


def test_rejects_out_of_range_distance_scale_quantile() -> None:
    with pytest.raises(ValueError, match="distance_scale_quantile"):
        assign_instances_to_fdi_slots(np.zeros((4, 4, 4)), AFFINE, distance_scale_quantile=1.0)


def test_rejects_non_positive_dustbin_cost() -> None:
    with pytest.raises(ValueError, match="dustbin_cost"):
        assign_instances_to_fdi_slots(np.zeros((4, 4, 4)), AFFINE, dustbin_cost=0.0)


def test_empty_volume_returns_all_empty_slots_and_no_matches() -> None:
    result = assign_instances_to_fdi_slots(np.zeros((10, 10, 10), dtype=np.uint8), AFFINE)
    assert result.matched == ()
    assert result.dustbin == ()
    assert len(result.empty_slots) == 4 * 2 * 8  # 4 quadrants x 2 categories x 8 slots
    assert all(e.reason == "no_candidate_in_group" for e in result.empty_slots)
