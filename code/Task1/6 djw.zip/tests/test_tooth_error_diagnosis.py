"""Tests for the residual tooth-numbering error taxonomy.

Synthetic volumes with hand-placed cuboids, so each expected category is known
by construction. The point is to pin the taxonomy boundaries -- especially the
quadrant-scoped definition of "arch neighbour", which must not swallow an L/R
error at the midline.
"""
from __future__ import annotations

import numpy as np
import pytest

from stsr2026.evaluation.tooth_error_diagnosis import (
    ToothError,
    diagnose_case,
    is_arch_neighbor,
    summarize,
)


def _volume(assignments: dict[int, tuple]) -> np.ndarray:
    volume = np.zeros((40, 40, 40), dtype=np.uint8)
    for cls, sl in assignments.items():
        volume[sl] = cls
    return volume


BLOCK = np.s_[5:15, 5:15, 5:15]
BLOCK_B = np.s_[20:30, 20:30, 20:30]


def test_exact_match_is_correct():
    gt = _volume({3: BLOCK})
    diagnosis = diagnose_case(gt.copy(), gt)
    (finding,) = diagnosis.findings
    assert finding.error is ToothError.CORRECT
    assert finding.iou_same_class == pytest.approx(1.0)


def test_contralateral_mislabel_is_detected():
    # GT tooth 3 (Q1); model called it tooth 11 (Q2, same slot) -- the L/R error
    gt = _volume({3: BLOCK})
    pred = _volume({11: BLOCK})
    (finding,) = diagnose_case(pred, gt).findings
    assert finding.error is ToothError.MISLABEL_CONTRALATERAL
    assert finding.claimed_by == 11


def test_arch_neighbor_mislabel_is_detected():
    # off-by-one along the arch, within the same quadrant
    gt = _volume({3: BLOCK})
    pred = _volume({4: BLOCK})
    (finding,) = diagnose_case(pred, gt).findings
    assert finding.error is ToothError.MISLABEL_ARCH_NEIGHBOR


def test_classes_8_and_9_are_not_arch_neighbors():
    # numerically adjacent but in opposite quadrants (across the midline):
    # calling this an off-by-one slide would hide an L/R-style error
    assert not is_arch_neighbor(8, 9)
    assert not is_arch_neighbor(9, 8)
    assert not is_arch_neighbor(24, 25)
    assert is_arch_neighbor(3, 4)
    assert is_arch_neighbor(17, 18)


def test_distant_class_is_mislabel_other():
    gt = _volume({3: BLOCK})
    pred = _volume({20: BLOCK})
    (finding,) = diagnose_case(pred, gt).findings
    assert finding.error is ToothError.MISLABEL_OTHER


def test_nothing_predicted_there_is_missing():
    gt = _volume({3: BLOCK})
    pred = _volume({3: BLOCK_B})  # right class, completely wrong place
    (finding,) = diagnose_case(pred, gt).findings
    assert finding.error is ToothError.MISSING
    assert finding.claimed_by is None


def test_right_class_but_low_overlap_is_partial():
    gt = _volume({3: np.s_[5:15, 5:15, 5:15]})
    pred = _volume({3: np.s_[5:9, 5:15, 5:15]})  # 40% of the GT tooth
    (finding,) = diagnose_case(pred, gt).findings
    assert finding.error is ToothError.PARTIAL
    assert finding.iou_same_class < 0.5


def test_spurious_predicted_class_is_reported():
    gt = _volume({3: BLOCK})
    pred = _volume({3: BLOCK, 27: BLOCK_B})
    diagnosis = diagnose_case(pred, gt)
    assert diagnosis.spurious_classes == [27]


def test_split_prediction_is_reported():
    gt = _volume({3: np.s_[5:15, 5:15, 5:15]})
    pred = _volume({3: np.s_[5:15, 5:15, 5:15]})
    pred[30:35, 30:35, 30:35] = 3  # disconnected second component of the same class
    diagnosis = diagnose_case(pred, gt)
    assert diagnosis.split_classes == {3: 2}


def test_tiny_split_fragments_are_ignored():
    gt = _volume({3: np.s_[5:15, 5:15, 5:15]})
    pred = _volume({3: np.s_[5:15, 5:15, 5:15]})
    pred[30, 30, 30] = 3  # 1 voxel, below MIN_COMPONENT_VOXELS
    assert diagnose_case(pred, gt).split_classes == {}


def test_canal_classes_are_ignored_entirely():
    gt = _volume({3: BLOCK, 35: BLOCK_B})
    pred = _volume({3: BLOCK, 43: BLOCK_B})
    diagnosis = diagnose_case(pred, gt)
    assert [f.gt_class for f in diagnosis.findings] == [3]
    assert diagnosis.spurious_classes == []


def test_shape_mismatch_raises():
    with pytest.raises(ValueError, match="shape mismatch"):
        diagnose_case(np.zeros((4, 4, 4), np.uint8), np.zeros((5, 5, 5), np.uint8))


def test_summarize_aggregates_across_cases():
    gt = _volume({3: BLOCK})
    good = diagnose_case(gt.copy(), gt)
    bad = diagnose_case(_volume({11: BLOCK}), gt)
    total = summarize({"a": good, "b": bad})
    assert total[ToothError.CORRECT.value] == 1
    assert total[ToothError.MISLABEL_CONTRALATERAL.value] == 1
