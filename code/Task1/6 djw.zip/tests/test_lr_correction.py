from __future__ import annotations

import numpy as np

from stsr2026.inference.lr_correction import MIN_COMPONENT_VOXELS, correct_lr_confusion

AFFINE = np.eye(4)


def _add_block(
    volume: np.ndarray,
    x: int,
    label: int,
    *,
    y: int = 1,
    shape: tuple[int, int, int] = (2, 2, 2),
) -> None:
    volume[x : x + shape[0], y : y + shape[1], 1 : 1 + shape[2]] = label


def _balanced_volume() -> np.ndarray:
    volume = np.zeros((10, 6, 4), dtype=np.uint8)
    _add_block(volume, 1, 1)
    _add_block(volume, 7, 9)
    return volume


def test_correct_lr_confusion_keeps_correctly_labeled_components() -> None:
    volume = _balanced_volume()
    _add_block(volume, 2, 3)
    _add_block(volume, 6, 11)

    corrected = correct_lr_confusion(volume, AFFINE)

    assert np.array_equal(corrected, volume)
    assert corrected is not volume


def test_correct_lr_confusion_flips_upper_right_component_with_left_label() -> None:
    volume = _balanced_volume()
    _add_block(volume, 2, 11)

    corrected = correct_lr_confusion(volume, AFFINE)

    assert np.all(corrected[2:4, 1:3, 1:3] == 3)
    assert np.all(volume[2:4, 1:3, 1:3] == 11)


def _quadrant_reference_volume() -> np.ndarray:
    # FDI_ORDER rotates Q1(right)->Q2(left)->Q3(left)->Q4(right) around the arch, so
    # the lower-jaw pair's polarity is the reverse of the upper pair's -- use several
    # small same-side reference teeth per quadrant (like a real arch) rather than one
    # big block per side, so a single mislabeled component doesn't dominate the
    # case's own midline estimate and create a false tie.
    volume = np.zeros((40, 10, 4), dtype=np.uint8)
    for i, label in enumerate((25, 26, 27, 28, 29, 30, 31, 32)):  # Q4, right side
        _add_block(volume, i, label, y=0, shape=(1, 3, 2))
    for i, label in enumerate((17, 18, 19, 20, 21, 22, 23, 24)):  # Q3, left side
        _add_block(volume, 25 + i, label, y=0, shape=(1, 3, 2))
    return volume


def test_correct_lr_confusion_flips_lower_jaw_pair() -> None:
    volume = _quadrant_reference_volume()
    _add_block(volume, 3, 20, y=0, shape=(1, 3, 2))  # class 20 (Q3, "left") sitting on the right side

    corrected = correct_lr_confusion(volume, AFFINE)

    assert np.all(corrected[3:4, 0:3, 1:2] == 28)


def test_correct_lr_confusion_keeps_correctly_labeled_lower_jaw_component() -> None:
    volume = _quadrant_reference_volume()

    corrected = correct_lr_confusion(volume, AFFINE)

    assert np.array_equal(corrected, volume)


def test_correct_lr_confusion_leaves_canal_labels_untouched() -> None:
    # Canal correction is intentionally disabled -- canal centroids don't separate
    # left/right reliably (verified on real data, see the CANAL_SWAPPABLE_CLASS_PAIRS
    # comment in lr_correction.py), so even an apparently-mismatched canal component
    # must be left as-is rather than flipped.
    volume = _quadrant_reference_volume()
    _add_block(volume, 3, 41, y=0, shape=(1, 3, 2))  # class 41 (Q2 canal, "left") sitting on the right side
    _add_block(volume, 26, 57, y=0, shape=(1, 3, 2))  # class 57 (Q4 canal, "right") sitting on the left side

    corrected = correct_lr_confusion(volume, AFFINE)

    assert np.all(corrected[3:4, 0:3, 1:2] == 41)
    assert np.all(corrected[26:27, 0:3, 1:2] == 57)


def test_correct_lr_confusion_keeps_tiny_spurious_components() -> None:
    volume = _balanced_volume()
    volume[2:4, 1:3, 1] = 11
    assert np.count_nonzero(volume == 11) == MIN_COMPONENT_VOXELS - 1

    corrected = correct_lr_confusion(volume, AFFINE)

    assert np.all(corrected[2:4, 1:3, 1] == 11)


def test_correct_lr_confusion_handles_no_tooth_voxels_and_one_side() -> None:
    canals_only = np.zeros((10, 6, 4), dtype=np.uint8)
    _add_block(canals_only, 1, 43)
    assert np.array_equal(correct_lr_confusion(canals_only, AFFINE), canals_only)

    one_side = np.zeros((10, 6, 4), dtype=np.uint8)
    _add_block(one_side, 1, 3)
    assert np.array_equal(correct_lr_confusion(one_side, AFFINE), one_side)
