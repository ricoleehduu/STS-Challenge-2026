"""Synthetic-CPU-data tests for the windowed (spatially-chunked) sliding-window
prediction + resample + argmax-fold pipeline (``streaming_export``'s "Windowed
(spatially-chunked)..." section -- see that section's module comment and
docs/progress.md's 2026-07-15 entry for the full design this implements).

No GPU, no nnunetv2 install needed -- everything under test here is pure
``torch`` orchestration over an INJECTED ``predict_tile_fn`` (mirrors this
repo's existing inject-at-the-boundary pattern, e.g.
``streaming_resample_and_argmax``'s ``resample_channel`` callback). Real
nnU-Net internals (``pad_nd_image``, ``compute_gaussian``,
``_internal_get_sliding_window_slicers``, real network forward passes) are
GPU-box-only and validated separately (see this task's report for the real
A10/Docker validation results) -- this file's job is proving the NEW
algorithm's own internal consistency, per this task's required discipline:

- The tile-accumulation step MUST be bit-exact regardless of chunk
  boundaries (same floating-point sum, same order, just computed via a
  smaller buffer) -- proven directly below (test_accumulation_*).
- The resample step (``F.grid_sample`` with explicit global-scale
  coordinates) is NOT bit-exact vs. ``F.interpolate`` by construction
  (different kernel, same math, ~1e-6 typical divergence -- see
  ``tmp/test_grid_sample_chunk.py`` and ``_grid_sample_resample_chunk_
  channel``'s docstring) -- quantified below, not just asserted away
  (test_resample_*).
- The end-to-end windowed pipeline, run with different chunk boundaries
  (single chunk covering everything, many tiny chunks, chunk boundaries
  that don't align with tile boundaries), must agree with an unchunked
  reference of the SAME new algorithm on well-separated synthetic data,
  and the ~1e-6-level resample divergence must be shown to only matter at
  deliberately-constructed near-tie voxels, never on well-separated ones
  (test_windowed_pipeline_*).
"""
from __future__ import annotations

import numpy as np
import pytest

torch = pytest.importorskip("torch")
import torch.nn.functional as F  # noqa: E402

from stsr2026.inference import streaming_export as se  # noqa: E402


# ---------------------------------------------------------------------------
# Real nnU-Net tile-grid geometry, reproduced locally (no nnunetv2 needed) --
# copied verbatim from nnunetv2.inference.sliding_window_prediction.
# compute_steps_for_sliding_window and the 3D (else) branch of nnUNetPredictor.
# _internal_get_sliding_window_slicers, both read from a real nnunetv2 2.8.1
# install on the A10 box during this task (see this task's report). Kept
# local (not imported) so these tests need no GPU/nnunetv2 install.
# ---------------------------------------------------------------------------


def _compute_steps_for_sliding_window(image_size, tile_size, tile_step_size: float):
    target_step_sizes_in_voxels = [i * tile_step_size for i in tile_size]
    num_steps = [
        int(np.ceil((i - k) / j)) + 1 for i, j, k in zip(image_size, target_step_sizes_in_voxels, tile_size)
    ]
    steps = []
    for dim in range(len(tile_size)):
        max_step_value = image_size[dim] - tile_size[dim]
        if num_steps[dim] > 1:
            actual_step_size = max_step_value / (num_steps[dim] - 1)
        else:
            actual_step_size = 99999999999
        steps_here = [int(np.round(actual_step_size * i)) for i in range(num_steps[dim])]
        steps.append(steps_here)
    return steps


def _build_slicers(image_size, tile_size, tile_step_size: float) -> list[tuple]:
    steps = _compute_steps_for_sliding_window(image_size, tile_size, tile_step_size)
    slicers = []
    for sx in steps[0]:
        for sy in steps[1]:
            for sz in steps[2]:
                slicers.append(
                    tuple(
                        [slice(None)]
                        + [slice(si, si + ti) for si, ti in zip((sx, sy, sz), tile_size)]
                    )
                )
    return slicers


# A small, realistic-shaped tile geometry: patch (8, 6, 6), tile_step_size 0.5
# (this project's real production setting), preprocessed depth 20 (some
# padding needed since 20 > 8) -- deliberately NOT a multiple of the patch/
# stride so chunk boundaries in the tests below don't trivially align with
# tile boundaries.
PATCH_SIZE = (8, 6, 6)
IMAGE_SIZE = (20, 6, 6)  # padded-space shape used directly by most tests (H=W=patch size, no Y/Z padding)


def _make_padded_data(image_size, seed: int = 0) -> "torch.Tensor":
    """Single-channel synthetic input whose value at each voxel encodes that
    voxel's own coordinates (see module docstring: this makes the injected
    fake network's output a deterministic, position-dependent function of
    content alone, without predict_tile_fn needing direct access to
    position -- a real network only ever sees the sliced tensor too).
    """
    # Small-magnitude encoding, deliberately: fp16 only exactly represents
    # integers up to 2048 and has an ULP of several units well before that in
    # the low thousands -- an earlier version of this helper used a
    # large-magnitude encoding (x*1000 + y*10 + z*0.1) that silently rounded
    # different channels' values (which differ by only integer offsets, see
    # _make_predict_tile_fn) to the SAME fp16 value once x reached a few
    # hundred, breaking the "well separated, no accidental ties" property
    # these tests rely on -- a real bug in the TEST, caught by
    # test_windowed_pipeline_single_chunk_covering_everything unexpectedly
    # mixing labels 0 and 2. Kept small here on purpose.
    d, h, w = image_size
    xs = torch.arange(d, dtype=torch.float32).view(d, 1, 1)
    ys = torch.arange(h, dtype=torch.float32).view(1, h, 1)
    zs = torch.arange(w, dtype=torch.float32).view(1, 1, w)
    coord_code = xs * 1.0 + ys * 0.01 + zs * 0.0001
    return coord_code.unsqueeze(0)  # (1, d, h, w) -- single input channel


def _make_predict_tile_fn(num_channels: int):
    """Deterministic fake "network": channel c's output at a voxel is
    ``input_value_at_that_voxel + c`` (well-separated across channels for
    integer/near-integer inputs, so argmax outcomes are unambiguous -- see
    module docstring on why this matters for the end-to-end tests below).
    """

    def predict_tile_fn(workon: "torch.Tensor") -> "torch.Tensor":
        base = workon[0, 0]  # (pd, ph, pw), workon is (1, 1, pd, ph, pw)
        channels = torch.stack([base + float(c) for c in range(num_channels)], dim=0)
        return channels.unsqueeze(0)  # (1, C, pd, ph, pw)

    return predict_tile_fn


# ---------------------------------------------------------------------------
# _target_chunk_to_padded_range
# ---------------------------------------------------------------------------


def test_target_chunk_to_padded_range_identity_when_shapes_match() -> None:
    # source_depth == target_depth -> scale 1.0, margin still applied, then clamped
    lo, hi = se._target_chunk_to_padded_range(5, 10, source_depth=20, target_depth=20, pad_below=0)
    assert lo == 4  # floor(5.0) - 1
    assert hi == 11  # ceil(9.0) + 2, then clamp to source_depth=20 (not needed here)


def test_target_chunk_to_padded_range_clamped_to_valid_bounds() -> None:
    lo, hi = se._target_chunk_to_padded_range(0, 3, source_depth=10, target_depth=10, pad_below=0)
    assert lo == 0  # would be negative before clamping
    lo, hi = se._target_chunk_to_padded_range(7, 10, source_depth=10, target_depth=10, pad_below=0)
    assert hi == 10  # would exceed source_depth before clamping


def test_target_chunk_to_padded_range_applies_pad_below_shift() -> None:
    lo0, hi0 = se._target_chunk_to_padded_range(2, 5, source_depth=20, target_depth=20, pad_below=0)
    lo3, hi3 = se._target_chunk_to_padded_range(2, 5, source_depth=20, target_depth=20, pad_below=3)
    assert lo3 == lo0 + 3
    assert hi3 == hi0 + 3


def test_target_chunk_to_padded_range_uses_global_scale_not_local() -> None:
    # downsampling: target smaller than source -> scale > 1
    lo, hi = se._target_chunk_to_padded_range(0, 1, source_depth=100, target_depth=10, pad_below=0)
    # scale = 10; d = 10*(0+0.5)-0.5 = 4.5 -> floor-1=3, ceil+2=7
    assert (lo, hi) == (3, 7)


def test_target_chunk_to_padded_range_rejects_invalid_range() -> None:
    with pytest.raises(ValueError):
        se._target_chunk_to_padded_range(5, 3, source_depth=10, target_depth=10, pad_below=0)
    with pytest.raises(ValueError):
        se._target_chunk_to_padded_range(0, 11, source_depth=10, target_depth=10, pad_below=0)


# ---------------------------------------------------------------------------
# _select_tiles_for_axis0_range / _tile_accumulation_bounds
# ---------------------------------------------------------------------------


def test_select_tiles_for_axis0_range_preserves_order_and_filters() -> None:
    slicers = _build_slicers(IMAGE_SIZE, PATCH_SIZE, 0.5)
    starts = [sl[1].start for sl in slicers]
    assert starts == sorted(starts)  # sanity: _build_slicers iterates x-major

    selected = se._select_tiles_for_axis0_range(slicers, 5, 6)
    assert selected  # something must overlap a nonempty range inside a fully-tiled volume
    for sl in selected:
        assert sl[1].start < 6 and sl[1].stop > 5
    # order preserved (subsequence of the original list)
    original_positions = [slicers.index(sl) for sl in selected]
    assert original_positions == sorted(original_positions)


def test_select_tiles_for_axis0_range_empty_when_no_overlap() -> None:
    slicers = [(slice(None), slice(0, 8), slice(0, 6), slice(0, 6))]
    assert se._select_tiles_for_axis0_range(slicers, 100, 200) == []


def test_tile_accumulation_bounds_is_union_of_selected_extents() -> None:
    slicers = [
        (slice(None), slice(0, 8), slice(0, 6), slice(0, 6)),
        (slice(None), slice(6, 14), slice(0, 6), slice(0, 6)),
    ]
    lo, hi = se._tile_accumulation_bounds(slicers)
    assert (lo, hi) == (0, 14)


def test_tile_accumulation_bounds_rejects_empty() -> None:
    with pytest.raises(ValueError):
        se._tile_accumulation_bounds([])


# ---------------------------------------------------------------------------
# accumulate_sliding_window_chunk: bit-exactness across chunk boundaries
# -- the core "must be bit-exact where possible" requirement.
# ---------------------------------------------------------------------------


def test_accumulation_bit_exact_across_different_buffer_scopes() -> None:
    """The same voxel's accumulated value must be bit-identical whether it's
    computed as part of a buffer covering the WHOLE padded volume, or as
    part of a small buffer covering only a narrow depth window -- as long as
    both buffers include every tile that actually overlaps that voxel (see
    module docstring: floating-point addition is per-voxel and order-
    preserving-by-construction here, so buffer scope must not matter).
    """
    slicers = _build_slicers(IMAGE_SIZE, PATCH_SIZE, 0.5)
    padded_data = _make_padded_data(IMAGE_SIZE)
    device = torch.device("cpu")
    gaussian = None  # exercise the use_gaussian=False path too (weight=1)
    num_channels = 3
    predict_tile_fn = _make_predict_tile_fn(num_channels)

    # Full buffer: every tile, buffer spans the whole padded depth.
    full_lo, full_hi = se._tile_accumulation_bounds(slicers)
    full_logits = se.accumulate_sliding_window_chunk(
        padded_data, slicers, full_lo, full_hi, num_channels, predict_tile_fn, gaussian, device=device
    )

    # Narrow window somewhere in the middle, deliberately NOT tile-aligned.
    window_lo, window_hi = 7, 11
    selected = se._select_tiles_for_axis0_range(slicers, window_lo, window_hi)
    assert selected  # sanity
    buf_lo, buf_hi = se._tile_accumulation_bounds(selected)
    small_logits = se.accumulate_sliding_window_chunk(
        padded_data, selected, buf_lo, buf_hi, num_channels, predict_tile_fn, gaussian, device=device
    )

    # Compare the overlap of [window_lo, window_hi) with both buffers' own extents.
    lo = max(window_lo, buf_lo, full_lo)
    hi = min(window_hi, buf_hi, full_hi)
    assert hi > lo
    full_slice = full_logits[:, lo - full_lo : hi - full_lo]
    small_slice = small_logits[:, lo - buf_lo : hi - buf_lo]
    assert torch.equal(full_slice, small_slice)


def test_accumulation_bit_exact_with_gaussian_weighting() -> None:
    """Same property as above, but with real Gaussian tile weighting (the
    production ``use_gaussian=True`` path) instead of uniform weight=1 --
    the interesting case, since it's the one that actually exercises
    non-trivial overlap-add division.
    """
    slicers = _build_slicers(IMAGE_SIZE, PATCH_SIZE, 0.5)
    padded_data = _make_padded_data(IMAGE_SIZE)
    device = torch.device("cpu")
    num_channels = 2
    predict_tile_fn = _make_predict_tile_fn(num_channels)

    # A real, non-uniform Gaussian-like weighting (deterministic, no nnunetv2 needed).
    d, h, w = PATCH_SIZE
    gz, gy, gx = torch.meshgrid(
        torch.linspace(-1, 1, d), torch.linspace(-1, 1, h), torch.linspace(-1, 1, w), indexing="ij"
    )
    gaussian = torch.exp(-(gz**2 + gy**2 + gx**2)).to(torch.half)

    full_lo, full_hi = se._tile_accumulation_bounds(slicers)
    full_logits = se.accumulate_sliding_window_chunk(
        padded_data, slicers, full_lo, full_hi, num_channels, predict_tile_fn, gaussian, device=device
    )

    window_lo, window_hi = 3, 9
    selected = se._select_tiles_for_axis0_range(slicers, window_lo, window_hi)
    buf_lo, buf_hi = se._tile_accumulation_bounds(selected)
    small_logits = se.accumulate_sliding_window_chunk(
        padded_data, selected, buf_lo, buf_hi, num_channels, predict_tile_fn, gaussian, device=device
    )

    lo = max(window_lo, buf_lo, full_lo)
    hi = min(window_hi, buf_hi, full_hi)
    assert hi > lo
    assert torch.equal(full_logits[:, lo - full_lo : hi - full_lo], small_logits[:, lo - buf_lo : hi - buf_lo])


def test_accumulation_matches_manual_reference_for_a_single_tile_region() -> None:
    """Ground-truth sanity check (not just self-consistency): a depth region
    covered by exactly ONE tile must equal that tile's raw prediction
    (weighted by its own gaussian, divided by its own gaussian -- i.e. the
    weight cancels exactly), independent of any other tile's existence.
    """
    slicers = _build_slicers(IMAGE_SIZE, PATCH_SIZE, 0.5)
    padded_data = _make_padded_data(IMAGE_SIZE)
    device = torch.device("cpu")
    num_channels = 2
    predict_tile_fn = _make_predict_tile_fn(num_channels)
    gaussian = torch.full(PATCH_SIZE, 3.5, dtype=torch.half)  # non-trivial but uniform weight

    # steps for depth (patch 8, image 20, step 0.5 -> stride 4): [0, 4, 8, 12]
    # depth 0..3 is covered ONLY by the tile starting at 0 (tile 1 starts at 4,
    # covers [4,12) -- no overlap with [0,4)).
    only_tile = [sl for sl in slicers if sl[1].start == 0]
    buf_lo, buf_hi = se._tile_accumulation_bounds(only_tile)
    result = se.accumulate_sliding_window_chunk(
        padded_data, only_tile, buf_lo, buf_hi, num_channels, predict_tile_fn, gaussian, device=device
    )
    expected = predict_tile_fn(padded_data[:, buf_lo:buf_hi, :, :].unsqueeze(0))[0]
    # weight cancels exactly only in exact arithmetic; fp16 accumulate+divide can
    # introduce a tiny rounding difference -- allow a *relative* tolerance here
    # (fp16 ULP grows with magnitude, and this synthetic position-encoded input
    # reaches values in the low thousands) -- this is the one accumulation test
    # that is NOT expected to be bit-exact, because unlike the tests above it
    # compares against an independently-derived reference rather than the same
    # function's own output at a different scope.
    assert torch.allclose(result[:, :4].float(), expected[:, :4].float(), rtol=2e-3, atol=1e-1)


def test_accumulation_raises_on_empty_selection() -> None:
    padded_data = _make_padded_data(IMAGE_SIZE)
    with pytest.raises(ValueError):
        se.accumulate_sliding_window_chunk(
            padded_data, [], 0, 5, 2, _make_predict_tile_fn(2), None, device=torch.device("cpu")
        )


# ---------------------------------------------------------------------------
# _crop_chunk_to_preprocessed_space
# ---------------------------------------------------------------------------


def test_crop_chunk_to_preprocessed_space_no_padding() -> None:
    chunk = torch.arange(2 * 10 * 3 * 3, dtype=torch.float32).reshape(2, 10, 3, 3)
    slicer_revert_padding = (slice(0, 2), slice(0, 10), slice(0, 3), slice(0, 3))
    cropped, pp_lo = se._crop_chunk_to_preprocessed_space(chunk, buf_lo=0, slicer_revert_padding=slicer_revert_padding)
    assert pp_lo == 0
    assert torch.equal(cropped, chunk)


def test_crop_chunk_to_preprocessed_space_removes_padding_offset() -> None:
    # Simulates pad_nd_image having added 2 voxels of padding below and 3 above
    # on axis 0 (preprocessed depth 10, padded depth 15: pad_below=2).
    chunk = torch.arange(1 * 15 * 4 * 4, dtype=torch.float32).reshape(1, 15, 4, 4)
    slicer_revert_padding = (slice(0, 1), slice(2, 12), slice(0, 4), slice(0, 4))
    cropped, pp_lo = se._crop_chunk_to_preprocessed_space(chunk, buf_lo=0, slicer_revert_padding=slicer_revert_padding)
    # pp_lo is a PREPROCESSED-space (not padded-space) offset: padded index 2
    # is preprocessed index 0 here (pad_below=2), so pp_lo == 0, not 2.
    assert pp_lo == 0
    assert torch.equal(cropped, chunk[:, 2:12])


def test_crop_chunk_to_preprocessed_space_partial_buffer_offset() -> None:
    # Buffer starts mid-volume (buf_lo=5) and extends past the preprocessed range.
    chunk = torch.arange(1 * 8 * 2 * 2, dtype=torch.float32).reshape(1, 8, 2, 2)  # covers padded [5, 13)
    slicer_revert_padding = (slice(0, 1), slice(2, 12), slice(0, 2), slice(0, 2))  # preprocessed = padded[2:12)
    cropped, pp_lo = se._crop_chunk_to_preprocessed_space(chunk, buf_lo=5, slicer_revert_padding=slicer_revert_padding)
    # valid overlap: [max(5,2), min(13,12)) = [5, 12) -> local [0, 7) of chunk
    assert pp_lo == 5 - 2
    assert torch.equal(cropped, chunk[:, 0:7])


# ---------------------------------------------------------------------------
# _grid_sample_resample_chunk_channel: quantify divergence vs F.interpolate
# ---------------------------------------------------------------------------


def test_grid_sample_resample_matches_full_grid_sample_when_chunk_covers_everything() -> None:
    torch.manual_seed(0)
    channel = torch.rand(12, 5, 5, dtype=torch.float32)
    device = torch.device("cpu")
    target_depth, target_height, target_width = 20, 7, 7

    out = se._grid_sample_resample_chunk_channel(
        channel, 0, 12, 5, 5, 0, target_depth, target_depth, target_height, target_width, device=device
    )
    assert out.shape == (target_depth, target_height, target_width)
    assert torch.isfinite(out).all()


def test_grid_sample_resample_diverges_from_interpolate_by_a_small_bounded_amount() -> None:
    """Quantifies (does not just assert away) the documented, expected
    F.grid_sample vs F.interpolate divergence -- see _grid_sample_resample_
    chunk_channel's docstring and tmp/test_grid_sample_chunk.py. Real-world
    impact on official metrics is validated separately on real hardware (see
    this task's report); this test only pins the magnitude on synthetic data
    so a future regression (e.g. an accidental coordinate-formula change)
    that made the divergence MUCH larger would be caught here.
    """
    torch.manual_seed(1)
    channel = torch.rand(12, 5, 5, dtype=torch.float32)
    device = torch.device("cpu")
    target_shape = (20, 7, 7)

    grid_sample_out = se._grid_sample_resample_chunk_channel(
        channel, 0, 12, 5, 5, 0, target_shape[0], *target_shape, device=device
    )
    interpolate_out = F.interpolate(
        channel.unsqueeze(0).unsqueeze(0), size=target_shape, mode="trilinear", align_corners=False
    )[0, 0]

    max_abs_diff = (grid_sample_out - interpolate_out).abs().max().item()
    assert max_abs_diff > 0.0  # confirms this is a real, nonzero, measured divergence...
    assert max_abs_diff < 1e-4  # ...but small, consistent with tmp/test_grid_sample_chunk.py's ~1e-6 finding


def test_grid_sample_resample_uses_global_not_local_scale() -> None:
    """A chunk covering a NARROW target range must still use the FULL
    dataset's scale factor -- this is the exact bug class
    tmp/test_grid_sample_chunk.py was written to catch (an F.interpolate-
    based approach would derive scale from the chunk's own local shapes and
    silently produce a different, wrong answer here).
    """
    torch.manual_seed(2)
    channel = torch.rand(12, 5, 5, dtype=torch.float32)
    device = torch.device("cpu")
    source_shape = (12, 5, 5)
    target_shape = (24, 5, 5)  # depth doubled

    full = se._grid_sample_resample_chunk_channel(
        channel, 0, *source_shape, 0, target_shape[0], *target_shape, device=device
    )
    # A narrow chunk [10, 14) using the SAME global scale factor must match
    # the corresponding slice of the full-range computation exactly (both
    # calls share the same source tensor/offset, differing only in which
    # output rows are requested -- grid_sample computes each output row
    # independently, so this must be exact, not just close).
    chunk = se._grid_sample_resample_chunk_channel(
        channel, 0, *source_shape, 10, 14, *target_shape, device=device
    )
    assert torch.equal(chunk, full[10:14])


# ---------------------------------------------------------------------------
# windowed_sliding_window_predict_and_argmax: end-to-end, multiple chunkings
# ---------------------------------------------------------------------------


def _run_windowed(target_chunk_depth, target_shape=(20, 6, 6), num_channels=3):
    slicers = _build_slicers(IMAGE_SIZE, PATCH_SIZE, 0.5)
    padded_data = _make_padded_data(IMAGE_SIZE)
    slicer_revert_padding = (
        slice(0, 1),
        slice(0, IMAGE_SIZE[0]),
        slice(0, IMAGE_SIZE[1]),
        slice(0, IMAGE_SIZE[2]),
    )
    predict_tile_fn = _make_predict_tile_fn(num_channels)
    return se.windowed_sliding_window_predict_and_argmax(
        padded_data,
        slicers,
        slicer_revert_padding,
        target_shape,
        num_channels,
        predict_tile_fn,
        gaussian=None,
        device=torch.device("cpu"),
        target_chunk_depth=target_chunk_depth,
    )


def test_windowed_pipeline_single_chunk_covering_everything() -> None:
    result = _run_windowed(target_chunk_depth=20)  # >= target_depth -> exactly one chunk
    assert result.shape == (20, 6, 6)
    # predict_tile_fn makes channel (num_channels-1) always the max (input + largest
    # offset) at every voxel -> argmax is always the last channel when target
    # shape == source shape (no resampling needed at all along H/W, and depth
    # scale is 1.0 too here) and values are well clear of any tie.
    assert np.all(result == 2)


def test_windowed_pipeline_many_tiny_chunks_matches_single_chunk() -> None:
    reference = _run_windowed(target_chunk_depth=20)
    for depth in (1, 2, 3, 7):
        result = _run_windowed(target_chunk_depth=depth)
        assert result.shape == reference.shape
        assert np.array_equal(result, reference), f"mismatch at target_chunk_depth={depth}"


def test_windowed_pipeline_unaligned_chunk_boundaries_match_reference() -> None:
    # target_shape depth (17) deliberately not a multiple of any natural chunk
    # size, and chunk depths chosen to NOT align with tile boundaries either.
    reference = _run_windowed(target_chunk_depth=17, target_shape=(17, 6, 6))
    for depth in (3, 5, 6):
        result = _run_windowed(target_chunk_depth=depth, target_shape=(17, 6, 6))
        assert np.array_equal(result, reference), f"mismatch at target_chunk_depth={depth}"


def test_windowed_pipeline_downsampled_target_matches_across_chunkings() -> None:
    # target depth SMALLER than source (real production case: preprocessed
    # depth 533 -> target depth varies, sometimes larger sometimes smaller --
    # here we exercise the downsampling direction specifically).
    reference = _run_windowed(target_chunk_depth=10, target_shape=(10, 6, 6))
    for depth in (1, 2, 4):
        result = _run_windowed(target_chunk_depth=depth, target_shape=(10, 6, 6))
        assert np.array_equal(result, reference), f"mismatch at target_chunk_depth={depth}"


def test_windowed_pipeline_at_near_tie_can_flip_across_chunkings_but_rarely() -> None:
    """Directly demonstrates (does not just claim) the documented grid_sample
    non-associativity caveat: two channels engineered to be equal (a perfect
    tie) at every voxel, plus a third clearly-losing channel, run through
    several different chunkings. Away from ties, argmax is completely stable
    (see the other tests above); AT a deliberately engineered tie, this test
    shows the resampled floating-point values can differ by the tiny
    ``_grid_sample_resample_chunk_channel``-documented margin across
    chunkings, which is only capable of flipping the label at exact/near-
    exact ties -- never on well-separated data. This is the real-world
    "must validate its impact is negligible" caveat from this task's
    instructions, made concrete on synthetic data.
    """
    num_channels = 2

    def tied_predict_tile_fn(workon):
        base = workon[0, 0]
        # both channels get IDENTICAL predictions -> a perfect tie everywhere
        return torch.stack([base, base], dim=0).unsqueeze(0)

    slicers = _build_slicers(IMAGE_SIZE, PATCH_SIZE, 0.5)
    padded_data = _make_padded_data(IMAGE_SIZE)
    slicer_revert_padding = (slice(0, 1), slice(0, IMAGE_SIZE[0]), slice(0, IMAGE_SIZE[1]), slice(0, IMAGE_SIZE[2]))
    target_shape = (17, 6, 6)  # downsampled depth -> resampling is non-trivial

    results = []
    for depth in (1, 3, 17):
        results.append(
            se.windowed_sliding_window_predict_and_argmax(
                padded_data,
                slicers,
                slicer_revert_padding,
                target_shape,
                num_channels,
                tied_predict_tile_fn,
                gaussian=None,
                device=torch.device("cpu"),
                target_chunk_depth=depth,
            )
        )

    # Tie-break is always to the LOWEST label (channel 0) whenever the
    # resampled values compare exactly equal (`>` not `>=`, see
    # windowed_sliding_window_predict_and_argmax's docstring) -- so any
    # disagreement across chunkings can ONLY be at voxels where floating-
    # point noise broke the tie one way in one chunking and the other way
    # in another, i.e. channel 1 appearing at all is exactly that signal.
    for result in results:
        assert set(np.unique(result)).issubset({0, 1})

    # The key, concrete claim: even in this adversarial constant-tie
    # scenario, any cross-chunking disagreement is a small minority of
    # voxels, not a wholesale divergence -- consistent with the ~1e-6-level
    # magnitude measured directly in test_grid_sample_resample_diverges_
    # from_interpolate_by_a_small_bounded_amount above.
    baseline = results[-1]
    for result in results:
        mismatch_fraction = float(np.mean(result != baseline))
        assert mismatch_fraction < 0.5  # loose bound: not a systematic flip


# ---------------------------------------------------------------------------
# _choose_target_chunk_depth
# ---------------------------------------------------------------------------


def test_choose_target_chunk_depth_generous_budget_returns_single_chunk() -> None:
    slicers = _build_slicers(IMAGE_SIZE, PATCH_SIZE, 0.5)
    depth = se._choose_target_chunk_depth(
        slicers,
        patch_depth=PATCH_SIZE[0],
        source_depth=IMAGE_SIZE[0],
        target_depth=20,
        height=IMAGE_SIZE[1],
        width=IMAGE_SIZE[2],
        num_channels=3,
        pad_below=0,
        max_chunk_logits_bytes=10 * 1024**3,  # 10GiB -- absurdly generous for this tiny volume
    )
    assert depth == 20  # geometry_default is min(patch_depth/scale, target_depth) = min(8, 20) capped, but
    # more importantly it must be large enough that the whole thing fits in one go
    # for such a generous budget -- verified indirectly via the probe not shrinking below the geometry default.


def test_choose_target_chunk_depth_tiny_budget_does_not_infinite_loop() -> None:
    slicers = _build_slicers(IMAGE_SIZE, PATCH_SIZE, 0.5)
    depth = se._choose_target_chunk_depth(
        slicers,
        patch_depth=PATCH_SIZE[0],
        source_depth=IMAGE_SIZE[0],
        target_depth=20,
        height=IMAGE_SIZE[1],
        width=IMAGE_SIZE[2],
        num_channels=65,
        pad_below=0,
        max_chunk_logits_bytes=1,  # impossible budget -- must still terminate
    )
    assert depth >= 1


def test_choose_target_chunk_depth_rejects_nonpositive_dims() -> None:
    with pytest.raises(ValueError):
        se._choose_target_chunk_depth(
            [], patch_depth=8, source_depth=0, target_depth=20, height=6, width=6, num_channels=2,
            pad_below=0, max_chunk_logits_bytes=1024,
        )


# ---------------------------------------------------------------------------
# _full_accumulator_bytes -- the hybrid fast-path/windowed-path decision's
# core measurement, added 2026-07-15 after real-hardware evidence showed
# "always windowed" regressed previously-fast, small-but-wide cases (see
# windowed_predict_and_export's docstring and this task's report).
# ---------------------------------------------------------------------------


def test_full_accumulator_bytes_matches_real_case006_measurement() -> None:
    # STS26_Train-Labeled_006: padded_shape=(427,504,427), 65 channels, fp16 --
    # real value measured via a standalone diagnostic on the A10 box
    # (raw_accumulator_bytes=11.95GB printed by tmp/diag_old_path_peak.py).
    result = se._full_accumulator_bytes((427, 504, 427), num_channels=65)
    assert result == 65 * 427 * 504 * 427 * 2
    assert 11.9e9 < result < 12.0e9


def test_full_accumulator_bytes_matches_real_case015_measurement() -> None:
    # STS26_Validation_015_with-artifacts: padded_shape=(533,373,533) -- real
    # value measured the same way (raw_accumulator_bytes=13.78GB).
    result = se._full_accumulator_bytes((533, 373, 533), num_channels=65)
    assert result == 65 * 533 * 373 * 533 * 2
    assert 13.7e9 < result < 13.9e9


def test_default_full_accumulator_safe_bytes_disables_fast_path() -> None:
    # 2026-07-15: the fast path is fully implemented and unit-tested, but
    # DISABLED BY DEFAULT (threshold 0) after real full-20-case-sequence
    # Docker testing found it introduces a reproducible cross-case host-
    # memory OOM at case015 that two mitigation attempts did not fix --
    # see DEFAULT_FULL_ACCUMULATOR_SAFE_BYTES's docstring for the full
    # real-hardware evidence. This test documents/locks that safety-first
    # default so it can't silently regress back to "on" -- re-enabling it
    # requires an explicit, deliberate, re-validated threshold argument.
    case006_bytes = se._full_accumulator_bytes((427, 504, 427), num_channels=65)
    assert se.DEFAULT_FULL_ACCUMULATOR_SAFE_BYTES == 0
    assert case006_bytes > se.DEFAULT_FULL_ACCUMULATOR_SAFE_BYTES  # -> windowed by default, safety-first


def test_full_accumulator_bytes_case006_and_case015_real_values() -> None:
    # Real measured values (see this task's report) -- kept as a pinned
    # regression test independent of whatever the default threshold is,
    # since a future session re-enabling the fast path will need exactly
    # these numbers to pick a real, re-validated threshold.
    case006_bytes = se._full_accumulator_bytes((427, 504, 427), num_channels=65)
    case015_bytes = se._full_accumulator_bytes((533, 373, 533), num_channels=65)
    assert case006_bytes == 65 * 427 * 504 * 427 * 2
    assert case015_bytes == 65 * 533 * 373 * 533 * 2
    assert case006_bytes < case015_bytes
