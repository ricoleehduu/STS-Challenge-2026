"""Unit tests for stsr2026.training.coord_weight_surgery -- pure torch, no
nnunetv2/GPU required. Uses a small synthetic state dict shaped like a real
nnU-Net PlainConvUNet checkpoint's stem-conv alias group (see that module's
docstring for why real checkpoints have 2-4 aliased key names for the same
underlying stem-conv parameter), not an actual nnU-Net network.
"""
from __future__ import annotations

import pytest
import torch

from stsr2026.training import coord_weight_surgery as surgery


def _make_stem_aliased_state_dict(out_channels: int = 4, in_channels: int = 1, kernel: int = 3) -> dict:
    """A minimal synthetic checkpoint mimicking the real alias pattern
    (encoder.stages.0.0.convs.0.{conv,all_modules.0}.weight and the same
    under a decoder.encoder.* prefix) plus one deeper, non-stem conv layer
    that must NOT be touched by surgery (its in_channels equals a feature
    width, not the input-image channel count).
    """
    stem_weight = torch.randn(out_channels, in_channels, kernel, kernel, kernel)
    stem_bias = torch.randn(out_channels)
    deeper_weight = torch.randn(out_channels, out_channels, kernel, kernel, kernel)
    return {
        "encoder.stages.0.0.convs.0.conv.weight": stem_weight,
        "encoder.stages.0.0.convs.0.all_modules.0.weight": stem_weight,
        "decoder.encoder.stages.0.0.convs.0.conv.weight": stem_weight,
        "decoder.encoder.stages.0.0.convs.0.all_modules.0.weight": stem_weight,
        "encoder.stages.0.0.convs.0.conv.bias": stem_bias,
        "encoder.stages.0.0.convs.1.conv.weight": deeper_weight,
        "encoder.stages.0.0.convs.1.conv.bias": torch.randn(out_channels),
    }


def test_finds_all_four_aliased_stem_keys():
    sd = _make_stem_aliased_state_dict()
    keys = surgery._find_stem_weight_keys(sd, old_in_channels=1)
    assert set(keys) == {
        "encoder.stages.0.0.convs.0.conv.weight",
        "encoder.stages.0.0.convs.0.all_modules.0.weight",
        "decoder.encoder.stages.0.0.convs.0.conv.weight",
        "decoder.encoder.stages.0.0.convs.0.all_modules.0.weight",
    }


def test_deeper_conv_layer_is_not_touched():
    sd = _make_stem_aliased_state_dict()
    new_sd, _report = surgery.surgically_expand_input_channels(sd, new_in_channels=2)
    assert torch.equal(new_sd["encoder.stages.0.0.convs.1.conv.weight"], sd["encoder.stages.0.0.convs.1.conv.weight"])
    assert torch.equal(new_sd["encoder.stages.0.0.convs.0.conv.bias"], sd["encoder.stages.0.0.convs.0.conv.bias"])


def test_zeros_init_channel0_equals_original_channel1_is_zero():
    sd = _make_stem_aliased_state_dict(out_channels=6, in_channels=1, kernel=3)
    new_sd, report = surgery.surgically_expand_input_channels(sd, new_in_channels=2, new_channel_init="zeros")
    for key in report.stem_keys:
        new_w = new_sd[key]
        assert new_w.shape == (6, 2, 3, 3, 3)
        assert torch.equal(new_w[:, 0], sd[key][:, 0])
        assert torch.all(new_w[:, 1] == 0.0)


def test_zeros_init_all_alias_keys_stay_identical_after_surgery():
    sd = _make_stem_aliased_state_dict()
    new_sd, report = surgery.surgically_expand_input_channels(sd, new_in_channels=2)
    values = [new_sd[key] for key in report.stem_keys]
    for other in values[1:]:
        assert torch.equal(values[0], other)


def test_small_random_init_is_nonzero_but_tiny_relative_to_original_std():
    sd = _make_stem_aliased_state_dict(out_channels=8, in_channels=1, kernel=3)
    new_sd, report = surgery.surgically_expand_input_channels(
        sd, new_in_channels=2, new_channel_init="small_random", seed=42
    )
    key = report.stem_keys[0]
    new_channel = new_sd[key][:, 1]
    assert not torch.all(new_channel == 0.0)
    original_std = float(sd[key].std())
    assert float(new_channel.std()) < original_std * 0.05  # "very small", not comparable magnitude


def test_small_random_init_is_reproducible_given_seed():
    sd = _make_stem_aliased_state_dict()
    new_sd_a, _ = surgery.surgically_expand_input_channels(sd, new_in_channels=2, new_channel_init="small_random", seed=7)
    new_sd_b, _ = surgery.surgically_expand_input_channels(sd, new_in_channels=2, new_channel_init="small_random", seed=7)
    key = "encoder.stages.0.0.convs.0.conv.weight"
    assert torch.equal(new_sd_a[key], new_sd_b[key])


def test_report_contents():
    sd = _make_stem_aliased_state_dict(out_channels=6, in_channels=1, kernel=3)
    _new_sd, report = surgery.surgically_expand_input_channels(sd, new_in_channels=2)
    assert report.old_in_channels == 1
    assert report.new_in_channels == 2
    assert report.out_channels == 6
    assert report.kernel_shape == (3, 3, 3)
    assert len(report.stem_keys) == 4


def test_does_not_mutate_input_dict():
    sd = _make_stem_aliased_state_dict()
    original = {k: v.clone() for k, v in sd.items()}
    surgery.surgically_expand_input_channels(sd, new_in_channels=2)
    for key, value in original.items():
        assert torch.equal(sd[key], value)


def test_three_channel_expansion():
    sd = _make_stem_aliased_state_dict(out_channels=4, in_channels=1, kernel=3)
    new_sd, report = surgery.surgically_expand_input_channels(sd, new_in_channels=4)
    assert report.new_in_channels == 4
    for key in report.stem_keys:
        assert new_sd[key].shape == (4, 4, 3, 3, 3)
        assert torch.all(new_sd[key][:, 1:] == 0.0)


def test_rejects_new_in_channels_not_greater_than_old():
    sd = _make_stem_aliased_state_dict()
    with pytest.raises(ValueError, match="must be >"):
        surgery.surgically_expand_input_channels(sd, new_in_channels=1)


def test_rejects_invalid_init_mode():
    sd = _make_stem_aliased_state_dict()
    with pytest.raises(ValueError, match="new_channel_init"):
        surgery.surgically_expand_input_channels(sd, new_in_channels=2, new_channel_init="bogus")


def test_rejects_no_matching_stem_keys():
    sd = {"foo.weight": torch.randn(4, 8, 3, 3, 3)}
    with pytest.raises(ValueError, match="no 5D conv weight"):
        surgery.surgically_expand_input_channels(sd, new_in_channels=2, old_in_channels=1)


def test_strict_raises_on_desynchronized_aliases():
    sd = _make_stem_aliased_state_dict()
    # Corrupt one of the supposed aliases so it no longer matches -- strict
    # mode must catch this rather than silently producing an inconsistent
    # checkpoint.
    sd["decoder.encoder.stages.0.0.convs.0.conv.weight"] = torch.randn_like(
        sd["decoder.encoder.stages.0.0.convs.0.conv.weight"]
    )
    with pytest.raises(ValueError, match="do not have identical values"):
        surgery.surgically_expand_input_channels(sd, new_in_channels=2, strict=True)


def test_non_strict_allows_desynchronized_aliases():
    sd = _make_stem_aliased_state_dict()
    sd["decoder.encoder.stages.0.0.convs.0.conv.weight"] = torch.randn_like(
        sd["decoder.encoder.stages.0.0.convs.0.conv.weight"]
    )
    # Should not raise.
    new_sd, report = surgery.surgically_expand_input_channels(sd, new_in_channels=2, strict=False)
    assert len(report.stem_keys) == 4
