from __future__ import annotations

import numpy as np

from stsr2026.inference.false_positive_cleanup import clean_false_positive_labels


def _volume(shape: tuple[int, int, int] = (10, 10, 10)) -> np.ndarray:
    return np.zeros(shape, dtype=np.int64)


def _fill(volume: np.ndarray, x: slice, y: slice, z: slice, label: int) -> None:
    volume[x, y, z] = label


def test_only_cleans_labels_absent_from_gt() -> None:
    volume = _volume()
    _fill(volume, slice(0, 1), slice(0, 1), slice(0, 1), 5)  # 1 voxel, label 5, IS in GT
    _fill(volume, slice(5, 6), slice(5, 6), slice(5, 6), 9)  # 1 voxel, label 9, NOT in GT

    cleaned, records = clean_false_positive_labels(volume, gt_labels={5}, volume_threshold=100)

    # label 5 untouched even though it's tiny -- it's a real GT label.
    assert cleaned[0, 0, 0] == 5
    # label 9 removed -- absent from GT and below threshold.
    assert cleaned[5, 5, 5] == 0
    assert len(records) == 1
    assert records[0].label == 9
    assert records[0].removed is True


def test_does_not_touch_real_small_structures() -> None:
    """A small but legitimate structure (label present in GT) must survive,
    even if its volume is far below any plausible cleanup threshold."""
    volume = _volume()
    _fill(volume, slice(3, 4), slice(3, 4), slice(3, 4), 40)  # 1-voxel canal tip, real GT label

    cleaned, records = clean_false_positive_labels(volume, gt_labels={40}, volume_threshold=10_000)

    assert np.array_equal(cleaned, volume)
    assert records == ()


def test_large_gt_absent_component_is_reported_but_not_removed() -> None:
    volume = _volume((20, 20, 20))
    _fill(volume, slice(0, 10), slice(0, 10), slice(0, 10), 60)  # 1000 voxels, NOT in GT

    cleaned, records = clean_false_positive_labels(volume, gt_labels=set(), volume_threshold=100)

    # Large component (1000 >= threshold 100) is left in place for human review.
    assert np.array_equal(cleaned, volume)
    assert len(records) == 1
    assert records[0].voxel_count == 1000
    assert records[0].removed is False


def test_threshold_boundary_is_exclusive_above() -> None:
    volume = _volume()
    _fill(volume, slice(0, 1), slice(0, 5), slice(0, 2), 7)  # exactly 10 voxels, NOT in GT

    at_threshold_kept = clean_false_positive_labels(volume, gt_labels=set(), volume_threshold=10)
    below_threshold_removed = clean_false_positive_labels(volume, gt_labels=set(), volume_threshold=11)

    cleaned_kept, records_kept = at_threshold_kept
    cleaned_removed, records_removed = below_threshold_removed

    assert records_kept[0].voxel_count == 10
    assert records_kept[0].removed is False
    assert np.array_equal(cleaned_kept, volume)

    assert records_removed[0].voxel_count == 10
    assert records_removed[0].removed is True
    assert np.count_nonzero(cleaned_removed == 7) == 0


def test_multiple_components_same_gt_absent_label_mixed_sizes() -> None:
    volume = _volume((20, 20, 20))
    _fill(volume, slice(0, 1), slice(0, 1), slice(0, 1), 12)  # 1 voxel, small, NOT in GT
    _fill(volume, slice(10, 15), slice(10, 15), slice(10, 15), 12)  # 125 voxels, large, same label

    cleaned, records = clean_false_positive_labels(volume, gt_labels=set(), volume_threshold=50)

    assert len(records) == 2
    sizes_removed = {r.voxel_count: r.removed for r in records}
    assert sizes_removed[1] is True
    assert sizes_removed[125] is False
    # small component cleared
    assert cleaned[0, 0, 0] == 0
    # large component preserved
    assert np.all(cleaned[10:15, 10:15, 10:15] == 12)


def test_canal_and_tooth_gt_absent_labels_both_handled_independently() -> None:
    volume = _volume((20, 20, 20))
    _fill(volume, slice(0, 1), slice(0, 1), slice(0, 1), 3)  # tooth, small, NOT in GT
    _fill(volume, slice(5, 6), slice(5, 6), slice(5, 6), 40)  # canal, small, NOT in GT
    _fill(volume, slice(10, 11), slice(10, 11), slice(10, 11), 3)  # tooth, present in GT

    cleaned, records = clean_false_positive_labels(volume, gt_labels={3}, volume_threshold=100)

    # class 3 appears in GT -> every component of class 3 is left alone, even the
    # spatially-separate small one that looks like noise.
    assert cleaned[0, 0, 0] == 3
    assert cleaned[10, 10, 10] == 3
    # class 40 (canal) not in GT, below threshold -> removed.
    assert cleaned[5, 5, 5] == 0
    assert len(records) == 1
    assert records[0].label == 40


def test_returns_new_array_even_when_nothing_removed() -> None:
    volume = _volume()
    _fill(volume, slice(0, 1), slice(0, 1), slice(0, 1), 8)

    cleaned, records = clean_false_positive_labels(volume, gt_labels={8}, volume_threshold=5)

    assert cleaned is not volume
    assert np.array_equal(cleaned, volume)
    assert records == ()


def test_empty_volume_no_gt_labels() -> None:
    volume = _volume()
    cleaned, records = clean_false_positive_labels(volume, gt_labels=set(), volume_threshold=5)
    assert np.array_equal(cleaned, volume)
    assert records == ()


def test_zero_threshold_removes_nothing() -> None:
    volume = _volume()
    _fill(volume, slice(0, 1), slice(0, 1), slice(0, 1), 6)  # 1 voxel, NOT in GT

    cleaned, records = clean_false_positive_labels(volume, gt_labels=set(), volume_threshold=0)

    # voxel_count (1) < volume_threshold (0) is never true -- nothing removed.
    assert np.array_equal(cleaned, volume)
    assert records[0].removed is False
