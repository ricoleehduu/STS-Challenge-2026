"""Bit-identical + performance regression tests for correct_lr_confusion's
optimization (crop-to-bbox instead of full-volume scans per class/component).

``_correct_lr_confusion_reference`` (kept, byte-for-byte, in lr_correction.py)
is the ORIGINAL implementation measured at 158.1s on one real ~512^3 case --
see that function's docstring. Every test here asserts the OPTIMIZED
``correct_lr_confusion`` produces an output array that is bit-identical
(``np.array_equal``) to what the reference implementation produces on the
same input, across a wide range of synthetic volumes designed to exercise
every branch: L/R-swapped teeth that must flip, correctly-placed teeth that
must not, multiple components per class, sub-MIN_COMPONENT_VOXELS
components, and exact ties at the midline.
"""
from __future__ import annotations

import time

import numpy as np
import pytest

from stsr2026.inference.lr_correction import (
    MIN_COMPONENT_VOXELS,
    _correct_lr_confusion_reference,
    correct_lr_confusion,
)


def _random_volume(
    rng: np.random.Generator,
    shape: tuple[int, int, int] = (60, 60, 60),
    n_components: int = 50,
    max_class: int = 32,
) -> np.ndarray:
    volume = np.zeros(shape, dtype=np.uint8)
    for _ in range(n_components):
        cls = int(rng.integers(1, max_class + 1))
        x = int(rng.integers(0, shape[0] - 4))
        y = int(rng.integers(0, shape[1] - 4))
        z = int(rng.integers(0, shape[2] - 4))
        sx, sy, sz = (int(v) for v in rng.integers(1, 5, 3))
        volume[x : x + sx, y : y + sy, z : z + sz] = cls
    return volume


def _random_affine(rng: np.random.Generator) -> np.ndarray:
    affine = np.eye(4)
    for axis in range(3):
        affine[axis, axis] = float(rng.uniform(0.15, 0.5))
        affine[axis, 3] = float(rng.uniform(-80, 80))
    return affine


@pytest.mark.parametrize("seed", range(30))
def test_optimized_matches_reference_on_random_volumes(seed: int) -> None:
    rng = np.random.default_rng(seed)
    volume = _random_volume(rng)
    affine = _random_affine(rng)

    reference = _correct_lr_confusion_reference(volume, affine)
    optimized = correct_lr_confusion(volume, affine)

    assert np.array_equal(reference, optimized), f"mismatch at seed={seed}"


@pytest.mark.parametrize("seed", range(10))
def test_optimized_matches_reference_with_many_small_components(seed: int) -> None:
    # Heavier fragmentation (more, smaller components per class) than the
    # general fuzz test above -- the shape most likely to expose an off-by-one
    # in bbox/crop-offset bookkeeping, since components sit close to each
    # other and to volume edges.
    rng = np.random.default_rng(1000 + seed)
    volume = _random_volume(rng, shape=(40, 40, 40), n_components=120, max_class=32)
    affine = _random_affine(rng)

    reference = _correct_lr_confusion_reference(volume, affine)
    optimized = correct_lr_confusion(volume, affine)

    assert np.array_equal(reference, optimized), f"mismatch at seed={seed}"


def test_optimized_matches_reference_with_axis_aligned_identity_affine() -> None:
    # Identity affine is the one used throughout test_lr_correction.py --
    # confirm the optimization agrees with the reference there too, not only
    # under randomized affines.
    rng = np.random.default_rng(99)
    volume = _random_volume(rng)
    affine = np.eye(4)

    reference = _correct_lr_confusion_reference(volume, affine)
    optimized = correct_lr_confusion(volume, affine)

    assert np.array_equal(reference, optimized)


def test_optimized_matches_reference_on_exact_midline_tie() -> None:
    # Engineered exact tie: every tooth voxel (hence the median midline_x)
    # and the flip-candidate component's centroid are the SAME single x
    # coordinate -- centroid_x == midline_x must skip the flip in both
    # implementations, not just "happen to agree" on a flip decision.
    affine = np.eye(4)
    volume = np.zeros((20, 6, 4), dtype=np.uint8)
    volume[5:6, 1:3, 1:3] = 9  # left-labeled class sitting exactly at the midline

    reference = _correct_lr_confusion_reference(volume, affine)
    optimized = correct_lr_confusion(volume, affine)

    assert np.array_equal(reference, optimized)
    assert np.array_equal(reference, volume)  # tie -> unchanged


def test_optimized_matches_reference_on_sub_threshold_component() -> None:
    affine = np.eye(4)
    volume = np.zeros((10, 6, 4), dtype=np.uint8)
    volume[1:3, 1:3, 1:3] = 1
    volume[7:9, 1:3, 1:3] = 9
    volume[2:4, 1:3, 1] = 11  # MIN_COMPONENT_VOXELS - 1 voxels, mismatched side
    assert np.count_nonzero(volume == 11) == MIN_COMPONENT_VOXELS - 1

    reference = _correct_lr_confusion_reference(volume, affine)
    optimized = correct_lr_confusion(volume, affine)

    assert np.array_equal(reference, optimized)


def test_optimized_matches_reference_on_empty_volume() -> None:
    affine = np.eye(4)
    volume = np.zeros((30, 30, 30), dtype=np.uint8)

    reference = _correct_lr_confusion_reference(volume, affine)
    optimized = correct_lr_confusion(volume, affine)

    assert np.array_equal(reference, optimized)
    assert np.array_equal(reference, volume)


def test_optimized_matches_reference_on_canal_only_volume() -> None:
    # No tooth voxels at all -> correct_lr_confusion returns early. Canal
    # classes must never be touched by either implementation.
    affine = np.eye(4)
    volume = np.zeros((10, 6, 4), dtype=np.uint8)
    volume[1:3, 1:3, 1:3] = 43

    reference = _correct_lr_confusion_reference(volume, affine)
    optimized = correct_lr_confusion(volume, affine)

    assert np.array_equal(reference, optimized)
    assert np.array_equal(reference, volume)


def test_optimized_matches_reference_with_components_touching_volume_edges() -> None:
    # Components flush against index 0 or the array's max index on every
    # axis -- exercises the bbox/crop-offset arithmetic at the boundary
    # where there is no padding available on one side.
    rng = np.random.default_rng(42)
    affine = _random_affine(rng)
    volume = np.zeros((16, 16, 16), dtype=np.uint8)
    volume[0:3, 0:3, 0:3] = 9  # left-labeled, at the very corner (origin)
    volume[13:16, 13:16, 13:16] = 1  # right-labeled, at the far corner
    volume[0:3, 13:16, 0:3] = 25
    volume[13:16, 0:3, 13:16] = 17

    reference = _correct_lr_confusion_reference(volume, affine)
    optimized = correct_lr_confusion(volume, affine)

    assert np.array_equal(reference, optimized)


@pytest.mark.slow
def test_optimized_is_well_under_budget_on_large_synthetic_volume() -> None:
    """Timing smoke test on a ~512^3-scale synthetic volume laid out like a
    real dental arch (each of the 32 tooth classes occupies a small,
    anatomically-localized neighbourhood with a few jittered/duplicate
    components -- real teeth are spatially compact, not scattered across the
    whole case, which is exactly the property the crop-to-bbox optimization
    exploits and the fully-random fuzz tests above do not exercise).

    The real per-case budget is a few seconds out of a ~60s total inference
    budget (inference itself is ~32s/case) -- 20s is a generous ceiling that
    still catches a regression back toward the reference implementation's
    158.1s-measured-on-real-hardware behaviour.
    """
    rng = np.random.default_rng(2026)
    shape = (512, 512, 400)
    volume = np.zeros(shape, dtype=np.uint8)
    center = np.array([256, 256, 200])
    radius = 150
    for i, cls in enumerate(range(1, 33)):
        theta = 2 * np.pi * i / 32
        slot = center + np.array(
            [radius * np.cos(theta), radius * np.sin(theta), 0]
        ).astype(int)
        for _ in range(int(rng.integers(1, 4))):
            jitter = rng.integers(-15, 15, 3)
            pos = np.clip(slot + jitter, 0, np.array(shape) - 10)
            sx, sy, sz = (int(v) for v in rng.integers(3, 10, 3))
            volume[pos[0] : pos[0] + sx, pos[1] : pos[1] + sy, pos[2] : pos[2] + sz] = cls
    for i, cls in enumerate(range(33, 65)):
        theta = 2 * np.pi * i / 32
        slot = center + np.array(
            [radius * np.cos(theta), radius * np.sin(theta), 0]
        ).astype(int)
        for _ in range(int(rng.integers(2, 6))):
            jitter = rng.integers(-10, 10, 3)
            pos = np.clip(slot + jitter, 0, np.array(shape) - 8)
            sx, sy, sz = (int(v) for v in rng.integers(2, 6, 3))
            volume[pos[0] : pos[0] + sx, pos[1] : pos[1] + sy, pos[2] : pos[2] + sz] = cls

    affine = np.eye(4)
    affine[0, 0] = affine[1, 1] = affine[2, 2] = 0.25
    affine[0, 3] = affine[1, 3] = -60.0
    affine[2, 3] = -40.0

    start = time.time()
    correct_lr_confusion(volume, affine)
    elapsed = time.time() - start

    assert elapsed < 20.0, f"correct_lr_confusion took {elapsed:.2f}s, expected well under 20s"
