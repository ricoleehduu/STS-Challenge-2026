from __future__ import annotations

import numpy as np

from stsr2026.inference.false_positive_cleanup import clean_or_relabel_false_positive_labels


def _volume(shape: tuple[int, int, int] = (14, 10, 4)) -> np.ndarray:
    return np.zeros(shape, dtype=np.int64)


def _block(volume: np.ndarray, x: slice, label: int, y: slice = slice(1, 4), z: slice = slice(1, 3)) -> None:
    volume[x, y, z] = label


def test_large_false_positive_relabeled_to_real_predicted_neighbor() -> None:
    """A large (>= threshold) GT-absent tooth component sitting right next to
    a real predicted tooth must be relabeled to that neighbour, not cleared."""
    volume = _volume()
    _block(volume, slice(0, 6), 21)  # real, GT-present tooth
    _block(volume, slice(6, 12), 20)  # false-positive component, adjacent
    fp_voxels = int(np.count_nonzero(volume == 20))

    output, records = clean_or_relabel_false_positive_labels(
        volume, gt_labels={21}, volume_threshold=fp_voxels, dilation_voxels=2
    )

    assert np.all(output[6:12, 1:4, 1:3] == 21)
    assert np.all(output[0:6, 1:4, 1:3] == 21)  # untouched real tooth
    assert len(records) == 1
    r = records[0]
    assert r.label == 20
    assert r.action == "relabeled_to_neighbor"
    assert r.new_label == 21


def test_large_false_positive_with_no_neighbor_falls_back_to_clearing() -> None:
    """A large GT-absent component with nothing tooth-like nearby must fall
    back to the original clear-to-background behaviour, not be forced onto
    an unreliable guess."""
    volume = _volume()
    _block(volume, slice(6, 12), 20)  # isolated, nothing else in the volume
    fp_voxels = int(np.count_nonzero(volume == 20))

    output, records = clean_or_relabel_false_positive_labels(
        volume, gt_labels=set(), volume_threshold=fp_voxels, dilation_voxels=2
    )

    assert np.count_nonzero(output == 20) == 0
    r = records[0]
    assert r.action == "cleared_large_no_neighbor"
    assert r.new_label is None


def test_large_false_positive_picks_neighbor_with_more_overlap() -> None:
    # Dilation only reaches 2 voxels deep, so overlap is governed by how much
    # of each neighbour's boundary surface sits within that margin -- vary
    # the x-extent (contact width along the shared boundary) rather than
    # y-depth (mostly outside the dilation's reach either way) to get an
    # unambiguous larger-vs-smaller overlap between the two candidates.
    volume = _volume((14, 14, 4))
    volume[6:8, 0:2, 1:3] = 3  # small real tooth: narrow contact (8 voxels within dilation reach)
    volume[6:12, 8:10, 1:3] = 9  # bigger real tooth: wide contact (24 voxels within dilation reach)
    volume[6:12, 2:8, 1:3] = 20  # false-positive component spanning between, touches both after dilation
    fp_voxels = int(np.count_nonzero(volume == 20))

    output, records = clean_or_relabel_false_positive_labels(
        volume, gt_labels={3, 9}, volume_threshold=fp_voxels, dilation_voxels=2
    )

    r = records[0]
    assert r.action == "relabeled_to_neighbor"
    assert r.new_label == 9  # the class with more touching voxels


def test_never_touches_real_gt_labeled_components() -> None:
    """Same protection as clean_false_positive_labels: a label present
    anywhere in this case's GT is never modified, regardless of size."""
    volume = _volume()
    _block(volume, slice(0, 8), 5)  # large component, but IS in GT

    output, records = clean_or_relabel_false_positive_labels(volume, gt_labels={5}, volume_threshold=1, dilation_voxels=2)

    assert np.array_equal(output, volume)
    assert records == ()


def test_small_false_positive_still_cleared_not_relabeled() -> None:
    """Below the volume threshold, behaviour matches
    clean_false_positive_labels exactly -- clear, never relabel, even if a
    plausible neighbour exists (small noise shouldn't get a promotion)."""
    volume = _volume()
    _block(volume, slice(0, 6), 21)
    volume[6, 1, 1] = 20  # 1-voxel false positive, well below threshold, touching real tooth 21

    output, records = clean_or_relabel_false_positive_labels(volume, gt_labels={21}, volume_threshold=100, dilation_voxels=2)

    assert np.count_nonzero(output == 20) == 0
    r = records[0]
    assert r.action == "cleared_small"
    assert r.new_label is None


def test_threshold_boundary_is_exclusive_above_for_large_path() -> None:
    volume = _volume()
    _block(volume, slice(0, 6), 21)
    _block(volume, slice(6, 8), 20, y=slice(1, 4), z=slice(1, 3))  # exactly 12 voxels
    voxel_count = int(np.count_nonzero(volume == 20))

    at_threshold = clean_or_relabel_false_positive_labels(volume, gt_labels={21}, volume_threshold=voxel_count)
    below_threshold = clean_or_relabel_false_positive_labels(volume, gt_labels={21}, volume_threshold=voxel_count + 1)

    # voxel_count < threshold is False when equal -> goes down the "large" (>=) path -> relabeled.
    assert at_threshold[1][0].action == "relabeled_to_neighbor"
    # voxel_count < threshold is True when threshold is one more -> goes down the "small" path -> cleared.
    assert below_threshold[1][0].action == "cleared_small"


def test_neighbor_search_ignores_other_components_of_the_same_false_positive_label() -> None:
    """A second component of the SAME false-positive label sitting nearby
    must not count as a valid 'neighbour' -- that would just preserve the
    wrong label instead of fixing it."""
    volume = _volume((20, 10, 4))
    _block(volume, slice(0, 4), 20)  # another (small) component of the SAME false-positive label 20
    _block(volume, slice(8, 14), 20)  # the large component under test -- far from the first, not touching
    fp_large_voxels = int(np.count_nonzero(volume[8:14, 1:4, 1:3] == 20))
    # nothing else nearby -> no real tooth neighbour should be found for either.

    output, records = clean_or_relabel_false_positive_labels(
        volume, gt_labels=set(), volume_threshold=fp_large_voxels, dilation_voxels=2
    )

    large_component_records = [r for r in records if r.voxel_count == fp_large_voxels]
    assert len(large_component_records) == 1
    assert large_component_records[0].action == "cleared_large_no_neighbor"


def test_large_canal_false_positive_never_relabeled_to_tooth_neighbor() -> None:
    """A large GT-absent CANAL component (33-64) must never be relabeled
    onto a neighbouring TOOTH class -- that would be semantically nonsensical
    and risks repeating inherit_canal_labels_from_corrected_teeth's real
    negative result via a different mechanism. It must fall back to
    clearing, exactly like the 'no neighbour found' case, even when a real
    tooth neighbour is sitting right next to it."""
    volume = _volume()
    _block(volume, slice(0, 6), 21)  # real tooth right next to it
    _block(volume, slice(6, 12), 41)  # canal class, false positive, large, adjacent to the tooth
    fp_voxels = int(np.count_nonzero(volume == 41))

    output, records = clean_or_relabel_false_positive_labels(
        volume, gt_labels={21}, volume_threshold=fp_voxels, dilation_voxels=2
    )

    assert np.count_nonzero(output == 41) == 0  # cleared, not relabeled
    assert np.all(output[0:6, 1:4, 1:3] == 21)  # real tooth untouched
    r = records[0]
    assert r.label == 41
    assert r.action == "cleared_large_non_tooth"
    assert r.new_label is None


def test_component_identification_uses_default_connectivity_like_clean_false_positive_labels() -> None:
    """Regression test for a real bug found via real-data validation: an
    earlier version of this function used 26-connectivity for identifying
    candidate components (matching the dilation structure), which silently
    merges diagonally-only-adjacent blobs that clean_false_positive_labels
    (default/6-connectivity) would count as two separate components -- this
    changed which components fell above/below volume_threshold and made
    results incomparable to clean_false_positive_labels. Two voxels touching
    only at a corner (diagonal, not face-adjacent) must be reported as two
    separate 1-voxel components, not merged into one 2-voxel component."""
    volume = _volume()
    volume[5, 1, 1] = 20  # false positive, not in GT
    volume[6, 2, 2] = 20  # touches the above only diagonally (corner), not face-adjacent

    _, records = clean_or_relabel_false_positive_labels(volume, gt_labels=set(), volume_threshold=1, dilation_voxels=0)

    assert len(records) == 2
    assert all(r.voxel_count == 1 for r in records)


def test_returns_new_array_and_multiple_labels_independent() -> None:
    volume = _volume((14, 14, 4))
    _block(volume, slice(0, 6), 21, y=slice(0, 3))
    _block(volume, slice(6, 12), 20, y=slice(0, 3))  # relabels to 21
    volume[13, 1, 1] = 99  # tiny unrelated false positive elsewhere -- cleared
    fp_voxels = int(np.count_nonzero(volume == 20))

    output, records = clean_or_relabel_false_positive_labels(
        volume, gt_labels={21}, volume_threshold=fp_voxels, dilation_voxels=2
    )

    assert output is not volume
    assert np.all(output[6:12, 0:3, 1:3] == 21)
    assert np.count_nonzero(output == 99) == 0
    assert len(records) == 2
