# STSR2026 Task 1 — Semi-supervised Tooth & Root-Canal Instance Segmentation in CBCT

Public implementation of team **djw**'s submitted method for the MICCAI STSR2026
Challenge, Task 1: instance-level segmentation and FDI numbering of teeth
(classes 1–32) and their root canals (classes 33–64) in 3D CBCT.

## Method overview

- **Backbone:** a single global nnU-Net (3D full-resolution) trained with a
  consistency-regularised semi-supervised schedule ("Line A / Phase B"). The
  submitted checkpoint is the multi-objective best snapshot, selected by
  instance-level / IA / canal metrics rather than training-loss.
- **GT-free post-processing** applied to every prediction inside the container:
  1. **Tooth L/R correction** — estimates each case's own mid-sagittal plane
     from the tooth voxels and reassigns any tooth instance whose centroid lies
     on the wrong side of the arch. This is the single largest validated gain
     (real Codabench `Challenge_Score` 0.5158 → 0.7207).
  2. **Teeth-only false-positive cleanup** — removes small hallucinated tooth
     components; canals (33–64) are excluded by construction so thin/fragmented
     real canals are never touched.
- **Efficiency:** sliding-window inference at `tile_step_size=1.0` and a
  memory-bounded windowed export path, tuned to meet the challenge's per-case
  60 s limit and 8 GB Docker memory cap on a 24 GB GPU.

Canal *identity* is deliberately **not** rewritten by any geometry rule: the
ground-truth canal labels are ~50/50 left/right-inconsistent with the tooth
labels, which caps any parent-tooth relabeling below the model's own accuracy.
The diagnostic code that established this (`data/canal_pairing.py`,
`evaluation/tooth_error_diagnosis.py`, `inference/canal_mirror_dedup.py`) is
included for transparency but is **not** part of the inference path.

## Repository layout

```text
src/stsr2026/
  inference/       submission inference chain: predict, checkpoint_runner,
                   postprocessing_pipeline, lr_correction,
                   false_positive_cleanup, streaming_export
                   (+ diagnostic-only modules, not wired into the container)
  training/        nnU-Net trainer subclasses & semi-supervised utilities
  data/            nnU-Net dataset conversion, split, audit, metal-artifact aug
  evaluation/      local scorer wrapping the official metrics, diagnostics
  submission/      output-contract validator
docker/            final submission image (Dockerfile.modern) + entrypoint
configs/           data / training / inference configuration
scripts/           preprocessing, post-processing and evaluation entry points
third_party/       vendored, unmodified official STSR scorer (for parity)
tests/             unit tests
```

Model weights, challenge data, predictions and submission archives are **not**
tracked (see `.gitignore`).

## Environment

```bash
python >= 3.10
pip install -e .                 # runtime deps (numpy, nibabel, scipy, SimpleITK)
pip install -e ".[training]"     # adds torch + nnunetv2 (GPU boxes only)
pip install -e ".[dev]"          # pytest + ruff
```

Point nnU-Net at directories outside the repo (see `.env.example`):

```bash
export nnUNet_raw=/path/to/nnUNet_raw
export nnUNet_preprocessed=/path/to/nnUNet_preprocessed
export nnUNet_results=/path/to/nnUNet_results
```

## Running the submitted method (Docker)

The trained checkpoint is not included; place it under `docker/checkpoint/`
(nnU-Net layout) as `fold_0/checkpoint_final.pth` with `dataset.json` and
`plans.json` alongside, then:

```bash
# build
docker build -t djw:latest -f docker/Dockerfile.modern .

# run — same form as the official evaluation command
docker container run --gpus all -m 8G --name djw --rm \
    -v $PWD/inputs/:/inputs \
    -v $PWD/outputs/:/outputs \
    djw:latest
```

The container reads every `*.nii.gz` under `/inputs` and writes
`<case>_mask.nii.gz` to `/outputs`, preserving each volume's NIfTI geometry.
Post-processing is on by default; set `-e STSR_APPLY_LR_CORRECTION=0` to emit
raw predictions.

## Local evaluation

`scripts/evaluate_checkpoint.py` scores predictions against ground truth with
the vendored official metrics, reporting tooth and canal, image- and
instance-level metrics separately:

```bash
PYTHONPATH=src python scripts/evaluate_checkpoint.py \
    --skip-inference --output-dir <predictions_dir> \
    --images <images_dir> --labels <labels_dir> --config-label my-run
```

## Tests

```bash
PYTHONPATH=src python -m pytest tests/ -q
```

## License & citation

See `LICENSE` (to be added). If you use this code, please cite the STSR2026
challenge and this repository.
