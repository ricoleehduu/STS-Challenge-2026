# Local data layout

比赛数据不进入 Git。获得主办方授权的数据后，建议放置为：

```text
data/
  raw/
    train_labeled/images/
    train_labeled/labels/
    train_unlabeled/images/
    validation/images/
  interim/               转换和审计的中间结果
  nnunet_raw/            nnU-Net raw dataset
  nnunet_preprocessed/   nnU-Net preprocessing cache
```

实际文件名以官方数据包为准，不要在没有审计的情况下批量重命名。所有复制和转换都应保留原始 NIfTI 几何信息。

