from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy import ndimage

from stsr2026.training.pseudo_label import (
    CANAL_CLASS_MIN,
    TOOTH_CLASS_MAX,
    TOOTH_CLASS_MIN,
    is_canal_class,
)

MIN_COMPONENT_VOXELS = 5
# Dilation radius (voxels) used when checking spatial overlap between a canal
# component and candidate parent teeth.  Real CBCT at 0.25mm iso: 5 voxels = 1.25mm.
# NOTE: correct_canal_parent_assignment() is NOT used in the production pipeline --
# validated as net-harmful on the 6-case holdout (canal Dice_Instance -0.063,
# IA -0.013).  Root cause: dilation at any useful radius also bleeds into adjacent
# teeth in a tight dental arch, misidentifying the best parent for already-correct
# canal predictions (e.g. canal 52 Dice 0.891→0.000).  Kept for reference.
CANAL_PARENT_DILATION_RADIUS = 5
# (right_start, left_start) per swappable pair. FDI_ORDER (pseudo_label.py) walks
# quadrants Q1->Q2->Q3->Q4 around the arch (upper-right, upper-left, lower-left,
# lower-right), so the right/left polarity of "low vs high class id" FLIPS between
# the upper pair (Q1=1-8 right, Q2=9-16 left) and the lower pair (Q3=17-24 left,
# Q4=25-32 right) -- right_start is deliberately > left_start for the lower pairs.
TOOTH_SWAPPABLE_CLASS_PAIRS: tuple[tuple[int, int], ...] = (
    (1, 9),    # Q1 (right) <-> Q2 (left)
    (25, 17),  # Q4 (right) <-> Q3 (left)
)
# Canal centroids do NOT reliably separate left/right the way tooth centroids do --
# verified on real data (case STS26_Train-Labeled_002): 11 canal instances spanning
# both true sides had world-X centroids clustered within ~15mm of the case midline,
# an order of magnitude tighter than teeth. Applying the same per-instance
# centroid-vs-midline rule to canals flipped many *already-correctly-labeled*
# canals (canal MISLABEL count went 60->88 on the 6-case holdout, Dice_Instance
# 0.45->0.32) -- net harmful, so canal correction is disabled here. A canal's
# label should instead be derived from whichever (corrected) tooth instance it
# spatially belongs to, not from the canal's own centroid -- not yet implemented,
# see plan.md D3.5.
CANAL_SWAPPABLE_CLASS_PAIRS: tuple[tuple[int, int], ...] = (
    (33, 41),  # Q1 canal (right) <-> Q2 canal (left)
    (57, 49),  # Q4 canal (right) <-> Q3 canal (left)
)
SWAPPABLE_CLASS_PAIRS: tuple[tuple[int, int], ...] = TOOTH_SWAPPABLE_CLASS_PAIRS
QUADRANT_CLASS_COUNT = 8


def _world_x(indices: np.ndarray, affine: np.ndarray) -> np.ndarray:
    return indices @ affine[0, :3] + affine[0, 3]


def correct_lr_confusion(label_volume: np.ndarray, affine: np.ndarray) -> np.ndarray:
    """Correct connected components whose label's left/right quadrant disagrees with geometry.

    PERFORMANCE, found via real-data validation: the straightforward version
    (still kept, byte-for-byte, as :func:`_correct_lr_confusion_reference`
    below, for tests to diff against) does a FULL-VOLUME ``ndimage.label``
    for each of the 32 tooth classes, and then, per connected component, a
    FULL-VOLUME boolean mask + ``np.argwhere`` + per-voxel world-X mean --
    on a real ~512^3 case this measured **158 seconds**, almost entirely
    wasted work: every tooth class and every one of its components is a
    small, spatially tight structure, so scanning the other ~99% of the
    volume that can't possibly contain it, 32+ times over, dominates the
    cost.

    This version computes the exact same decisions using the exact same
    arithmetic (same global voxel coordinates, same summation order --
    see the loop body below for why bounding-box cropping cannot change
    either), just without visiting voxels miles away from any given tooth
    class or component:

    1. ``ndimage.find_objects(label_volume, max_label=TOOTH_CLASS_MAX)`` --
       ONE pass over the full volume gives a tight per-class bounding box
       for every one of the 32 tooth classes at once (this is what
       ``find_objects`` is for: it just tracks per-label min/max index
       while scanning once, no union-find, much cheaper than 32 separate
       ``label_volume == class_id`` full-volume boolean compares would be).
    2. ``ndimage.label`` then runs on that class's small CROPPED region,
       not the full volume.
    3. Per-component voxel counts (the ``MIN_COMPONENT_VOXELS`` filter) are
       read from one vectorized ``np.bincount`` over the cropped labeled
       array, instead of a wasted per-component ``argwhere`` just to check
       ``.shape[0]``.
    4. A second, component-local ``ndimage.find_objects`` (on the already-
       small cropped array) gives each component its own tight bounding
       box, so the final ``np.argwhere``-then-``np.mean`` centroid step
       only ever touches that one component's own voxels -- identical
       values, identical order, just without scanning anything outside its
       box. (Center-of-mass IS mathematically exactly this mean, since
       ``_world_x`` is affine-linear -- but ``scipy.ndimage.center_of_mass``
       was deliberately NOT used here: its internal reduction order is not
       guaranteed to match ``np.mean``'s, which risks disagreeing with the
       reference implementation by a float ULP or two on real data. Cropping
       instead of changing the reduction keeps every floating-point op byte-
       for-byte identical to the reference, including the ``== midline_x``
       tie check.)

    Every array indexed into below (``label_volume[bbox]``,
    ``component_labels[sub_bbox]``) is a NumPy *view*, not a copy, and
    slicing a C-contiguous array to a rectangular sub-box never reorders or
    drops voxels relative to a full-array scan restricted to the same
    voxels -- it only skips scanning regions that are guaranteed not to
    contain them. That is what makes this a pure performance change: same
    inputs in, same outputs out, for every voxel, every component, every
    tie.
    """
    if label_volume.ndim != 3:
        raise ValueError(f"label_volume must be 3-dimensional, got shape {label_volume.shape}")
    if affine.shape != (4, 4):
        raise ValueError(f"affine must have shape (4, 4), got {affine.shape}")

    corrected = label_volume.copy()
    tooth_indices = np.argwhere((label_volume >= 1) & (label_volume <= 32))
    if tooth_indices.size == 0:
        return corrected
    midline_x = float(np.median(_world_x(tooth_indices, affine)))

    # One O(volume) pass -> tight bounding box for every tooth class 1..32
    # at once (None for a class entirely absent from this volume).
    class_bboxes = ndimage.find_objects(label_volume, max_label=TOOTH_CLASS_MAX)

    for right_start, left_start in SWAPPABLE_CLASS_PAIRS:
        offset = left_start - right_start
        for class_id, predicted_right in (
            *((c, True) for c in range(right_start, right_start + QUADRANT_CLASS_COUNT)),
            *((c, False) for c in range(left_start, left_start + QUADRANT_CLASS_COUNT)),
        ):
            bbox = class_bboxes[class_id - 1]
            if bbox is None:
                continue  # class not present in this volume at all

            cropped_labels = label_volume[bbox]
            cropped_mask = cropped_labels == class_id
            component_labels, component_count = ndimage.label(cropped_mask)
            if component_count == 0:
                continue

            # Vectorized per-component voxel counts, replacing the
            # reference's per-component argwhere-just-to-count.
            counts = np.bincount(component_labels.ravel())
            component_bboxes = ndimage.find_objects(component_labels)
            crop_origin = np.array([s.start for s in bbox])

            for component_id in range(1, component_count + 1):
                if counts[component_id] < MIN_COMPONENT_VOXELS:
                    continue

                sub_bbox = component_bboxes[component_id - 1]
                local_labels = component_labels[sub_bbox]
                local_mask = local_labels == component_id
                local_indices = np.argwhere(local_mask)
                sub_origin = np.array([s.start for s in sub_bbox])
                # These, in this exact order, are identical to what
                # np.argwhere(full_volume_component) would enumerate -- see
                # this function's docstring.
                global_indices = local_indices + sub_origin + crop_origin

                centroid_x = float(np.mean(_world_x(global_indices, affine)))
                if centroid_x == midline_x:
                    continue
                actual_right = centroid_x < midline_x
                if predicted_right == actual_right:
                    continue

                paired_class_id = class_id + offset if predicted_right else class_id - offset
                global_slices = tuple(
                    slice(
                        int(crop_origin[a] + sub_origin[a]),
                        int(crop_origin[a] + sub_origin[a] + local_mask.shape[a]),
                    )
                    for a in range(3)
                )
                corrected[global_slices][local_mask] = paired_class_id

    return corrected


def _correct_lr_confusion_reference(label_volume: np.ndarray, affine: np.ndarray) -> np.ndarray:
    """Byte-for-byte the ORIGINAL, unoptimized ``correct_lr_confusion`` --
    kept ONLY so tests can diff the optimized version above against it on
    synthetic volumes. Never call this from production code: it is the
    exact implementation measured at 158s/case on real ~512^3 data (see
    :func:`correct_lr_confusion`'s docstring). Do not "clean this up" by
    merging it back with the optimized version above -- the whole point of
    keeping it is that it must NOT change, ever, so it stays a trustworthy
    independent reference.
    """
    if label_volume.ndim != 3:
        raise ValueError(f"label_volume must be 3-dimensional, got shape {label_volume.shape}")
    if affine.shape != (4, 4):
        raise ValueError(f"affine must have shape (4, 4), got {affine.shape}")

    corrected = label_volume.copy()
    tooth_indices = np.argwhere((label_volume >= 1) & (label_volume <= 32))
    if tooth_indices.size == 0:
        return corrected
    midline_x = float(np.median(_world_x(tooth_indices, affine)))

    for right_start, left_start in SWAPPABLE_CLASS_PAIRS:
        offset = left_start - right_start
        for class_id, predicted_right in (
            *((c, True) for c in range(right_start, right_start + QUADRANT_CLASS_COUNT)),
            *((c, False) for c in range(left_start, left_start + QUADRANT_CLASS_COUNT)),
        ):
            component_labels, component_count = ndimage.label(label_volume == class_id)
            for component_id in range(1, component_count + 1):
                component = component_labels == component_id
                indices = np.argwhere(component)
                if indices.shape[0] < MIN_COMPONENT_VOXELS:
                    continue

                centroid_x = float(np.mean(_world_x(indices, affine)))
                if centroid_x == midline_x:
                    continue
                actual_right = centroid_x < midline_x
                if predicted_right == actual_right:
                    continue

                paired_class_id = class_id + offset if predicted_right else class_id - offset
                corrected[component] = paired_class_id

    return corrected


def correct_canal_parent_assignment(
    label_volume: np.ndarray,
    *,
    dilation_radius: int = CANAL_PARENT_DILATION_RADIUS,
    min_overlap_fraction: float = 0.10,
) -> np.ndarray:
    """Re-assign canal labels whose parent tooth disagrees with spatial location.

    Each canal label c (33–64) should anatomically reside inside (or immediately
    adjacent to) its parent tooth label c-32 (1–32).  When the model predicts the
    correct canal region but assigns the wrong canal number, the canal voxels end up
    spatially inside a *different* tooth's territory.

    Algorithm (per canal label c present in the prediction):
    1. Build a dilated mask of the *predicted* parent tooth (c-32).
    2. Measure the overlap between the canal-c voxels and each tooth's dilated mask.
    3. If the canal's own parent (c-32) has < ``min_overlap_fraction`` overlap *and*
       some other tooth t has more overlap, reassign the canal voxels to canal t+32.
    4. Tie-break: choose the tooth t with the most overlap voxels.

    This is structurally different from the centroid-based L/R correction:
    - It does not rely on L/R axis geometry (which fails for canals).
    - It exploits the anatomical containment relationship (canal is inside tooth).
    - It can fix any label swap, not just L/R pairs.

    Verified on 6-case holdout: 41% of canal instances are mislabeled (found at the
    right position but under the wrong canal number) -- this is the target population.

    **NOT used in the production pipeline** -- validated as net-harmful on the
    6-case holdout (canal Dice_Instance -0.063, IA -0.013). Kept for reference;
    see docs/progress-teammate.md's 2026-07-17 write-up for the full diagnosis.
    A second, independent implementation of essentially the same idea
    (``inherit_canal_labels_from_corrected_teeth`` below, dilation=2 instead of
    5, always-take-max-overlap instead of a parent-overlap threshold) was
    built the same day without knowledge of this function and found the same
    net-harmful result -- see that function's docstring and
    docs/experiment-log.md's ``Day1-TaskC`` notes. Both are kept; neither
    should be re-attempted with a third variant without new evidence.
    """
    if label_volume.ndim != 3:
        raise ValueError(
            f"label_volume must be 3-dimensional, got shape {label_volume.shape}"
        )

    corrected = label_volume.copy()

    # Pre-compute dilated tooth masks for all teeth present in the prediction.
    # Dilation bridges the thin boundary between tooth enamel/dentin and canal.
    struct = ndimage.generate_binary_structure(3, 1)
    tooth_dilated: dict[int, np.ndarray] = {}
    for t in range(1, 33):
        tooth_mask = label_volume == t
        if not tooth_mask.any():
            continue
        tooth_dilated[t] = ndimage.binary_dilation(
            tooth_mask, structure=struct, iterations=dilation_radius
        )

    if not tooth_dilated:
        return corrected  # no teeth predicted at all

    # Process each canal label
    for c in range(33, 65):
        canal_mask = label_volume == c
        if not canal_mask.any():
            continue

        canal_vox_count = int(canal_mask.sum())
        parent_tooth = c - 32

        # Overlap of this canal with each predicted tooth (dilated)
        overlaps: dict[int, int] = {}
        for t, tdil in tooth_dilated.items():
            ov = int((canal_mask & tdil).sum())
            if ov > 0:
                overlaps[t] = ov

        if not overlaps:
            # Canal floats in background with no tooth nearby -- leave unchanged.
            continue

        best_tooth = max(overlaps, key=lambda t: overlaps[t])
        parent_overlap = overlaps.get(parent_tooth, 0)
        parent_fraction = parent_overlap / canal_vox_count

        if best_tooth == parent_tooth or parent_fraction >= min_overlap_fraction:
            # Canal is correctly associated with its parent tooth (or close enough).
            continue

        # Reassign: canal c → canal best_tooth+32
        new_canal = best_tooth + 32
        if new_canal == c:
            continue

        corrected[canal_mask] = new_canal

    return corrected


# ---------------------------------------------------------------------------
# Canal left/right correction via parent-tooth inheritance.
#
# NEW, SEPARATE step from correct_lr_confusion above -- does not modify that
# function or its logic in any way (plan.md D7 explicitly forbids touching
# the already-Codabench-validated tooth correction). Intended to run AFTER
# correct_lr_confusion (and, in the real pipeline, after the false-positive
# label cleanup in stsr2026.inference.false_positive_cleanup) has already
# been applied to the tooth classes 1-32; canal classes 33-64 are expected to
# still be the model's raw, uncorrected prediction when this function runs,
# since correct_lr_confusion's SWAPPABLE_CLASS_PAIRS = TOOTH_SWAPPABLE_CLASS_PAIRS
# only (canal correction is deliberately disabled there, see
# CANAL_SWAPPABLE_CLASS_PAIRS' comment above).
#
# Rationale (docs/progress-teammate.md, plan.md D3.5): a canal's own
# centroid does not reliably separate left/right (verified on real data,
# see the comment on CANAL_SWAPPABLE_CLASS_PAIRS above). But canal class id
# = parent tooth class id + 32 by this dataset's convention, and a root
# canal is physically embedded inside its parent tooth's root -- so instead
# of re-deriving laterality from the canal's own (unreliable) geometry, this
# function looks up which *already-corrected* tooth class is actually next
# to each canal component in the volume and relabels the canal to match.
# ---------------------------------------------------------------------------

CANAL_TO_TOOTH_CLASS_OFFSET = CANAL_CLASS_MIN - TOOTH_CLASS_MIN  # 33 - 1 = 32
# How far to grow a canal component's mask, in voxels, when searching for a
# neighbouring tooth label. Canal and tooth are mutually-exclusive per-voxel
# labels (a single voxel cannot carry both), so a canal component's own mask
# never directly touches any tooth-labeled voxel -- the parent tooth can only
# be found by looking at a small neighbourhood around the canal, not the
# canal's own voxels. 2 iterations of a full 26-connectivity structuring
# element is deliberately small: root canals sit directly inside/against
# their parent tooth's root wall (real gap is typically 0-1 voxels at this
# dataset's resampled resolution), so a small radius is enough to reach the
# parent while staying unlikely to reach an unrelated neighbouring tooth
# across an actual anatomical gap. Exposed as a parameter rather than a
# hardcoded constant so it can be tuned against real predictions without
# touching this function's logic.
DEFAULT_PARENT_TOOTH_SEARCH_DILATION_VOXELS = 2


@dataclass(frozen=True)
class CanalInheritanceDecision:
    """One canal connected component's parent-tooth-inheritance decision."""

    original_label: int
    component_voxels: int
    parent_tooth_class: int | None  # None if no parent tooth was found nearby
    new_label: int  # == original_label when unchanged
    changed: bool
    reason: str


def inherit_canal_labels_from_corrected_teeth(
    corrected_label_volume: np.ndarray,
    dilation_voxels: int = DEFAULT_PARENT_TOOTH_SEARCH_DILATION_VOXELS,
) -> tuple[np.ndarray, tuple[CanalInheritanceDecision, ...]]:
    """Relabel each canal connected component to (parent tooth class + 32).

    ``corrected_label_volume`` is expected to already have tooth classes
    (1-32) in their final, corrected state -- this function only *reads*
    tooth labels, it never modifies them. For every connected component of
    every canal class (33-64) present in the volume, the "parent tooth" is
    determined by dilating the component's mask by ``dilation_voxels`` and
    taking whichever tooth class (1-32) has the most voxels in that dilated
    neighbourhood (excluding the canal component's own voxels, which by
    construction never carry a tooth label) -- i.e. spatial adjacency, not
    an assumed ``canal_class - 32 == tooth_class`` identity, per plan.md's
    explicit instruction not to just assume the naive class-id mapping,
    since the "parent" identified this way could itself have been a
    different tooth than the naive mapping would suggest (e.g. if nnU-Net
    mislabeled the tooth into an adjacent FDI position).

    Boundary cases (plan.md D7 task C, decided and documented here):

    - **No tooth voxels found in the dilated neighbourhood** (component is
      spatially isolated, or ``dilation_voxels`` wasn't enough to reach any
      tooth): the canal keeps its original label, unchanged.
      ``parent_tooth_class`` is ``None``, ``reason`` explains why.
    - **Multiple different tooth classes touch the dilated neighbourhood**:
      the one with the strictly largest voxel count wins (a tie keeps the
      numerically smaller class id, an arbitrary but deterministic
      tie-break -- ties are expected to be rare to nonexistent on real data
      given canal geometry, and are handled rather than left to raise).
    - **The parent tooth found is itself a hallucinated/false-positive
      label** (a class id present in the prediction but absent from this
      case's real ground truth): this function has no access to ground
      truth (it only ever sees the prediction volume, matching what the
      real inference pipeline can see), so it cannot detect this case --
      the canal simply inherits whatever tooth label is actually present in
      the volume at that location, correct or not. This is a documented
      limitation, not a bug: running
      :func:`stsr2026.inference.false_positive_cleanup.clean_false_positive_labels`
      on the tooth classes *before* this function (the real pipeline order)
      reduces this risk by removing small hallucinated tooth labels first,
      but cannot eliminate it for large false-positive tooth components that
      are deliberately left for manual review (see plan.md D7 task A step 4).
    - **A canal component smaller than ``MIN_COMPONENT_VOXELS`` voxels**
      (this module's existing noise-floor constant, reused here for
      consistency with :func:`correct_lr_confusion`): left unchanged without
      searching for a parent, to avoid a single-voxel noise blip picking up
      a "parent" by chance proximity.
    - **The parent tooth's class already implies the canal's current
      label** (``parent_tooth_class + 32 == original_label``): reported as
      ``changed=False`` -- inheriting doesn't always mean relabeling.

    Returns ``(relabeled_volume, decisions)`` -- ``relabeled_volume`` is
    always a new array; ``decisions`` has one entry per canal connected
    component considered, in (label, component id) order, for auditing.
    """
    if corrected_label_volume.ndim != 3:
        raise ValueError(f"corrected_label_volume must be 3-dimensional, got shape {corrected_label_volume.shape}")
    if dilation_voxels < 0:
        raise ValueError(f"dilation_voxels must be >= 0, got {dilation_voxels}")

    output = corrected_label_volume.copy()
    decisions: list[CanalInheritanceDecision] = []
    structure = ndimage.generate_binary_structure(3, 3)  # 26-connectivity, matches correct_lr_confusion's neighbour model

    canal_labels_present = sorted(
        int(label) for label in np.unique(corrected_label_volume) if is_canal_class(int(label))
    )
    for canal_label in canal_labels_present:
        canal_mask = corrected_label_volume == canal_label
        component_labels, component_count = ndimage.label(canal_mask, structure=structure)
        for component_id in range(1, component_count + 1):
            component_mask = component_labels == component_id
            voxel_count = int(np.count_nonzero(component_mask))

            if voxel_count < MIN_COMPONENT_VOXELS:
                decisions.append(
                    CanalInheritanceDecision(
                        canal_label, voxel_count, None, canal_label, False, "component below MIN_COMPONENT_VOXELS, left unchanged"
                    )
                )
                continue

            neighbourhood = ndimage.binary_dilation(component_mask, structure=structure, iterations=dilation_voxels)
            neighbourhood &= ~component_mask  # canal voxels themselves never carry a tooth label; explicit for clarity
            tooth_neighbours = corrected_label_volume[neighbourhood]
            tooth_neighbours = tooth_neighbours[
                (tooth_neighbours >= TOOTH_CLASS_MIN) & (tooth_neighbours <= TOOTH_CLASS_MAX)
            ]

            if tooth_neighbours.size == 0:
                decisions.append(
                    CanalInheritanceDecision(
                        canal_label, voxel_count, None, canal_label, False,
                        f"no tooth label found within {dilation_voxels}-voxel dilation, left unchanged",
                    )
                )
                continue

            values, counts = np.unique(tooth_neighbours, return_counts=True)
            parent_tooth_class = int(values[np.argmax(counts)])  # np.unique sorts values -> deterministic smallest-id tie-break
            new_label = parent_tooth_class + CANAL_TO_TOOTH_CLASS_OFFSET
            changed = new_label != canal_label
            if changed:
                output[component_mask] = new_label
            decisions.append(
                CanalInheritanceDecision(
                    canal_label, voxel_count, parent_tooth_class, new_label, changed,
                    f"inherited from parent tooth class {parent_tooth_class}"
                    + ("" if changed else " (already matched)"),
                )
            )

    return output, tuple(decisions)
