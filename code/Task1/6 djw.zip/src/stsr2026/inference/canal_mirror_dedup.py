"""Drop the redundant member when the model predicts a canal AND its mirror.

WHY THIS IS DIFFERENT FROM THE 11 FAILED CANAL FIXES
----------------------------------------------------
``docs/research/07-canal-label-convention-inconsistency.md`` showed the GT canal
labels are ~50/50 inconsistent with the tooth labels, which caps any
"canal inherits its parent tooth's identity" rule at 43.3% on the holdout --
below the model's own 51.1%.  Every previous fix lost because it OVERRODE the
model with such a rule.

This step does not assign identity at all.  It only removes a label the model
itself contradicted: measured on the holdout, 32 of the 34 spurious predicted
canal labels (94.1%) come in mirror pairs -- the model emitted both ``c`` and
``mirror(c)``, plausibly because training supervision for that canal was 50/50
contradictory.  One member of such a pair is necessarily wrong, so dropping one
is a decision the model's own output already forces.

THE BREAK-EVEN THAT DECIDES WHETHER THIS PAYS
---------------------------------------------
IA = hits / |GT labels union predicted labels|, and the two outcomes are
asymmetric:

  * drop the spurious member -> union shrinks by 1, hits unchanged: gain ~ IA/U
  * drop the TRUE member     -> hits fall by 1, but the label is still in GT so
    the union does NOT shrink: loss ~ 1/U

A wrong drop costs more than a right drop gains, so with per-case union U ~ 60
the rule must be right roughly 65% of the time just to break even.  Using voxel
count as the proxy for "which member is spurious" is right 65.6% of the time
(21/32) -- i.e. this sits ON the break-even line, which is why it must be
measured with the official scorer rather than assumed.  ``require_same_parent``
exposes the stricter variant: pairs whose two members share a nearest predicted
tooth are the clearest "one physical canal, two labels" cases (7 of 32), at the
cost of touching far fewer labels.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy import ndimage

from stsr2026.data.canal_pairing import mirror_tooth_class
from stsr2026.training.pseudo_label import (
    CANAL_CLASS_MAX,
    CANAL_CLASS_MIN,
    TOOTH_CLASS_MAX,
    TOOTH_CLASS_MIN,
)

N_CLASSES = CANAL_CLASS_MAX + 1


@dataclass(frozen=True)
class DedupDecision:
    kept: int
    dropped: int
    kept_voxels: int
    dropped_voxels: int
    same_parent: bool


def mirror_canal_class(canal_class: int) -> int:
    """Contralateral canal class, same slot in the mirrored quadrant."""
    if not CANAL_CLASS_MIN <= canal_class <= CANAL_CLASS_MAX:
        raise ValueError(f"{canal_class} is not a canal class")
    offset = CANAL_CLASS_MIN - TOOTH_CLASS_MIN
    return mirror_tooth_class(canal_class - offset) + offset


def _class_stats(volume: np.ndarray) -> tuple[dict[int, int], dict[int, np.ndarray]]:
    counts = np.bincount(volume.ravel(), minlength=N_CLASSES)[1:]
    present = np.arange(1, N_CLASSES)[counts > 0]
    if present.size == 0:
        return {}, {}
    centroids = ndimage.center_of_mass(
        np.ones_like(volume, dtype=np.uint8), volume, present.tolist()
    )
    return (
        {int(c): int(counts[c - 1]) for c in present},
        {int(c): np.asarray(cen) for c, cen in zip(present.tolist(), centroids)},
    )


def dedup_mirror_canals(
    label_volume: np.ndarray,
    *,
    require_same_parent: bool = False,
) -> tuple[np.ndarray, list[DedupDecision]]:
    """Remove the smaller member of every predicted canal/mirror-canal pair.

    Returns the corrected volume and the decisions taken.  Voxels of the dropped
    class are set to background, never reassigned to the kept class -- relabeling
    them would change the binary foreground mask and therefore move image-level
    metrics, which this step must leave untouched.
    """
    counts, centroids = _class_stats(label_volume)
    tooth_centroids = {
        t: cen for t, cen in centroids.items()
        if TOOTH_CLASS_MIN <= t <= TOOTH_CLASS_MAX
    }

    def nearest_tooth(canal_class: int) -> int | None:
        if canal_class not in centroids or not tooth_centroids:
            return None
        centroid = centroids[canal_class]
        return min(
            tooth_centroids,
            key=lambda t: float(np.linalg.norm(centroid - tooth_centroids[t])),
        )

    corrected = label_volume.copy()
    decisions: list[DedupDecision] = []
    handled: set[int] = set()

    for canal in sorted(c for c in counts if CANAL_CLASS_MIN <= c <= CANAL_CLASS_MAX):
        if canal in handled:
            continue
        mirror = mirror_canal_class(canal)
        if mirror not in counts:
            continue
        handled.update({canal, mirror})

        same_parent = nearest_tooth(canal) == nearest_tooth(mirror)
        if require_same_parent and not same_parent:
            continue
        if counts[canal] == counts[mirror]:
            continue  # no basis to choose; leave both rather than guess

        dropped = canal if counts[canal] < counts[mirror] else mirror
        kept = mirror if dropped == canal else canal
        corrected[corrected == dropped] = 0
        decisions.append(DedupDecision(
            kept=kept, dropped=dropped,
            kept_voxels=counts[kept], dropped_voxels=counts[dropped],
            same_parent=same_parent,
        ))

    return corrected, decisions
