"""Geometry-preserving inference I/O shared by the Docker entrypoint.

The official 2026 Docker input/output contract (single case vs. batch mount,
exact output filename) is not published yet, so :func:`run_inference` mirrors
the 2025 template's ``/inputs`` -> ``/outputs`` directory convention but keeps
the *same* filename as the input (matching ``stsr2026.submission.validator``,
which requires exact name matches) rather than the 2025 template's
``_mask`` suffix. Revisit once the organizers confirm plan.md section 8, Q1.
"""
from __future__ import annotations

from pathlib import Path
from typing import Callable

import nibabel as nib
import numpy as np

from stsr2026.data.audit import find_niftis

PredictFn = Callable[[np.ndarray], np.ndarray]


def fake_predict(image: np.ndarray) -> np.ndarray:
    """All-background placeholder prediction, valid in the 0-64 label range."""
    return np.zeros(image.shape, dtype=np.uint8)


def predict_case(image_path: Path, output_path: Path, predict_fn: PredictFn = fake_predict) -> None:
    source = nib.load(str(image_path))
    image = np.asanyarray(source.dataobj)
    prediction = predict_fn(image)
    if prediction.shape != image.shape:
        raise ValueError(f"{image_path}: prediction shape {prediction.shape} != input shape {image.shape}")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    out = nib.Nifti1Image(prediction.astype(np.uint8), source.affine, source.header)
    out.header.set_data_dtype(np.uint8)
    nib.save(out, str(output_path))


def run_inference(input_dir: Path, output_dir: Path, predict_fn: PredictFn = fake_predict) -> list[Path]:
    """Predict every case in ``input_dir`` and write same-named files to ``output_dir``."""
    written = []
    for image_path in find_niftis(input_dir):
        output_path = output_dir / image_path.name
        predict_case(image_path, output_path, predict_fn)
        written.append(output_path)
    return written
