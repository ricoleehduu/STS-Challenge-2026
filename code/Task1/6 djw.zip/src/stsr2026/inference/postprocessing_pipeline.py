"""Compose the validated post-processing steps, in order, and apply them to
an already-written prediction file -- plan.md D7's "integrate into the real
inference pipeline" step.

Three steps, in this fixed order:

1. ``correct_lr_confusion`` (tooth left/right correction) -- already
   committed to ``main``, already validated on real Codabench hidden GT
   (+0.205 ``Challenge_Score``). Needs no ground truth. **Always applied.**
2. GT-free teeth-only false-positive cleanup: ``clean_or_relabel_false_positive_labels``
   called with ``gt_labels=None`` and ``gtfree_options=GTFreeOptions(clean_classes="teeth")``,
   at ``DEFAULT_SMALL_VOLUME_THRESHOLD``. Candidates are derived purely from
   the prediction itself via ``identify_gtfree_fp_candidates`` (duplicate
   same-label components, per-quadrant FDI-slot overcount, spatial isolation
   -- the OT-dustbin signal stays off, matching ``GTFreeOptions``'s own
   conservative default). ``clean_classes="teeth"`` means canal labels
   (33-64) are categorically excluded from every signal and therefore never
   touched by this step, by construction -- this is the setting real-data
   validation on the 6-case holdout confirmed safe (``taskG-teeth-only``: IA
   0.5472 -> 0.5518, mIoU +0.006, tooth Dice_Instance up, all four canal
   metrics EXACTLY unchanged versus the ``baseline_lrfix_v2`` reference, see
   ``docs/research/08-gtfree-fp-cleanup-design.md``). Needs no ground truth.
   **Always applied**, independent of this function's own ``gt_labels``
   argument.
3. The original GT-informed ``clean_or_relabel_false_positive_labels`` at
   ``DEFAULT_SMALL_VOLUME_THRESHOLD`` -- subsumes both the already-adopted
   small-volume false-positive cleanup AND the large-tooth-false-positive
   neighbour-relabel validated on the 6-case holdout (bit-for-bit identical
   to the ground-truth-informed version there, see plan.md D7's Task D
   real-data comparison). Needs ``gt_labels``. **Only applied when
   ``gt_labels`` is given** (offline evaluation against a known holdout,
   e.g. ``scripts/evaluate_checkpoint.py`` -- never available for the real
   Docker submission's hidden test cases).

ARCHITECTURAL GAP -- ONE SIDE NOW RESOLVED, READ BEFORE TOUCHING THIS MODULE:
--------------------------------------------------------------------------
Step 3 needs ``gt_labels`` -- the set of class labels actually present in a
case's ground truth -- to decide which predicted labels are "false-positive
candidates" in the first place. That is a correct, deliberate design for
OFFLINE evaluation (this repo's 6-case local holdout, where real GT exists
to score against). The REAL Docker inference pipeline processes the
organizers' hidden test cases with **no ground truth available at all**, so
step 3 is permanently unavailable there and stays gated on ``gt_labels is
not None`` -- there is still no trustworthy expected-label-set source for a
single case's prediction alone (the closest existing attempt,
``stsr2026.training.pseudo_label.EXPECTED_CANAL_COUNT_RANGE``, is a
per-FDI-position canal-*count* prior, not a full expected-label-set, and
only covers canals, not teeth).

Step 2 closes the equivalent gap for the TEETH side (D7 Day 1 follow-up,
real-data-validated 2026-07-18, see ``docs/research/08-gtfree-fp-cleanup-design.md``
and ``docs/experiment-log.md``'s ``taskG-teeth-only`` row): it derives its own
candidate set GT-free via ``identify_gtfree_fp_candidates`` instead of
screening against ground truth, so it is a real, measured net win with
``gt_labels=None`` and now runs unconditionally, before step 3, for every
caller including the real Docker submission. The CANAL side of the gap
remains open on purpose -- canals fragment naturally into many small
components as real anatomy, so ``clean_classes="all"`` (which would make
canal labels eligible for cleanup too) is deliberately NOT used here; the
6-case holdout run that tried it cratered canal Dice_Instance/NSD despite
raising IA (see that same design doc's "REAL-DATA FINDING" section). Wiring
this into ``checkpoint_runner.py``/the Docker entrypoint therefore delivers
BOTH step 1's already-proven L/R win AND step 2's now-validated GT-free
teeth-FP win to the real submission, with ``gt_labels=None``, while step 3
stays coded, tested, and available for offline evaluation contexts (or
once/if the canal-side ``gt_labels``-sourcing question is separately
resolved) -- that remaining decision is still a product decision for the
team, not something resolved unilaterally here.
"""
from __future__ import annotations

from pathlib import Path
from typing import AbstractSet

import nibabel as nib
import numpy as np

from stsr2026.inference.false_positive_cleanup import (
    GTFreeOptions,
    clean_or_relabel_false_positive_labels,
)
from stsr2026.inference.lr_correction import correct_lr_confusion

DEFAULT_SMALL_VOLUME_THRESHOLD = 5000
DEFAULT_DILATION_VOXELS = 2

# Step 2's GT-free candidate identification is deliberately pinned to
# "teeth" here -- see module docstring -- regardless of any future change to
# GTFreeOptions's own default, so this module's behaviour cannot silently
# drift into touching canal labels just because someone changes
# false_positive_cleanup.DEFAULT_CLEAN_CLASSES for an unrelated caller.
_GTFREE_TEETH_ONLY_OPTIONS = GTFreeOptions(clean_classes="teeth")


def apply_postprocessing_chain(
    label_volume: np.ndarray,
    affine: np.ndarray,
    gt_labels: AbstractSet[int] | None = None,
    volume_threshold: int = DEFAULT_SMALL_VOLUME_THRESHOLD,
    dilation_voxels: int = DEFAULT_DILATION_VOXELS,
) -> np.ndarray:
    """Apply the validated post-processing chain to one in-memory label volume.

    Step 1 (``correct_lr_confusion``) always runs. Step 2 (GT-free
    teeth-only false-positive cleanup) always runs too, with
    ``gt_labels=None`` internally -- independent of this function's own
    ``gt_labels`` argument -- and never touches canal labels (33-64) by
    construction (``clean_classes="teeth"``). Step 3 (the original
    GT-informed ``clean_or_relabel_false_positive_labels``) only runs when
    this function's ``gt_labels`` argument is not ``None`` -- see module
    docstring for why real Docker inference currently has no ``gt_labels``
    to supply for that step.
    """
    corrected = correct_lr_confusion(label_volume, affine)
    teeth_cleaned, _ = clean_or_relabel_false_positive_labels(
        corrected,
        gt_labels=None,
        volume_threshold=volume_threshold,
        dilation_voxels=dilation_voxels,
        affine=affine,
        gtfree_options=_GTFREE_TEETH_ONLY_OPTIONS,
    )
    if gt_labels is None:
        return teeth_cleaned
    cleaned, _ = clean_or_relabel_false_positive_labels(
        teeth_cleaned, gt_labels, volume_threshold, dilation_voxels=dilation_voxels
    )
    return cleaned


def apply_postprocessing_to_prediction_file(
    output_path: Path,
    gt_labels: AbstractSet[int] | None = None,
    volume_threshold: int = DEFAULT_SMALL_VOLUME_THRESHOLD,
    dilation_voxels: int = DEFAULT_DILATION_VOXELS,
) -> bool:
    """Read a written prediction NIfTI, apply :func:`apply_postprocessing_chain`,
    and overwrite it in place if anything changed.

    Deliberately pure file I/O (nibabel) plus already-tested, GPU-free pure
    array functions -- no nnunetv2/torch import, no dependency on anything
    inside ``stsr2026.inference.streaming_export``. This is the whole point
    of the "post-write" integration design: it runs strictly AFTER
    ``predict_case_streaming`` has already finished writing its output file,
    so it never touches that module's memory-sensitive sliding-window/
    chunking internals (currently a high-churn, high-risk area with
    multiple in-flight OOM fixes and a teammate's parallel branch working in
    the same file -- see plan.md D7's integration notes).

    Returns ``True`` if the file was rewritten, ``False`` if the
    post-processing chain made no change (avoids a redundant write in the
    common case where steps 1 and 2 both find nothing to flip/clean and
    step 3 is skipped -- no ``gt_labels`` -- or also finds nothing to clean).
    """
    image = nib.load(str(output_path))
    labels = np.asanyarray(image.dataobj)
    corrected = apply_postprocessing_chain(labels, image.affine, gt_labels, volume_threshold, dilation_voxels)
    if np.array_equal(corrected, labels):
        return False
    nib.save(
        nib.Nifti1Image(corrected.astype(image.get_data_dtype()), image.affine, image.header.copy()),
        str(output_path),
    )
    return True
