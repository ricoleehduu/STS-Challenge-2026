"""GT-free global instance-to-FDI-slot reassignment via entropy-regularized
optimal transport (Sinkhorn), constrained per (category, quadrant).

CONTEXT -- read ``docs/experiment-log.md``'s ``Day1-TaskE-Hungarian-default``
entry (and the root-cause diagnosis right after it) before touching this
module. That entry is a *real*, measured failure of a hard one-to-one
Hungarian version of this same idea (``hungarian_instance_assignment.py``):
on the real 6-case holdout, every instance/NSD/IA/mIoU metric got WORSE (IA
-0.0437), and a 21-decision GT audit found 0/21 correct relabels. The
post-mortem pinned two independent, concrete root causes:

1. ``_category_distance_scale`` normalized every candidate's distance-from-
   midline by ``np.max()`` over the whole case -- a single small (180-voxel,
   just above the noise floor) misplaced component sitting at an
   anatomically-impossible distance (52.9mm) silently became the
   normalization denominator, compressing every real candidate's normalized
   position toward 0 and corrupting the whole quadrant's assignment.
2. Same-label connected-component fragments (a canal split into 8-12 pieces
   by the segmentation model) were treated as independent candidates
   competing for *separate* slots, scattering one already-imperfect instance
   across 4-5 different final labels instead of consolidating it.

Crucially, the diagnosis also *confirmed* (real-GT correlation check,
``scripts/validate_order_assumption.py``, mean Spearman rho=0.872, 96% of
quadrant groups rho>0.5) that the underlying idea -- distance-from-midline
increases monotonically with FDI position-in-quadrant, so a global
assignment problem is a sound way to fix locally-confused adjacent-position
labels -- is NOT what failed. Only the implementation was fragile. This
module keeps the sound idea and structurally redesigns the two fragile
parts, rather than re-tuning the same brittle mechanism:

STRUCTURAL FIX 1 -- FRAGMENTS
------------------------------
Same-predicted-label connected components within one (category, quadrant)
group are merged into a single candidate (summed voxel count, voxel-count-
weighted mean centroid) *before* the cost matrix is built at all -- see
``_merge_same_label_components``. This directly eliminates the case_021-style
failure (one canal, 9 fragments, same label, scattered across 4-5 slots by
Hungarian) at the source: the 9 fragments become exactly one candidate, so
there is nothing left to scatter. On top of that, the optimal-transport
solve itself is *soft*: a losing candidate's mass does not have to be
dumped onto whatever real slot is cheapest next (Hungarian's rectangular
solve forces every one of up to 8 candidates into a distinct real slot,
which is precisely how fragments-turned-independent-candidates corrupted
OTHER, unrelated positions). Here a candidate that loses its preferred slot
(see the dustbin mechanism below) is routed to a dedicated non-anatomical
"trash" outcome instead of forced onto a second real slot it does not
actually belong to.

STRUCTURAL FIX 2 -- OUTLIERS / FALSE POSITIVES
------------------------------------------------
``_category_distance_scale`` (this module's version) replaces ``np.max()``
with a **voxel-count-weighted high quantile** (default p90,
``distance_scale_quantile``) of the per-component distance-from-midline
distribution, pooled across all four quadrants for that category (tooth or
canal), exactly mirroring the *scope* of the original global scale (see that
function's docstring for why per-quadrant-only scaling is unsound) but not
its *sensitivity to a single point*. A component with a small voxel count
contributes a small weight to the quantile estimate, so a 180-voxel noise
blob sitting at 52.9mm can no longer single-handedly define the
normalization denominator the way ``np.max()`` did -- it needs enough
combined mass near the tail to shift the p90 point, which one outlier alone
essentially never has. Separately, this module adds an explicit **dustbin
("trash") slot** per (category, quadrant) group via unbalanced optimal
transport (see below) -- a genuine false-positive candidate that does not
fit any real slot well can be assigned to the dustbin instead of being
force-fit into the least-bad real slot, which is what a plain (non-
rectangular, non-rejecting) assignment would otherwise do.

WHY OPTIMAL TRANSPORT, NOT JUST "HUNGARIAN WITH A BETTER SCALE"
--------------------------------------------------------------------
Fixing the scale alone would already address root cause 1. This module goes
further and also replaces the *solver*, for two reasons documented in the
Hungarian module's own post-mortem:

- Hungarian's docstring records a **proven-false** attempt to fold a reject
  option directly into the cost matrix via same-sized dummy opt-out
  rows/columns (a 2x2 counterexample showed the "both sides pay independently"
  cost of opting out is ``2 * reject_cost_threshold``, not
  ``reject_cost_threshold`` -- the intended guarantee does not hold). Its
  shipped version instead used a *post-hoc* filter on the unconstrained
  solve, with the documented, accepted limitation that filtering after the
  fact cannot let the solver re-optimize the rest of a group once a pair is
  dropped.
- This module's dustbin is not a same-sized dummy block -- it follows the
  standard "optimal transport with a dustbin" construction used for
  learned soft assignment (Sarlin et al. 2020, SuperGlue, section 3.2): one
  extra dustbin row and one extra dustbin column, with dustbin row mass set
  to the number of real slots (8) and dustbin column mass set to the number
  of real candidates (n) -- so total supply and demand stay exactly balanced
  (``n + 8`` on each side) for *any* n, and a losing candidate's "reservation
  price" is paid out of a shared pool rather than a private dummy partner,
  avoiding the specific bug Hungarian's docstring found and rejected.

ENTROPIC REGULARIZATION (why "soft" helps with near-ties)
------------------------------------------------------------
The Sinkhorn solve (``sinkhorn_log_domain``, self-contained, log-domain
Cuturi 2013) does not pick a single discrete optimum the way
``linear_sum_assignment`` does; it converges to a smooth transport plan
where mass spreads roughly proportionally to ``exp(-cost / reg)``. For two
candidates whose real costs to a slot are close together (a genuine near-
tie, e.g. two adjacent-position teeth of similar distance from midline),
this produces a graded preference rather than an arbitrary hard pick that
can cascade into a different wrong pick elsewhere in the same solve -- the
kind of "one flipped bit changes everything downstream" brittleness a
combinatorial solver is prone to when two rows/columns of a cost matrix are
nearly degenerate.

SOFT -> HARD READOUT
------------------------
Every real (candidate, slot) decision must ultimately become one concrete
relabel, so after Sinkhorn converges this module reads the plan out with a
**mutual-argmax** rule (also from SuperGlue): candidate *i* is accepted for
real slot *j* only if slot *j* is candidate *i*'s highest-mass column AND
candidate *i* is slot *j*'s highest-mass row among the real (non-dustbin)
candidates. Any candidate that does not clear this bar (its own best column
was the dustbin, or it lost the mutual check to a competitor) is reported as
a dustbin outcome and its original label is left untouched -- mirroring
Hungarian's own "unmatched candidates keep their original label" contract
(cleanup of a genuinely unmatched component is ``false_positive_cleanup.py``'s
job, not this module's).

GT-FREE BY CONSTRUCTION
-------------------------
Same guarantee as ``hungarian_instance_assignment.py``: the 65 FDI slots (1
background, 32 teeth, 32 canals) are the fixed prior from
``stsr2026.training.pseudo_label.FDI_ORDER`` -- not any case's actual GT
label set. Every quantity this module's cost matrix or Sinkhorn solve
touches (component centroid, voxel count, current predicted label, the
case's own midline estimate) is derived from the prediction volume alone.
This function never accepts a ``gt_labels`` argument.

SCOPE BOUNDARY -- THIS DOES NOT AND CANNOT FIX LEFT/RIGHT CONFUSION
------------------------------------------------------------------------
Exactly like ``hungarian_instance_assignment.py`` (see its module docstring
for the full reasoning, unchanged here): candidates are grouped strictly by
(category, quadrant) using each component's *current* predicted label to
decide which quadrant's 8 slots it competes for. There is no cross-quadrant
transport anywhere in this module -- a canal or tooth component currently
labeled into the wrong quadrant (an L/R mirror confusion) stays grouped with
that wrong quadrant's slots and this module cannot move it to the correct
side. This is a deliberate, load-bearing constraint (not an oversight): it
is what makes it structurally impossible for this module to smear left/right
identity for near-midline canals, per the task's explicit requirement, and
per ``docs/research/06-2026-improvement-survey.md`` section 3's note that
FDI ordering is mesiodistal only and does not by itself resolve L/R.

NO SOFTMAX AVAILABLE
------------------------
Same constraint as the Hungarian module: ``streaming_export.py`` never
writes probabilities, so the label-consistency term is a binary
match/mismatch flag against each candidate's current predicted label, not a
softmax-informed cost.

KNOWN LIMITATIONS (found during this module's own synthetic testing, not
hypothesized -- see ``tests/test_ot_instance_assignment.py`` for the exact
reproductions)
----------------------------------------------------------------------------
1. **Same-label merge can conflate two unrelated components.** The merge
   step (structural fix 1) assumes every same-label component within a
   (category, quadrant) group is a fragment of ONE true instance. When two
   genuinely different physical structures happen to carry the identical
   wrong label (a rarer coincidence than plain fragmentation -- it requires
   two separate blobs to land on the exact same wrong class id, not just
   any two blobs breaking off one real instance), the merge combines their
   centroids by voxel-count-weighted average, which can pull the resulting
   single candidate to a position that matches neither original component
   well and can, in the joint solve, displace a correctly-labeled neighbour.
   See ``test_same_label_merge_can_conflate_two_unrelated_components``,
   which documents the current, checked behaviour rather than hiding it.
   Mitigating this (e.g. a spatial-proximity gate on which same-label
   components are allowed to merge) was considered but not implemented:
   the real ``case_021`` fragmentation this module targets is explicitly
   described in the Hungarian post-mortem as "spatially dispersed"
   fragments of one canal, so a naive distance cutoff risks excluding the
   exact fragments this fix exists to consolidate. Left as a documented
   risk for real-data validation to quantify, not resolved here.
2. **The dustbin's practical activation threshold is not simply "cost >
   dustbin_cost".** Because the SuperGlue-style construction gives the
   dustbin row/column shared, pooled mass (8 and n respectively, not a
   private per-candidate reservation), a sparsely-populated group's spare
   dustbin-row mass often ends up "buying" an otherwise-uncontested real
   slot more cheaply than routing a specific bad candidate through the
   scarce dustbin column would cost the system overall -- empirically, an
   isolated bad candidate with no direct competitor for its best real slot
   very rarely reaches the dustbin under default weights, even when its
   real cost there exceeds ``dustbin_cost``. Reliable dustbin rejection was
   confirmed for genuine, no-fallback competition (see
   ``test_solve_group_routes_doubly_outcompeted_candidate_to_dustbin``,
   modeled on the classic "more candidates than slots" scenario), which is
   the situation that actually matters for this module's target failure
   mode (a duplicate stealing another instance's identity) -- but this is a
   narrower guarantee than "any sufficiently bad candidate gets trashed,"
   and real-data validation should check whether ``dustbin_cost`` needs
   retuning for the case mix actually seen in the 6-case holdout.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy import ndimage
from scipy.special import logsumexp

from stsr2026.training.pseudo_label import (
    CANAL_CLASS_MIN,
    TOOTH_CLASS_MAX,
    TOOTH_CLASS_MIN,
)

# Kept numerically identical to lr_correction.py / hungarian_instance_assignment.py's
# own noise floor, duplicated rather than imported for the same
# independent-module-auditability reason those modules give.
MIN_COMPONENT_VOXELS = 5

QUADRANT_SIZE = 8
NUM_QUADRANTS = 4
CATEGORIES: tuple[str, ...] = ("tooth", "canal")

DEFAULT_ORDER_WEIGHT = 0.6
DEFAULT_LABEL_MISMATCH_COST = 0.4
DEFAULT_DUSTBIN_COST = 0.5
# High (not max) quantile, weighted by voxel count -- see module docstring's
# "STRUCTURAL FIX 2" section for why this replaces np.max().
DEFAULT_DISTANCE_SCALE_QUANTILE = 0.9
DEFAULT_SINKHORN_REG = 0.05
DEFAULT_SINKHORN_MAX_ITER = 200
DEFAULT_SINKHORN_TOL = 1e-9


# ---------------------------------------------------------------------------
# Self-contained log-domain Sinkhorn (Cuturi 2013). No POT/``ot`` dependency
# exists in this repo (checked: ``import ot`` fails, nothing in pyproject.toml)
# and the task calls for staying self-contained rather than adding one.
# ---------------------------------------------------------------------------


def sinkhorn_log_domain(
    cost: np.ndarray,
    a: np.ndarray,
    b: np.ndarray,
    reg: float = DEFAULT_SINKHORN_REG,
    max_iter: int = DEFAULT_SINKHORN_MAX_ITER,
    tol: float = DEFAULT_SINKHORN_TOL,
) -> np.ndarray:
    """Entropy-regularized optimal transport, solved in log domain for
    numerical stability (the naive ``exp(-cost/reg)`` kernel underflows for
    small ``reg``; the log-domain update never exponentiates a raw cost).

    Solves ``min_P <P, cost> + reg * KL(P || a (x) b)`` subject to
    ``P @ ones == a`` and ``P.T @ ones == b`` (the balanced OT problem),
    via alternating dual updates (Sinkhorn-Knopp in log space)::

        f_i = reg * (log(a_i) - logsumexp_j((g_j - cost_ij) / reg))
        g_j = reg * (log(b_j) - logsumexp_i((f_i - cost_ij) / reg))
        P_ij = exp((f_i + g_j - cost_ij) / reg)

    Parameters
    ----------
    cost:
        ``(n, m)`` non-negative cost matrix.
    a, b:
        Row/column marginals (supply/demand). ``sum(a)`` must equal
        ``sum(b)`` (balanced OT) -- callers needing an unbalanced problem
        (this module's dustbin mechanism) must construct that balance
        explicitly beforehand, see ``_solve_group`` for how.
    reg:
        Entropic regularization strength. Smaller values track the exact
        (Hungarian-equivalent) optimal transport plan more closely but
        converge more slowly and are more prone to numerical underflow;
        larger values smooth the plan more (useful for near-tie robustness,
        see module docstring) at the cost of blurring genuinely different
        options together.
    max_iter, tol:
        Stop after ``max_iter`` iterations or once the max absolute change
        in the row dual ``f`` between iterations drops below ``tol``,
        whichever comes first.

    Returns
    -------
    ``(n, m)`` transport plan ``P`` with (approximately, subject to ``tol``)
    ``P.sum(axis=1) == a`` and ``P.sum(axis=0) == b``.
    """
    cost = np.asarray(cost, dtype=np.float64)
    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    if cost.ndim != 2:
        raise ValueError(f"cost must be 2-dimensional, got shape {cost.shape}")
    if a.shape != (cost.shape[0],):
        raise ValueError(f"a must have shape ({cost.shape[0]},), got {a.shape}")
    if b.shape != (cost.shape[1],):
        raise ValueError(f"b must have shape ({cost.shape[1]},), got {b.shape}")
    if not np.isclose(a.sum(), b.sum(), rtol=1e-9, atol=1e-6):
        raise ValueError(
            f"balanced OT requires sum(a) == sum(b), got sum(a)={a.sum()!r} sum(b)={b.sum()!r}"
        )
    if reg <= 0:
        raise ValueError(f"reg must be > 0, got {reg}")

    log_a = np.log(np.clip(a, 1e-300, None))
    log_b = np.log(np.clip(b, 1e-300, None))
    f = np.zeros_like(a)
    g = np.zeros_like(b)
    for _ in range(max_iter):
        f_prev = f
        f = reg * (log_a - logsumexp((g[None, :] - cost) / reg, axis=1))
        g = reg * (log_b - logsumexp((f[:, None] - cost) / reg, axis=0))
        if np.max(np.abs(f - f_prev)) < tol:
            break
    log_plan = (f[:, None] + g[None, :] - cost) / reg
    return np.exp(log_plan)


def _weighted_quantile(values: np.ndarray, weights: np.ndarray, quantile: float) -> float:
    """Weighted quantile via linear interpolation on the weighted empirical
    CDF (the standard "Type 7"-analogue recipe for weighted data: each
    point's CDF position is its cumulative weight up to its own midpoint,
    normalized by total weight). Used instead of ``np.max()`` for the
    distance-scale calibration -- see module docstring's "STRUCTURAL FIX 2".

    A component contributes to the quantile in proportion to its voxel
    count, so a small outlier component needs far more company at the tail
    to move a high quantile than it needs to move ``np.max()`` (which any
    single point, regardless of size, can dominate).
    """
    values = np.asarray(values, dtype=np.float64)
    weights = np.asarray(weights, dtype=np.float64)
    if values.size == 0:
        raise ValueError("values must be non-empty")
    order = np.argsort(values)
    values = values[order]
    weights = weights[order]
    cum_weights = np.cumsum(weights) - 0.5 * weights
    cum_weights /= weights.sum()
    return float(np.interp(quantile, cum_weights, values))


def _quadrant_class_range(category: str, quadrant_index: int) -> tuple[int, int]:
    """Inclusive (start, end) class-id range for one (category, quadrant)
    group -- identical convention to ``hungarian_instance_assignment.py``
    (Q1=1-8, Q2=9-16, Q3=17-24, Q4=25-32 for teeth; canal = tooth + 32)."""
    if category == "tooth":
        base = TOOTH_CLASS_MIN
    elif category == "canal":
        base = CANAL_CLASS_MIN
    else:
        raise ValueError(f"category must be 'tooth' or 'canal', got {category!r}")
    start = base + quadrant_index * QUADRANT_SIZE
    return start, start + QUADRANT_SIZE - 1


def _slot_class_id(category: str, quadrant_index: int, position_in_quadrant: int) -> int:
    """``position_in_quadrant`` is 1-indexed (1 = central incisor .. 8 = 3rd molar)."""
    start, _ = _quadrant_class_range(category, quadrant_index)
    return start + position_in_quadrant - 1


def _world_x(indices: np.ndarray, affine: np.ndarray) -> np.ndarray:
    """Identical formula to ``lr_correction._world_x`` / the Hungarian
    module's own copy -- duplicated, not imported, for the same
    module-independence reason those modules document."""
    return indices @ affine[0, :3] + affine[0, 3]


@dataclass(frozen=True)
class _RawComponent:
    """One connected component, pre-merge."""

    category: str
    quadrant_index: int
    original_label: int
    component_id: int
    voxel_count: int
    centroid_world_x: float


@dataclass(frozen=True)
class Candidate:
    """One or more same-label connected components merged into a single OT
    candidate -- see module docstring's "STRUCTURAL FIX 1"."""

    category: str
    quadrant_index: int
    original_label: int
    component_ids: tuple[int, ...]
    voxel_count: int
    centroid_world_x: float


@dataclass(frozen=True)
class MatchedAssignment:
    """One candidate accepted (mutual-argmax) for one real FDI slot."""

    category: str
    quadrant_index: int
    original_label: int
    component_ids: tuple[int, ...]
    voxel_count: int
    slot_class_id: int
    slot_position_in_quadrant: int  # 1-8
    transport_mass: float  # P[candidate, slot] in the converged Sinkhorn plan
    order_cost: float
    label_mismatch_cost: float
    total_cost: float
    new_label: int  # == original_label when unchanged
    changed: bool


@dataclass(frozen=True)
class DustbinAssignment:
    """A candidate (or a too-small raw component) that did not receive a
    real FDI slot -- left with its original label, completely untouched,
    exactly like Hungarian's ``UnmatchedCandidate`` contract."""

    category: str
    quadrant_index: int
    original_label: int
    component_ids: tuple[int, ...]
    voxel_count: int
    reason: str  # "too_small" | "routed_to_dustbin" | "lost_slot_competition"


@dataclass(frozen=True)
class EmptySlot:
    """An FDI slot that received no accepted candidate."""

    category: str
    quadrant_index: int
    slot_class_id: int
    slot_position_in_quadrant: int
    reason: str  # "no_candidate_in_group" | "no_accepted_candidate"


@dataclass(frozen=True)
class OTAssignmentResult:
    output_volume: np.ndarray
    matched: tuple[MatchedAssignment, ...]
    dustbin: tuple[DustbinAssignment, ...]
    empty_slots: tuple[EmptySlot, ...]
    # Keyed by (category, quadrant_index) -> the converged augmented
    # (n_candidates + 1, 9) transport plan actually solved for that group
    # (last row/column is the dustbin), for auditing. A group with zero
    # candidates is omitted.
    transport_plans: dict[tuple[str, int], np.ndarray]


def _collect_components(
    label_volume: np.ndarray,
    affine: np.ndarray,
    category: str,
    quadrant_index: int,
    min_component_voxels: int,
) -> tuple[list[_RawComponent], list[_RawComponent]]:
    """Enumerate connected components for one (category, quadrant) group.

    Returns ``(kept, too_small)`` -- ``too_small`` components fall below
    ``min_component_voxels`` and are excluded from every downstream step
    (merging, scale calibration, the OT solve itself); ``kept`` feeds both
    the robust distance-scale calibration and (after merging) the
    candidate set for the solve.
    """
    start, end = _quadrant_class_range(category, quadrant_index)
    kept: list[_RawComponent] = []
    too_small: list[_RawComponent] = []
    for class_id in range(start, end + 1):
        mask = label_volume == class_id
        if not np.any(mask):
            continue
        component_labels, component_count = ndimage.label(mask)
        for component_id in range(1, component_count + 1):
            component_mask = component_labels == component_id
            voxel_count = int(np.count_nonzero(component_mask))
            indices = np.argwhere(component_mask)
            centroid_x = float(np.mean(_world_x(indices, affine)))
            record = _RawComponent(
                category=category,
                quadrant_index=quadrant_index,
                original_label=class_id,
                component_id=component_id,
                voxel_count=voxel_count,
                centroid_world_x=centroid_x,
            )
            (kept if voxel_count >= min_component_voxels else too_small).append(record)
    return kept, too_small


def _merge_same_label_components(components: list[_RawComponent]) -> list[Candidate]:
    """Merge connected components sharing the same ``original_label`` into
    one :class:`Candidate` each -- voxel-count-weighted mean centroid, summed
    voxel count. See module docstring's "STRUCTURAL FIX 1": this is what
    turns a canal split into 9 fragments (case_021, same label, per the
    Hungarian post-mortem) back into exactly one candidate before the cost
    matrix is even built, rather than relying on the OT solve alone to
    avoid scattering them.
    """
    by_label: dict[int, list[_RawComponent]] = {}
    for component in components:
        by_label.setdefault(component.original_label, []).append(component)

    candidates: list[Candidate] = []
    for label, group in sorted(by_label.items()):
        total_voxels = sum(c.voxel_count for c in group)
        weighted_centroid = sum(c.centroid_world_x * c.voxel_count for c in group) / total_voxels
        candidates.append(
            Candidate(
                category=group[0].category,
                quadrant_index=group[0].quadrant_index,
                original_label=label,
                component_ids=tuple(sorted(c.component_id for c in group)),
                voxel_count=total_voxels,
                centroid_world_x=weighted_centroid,
            )
        )
    return candidates


def _category_distance_scale(
    components: list[_RawComponent], midline_x: float | None, quantile: float
) -> float | None:
    """Voxel-count-weighted ``quantile`` (default p90) of distance-from-
    midline over all kept components of one category, pooled across all
    four quadrants -- see module docstring's "STRUCTURAL FIX 2" for why this
    replaces the failed ``np.max()`` version. Returns ``None`` when there is
    nothing to calibrate against (no components, no midline, or every
    component sits exactly at the midline).
    """
    if not components or midline_x is None:
        return None
    distances = np.array([abs(c.centroid_world_x - midline_x) for c in components])
    weights = np.array([c.voxel_count for c in components], dtype=np.float64)
    scale = _weighted_quantile(distances, weights, quantile)
    return scale if scale > 0 else None


def _solve_group(
    candidates: list[Candidate],
    category: str,
    quadrant_index: int,
    normalized_rank: np.ndarray,
    order_weight: float,
    label_mismatch_cost: float,
    dustbin_cost: float,
    sinkhorn_reg: float,
    sinkhorn_max_iter: int,
) -> tuple[np.ndarray, np.ndarray]:
    """Build the real (n, 8) cost matrix, augment it with a SuperGlue-style
    dustbin row/column, solve entropic OT, and return ``(real_cost, plan)``
    where ``plan`` has shape ``(n + 1, 9)`` (last row/column = dustbin).
    """
    n = len(candidates)
    real_cost = np.empty((n, QUADRANT_SIZE), dtype=np.float64)
    for i, candidate in enumerate(candidates):
        for position in range(1, QUADRANT_SIZE + 1):
            slot_class_id = _slot_class_id(category, quadrant_index, position)
            normalized_slot_position = (position - 1) / (QUADRANT_SIZE - 1)
            order_cost = abs(float(normalized_rank[i]) - normalized_slot_position)
            mismatch_cost = 0.0 if candidate.original_label == slot_class_id else 1.0
            real_cost[i, position - 1] = order_weight * order_cost + label_mismatch_cost * mismatch_cost

    # Augmented (n+1, 9) cost: dustbin row/column priced at dustbin_cost,
    # dustbin-dustbin corner free (it only absorbs leftover mass once real
    # supply/demand is satisfied -- see module docstring's dustbin section).
    aug_cost = np.full((n + 1, QUADRANT_SIZE + 1), dustbin_cost, dtype=np.float64)
    aug_cost[:n, :QUADRANT_SIZE] = real_cost
    aug_cost[n, QUADRANT_SIZE] = 0.0

    # Dustbin row mass = number of real slots, dustbin column mass = number
    # of real candidates -- keeps total supply == total demand == n + 8 for
    # any n (SuperGlue section 3.2 convention), see module docstring.
    a = np.concatenate([np.ones(n), [float(QUADRANT_SIZE)]])
    b = np.concatenate([np.ones(QUADRANT_SIZE), [float(n)]])

    plan = sinkhorn_log_domain(aug_cost, a, b, reg=sinkhorn_reg, max_iter=sinkhorn_max_iter)
    return real_cost, plan


def assign_instances_to_fdi_slots(
    label_volume: np.ndarray,
    affine: np.ndarray,
    order_weight: float = DEFAULT_ORDER_WEIGHT,
    label_mismatch_cost: float = DEFAULT_LABEL_MISMATCH_COST,
    dustbin_cost: float = DEFAULT_DUSTBIN_COST,
    distance_scale_quantile: float = DEFAULT_DISTANCE_SCALE_QUANTILE,
    sinkhorn_reg: float = DEFAULT_SINKHORN_REG,
    sinkhorn_max_iter: int = DEFAULT_SINKHORN_MAX_ITER,
    min_component_voxels: int = MIN_COMPONENT_VOXELS,
) -> OTAssignmentResult:
    """Reassign each quadrant's predicted connected components to FDI slots
    via one entropy-regularized optimal transport solve per (category,
    quadrant) group. See module docstring for the full design and how it
    addresses the two root causes found in ``hungarian_instance_assignment.py``'s
    real-data failure.

    ``label_volume`` should already have had ``lr_correction.correct_lr_confusion``
    applied to its tooth classes (1-32) -- same precondition as the Hungarian
    module, for the same reason (this function trusts a component's current
    label to pick its quadrant grouping; see module docstring's scope
    boundary section for canal L/R, which is explicitly out of scope either
    way).

    Parameters
    ----------
    label_volume, affine:
        Same conventions as ``lr_correction.correct_lr_confusion``.
    order_weight, label_mismatch_cost:
        Cost-matrix weights, identical meaning to the Hungarian module.
    dustbin_cost:
        Fixed cost of routing a candidate to the dustbin (or a real slot
        going unfilled by any candidate), and the cost every real slot
        implicitly competes against. A candidate whose best real-slot cost
        exceeds this by enough (after entropic smoothing) will prefer the
        dustbin over a bad real-slot fit.
    distance_scale_quantile:
        The voxel-count-weighted quantile used for the per-category distance
        normalization scale (default p90) -- see module docstring's
        "STRUCTURAL FIX 2".
    sinkhorn_reg, sinkhorn_max_iter:
        Passed through to :func:`sinkhorn_log_domain`.
    min_component_voxels:
        Components smaller than this are excluded entirely (reported as
        :class:`DustbinAssignment` with ``reason="too_small"``), matching
        the noise floor used elsewhere in this repo's post-processing chain.

    Returns
    -------
    :class:`OTAssignmentResult`.
    """
    if label_volume.ndim != 3:
        raise ValueError(f"label_volume must be 3-dimensional, got shape {label_volume.shape}")
    if affine.shape != (4, 4):
        raise ValueError(f"affine must have shape (4, 4), got {affine.shape}")
    if min_component_voxels < 1:
        raise ValueError(f"min_component_voxels must be >= 1, got {min_component_voxels}")
    if not (0.0 < distance_scale_quantile < 1.0):
        raise ValueError(f"distance_scale_quantile must be in (0, 1), got {distance_scale_quantile}")
    if dustbin_cost <= 0:
        raise ValueError(f"dustbin_cost must be > 0, got {dustbin_cost}")

    output = label_volume.copy()

    tooth_indices = np.argwhere((label_volume >= TOOTH_CLASS_MIN) & (label_volume <= TOOTH_CLASS_MAX))
    midline_x = float(np.median(_world_x(tooth_indices, affine))) if tooth_indices.size else None

    # Pass 1: collect raw (pre-merge) components per group, and pool them
    # per category for the robust distance-scale calibration.
    raw_by_group: dict[tuple[str, int], list[_RawComponent]] = {}
    dustbin: list[DustbinAssignment] = []
    pooled_by_category: dict[str, list[_RawComponent]] = {category: [] for category in CATEGORIES}
    for category in CATEGORIES:
        for quadrant_index in range(NUM_QUADRANTS):
            kept, too_small = _collect_components(
                label_volume, affine, category, quadrant_index, min_component_voxels
            )
            raw_by_group[(category, quadrant_index)] = kept
            pooled_by_category[category].extend(kept)
            for record in too_small:
                dustbin.append(
                    DustbinAssignment(
                        category=record.category,
                        quadrant_index=record.quadrant_index,
                        original_label=record.original_label,
                        component_ids=(record.component_id,),
                        voxel_count=record.voxel_count,
                        reason="too_small",
                    )
                )

    category_scale = {
        category: _category_distance_scale(pooled_by_category[category], midline_x, distance_scale_quantile)
        for category in CATEGORIES
    }

    matched: list[MatchedAssignment] = []
    empty_slots: list[EmptySlot] = []
    transport_plans: dict[tuple[str, int], np.ndarray] = {}

    for category in CATEGORIES:
        for quadrant_index in range(NUM_QUADRANTS):
            raw_components = raw_by_group[(category, quadrant_index)]
            if not raw_components:
                for position in range(1, QUADRANT_SIZE + 1):
                    empty_slots.append(
                        EmptySlot(
                            category=category,
                            quadrant_index=quadrant_index,
                            slot_class_id=_slot_class_id(category, quadrant_index, position),
                            slot_position_in_quadrant=position,
                            reason="no_candidate_in_group",
                        )
                    )
                continue

            candidates = _merge_same_label_components(raw_components)
            n = len(candidates)
            scale = category_scale[category]
            if midline_x is not None and scale is not None:
                normalized_rank = np.array(
                    [min(abs(c.centroid_world_x - midline_x) / scale, 1.0) for c in candidates]
                )
            else:
                normalized_rank = np.full(n, 0.5)  # neutral fallback, same as Hungarian module

            real_cost, plan = _solve_group(
                candidates,
                category,
                quadrant_index,
                normalized_rank,
                order_weight,
                label_mismatch_cost,
                dustbin_cost,
                sinkhorn_reg,
                sinkhorn_max_iter,
            )
            transport_plans[(category, quadrant_index)] = plan

            # Soft -> hard readout: mutual-argmax among real rows/columns
            # only (see module docstring). Row n and column QUADRANT_SIZE
            # are the dustbin; excluded from the "real" argmax comparisons.
            real_plan = plan[:n, :QUADRANT_SIZE]
            row_argmax_incl_dustbin = np.argmax(plan[:n, :], axis=1)
            col_argmax_real = np.argmax(real_plan, axis=0) if n > 0 else np.array([], dtype=int)

            candidate_slot: dict[int, int] = {}  # candidate idx -> slot0, accepted only
            candidate_reason: dict[int, str] = {}
            for i in range(n):
                best_col = int(row_argmax_incl_dustbin[i])
                if best_col == QUADRANT_SIZE:
                    candidate_reason[i] = "routed_to_dustbin"
                    continue
                if int(col_argmax_real[best_col]) == i:
                    candidate_slot[i] = best_col
                else:
                    candidate_reason[i] = "lost_slot_competition"

            for i, candidate in enumerate(candidates):
                if i not in candidate_slot:
                    dustbin.append(
                        DustbinAssignment(
                            category=candidate.category,
                            quadrant_index=candidate.quadrant_index,
                            original_label=candidate.original_label,
                            component_ids=candidate.component_ids,
                            voxel_count=candidate.voxel_count,
                            reason=candidate_reason[i],
                        )
                    )
                    continue

                slot0 = candidate_slot[i]
                position = slot0 + 1
                slot_class_id = _slot_class_id(category, quadrant_index, position)
                normalized_slot_position = slot0 / (QUADRANT_SIZE - 1)
                order_cost = abs(float(normalized_rank[i]) - normalized_slot_position) * order_weight
                total_cost = float(real_cost[i, slot0])
                mismatch_cost = total_cost - order_cost
                new_label = slot_class_id
                changed = new_label != candidate.original_label
                if changed:
                    component_labels, _ = ndimage.label(label_volume == candidate.original_label)
                    mask = np.isin(component_labels, candidate.component_ids)
                    output[mask] = new_label
                matched.append(
                    MatchedAssignment(
                        category=category,
                        quadrant_index=quadrant_index,
                        original_label=candidate.original_label,
                        component_ids=candidate.component_ids,
                        voxel_count=candidate.voxel_count,
                        slot_class_id=slot_class_id,
                        slot_position_in_quadrant=position,
                        transport_mass=float(plan[i, slot0]),
                        order_cost=order_cost,
                        label_mismatch_cost=mismatch_cost,
                        total_cost=total_cost,
                        new_label=new_label,
                        changed=changed,
                    )
                )

            accepted_slots = set(candidate_slot.values())
            for position in range(1, QUADRANT_SIZE + 1):
                if (position - 1) not in accepted_slots:
                    empty_slots.append(
                        EmptySlot(
                            category=category,
                            quadrant_index=quadrant_index,
                            slot_class_id=_slot_class_id(category, quadrant_index, position),
                            slot_position_in_quadrant=position,
                            reason="no_accepted_candidate",
                        )
                    )

    return OTAssignmentResult(
        output_volume=output,
        matched=tuple(matched),
        dustbin=tuple(dustbin),
        empty_slots=tuple(empty_slots),
        transport_plans=transport_plans,
    )
