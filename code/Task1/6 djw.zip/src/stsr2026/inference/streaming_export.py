"""Memory-bounded (streaming-argmax) full-resolution export for the Docker path.

Context (see plan.md section 1 and docs/progress.md 2026-07-12/13 entries): the
official Docker target is a single RTX 3090 (24GB VRAM) with only 28GB system
RAM, 60s/case hard cutoff. ``stsr2026.evaluation.nnunet_inference`` already
root-caused and fixed the *time* half of nnU-Net's export bottleneck -- its
``_gpu_resample_to_shape`` / ``_install_gpu_probability_resampling`` swap nnU-Net's
default CPU scipy per-channel resample (order=1 linear, >4min/case) for GPU
trilinear (align_corners=False), which is a semantically exact swap validated on a
real 5090 GPU box. But that fix still assembles the *entire* resampled 65-channel,
full-resolution (~512x512x400) array in memory before argmaxing it down to a single
label map -- fine on a 184GB training box (peak measured ~60GB), not on the 28GB-RAM
Docker target. That is the bug this module fixes, per docs/progress.md's "Immediate
next steps" item 2: "Make the export incremental-argmax for Docker".

This is a **separate module**, not an edit to ``predict.py`` or
``nnunet_inference.py``:
- ``stsr2026.inference.predict`` is left untouched -- it's the D0 generic
  geometry-preserving I/O skeleton (``fake_predict``/``run_inference``) the Docker
  entrypoint already uses and already has passing tests; there is no reason to
  put GPU/nnunetv2-dependent code in it.
- ``stsr2026.evaluation.nnunet_inference``'s GPU-resample fix is explicitly out of
  scope to modify (already validated on a real GPU box, see docs/progress.md). Its
  approach is *mirrored* here (same GPU trilinear math, same anisotropic-spacing
  safety net) but written independently rather than imported, because the actual
  data-flow differs in a way that matters: that module's fix still returns one
  assembled ``[C, X, Y, Z]`` array (fixing time, not memory); this module's fix
  never assembles more than one channel at a time (fixing memory). Forcing those
  two into one shared function would either reintroduce the memory bug into the
  eval path or bolt an unrelated streaming-fold concern onto an already-validated,
  frozen piece of code -- not worth it for ~30 overlapping lines. Predictor-loading
  utilities that genuinely have nothing to do with either bug (``load_predictor``,
  ``CaseInferenceResult``, ``InferenceError``, ``find_case_images``) ARE reused by
  importing them, since duplicating those would be pure waste.

Two independent layers, with very different verification status:

1. ``StreamingArgmax`` + ``streaming_resample_and_argmax``: pure, GPU-independent
   streaming-argmax logic. Fully unit-tested in this sandbox (no GPU, no nnunetv2
   needed) against synthetic arrays, including tie cases, using a fake injectable
   ``resample_channel`` callback and, for the GPU building block specifically,
   real CPU ``torch`` (available in this sandbox even though CUDA is not) compared
   bit-for-bit against a naive "resample-all-channels-then-argmax" reference. This
   layer is the actual correctness-critical piece requested by this task and IS
   verified here, just not against a real CUDA device or real CBCT volumes.

2. ``streaming_convert_predicted_logits_to_segmentation_with_correct_shape`` /
   ``streaming_export_prediction_from_logits``: the nnU-Net integration point,
   wiring layer 1 into the real preprocess -> predict -> export sequence.
   GPU-DEPENDENT AND UNVERIFIED, same disclaimer as ``nnunet_inference.py``'s
   module docstring: this sandbox has no GPU and no working
   ``nnunetv2``/``torch``-with-CUDA install, so nothing in this layer has ever
   executed against a real checkpoint. Every ``ASSUMPTION`` comment below is a
   specific, falsifiable claim about nnU-Net internals that must be checked on a
   real GPU box before trusting this for the D3 Docker path. Do not treat this
   layer as validated.

**2026-07-13: ``predict_case_streaming`` no longer calls
``predictor.predict_from_files_sequential`` and no longer monkeypatches nnU-Net's
export call site.** Same root cause as ``stsr2026.evaluation.nnunet_inference``
(see that module's docstring): ``predict_from_files_sequential`` only exists from
nnunetv2>=2.6.0, which requires torch>=2.1.2 -- and torch never published an
official CUDA 11.3 wheel past 1.12.1. Fix: ``predict_case_streaming`` now
replicates the single-case preprocess/predict loop directly (same three
primitives as ``nnunet_inference.predict_case`` --
``configuration_manager.preprocessor_class``,
``predictor.predict_logits_from_preprocessed_data``, confirmed present in
nnunetv2 2.3.1 through 2.8.1) and then calls
``streaming_export_prediction_from_logits`` **directly** as the export step,
rather than patching it into nnU-Net's own
``predict_from_raw_data.export_prediction_from_logits`` call site. The previous
``install_streaming_export`` function (module-attribute patch of
``predict_from_raw_data.export_prediction_from_logits``) has been removed: it
existed only to intercept nnU-Net's own orchestration
(``predict_from_files_sequential`` -> that module-level name), and now that
``predict_case_streaming`` owns the whole call chain itself end to end, there is
no orchestration left to intercept -- calling the streaming exporter directly is
simpler and removes indirection that stopped doing anything useful. This also
means ``streaming_export.py`` no longer needs to import
``nnunetv2.inference.predict_from_raw_data`` at all.
"""
from __future__ import annotations

import time
from pathlib import Path
from typing import Callable, Sequence

import numpy as np

from stsr2026.data.audit import nifti_case_id
from stsr2026.evaluation.nnunet_inference import CaseInferenceResult, InferenceError

try:  # pragma: no cover - exercised only when torch is installed (CPU is enough)
    import torch
    import torch.nn.functional as F

    TORCH_AVAILABLE = True
except ImportError:  # pragma: no cover
    torch = None  # type: ignore[assignment]
    F = None  # type: ignore[assignment]
    TORCH_AVAILABLE = False

try:  # pragma: no cover - exercised only on a real nnU-Net install
    from acvl_utils.cropping_and_padding.bounding_boxes import insert_crop_into_image
    from acvl_utils.cropping_and_padding.padding import pad_nd_image
    from nnunetv2.inference.sliding_window_prediction import compute_gaussian
    from nnunetv2.utilities.helpers import empty_cache

    NNUNETV2_EXPORT_AVAILABLE = True
except ImportError:  # pragma: no cover - the expected case in this sandbox
    insert_crop_into_image = None  # type: ignore[assignment]
    pad_nd_image = None  # type: ignore[assignment]
    compute_gaussian = None  # type: ignore[assignment]
    empty_cache = None  # type: ignore[assignment]
    NNUNETV2_EXPORT_AVAILABLE = False

try:  # pragma: no cover - exercised only on a real nnU-Net install
    # Used by _predict_logits_keep_on_device to replicate
    # nnUNetPredictor.predict_logits_from_preprocessed_data's fold loop exactly
    # (see that function's docstring). Module-level (not imported inline inside
    # the function) so tests can monkeypatch these names the same way they
    # monkeypatch `torch`/`NNUNETV2_EXPORT_AVAILABLE` above, without needing a
    # real nnunetv2 install in this sandbox.
    from nnunetv2.inference.predict_from_raw_data import OptimizedModule, default_num_processes
except ImportError:  # pragma: no cover - the expected case in this sandbox
    OptimizedModule = ()  # type: ignore[assignment]  # isinstance(x, ()) is always False
    default_num_processes = 8  # matches nnU-Net's real default (see module docstring)


ResampleChannelFn = Callable[[int, "np.ndarray"], "np.ndarray"]


def _require_torch() -> None:
    if not TORCH_AVAILABLE:
        raise InferenceError(
            "torch is not installed in this environment; the GPU channel-resample "
            "building block needs it (CPU torch is enough to run, just slow -- a "
            "real GPU is only needed for real-size CBCT volumes to stay inside "
            "the 60s/case budget)."
        )


def _require_nnunetv2_export() -> None:
    if not NNUNETV2_EXPORT_AVAILABLE:
        raise InferenceError(
            "nnunetv2/acvl_utils are not installed in this environment. On the "
            "GPU box, install the 'training' extra (pip install -e '.[training]') "
            "before wiring streaming export into a real nnUNetPredictor; this "
            "sandbox intentionally does not have a working nnunetv2 install (see "
            "pyproject.toml)."
        )


# ---------------------------------------------------------------------------
# Layer 1: pure streaming-argmax logic (GPU-independent, fully tested here)
# ---------------------------------------------------------------------------


class StreamingArgmax:
    """Fold full-resolution channels into a running ``(best_value, best_label)``
    pair one at a time, so peak memory is O(1 channel + this pair), never
    O(num_channels x full-resolution-volume).

    Reproduces exact ``np.argmax``/``torch.argmax`` first-max-wins tie-breaking
    semantics *provided* channels are folded via :meth:`update` in strictly
    increasing ``label`` order (enforced -- see below): each update only
    overwrites the running best where the new channel is **strictly** greater
    (``>``, never ``>=``), so on a tie the earlier (lower-index / lower-label)
    channel keeps its claim, exactly like ``np.argmax`` picking the first
    occurrence of the max.
    """

    def __init__(self, shape: Sequence[int], label_dtype: "np.dtype | type" = np.uint8) -> None:
        self.shape = tuple(int(s) for s in shape)
        self.best_value = np.full(self.shape, -np.inf, dtype=np.float32)
        self.best_label = np.zeros(self.shape, dtype=label_dtype)
        self._last_label: int | None = None
        self._updates = 0

    def update(self, label: int, channel: "np.ndarray") -> None:
        channel = np.asarray(channel)
        if channel.shape != self.shape:
            raise ValueError(f"channel shape {channel.shape} != accumulator shape {self.shape}")
        if self._last_label is not None and label <= self._last_label:
            raise ValueError(
                "channels must be folded via update() in strictly increasing label "
                f"order to preserve first-max-wins argmax tie-breaking semantics "
                f"(got label {label} after {self._last_label})"
            )
        mask = channel > self.best_value
        if np.any(mask):
            np.copyto(self.best_value, channel, where=mask)
            self.best_label[mask] = label
        self._last_label = label
        self._updates += 1

    def finalize(self) -> "np.ndarray":
        if self._updates == 0:
            raise RuntimeError("StreamingArgmax.finalize() called before any update()")
        return self.best_label


def streaming_resample_and_argmax(
    logits: "np.ndarray",
    target_shape: Sequence[int],
    resample_channel: ResampleChannelFn,
    channel_to_label: Sequence[int] | None = None,
    label_dtype: "np.dtype | type" = np.uint8,
) -> "np.ndarray":
    """Resample each channel of ``logits`` (shape ``[C, ...]`` at whatever
    resolution it currently is) to ``target_shape`` via ``resample_channel``,
    folding each result into a :class:`StreamingArgmax` accumulator immediately
    and discarding it -- so peak memory for this step is O(1 source-res channel +
    1 target-res channel + the accumulator's 2 target-res buffers), never
    O(C x target-res).

    ``resample_channel(channel_index, channel_array, target_shape) -> np.ndarray``
    is injected so this function has no GPU/torch/nnU-Net dependency itself and is
    fully testable with a synthetic callback (see tests/test_streaming_export.py).

    ``channel_to_label`` maps channel index -> output label value (default:
    identity, i.e. channel ``c`` produces label ``c``) and must be strictly
    increasing to preserve tie-breaking semantics -- this matches nnU-Net's own
    non-region-based ``LabelManager.convert_probabilities_to_segmentation``,
    which does a plain ``argmax(0)`` with no remapping (channel index IS the
    label value there too), so identity is also nnU-Net's own assumption, not an
    extra one introduced here.
    """
    num_channels = int(logits.shape[0])
    labels = list(range(num_channels)) if channel_to_label is None else list(channel_to_label)
    if len(labels) != num_channels:
        raise ValueError(f"channel_to_label has {len(labels)} entries, logits has {num_channels} channels")
    if labels != sorted(labels) or len(set(labels)) != len(labels):
        raise ValueError(
            "channel_to_label must be strictly increasing (no repeats, no reordering) "
            "to preserve first-max-wins argmax tie-breaking semantics"
        )

    target_shape = tuple(int(s) for s in target_shape)
    accumulator = StreamingArgmax(target_shape, label_dtype=label_dtype)
    for channel_index, label in enumerate(labels):
        resampled = resample_channel(channel_index, logits[channel_index], target_shape)
        accumulator.update(label, resampled)
        del resampled
    return accumulator.finalize()


# ---------------------------------------------------------------------------
# GPU channel-resample building block (mirrors, does not share, the eval
# module's _gpu_resample_to_shape -- see module docstring for why)
# ---------------------------------------------------------------------------


def _is_anisotropic(spacing: Sequence[float], anisotropy_threshold: int = 3) -> bool:
    vals = [float(x) for x in spacing]
    lo = min(vals)
    return lo > 0 and (max(vals) / lo) > anisotropy_threshold


def _gpu_resample_channel_to_shape(channel: "np.ndarray", target_shape: Sequence[int], *, device) -> "np.ndarray":
    """Resample a single channel to ``target_shape`` via GPU trilinear
    interpolation (``align_corners=False``) -- the same math nnU-Net's own
    ``resampling_fn_probabilities`` uses at ``order=1`` (verified against this
    dataset's ``plans.json`` by ``stsr2026.evaluation.nnunet_inference``'s
    already-validated fix, see its module docstring), applied to one channel at
    a time instead of the whole stack, and returned to CPU immediately so the
    caller can discard the source channel and fold this result into the running
    argmax without ever holding more than this single resampled channel.
    """
    _require_torch()
    target = [int(s) for s in target_shape]
    src = torch.from_numpy(channel) if isinstance(channel, np.ndarray) else channel
    if list(src.shape) == target:
        return src.cpu().numpy() if isinstance(src, torch.Tensor) else np.asarray(src)

    with torch.no_grad():
        # Upload in the source's native dtype (fp16 for nnU-Net logits) and cast to
        # float32 *on the device*, not during the .to() transfer: casting on transfer
        # sends float32-sized bytes over PCIe, ~2x the fp16 traffic -- profiled on a
        # 4090D (see docs/experiment-log.md) as ~22s of pure upload for case_006's 65
        # channels, dropping to ~2s when the fp16->fp32 expansion happens GPU-side.
        # Bit-exact: F.interpolate runs in float32 either way; only *when* the widening
        # cast happens changes, and fp16->fp32 is lossless.
        patch = src.unsqueeze(0).unsqueeze(0).to(device=device).to(dtype=torch.float32)  # [1,1,X,Y,Z]
        resampled = F.interpolate(patch, size=target, mode="trilinear", align_corners=False)
        out = resampled[0, 0].to("cpu").numpy()
        del patch, resampled
    # NOTE: no per-channel torch.cuda.empty_cache() here -- profiled as pure overhead
    # (~2s/large case on real A10, zero effect on output values); the caching allocator
    # reuses the freed single-channel blocks across iterations without it.
    return out


def make_gpu_channel_resampler(
    *,
    device,
    current_spacing: Sequence[float],
    new_spacing: Sequence[float],
    cpu_fallback_resample_channel: ResampleChannelFn | None = None,
    anisotropy_threshold: int = 3,
) -> ResampleChannelFn:
    """Build a ``resample_channel(channel_index, channel, target_shape)``
    callable for :func:`streaming_resample_and_argmax`.

    Spacing is checked once (not per channel -- it's constant across channels
    for a given case) for the same anisotropic-axis case
    ``stsr2026.evaluation.nnunet_inference._gpu_resample_to_shape`` falls back
    on to stay bit-compatible with nnU-Net's own per-axis resampling. This
    dataset is confirmed near-isotropic (0.25/0.3mm, D0 audit, plan.md section
    1), so that branch is not expected to trigger in practice. Unlike the eval
    module (which has a ready-made ``orig_fn`` -- nnU-Net's own CPU scipy path --
    to fall back to), this function has no default CPU fallback implementation
    of its own for the anisotropic case: nnU-Net's real per-axis-then-in-plane
    resampling logic is intricate enough that reimplementing it here, unable to
    test against a real anisotropic case or real nnU-Net internals in this
    sandbox, would risk silently-wrong output more than an explicit error would.
    If this branch ever triggers for real, pass ``cpu_fallback_resample_channel``
    (e.g. a per-channel ``scipy.ndimage.zoom(order=1)`` wrapper) explicitly.
    """
    aniso = _is_anisotropic(current_spacing, anisotropy_threshold) or _is_anisotropic(new_spacing, anisotropy_threshold)

    def _resample(channel_index: int, channel: "np.ndarray", target_shape: Sequence[int]) -> "np.ndarray":
        if aniso:
            if cpu_fallback_resample_channel is None:
                raise InferenceError(
                    f"anisotropic spacing detected (current={list(current_spacing)}, "
                    f"new={list(new_spacing)}) but no cpu_fallback_resample_channel was "
                    "supplied to make_gpu_channel_resampler; this dataset is expected "
                    "to be near-isotropic (plan.md section 1), so this should not "
                    "trigger in practice, but streaming export refuses to silently "
                    "guess a fallback here."
                )
            return cpu_fallback_resample_channel(channel_index, channel, target_shape)
        return _gpu_resample_channel_to_shape(channel, target_shape, device=device)

    return _resample


def gpu_resample_and_argmax(
    logits: "np.ndarray",
    target_shape: Sequence[int],
    *,
    device,
    channel_to_label: Sequence[int] | None = None,
    label_dtype: "np.dtype | type" = np.uint8,
) -> "np.ndarray":
    """GPU-resident equivalent of :func:`streaming_resample_and_argmax` for the
    isotropic GPU path: resample each channel to ``target_shape`` with GPU
    trilinear interpolation and fold it into a running ``(best_value, best_label)``
    argmax pair that *stays on the device*, so only the final uint8 label map is
    copied back to CPU -- never the 65 full-resolution float32 resampled channels.

    Why this exists alongside the CPU-callback :func:`streaming_resample_and_argmax`
    (rather than replacing it): the pure callback version downloads each resampled
    channel to CPU and folds there. Profiled on a 4090D (see docs/experiment-log.md),
    that download of 65 full-res float32 channels (~40GB over PCIe) plus the CPU-side
    numpy argmax fold was ~46s of case_006's ~67s export -- the dominant cost, and
    entirely PCIe/CPU-bound, not compute (the interpolation itself is ~0.2s). Holding
    the two accumulator buffers on the GPU and folding there collapses that to ~2s.
    The callback version is retained for the anisotropic CPU fallback, for unit tests
    (no CUDA needed), and as the exact numpy reference this function is validated
    against.

    **Bit-exactness**: this computes the same first-max-wins argmax as
    :func:`streaming_resample_and_argmax` / ``np.argmax(axis=0)`` -- each fold
    overwrites the running best only where the new channel is *strictly* greater
    (``>``), so ties keep the lower label, and channels are folded in strictly
    increasing label order (enforced below). The interpolation math is identical to
    :func:`_gpu_resample_channel_to_shape` (same fp16-upload / GPU-side fp32 cast /
    ``F.interpolate(..., mode="trilinear", align_corners=False)``). Validated
    voxel-for-voxel (0 mismatches of ~158M voxels on case_006) against the CPU-fold
    reference on real hardware -- see tmp/verify_gpu_argmax_bitexact.py.

    Memory: peak is O(one fp16 source channel + one fp32 resampled channel + the two
    target-res accumulator buffers [fp32 value + uint8 label] + one bool mask). For
    case_006's (512, 605, 512) target that is ~0.3GB(source) + 0.6GB + 0.6GB + 0.15GB
    + 0.15GB ~= 1.9GB of VRAM on top of whatever else is live -- well inside the 24GB
    target budget, and it puts *nothing* extra on the 28GB-RAM Docker host (only the
    final uint8 label map returns to system RAM, same as before).
    """
    _require_torch()
    num_channels = int(logits.shape[0])
    labels = list(range(num_channels)) if channel_to_label is None else list(channel_to_label)
    if len(labels) != num_channels:
        raise ValueError(f"channel_to_label has {len(labels)} entries, logits has {num_channels} channels")
    if labels != sorted(labels) or len(set(labels)) != len(labels):
        raise ValueError(
            "channel_to_label must be strictly increasing (no repeats, no reordering) "
            "to preserve first-max-wins argmax tie-breaking semantics"
        )

    target = [int(s) for s in target_shape]
    torch_label_dtype = torch.uint8 if np.dtype(label_dtype) == np.uint8 else torch.int32
    src_is_target = list(logits.shape[1:]) == target

    with torch.no_grad():
        best_value = torch.full(target, float("-inf"), dtype=torch.float32, device=device)
        best_label = torch.zeros(target, dtype=torch_label_dtype, device=device)
        for channel_index, label in enumerate(labels):
            src = logits[channel_index]
            src_t = torch.from_numpy(src) if isinstance(src, np.ndarray) else src
            if src_is_target:
                resampled = src_t.to(device=device).to(dtype=torch.float32)
            else:
                # fp16 upload, GPU-side fp32 cast (see _gpu_resample_channel_to_shape)
                patch = src_t.unsqueeze(0).unsqueeze(0).to(device=device).to(dtype=torch.float32)
                resampled = F.interpolate(patch, size=target, mode="trilinear", align_corners=False)[0, 0]
                del patch
            mask = resampled > best_value
            best_value = torch.where(mask, resampled, best_value)
            label_scalar = torch.tensor(label, dtype=torch_label_dtype, device=device)
            best_label = torch.where(mask, label_scalar, best_label)
            del src_t, resampled, mask
        out = best_label.to("cpu").numpy().astype(label_dtype, copy=False)
        del best_value, best_label
    return out


def _default_device():
    _require_torch()
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


# ---------------------------------------------------------------------------
# Windowed (spatially-chunked) sliding-window prediction + resample + argmax fold
# -- fuses three normally-separate stages so the full (65, D, H, W) logits
# array is never materialized anywhere, GPU or CPU. See docs/progress.md's
# 2026-07-15 entry for the full root-cause investigation and design writeup;
# summary of WHY this exists:
#
# nnU-Net's own sliding-window accumulator (built inside
# ``nnUNetPredictor._internal_predict_sliding_window_return_logits``, real
# unmodified nnU-Net code) is ``torch.zeros((65, *data.shape[1:]), dtype=half,
# device=results_device)`` -- for a real large STSR2026 validation-set case
# (preprocessed shape (533, 373, 533)) that is ~10.5GB fp16, and for other
# real cases with less cropping it reaches ~16.4GB. That does not reliably
# fit in a 23-24GB VRAM budget alongside network weights/activations, and
# when it doesn't fit, nnU-Net's own ``predict_sliding_window_return_logits``
# (also unmodified) catches the resulting ``RuntimeError`` and rebuilds the
# SAME array on host RAM instead -- which then blows the organizers' real
# ``-m 8G`` Docker memory limit (confirmed via ``dmesg``: ``Memory cgroup out
# of memory``, on the real 20-case official validation set, 2026-07-15).
#
# The fix below drives the *output* (target-space, i.e.
# ``shape_after_cropping_and_before_resampling``) loop in depth chunks, and
# for each chunk: (1) figures out which of nnU-Net's own precomputed sliding-
# window tiles are actually needed to cover that chunk's resampled source
# region, (2) runs ONLY those tiles through the network and accumulates them
# into a SMALL (65, chunk_depth, H, W) buffer using nnU-Net's own exact
# Gaussian-weighted overlap-add arithmetic (copied verbatim from
# ``stsr2026.evaluation.nnunet_inference._memory_safe_internal_predict_
# sliding_window_return_logits``, just scoped to the small buffer), (3)
# resamples that small buffer straight to the target-space chunk with
# explicit-coordinate ``F.grid_sample`` (NOT ``F.interpolate`` -- see
# ``_grid_sample_resample_chunk_channel``'s docstring for why), (4) argmax-
# folds it into a running label map one channel at a time (same tie-break
# pattern as :func:`gpu_resample_and_argmax`), (5) discards the chunk buffer
# before moving to the next chunk. The full 65-channel array, at any
# resolution, never exists anywhere in this pipeline -- peak memory is
# bounded by one chunk's accumulator, which is small by construction (see
# :func:`_choose_target_chunk_depth`).
#
# H and W (axes 1, 2) are deliberately NOT chunked, only D (axis 0,
# "depth") -- a scope decision from the design, not an oversight: this
# dataset's tile geometry (patch_size=[160,112,160] vs. real preprocessed
# depths of 500+) already gets peak memory for a large real case down from
# ~16.4GB to roughly 7-9GB with depth-only chunking (see
# :func:`_choose_target_chunk_depth`'s docstring for the real-number
# derivation of that floor), which is comfortably inside a 23-24GB VRAM
# budget -- 2D/3D windowing would add real implementation complexity for a
# problem 1D windowing already appears to solve. This must be confirmed on
# real hardware (see this task's validation checklist) before treating that
# "appears to solve" as settled; if real measurement shows otherwise, this
# is the place to extend to H/W chunking too.
# ---------------------------------------------------------------------------


def _target_chunk_to_padded_range(
    t0: int, t1: int, source_depth: int, target_depth: int, pad_below: int
) -> tuple[int, int]:
    """Map a target-space output depth range ``[t0, t1)`` to the padded-space
    (nnU-Net tile-grid coordinate system) source depth range that must be read
    to compute it.

    Uses the SAME pixel-center-alignment formula already established in this
    codebase for exactly this kind of coordinate-chunked resample
    (``src = scale*(dst+0.5)-0.5``, see
    ``stsr2026.evaluation.nnunet_inference._parallel_resample_channel`` and
    ``tmp/test_grid_sample_chunk.py``), with a +-1/+2 voxel margin for the
    trilinear neighbor lookup (matches the verified technique in that test
    script exactly: ``floor(min) - 1`` .. ``ceil(max) + 2``), then shifts by
    ``pad_below`` (the amount nnU-Net's own ``pad_nd_image`` padded onto the
    *start* of axis 0 -- ``slicer_revert_padding[1].start``) to convert from
    preprocessed-space into the padded tile-grid space that
    ``predictor._internal_get_sliding_window_slicers`` operates in.

    ``scale = source_depth / target_depth`` is the GLOBAL scale factor (the
    whole-volume ratio), computed once per call from the two full depths
    passed in -- never derived locally from a chunk's own size. Using a
    locally-derived scale factor here would be the same class of bug
    ``tmp/test_grid_sample_chunk.py`` was written to catch for the resample
    step itself (a "chunk-local size implies chunk-local scale" mistake) --
    this function is a different, upstream use of the same principle: even
    though it is not itself a resample, getting the source range's scale
    wrong here would make the eventual resample read the wrong voxels.
    """
    if target_depth <= 0 or source_depth <= 0:
        raise ValueError(f"source_depth ({source_depth}) and target_depth ({target_depth}) must both be positive")
    if not (0 <= t0 < t1 <= target_depth):
        raise ValueError(f"invalid target chunk range [{t0}, {t1}) for target_depth={target_depth}")
    scale = source_depth / target_depth
    d_first = scale * (t0 + 0.5) - 0.5
    d_last = scale * (t1 - 1 + 0.5) - 0.5
    lo = int(np.floor(min(d_first, d_last))) - 1
    hi = int(np.ceil(max(d_first, d_last))) + 2
    lo = max(0, lo)
    hi = min(source_depth, hi)
    return lo + pad_below, hi + pad_below


def _select_tiles_for_axis0_range(slicers: Sequence[tuple], lo: int, hi: int) -> list[tuple]:
    """Return the subsequence of ``slicers`` (nnU-Net's own
    ``predictor._internal_get_sliding_window_slicers(...)`` output -- tuples
    ``(slice(None), slice_x, slice_y, slice_z)``, one per tile, ALL axes at
    full ``patch_size`` extent) whose axis-0 (depth) extent overlaps
    ``[lo, hi)``, preserving the original relative order.

    Order preservation matters for bit-exactness: nnU-Net's own accumulation
    is a floating-point sum over tiles in slicer-list order
    (``predicted_logits[sl] += prediction``), and floating-point addition is
    not associative -- summing the same tiles in a different order can
    change the last bit or two. Iterating the FULL slicer list once and
    filtering (rather than, say, re-deriving a chunk-local tile list from
    scratch) guarantees every chunk sees its tiles in the same relative
    order nnU-Net's own unchunked accumulation would have used, which is
    exactly what makes the accumulation step bit-exact across different
    chunkings (see tests/test_windowed_prediction.py).
    """
    return [sl for sl in slicers if sl[1].start < hi and sl[1].stop > lo]


def _tile_accumulation_bounds(selected_slicers: Sequence[tuple]) -> tuple[int, int]:
    """Union of the selected tiles' axis-0 (depth) extents, in padded-space
    coordinates -- the exact bounds of the small accumulator buffer needed to
    hold every selected tile's contribution.
    """
    if not selected_slicers:
        raise ValueError("selected_slicers is empty -- cannot compute accumulation bounds")
    los = [sl[1].start for sl in selected_slicers]
    his = [sl[1].stop for sl in selected_slicers]
    return min(los), max(his)


def accumulate_sliding_window_chunk(
    padded_data: "torch.Tensor",
    selected_slicers: Sequence[tuple],
    buf_lo: int,
    buf_hi: int,
    num_channels: int,
    predict_tile_fn: Callable[["torch.Tensor"], "torch.Tensor"],
    gaussian: "torch.Tensor | None",
    *,
    device,
    dtype: "torch.dtype | None" = None,
) -> "torch.Tensor":
    """Bit-exact-by-construction replica of nnU-Net's own tile Gaussian-
    weighted overlap-add accumulation (see
    ``stsr2026.evaluation.nnunet_inference._memory_safe_internal_predict_
    sliding_window_return_logits``, the class-level-patched version of
    nnU-Net's real ``_internal_predict_sliding_window_return_logits`` this
    repo already ships and validated on real hardware), scoped to the
    padded-space depth sub-range ``[buf_lo, buf_hi)`` and a caller-selected
    subset of tiles instead of the whole volume / whole tile list.

    ``predict_tile_fn`` is injected (real production passes
    ``predictor._internal_maybe_mirror_and_predict``, nnU-Net's own unchanged
    method) so this function has no nnU-Net/GPU dependency itself and is
    fully unit-testable with a synthetic callback -- same pattern as
    :func:`streaming_resample_and_argmax`'s ``resample_channel`` injection.

    Unlike nnU-Net's own version, this always runs synchronously (no
    producer-thread tile-prefetch queue, no try/except CPU-fallback): the
    whole point of chunking is that the buffer this function builds is
    small enough to always fit on ``device``, so there is nothing to fall
    back from. The producer-thread prefetch is a real throughput
    optimization nnU-Net's own code has (overlaps host->device tile copies
    with the previous tile's inference) that this simplification gives up --
    see this task's report for the measured real-hardware cost of that,
    if any.

    ``dtype`` defaults to ``torch.half``, matching nnU-Net's own
    ``predicted_logits``/``n_predictions`` dtype exactly (real
    ``_internal_predict_sliding_window_return_logits`` source).
    """
    _require_torch()
    if dtype is None:
        dtype = torch.half
    if not selected_slicers:
        raise ValueError("selected_slicers is empty -- nothing to accumulate")
    height, width = int(padded_data.shape[2]), int(padded_data.shape[3])
    depth = buf_hi - buf_lo
    predicted_logits = torch.zeros((num_channels, depth, height, width), dtype=dtype, device=device)
    n_predictions = torch.zeros((depth, height, width), dtype=dtype, device=device)
    for sl in selected_slicers:
        sx, sy, sz = sl[1], sl[2], sl[3]
        local_x = slice(sx.start - buf_lo, sx.stop - buf_lo)
        workon = padded_data[(slice(None), sx, sy, sz)].unsqueeze(0).to(device=device)
        prediction = predict_tile_fn(workon)[0].to(device=device)
        if gaussian is not None:
            prediction = prediction * gaussian
            weight = gaussian
        else:
            weight = 1
        predicted_logits[(slice(None), local_x, sy, sz)] += prediction
        n_predictions[(local_x, sy, sz)] += weight
        del workon, prediction
    torch.div(predicted_logits, n_predictions, out=predicted_logits)
    return predicted_logits


def _crop_chunk_to_preprocessed_space(
    chunk: "torch.Tensor", buf_lo: int, slicer_revert_padding: Sequence
) -> tuple["torch.Tensor", int]:
    """Crop a padded-space accumulator chunk (axis 0 already scoped to
    ``[buf_lo, buf_lo + chunk.shape[1])`` by the caller) down to
    preprocessed-space (removing whatever ``pad_nd_image`` padding nnU-Net
    added on all three spatial axes to reach at least ``patch_size``),
    exactly mirroring what nnU-Net's own
    ``predicted_logits[(slice(None), *slicer_revert_padding[1:])]`` line does
    to the FULL accumulator in ``predict_sliding_window_return_logits`` --
    just applied to a depth sub-range instead of the whole volume.

    Returns ``(cropped_chunk, pp_lo)`` where ``pp_lo`` is the GLOBAL
    preprocessed-space depth offset of ``cropped_chunk[:, 0]`` -- the
    resample step needs this to place the chunk correctly against the
    dataset-wide scale factor (see
    :func:`_grid_sample_resample_chunk_channel`).

    H/W (axes 2, 3) are cropped via the FULL ``slicer_revert_padding[2]``/
    ``[3]`` slices unconditionally (not chunked -- see this section's module
    comment) -- correct because those axes were never chunked in the first
    place, so the chunk's H/W already spans the full padded extent.
    """
    pad_below_x = slicer_revert_padding[1].start
    source_depth = slicer_revert_padding[1].stop - pad_below_x
    valid_lo = max(buf_lo, pad_below_x)
    valid_hi = min(buf_lo + int(chunk.shape[1]), pad_below_x + source_depth)
    if valid_hi <= valid_lo:
        raise ValueError(
            f"chunk padded-space range [{buf_lo}, {buf_lo + int(chunk.shape[1])}) does not overlap "
            f"the preprocessed-space range [{pad_below_x}, {pad_below_x + source_depth}) at all -- "
            "should be unreachable given _target_chunk_to_padded_range's own clamping."
        )
    local_lo = valid_lo - buf_lo
    local_hi = valid_hi - buf_lo
    cropped = chunk[:, local_lo:local_hi, slicer_revert_padding[2], slicer_revert_padding[3]]
    pp_lo = valid_lo - pad_below_x
    return cropped, pp_lo


def _grid_sample_resample_chunk_channel(
    channel: "torch.Tensor",
    pp_lo: int,
    source_depth: int,
    source_height: int,
    source_width: int,
    t0: int,
    t1: int,
    target_depth: int,
    target_height: int,
    target_width: int,
    *,
    device,
) -> "torch.Tensor":
    """Resample one channel's preprocessed-space depth-chunk
    (``channel`` shape ``(local_depth, source_height, source_width)``,
    starting at GLOBAL preprocessed-space depth offset ``pp_lo``) to the
    target-space depth range ``[t0, t1)`` (full ``target_height`` x
    ``target_width``), via explicit-coordinate ``F.grid_sample`` using the
    GLOBAL scale factors (``source_depth/target_depth`` etc, computed from
    the FULL dataset-wide shapes passed in, never from ``channel``'s own
    local size).

    **Why not ``F.interpolate``** (this is the one genuinely new numerical
    technique this task introduces, not an existing pattern being reused --
    see docs/progress.md's 2026-07-15 entry and ``tmp/test_grid_sample_chunk.py``
    for the full investigation this comment summarizes): ``F.interpolate(...,
    size=target_shape)`` derives its internal scale factor from the *ratio of
    its own input/output tensor shapes* -- for a depth-chunked call, that
    would be ``local_depth / (t1-t0)``, which is NOT the same number as the
    real dataset-wide ``source_depth / target_depth`` (they only coincide if
    the chunk's local crop happens to be in exactly the same proportion as
    the whole volume, which it generally is not, especially near the +-1/+2
    voxel margin added by :func:`_target_chunk_to_padded_range`). Using
    ``F.interpolate`` here would silently resample with the WRONG scale
    factor at every chunk boundary -- this was caught during this task's
    design phase, not on real hardware, exactly because a synthetic test
    comparing chunked-vs-unchunked output would have failed loudly. The fix:
    compute each output voxel's *source coordinate* explicitly with the
    REAL global scale factor (``scale*(dst+0.5)-0.5``, the same pixel-center
    formula used everywhere else in this codebase for exactly this reason),
    normalize those explicit coordinates into ``F.grid_sample``'s
    ``align_corners=False`` convention relative to ``channel``'s own local
    offset (``pp_lo``) and size, and let ``grid_sample`` do the (bilinear,
    i.e. trilinear for 5D input) interpolation from there. This makes the
    *scale factor* independent of chunking (always the global one) while the
    *coordinate normalization* is correctly chunk-relative (grid_sample's
    grid must be in the input tensor's own local coordinate frame).

    **Known, expected, quantified non-bit-exactness vs. ``F.interpolate``**
    (do not treat this as a bug -- see this task's report for the official-
    scorer validation of its real-world impact): ``F.grid_sample`` and
    ``F.interpolate(mode='trilinear', align_corners=False)`` are NOT
    bit-identical for the same logical operation -- different underlying
    kernels, same math, measured ~1e-6 max absolute difference on synthetic
    float32 data even for a single unchunked call (``tmp/test_grid_sample_
    chunk.py``). This function is used instead of the already-existing,
    already-validated ``_gpu_resample_channel_to_shape``/``gpu_resample_and_
    argmax`` (which use ``F.interpolate``) specifically because ``F.interpolate``
    cannot express "resample this local chunk using a global scale factor" at
    all -- its ``size=`` parameter only ever expresses a local one. This is a
    real, deliberate, and load-bearing tradeoff, not an oversight.
    """
    scale_d = source_depth / target_depth
    scale_h = source_height / target_height
    scale_w = source_width / target_width

    d_out = torch.arange(t0, t1, dtype=torch.float64, device=device)
    h_out = torch.arange(target_height, dtype=torch.float64, device=device)
    w_out = torch.arange(target_width, dtype=torch.float64, device=device)

    src_d = scale_d * (d_out + 0.5) - 0.5 - pp_lo  # relative to channel's own local depth-0
    src_h = scale_h * (h_out + 0.5) - 0.5
    src_w = scale_w * (w_out + 0.5) - 0.5

    local_depth = int(channel.shape[0])
    gd = (2 * src_d + 1) / local_depth - 1
    gh = (2 * src_h + 1) / source_height - 1
    gw = (2 * src_w + 1) / source_width - 1

    grid_d, grid_h, grid_w = torch.meshgrid(gd, gh, gw, indexing="ij")
    # grid_sample expects grid[..., 0]=x(=W), grid[...,1]=y(=H), grid[...,2]=z(=D)
    grid = torch.stack([grid_w, grid_h, grid_d], dim=-1).unsqueeze(0).to(torch.float32)

    inp = channel.unsqueeze(0).unsqueeze(0).to(device=device, dtype=torch.float32)
    out = F.grid_sample(inp, grid, mode="bilinear", padding_mode="border", align_corners=False)
    return out[0, 0]  # (t1-t0, target_height, target_width)


def _choose_target_chunk_depth(
    slicers: Sequence[tuple],
    patch_depth: int,
    source_depth: int,
    target_depth: int,
    height: int,
    width: int,
    num_channels: int,
    pad_below: int,
    *,
    max_chunk_logits_bytes: int,
    itemsize: int = 2,
) -> int:
    """Pick a target-space chunk depth that keeps the accumulator buffer
    (:func:`accumulate_sliding_window_chunk`'s output, shape ``(num_channels,
    chunk_padded_depth, height, width)``) within ``max_chunk_logits_bytes``.

    **Real-geometry finding this function is built around** (worked out
    during this task's design, confirmed against this dataset's real
    ``compute_steps_for_sliding_window`` output on the A10 box): for
    ``tile_step_size=0.5`` (this project's real production setting), a tile's
    stride along an axis is exactly half its ``patch_size`` on that axis, so
    UP TO 3 overlapping tiles can cover any single point along that axis
    (``ceil(patch_size / stride) = ceil(patch_size / (patch_size/2)) = 2``,
    plus one more from rounding at typical real step counts -- confirmed by
    directly inspecting real tile-start lists on the A10 box, e.g.
    ``[0, 75, 150, 226, 301, 376]`` for ``patch_depth=160``: the point x=155
    is covered by tiles starting at 0, 75, AND 150). This means the
    accumulator's padded-space depth span has a FLOOR of roughly
    ``2 * patch_depth`` REGARDLESS of how small the target-space chunk is --
    shrinking ``target_chunk_depth`` below the point where the corresponding
    *needed source range* is already smaller than this floor does NOT reduce
    peak memory any further, it only adds MORE chunks (i.e. more redundant
    tile re-computation at chunk boundaries) for no memory benefit. So this
    function does not blindly binary-search down to the smallest depth that
    fits the budget -- it first tries a geometry-driven default (`~1 tile's
    worth of target-space depth`, chosen so chunk *boundaries* roughly track
    real tile spacing and each tile is reprocessed by at most ~2 adjacent
    chunks) and only shrinks further, with a real per-candidate probe against
    the ACTUAL tile list (not a formula), if that default's real accumulator
    size exceeds the byte budget -- which does not happen for any real case
    measured so far (see this task's report), but is kept as a genuine safety
    net rather than an assumption, in case some other checkpoint's plans.json
    ever configures a different ``tile_step_size``/``patch_size`` combination
    where the floor above is not conservative enough.

    Real numbers (STS26_Validation_015_with-artifacts, patch_size=[160,112,160],
    preprocessed shape (533,373,533), target shape (640,448,640), see this
    task's report for the measured real-hardware value): the geometry-driven
    default picks ~4-6 chunks, and the resulting worst-case accumulator is
    ~7-9GB fp16 -- down from nnU-Net's own ~10.5-16.4GB whole-volume
    accumulator, comfortably inside a 23-24GB VRAM budget alongside network
    weights/activations.

    **Small/medium cases collapse to a single chunk (zero windowing
    overhead)**: before doing any of the above, this function first checks
    whether the WHOLE volume already fits in ``max_chunk_logits_bytes`` as
    one chunk, and returns ``target_depth`` (one chunk, no windowing at all)
    if so -- this is what makes :func:`windowed_predict_and_export`'s "always
    windowed, no small-case fast path" design choice actually cost-free for
    small cases (see that function's docstring): a case whose full
    accumulator already fits the budget pays exactly the same memory/compute
    as the pre-windowed pipeline, just reached through this one code path
    instead of a separate one.

    **Real bug found during this task's A10 timing validation, fixed here
    (twice)**: an earlier version of this function's ``_probe`` only checked
    a chunk placed at the START of the volume (``t0=0``), on the assumption
    that "real tile geometry is regular/periodic, so the first chunk's
    selected-tile span is a good proxy for interior chunks". Real measurement
    on ``STS26_Validation_015_with-artifacts`` disproved this: the t0=0
    chunk's selected-tile union spanned 235 padded-space voxels, while an
    interior chunk (t0=192) spanned 384 -- 63% larger, because an edge chunk
    only has neighboring tiles on ONE side while an interior chunk has them
    on both. A second attempt probed t0=0 AND the volume's midpoint and took
    the larger of the two -- still measurably wrong: for ``depth=192`` the
    TRUE worst real chunk (at ``t0=192``, not exactly the volume midpoint)
    measured 458/11.84GB, vs. the 2-point probe's 383/9.90GB estimate (still
    ~30% under). Root cause: the true worst case depends on exact alignment
    with real tile step positions, not a generic "middle of the volume"
    heuristic. **Fixed properly this time**: probe EVERY position the real
    windowed loop will actually use for this ``depth`` (i.e. every
    ``t0 in range(0, target_depth, depth)``, exactly matching
    :func:`windowed_sliding_window_predict_and_argmax`'s own loop) and take
    the true max -- this is exact for the chunking scheme actually used, not
    an approximation, and still cheap (pure tile-list filtering, no GPU/
    network calls; at most ``target_depth/depth`` iterations, e.g. <=8 for
    every real case measured so far).
    """
    if source_depth <= 0 or target_depth <= 0 or patch_depth <= 0:
        raise ValueError("source_depth, target_depth, and patch_depth must all be positive")

    def _probe(depth: int) -> tuple[int, int]:
        """Return (worst_buffer_depth, worst_buffer_bytes) across every real
        chunk start position ``windowed_sliding_window_predict_and_argmax``
        would use for this ``depth`` -- see the docstring's "Real bug found"
        section for why this must be exhaustive over real chunk positions,
        not a small fixed sample of them.
        """
        worst_buffer_depth = 0
        for t0 in range(0, target_depth, depth):
            t1 = min(t0 + depth, target_depth)
            padded_lo, padded_hi = _target_chunk_to_padded_range(t0, t1, source_depth, target_depth, pad_below)
            selected = _select_tiles_for_axis0_range(slicers, padded_lo, padded_hi)
            buf_lo, buf_hi = _tile_accumulation_bounds(selected)
            worst_buffer_depth = max(worst_buffer_depth, buf_hi - buf_lo)
        return worst_buffer_depth, num_channels * worst_buffer_depth * height * width * itemsize

    # Whole-volume-as-one-chunk first: if it already fits, use it -- see the
    # "Small/medium cases collapse..." docstring section above.
    _, whole_volume_bytes = _probe(target_depth)
    if whole_volume_bytes <= max_chunk_logits_bytes:
        return target_depth

    scale = source_depth / target_depth
    geometry_default = max(1, min(target_depth, round(patch_depth / scale)))
    depth = geometry_default
    _, size_bytes = _probe(depth)

    if size_bytes <= max_chunk_logits_bytes:
        # Real-hardware timing finding (A10, STS26_Validation_015_with-
        # artifacts and STS26_Validation_007, see this task's report): the
        # geometry-driven default alone (~4-7 small chunks) leaves real,
        # measured GPU headroom unused -- e.g. 4 chunks of depth 192 on
        # case015 measured ~16GB peak VRAM against a 23-24GB budget, while
        # total wall-clock (~61s just for this loop, before preprocessing)
        # already exceeded the 60s/case target because of redundant tile
        # re-computation at chunk boundaries (measured ~2x total tile-
        # forward-passes vs. the unchunked tile count). GROW from the
        # geometry default (fewer, bigger chunks -> less redundant tile
        # work) as long as the real probed size still fits the budget.
        #
        # Doubling alone (first version of this growth phase) only ever
        # lands on power-of-two multiples of the geometry default, which
        # measurably left real performance on the table: on case007
        # (536,440,536, no resampling needed), doubling from 80 landed on
        # either 80 (99.8s, 15.5GB peak) or overshot straight to 320 (45.2s,
        # but measured peak VRAM for that exact config varied 17.3-22.6GB
        # across repeated runs -- CUDA allocator fragmentation, the same
        # real phenomenon this project's own earlier investigation already
        # found decides whether adjacent similarly-sized real cases fit --
        # too close to the 23GB physical ceiling to trust). A direct sweep
        # of intermediate depths found real sweet spots doubling alone can
        # never reach, e.g. depth=240 (3 chunks): 50.4s, 14.9GB peak, with
        # real margin. Fixed by refining with a bisection search between the
        # last known-good depth and the first depth that exceeds budget (or
        # target_depth itself), so the chosen depth is close to the true
        # largest-that-fits rather than only ever a power of two of the
        # geometry default.
        good_depth = depth
        bad_depth: int | None = None
        while good_depth < target_depth:
            candidate = min(target_depth, good_depth * 2)
            _, candidate_bytes = _probe(candidate)
            if candidate_bytes > max_chunk_logits_bytes:
                bad_depth = candidate
                break
            good_depth = candidate
            if candidate == target_depth:
                break
        if bad_depth is not None:
            lo, hi = good_depth, bad_depth
            while hi - lo > 1:
                mid = (lo + hi) // 2
                _, mid_bytes = _probe(mid)
                if mid_bytes <= max_chunk_logits_bytes:
                    lo = mid
                else:
                    hi = mid
            good_depth = lo
        return good_depth

    while size_bytes > max_chunk_logits_bytes and depth > 1:
        next_depth = max(1, depth // 2)
        next_buffer_depth, next_size_bytes = _probe(next_depth)
        if next_depth == depth or next_size_bytes >= size_bytes:
            # Hit the tile-overlap floor: shrinking the target chunk further
            # is not reducing the accumulator size any more (or can't shrink
            # further at all) -- stop here rather than uselessly multiplying
            # chunk count. The caller still gets a real, working (if larger
            # than requested) buffer; this is a soft budget, not a hard cap
            # this design can always satisfy without 2D/3D windowing (see
            # this module's section comment above).
            break
        depth, size_bytes = next_depth, next_size_bytes
    return max(1, depth)


def _chunk_has_inf(tensor: "torch.Tensor", channels_per_subchunk: int = 4) -> bool:
    """Same chunked-``isinf`` check, and same real-hardware root cause, as
    ``stsr2026.evaluation.nnunet_inference._chunked_tensor_has_inf`` (see that
    function's docstring for the full story: nnU-Net's own diagnostic
    ``torch.any(torch.isinf(predicted_logits))`` safety check, run on the
    FULL accumulator, was itself caught doubling peak host memory on a real
    A10 run). Deliberately a LOCAL copy rather than a cross-module import:
    that module's own ``torch`` name is only bound when a real ``nnunetv2``
    install is ALSO present (see its module docstring's import-guard
    pattern), so importing its function here would silently break in any
    environment with real ``torch`` but no ``nnunetv2`` -- exactly this
    project's own CPU-torch-only sandbox, which is precisely where this
    module's own synthetic tests (tests/test_windowed_prediction.py) need to
    run. ``streaming_export.py`` binds its own ``torch`` independently (see
    top of this module) specifically to avoid this class of coupling, so
    this tiny (~6 line) duplication keeps that independence rather than
    reintroducing it through the back door.

    Our chunk buffer is already small by construction (that is the entire
    point of this module), so ``channels_per_subchunk`` further sub-chunking
    here is a much smaller optimization than it is for nnU-Net's own
    full-volume check -- kept anyway for consistency/defense-in-depth, not
    because it is load-bearing at this buffer size.
    """
    for start in range(0, int(tensor.shape[0]), channels_per_subchunk):
        chunk = tensor[start : start + channels_per_subchunk]
        if torch.any(torch.isinf(chunk)):
            return True
    return False


def windowed_sliding_window_predict_and_argmax(
    padded_data: "torch.Tensor",
    slicers: Sequence[tuple],
    slicer_revert_padding: Sequence,
    target_shape: Sequence[int],
    num_channels: int,
    predict_tile_fn: Callable[["torch.Tensor"], "torch.Tensor"],
    gaussian: "torch.Tensor | None",
    *,
    device,
    target_chunk_depth: int,
    label_dtype: "np.dtype | type" = np.uint8,
) -> "np.ndarray":
    """Core windowed pipeline: fuses nnU-Net's own sliding-window tile
    accumulation, this module's GPU trilinear-equivalent resample, and its
    streaming per-channel argmax fold into one depth-chunked loop, so the
    full ``(num_channels, D, H, W)`` array is never materialized at ANY
    resolution -- see this section's module comment for the full picture.

    Pure orchestration over the injected ``predict_tile_fn``/``gaussian`` --
    has no nnU-Net dependency itself beyond ``torch``, so it is fully
    unit-testable on synthetic CPU data with a fake ``predict_tile_fn`` (see
    tests/test_windowed_prediction.py), the same injection pattern already
    used by :func:`streaming_resample_and_argmax`'s ``resample_channel``.

    Each target-space depth chunk is processed independently and written to
    a DISJOINT depth range of the output ``label_map`` -- unlike
    :func:`gpu_resample_and_argmax`'s single-pass streaming fold (which folds
    overlapping full-volume channels into a running best-value/best-label
    pair), chunks here never overlap in target-space by construction (they
    partition ``[0, target_depth)``), so there is no cross-chunk comparison
    needed: within a chunk, channels are folded via the same first-max-wins
    mask/``torch.where`` pattern as :func:`gpu_resample_and_argmax` (strictly
    increasing label order, ``>`` not ``>=``, so ties keep the lower label --
    identical tie-break semantics), and the chunk's finished
    ``best_label`` is written directly into ``label_map[t0:t1]``.

    Memory: peak is O(one chunk's accumulator [num_channels x chunk_padded_
    depth x H x W, fp16] + one resampled channel [chunk_target_depth x
    H_target x W_target, fp32] + the chunk's best_value/best_label buffers +
    the full-size uint8 ``label_map`` [cheap, ~1 byte/voxel]) -- never
    O(num_channels x full-volume), at either the preprocessed or target
    resolution.
    """
    _require_torch()
    if target_chunk_depth <= 0:
        raise ValueError("target_chunk_depth must be positive")

    target_depth, target_height, target_width = (int(s) for s in target_shape)
    pad_below_x = slicer_revert_padding[1].start
    source_depth = slicer_revert_padding[1].stop - pad_below_x
    source_height = slicer_revert_padding[2].stop - slicer_revert_padding[2].start
    source_width = slicer_revert_padding[3].stop - slicer_revert_padding[3].start

    torch_label_dtype = torch.uint8 if np.dtype(label_dtype) == np.uint8 else torch.int32
    label_map = torch.zeros((target_depth, target_height, target_width), dtype=torch_label_dtype, device=device)

    with torch.no_grad():
        for t0 in range(0, target_depth, target_chunk_depth):
            t1 = min(t0 + target_chunk_depth, target_depth)
            padded_lo, padded_hi = _target_chunk_to_padded_range(t0, t1, source_depth, target_depth, pad_below_x)
            selected = _select_tiles_for_axis0_range(slicers, padded_lo, padded_hi)
            if not selected:
                raise InferenceError(
                    f"no sliding-window tiles overlap padded depth range [{padded_lo}, {padded_hi}) "
                    f"for target chunk [{t0}, {t1}) -- should be unreachable given nnU-Net's own "
                    "sliding-window full-coverage guarantee (compute_steps_for_sliding_window "
                    "always tiles the whole padded volume); if this fires, the tile/padding "
                    "coordinate math in this module has a real bug."
                )
            buf_lo, buf_hi = _tile_accumulation_bounds(selected)
            chunk_logits = accumulate_sliding_window_chunk(
                padded_data, selected, buf_lo, buf_hi, num_channels, predict_tile_fn, gaussian, device=device
            )
            if _chunk_has_inf(chunk_logits):
                raise RuntimeError(
                    "Encountered inf in predicted array. Aborting... If this problem persists, "
                    "reduce value_scaling_factor in compute_gaussian or increase the dtype of "
                    "predicted_logits to fp32"
                )
            buffer_pp, pp_lo = _crop_chunk_to_preprocessed_space(chunk_logits, buf_lo, slicer_revert_padding)
            del chunk_logits

            best_value = torch.full(
                (t1 - t0, target_height, target_width), float("-inf"), dtype=torch.float32, device=device
            )
            best_label = torch.zeros((t1 - t0, target_height, target_width), dtype=torch_label_dtype, device=device)
            for label in range(num_channels):
                resampled = _grid_sample_resample_chunk_channel(
                    buffer_pp[label],
                    pp_lo,
                    source_depth,
                    source_height,
                    source_width,
                    t0,
                    t1,
                    target_depth,
                    target_height,
                    target_width,
                    device=device,
                )
                mask = resampled > best_value
                best_value = torch.where(mask, resampled, best_value)
                label_scalar = torch.tensor(label, dtype=torch_label_dtype, device=device)
                best_label = torch.where(mask, label_scalar, best_label)
                del resampled, mask
            label_map[t0:t1] = best_label
            del buffer_pp, best_value, best_label

    return label_map.to("cpu").numpy().astype(label_dtype, copy=False)


# Derived, not hand-picked, from two independent real-hardware findings on
# the A10 (23GB VRAM) box -- see this task's report for the full budget-sweep
# tables this is built from:
#
# 1. ``_choose_target_chunk_depth``'s byte budget only accounts for the
#    ``predicted_logits``/``n_predictions`` accumulator itself -- real
#    measured peak VRAM (network activations, the gaussian buffer, per-tile
#    workon copies, and CUDA caching-allocator fragmentation on top of that)
#    runs SUBSTANTIALLY higher, and the ratio is not fixed: measured
#    real-peak-VRAM / probed-accumulator-bytes ranged from ~1.2x up to
#    ~1.6x for the SAME nominal chunk configuration across repeated runs on
#    two different real cases (STS26_Validation_015_with-artifacts,
#    STS26_Validation_007) -- e.g. one config's peak measured 17.28GB in one
#    run and 22.56GB in another, on a 23GB box. This run-to-run variance is
#    the same real phenomenon this project's own earlier investigation
#    already found (CUDA allocator fragmentation deciding whether adjacent,
#    similarly-sized real cases fit or fall back to the CPU path) -- not a
#    bug in the probe, a genuine property of the CUDA allocator that this
#    budget must be conservative against, not just accurate against.
# 2. A first version of this constant (12GiB) was tuned against ONLY
#    case015 and looked good there (2 chunks, ~41s, 13.36GB peak) -- but
#    re-measuring against a SECOND real case (case007, a different, harder
#    tile geometry: preprocessed shape == target shape exactly, no
#    resampling at all) at that same 12GiB budget, after fixing
#    ``_choose_target_chunk_depth``'s search to be more precise (bisection
#    instead of pure doubling, see that function's docstring), pushed
#    case015 to a MORE aggressive 2-chunk config than the one validated
#    (446 vs. 192) -- because a more precise search finds a LARGER "still
#    fits the nominal budget" chunk depth, which is exactly the wrong
#    direction once real overhead varies 1.2x-1.6x: real measured peak for
#    that reoptimized config was 20.23GB, only ~2.8GB under the 23GB
#    ceiling. This is a real, caught-during-this-task's-own-validation
#    example of the exact failure mode this whole fix exists to prevent --
#    do not tune this constant against a single case's measurement again.
#
# Fix: target a REAL peak VRAM budget with actual margin (16GB, leaving
# ~7GB under a 23-24GB ceiling), and divide by the WORST observed overhead
# ratio (1.6x) rather than a typical one, before handing the result to
# ``_choose_target_chunk_depth`` as its (accumulator-only) byte budget:
# 16GB / 1.6 ~= 10GiB. Re-validated at 10GiB against BOTH real cases after
# this change (see this task's report): both land back in the "many
# small-to-medium chunks" tier this project has the most repeated, stable
# real measurements for (12-15GB peak, no run seen above ~16GB), at the
# cost of slower wall-clock on the hardest real cases (measured up to
# ~130-140s for the worst tile geometry) than a more aggressive budget
# would give -- an explicit, documented choice to prioritize never risking
# an OOM kill over shaving time off the worst case (see this task's report
# for the full discussion, including why the organizers' 60s/case rule
# fails that ONE case's score rather than crashing the whole container --
# a real regression, not nothing, but far better than the alternative this
# whole task exists to eliminate).
DEFAULT_MAX_CHUNK_LOGITS_BYTES = 10 * 1024**3


def _full_accumulator_bytes(padded_shape: Sequence[int], num_channels: int, itemsize: int = 2) -> int:
    """Size, in bytes, of nnU-Net's own UN-chunked ``(num_channels, *padded_
    shape)`` fp16 accumulator (``predicted_logits`` inside its real
    ``_internal_predict_sliding_window_return_logits``) -- i.e. exactly what
    the pre-windowing fast path (``_predict_logits_keep_on_device`` +
    ``gpu_resample_and_argmax``) will build on-device if used for this case.
    ``padded_shape`` is the PADDED spatial shape (``padded_data.shape[1:]``),
    matching nnU-Net's own accumulator dimensions exactly (built after
    ``pad_nd_image``, before any resampling).
    """
    d, h, w = (int(s) for s in padded_shape)
    return num_channels * d * h * w * itemsize


# 12GiB, derived from two direct real-A10 measurements (2026-07-15, see this
# task's report for the full table) of the TRUE pre-windowing fast path
# (``_predict_logits_keep_on_device`` + ``gpu_resample_and_argmax``, i.e.
# nnU-Net's own threaded tile accumulation + F.interpolate-based GPU fold --
# exactly what this repo had before the windowed pipeline existed):
#
# - STS26_Train-Labeled_006 (raw accumulator 11.95GB / 11.13GiB, previously
#   fast and never flagged as a problem case): fast path measured 16.42s,
#   peak 15.14GB actual VRAM -- comfortable, real overhead ratio ~1.27x
#   (much lower than the windowed path's worst-observed 1.6x, because this
#   is one synchronous accumulate + one resample pass, none of the windowed
#   path's per-chunk redundant tile re-computation).
# - STS26_Validation_015_with-artifacts (raw accumulator 13.78GB / 12.83GiB,
#   THE flagship case this whole task's memory investigation started from):
#   fast path measured 17.05GB peak VRAM *in isolation* -- notably, this
#   technically "succeeded" as a standalone measurement, which at first
#   looks like it contradicts this case's own documented history. It
#   doesn't: docs/progress.md's real investigation (before this task) found
#   this exact case alternates between succeeding on-device and falling
#   back to a catastrophic CPU rebuild *depending on which case ran right
#   before it in the same long-running container* -- CUDA allocator
#   fragmentation accumulated across a real multi-case batch, not visible
#   in a single isolated measurement. So this case's raw accumulator size
#   (12.83GiB) is treated as the real dividing line, not its isolated-peak
#   number, which cannot be trusted alone given that documented history.
#
# **Revised 2026-07-15, same day, after a second real-hardware finding**:
# 12GiB (binary, 12,884,901,888 bytes) was the first value shipped here,
# chosen to be comfortably above STS26_Train-Labeled_006 (11.95GB decimal)
# and below STS26_Validation_015_with-artifacts (13.78GB decimal). A REAL
# full-20-case-sequence Docker run under ``-m 8G`` then OOM-killed the
# container during PREPROCESSING of case015 (position 15 in the sequence)
# -- reproduced twice, and confirmed via a controlled A/B test that the
# EXACT SAME 15-case sequence with the pre-hybrid (always-windowed) code
# succeeded at that exact position. Root cause traced (see
# ``windowed_predict_and_export``'s fast-path branch comment) to a small
# (~30-40MB) but real amount of extra host-memory residual per fast-path
# case that is not fully reclaimed by the existing per-case
# ``_release_memory_between_cases()`` reclaim -- an added ``gc.collect()``
# at the fast path's exit point measurably did NOT fix it, meaning the
# residual is not a simple Python-level reference-cycle problem. Given
# case015's own preprocessing peak is ALREADY right at the real `-m 8G`
# ceiling by itself (this is the same case whose real-hardware fragility
# is what started this entire task, see docs/progress.md's 2026-07-15
# entry), even a small extra cross-case baseline is enough to tip it over
# after ~14 prior cases.
#
# **DISABLED BY DEFAULT as of this same investigation, honestly reported
# rather than papered over**: a first attempt at a fix (raising this
# threshold's precision, then lowering it from 12GiB binary to 12.1GB
# decimal to remove 2 of 6 real validation-set cases from the fast path)
# was re-validated with a REAL full-20-case-sequence Docker run under
# ``-m 8G`` and STILL failed at case015 (position 15) -- the exact same
# failure, reproduced a second time even after that mitigation. A back-
# to-back control test then showed the pre-hybrid, always-windowed code
# (``djw:windowed8``) succeeding at that exact position TWICE in a row
# (not once, which could have been fragmentation-variance luck) while
# every hybrid variant tried failed. This is real, reproducible evidence
# that the fast path (not fragmentation variance in general) is
# responsible, and that neither mitigation attempted so far actually
# fixes it -- the true mechanism (suspected: something host-memory-
# related in nnU-Net's own threaded tile-prefetch, used only by
# ``predict_sliding_window_return_logits``, which only this fast path
# calls) was not pinned down before this task's time ran out.
#
# Given this project's own stated priority ("correctness matters more
# than speed, and OOM-killing the real submission container is
# catastrophic, a slow case is merely suboptimal"), this constant is set
# to ``0`` -- i.e. the fast path documented above is fully implemented,
# unit-tested, and real-hardware-validated for ACCURACY (bit-for-bit
# identical to the pre-windowing code, since it IS the pre-windowing
# code), but is not used by default until a human has either found the
# real root cause of the cross-case host-memory issue above, or accepted
# the residual risk explicitly with a real, re-validated threshold. Pass
# a positive ``full_accumulator_safe_bytes`` explicitly to
# :func:`windowed_predict_and_export` to re-enable it for cases at or
# below that many bytes -- e.g. the previous ``12_100_000_000`` value
# this task tried is preserved here in a comment as a starting point for
# that follow-up investigation, NOT as a value known to be safe.
DEFAULT_FULL_ACCUMULATOR_SAFE_BYTES = 0


# ---------------------------------------------------------------------------
# Layer 2: nnU-Net integration (GPU-dependent, unverified -- see module docstring)
# ---------------------------------------------------------------------------


def _check_streaming_export_preconditions(label_manager) -> None:  # type: ignore[no-untyped-def]
    """Shared precondition checks for every streaming/windowed export path
    below -- factored out so the windowed pipeline
    (:func:`windowed_predict_and_export`) and the original streaming pipeline
    (:func:`streaming_convert_predicted_logits_to_segmentation_with_correct_shape`)
    can't drift apart on what they refuse to (mis)handle. See the original
    function's docstring (now below) for why these two checks exist.
    """
    if label_manager.has_regions:
        raise InferenceError(
            "streaming export does not support region-based training "
            "(label_manager.has_regions is True). This dataset is not "
            "region-based (65 discrete classes, plan.md section 1), so this is "
            "not expected to trigger; if it does, use the original nnU-Net "
            "export path instead of streaming export for this checkpoint."
        )

    all_labels = list(label_manager.all_labels)
    if all_labels != list(range(len(all_labels))):
        raise InferenceError(
            "streaming export assumes channel index == label value directly, "
            "matching nnU-Net's own non-region convert_probabilities_to_segmentation "
            f"(plain argmax(0), no remapping) -- only correct when all_labels is "
            f"exactly [0..C-1]. Got all_labels={all_labels}. This dataset's plans "
            "are expected to satisfy this (65 classes, 0..64), so this should not "
            "trigger in practice."
        )


def _compute_spacings(properties_dict: dict, plans_manager, configuration_manager):  # type: ignore[no-untyped-def]
    """``shape_after_cropping_and_before_resampling``/``current_spacing``/
    ``target_spacing`` -- extracted from ``streaming_convert_predicted_logits_
    to_segmentation_with_correct_shape`` so :func:`windowed_predict_and_export`
    can compute the exact same three values without duplicating the (already
    real-hardware-validated) formula.
    """
    shape_after_cropping = properties_dict["shape_after_cropping_and_before_resampling"]
    spacing_transposed = [properties_dict["spacing"][i] for i in plans_manager.transpose_forward]
    current_spacing = (
        configuration_manager.spacing
        if len(configuration_manager.spacing) == len(shape_after_cropping)
        else [spacing_transposed[0], *configuration_manager.spacing]
    )
    target_spacing = [properties_dict["spacing"][i] for i in plans_manager.transpose_forward]
    return shape_after_cropping, current_spacing, target_spacing


def _revert_crop_and_transpose(label_map_cropped, properties_dict: dict, plans_manager, label_dtype):  # type: ignore[no-untyped-def]
    """``insert_crop_into_image`` + ``transpose_backward`` -- the shared tail
    of every export path in this module, operating on the small uint8 label
    map (not logits), so it is already cheap and needs no windowing/chunking
    of its own. Extracted so :func:`windowed_predict_and_export` doesn't
    duplicate it.
    """
    segmentation_reverted_cropping = np.zeros(properties_dict["shape_before_cropping"], dtype=label_dtype)
    segmentation_reverted_cropping = insert_crop_into_image(
        segmentation_reverted_cropping, label_map_cropped, properties_dict["bbox_used_for_cropping"]
    )
    return segmentation_reverted_cropping.transpose(plans_manager.transpose_backward)


def streaming_convert_predicted_logits_to_segmentation_with_correct_shape(
    predicted_logits,
    plans_manager,
    configuration_manager,
    label_manager,
    properties_dict: dict,
    device,
):
    """Memory-bounded replacement for nnU-Net's own
    ``export_prediction.convert_predicted_logits_to_segmentation_with_correct_shape``.

    ASSUMPTION (unverified without a real nnunetv2 install + GPU + checkpoint --
    see module docstring): mirrors the control flow read from a vendored nnU-Net
    v2 fork (``tmp/literature/code/extracted/UMamba2-master/nnunetv2/inference/
    export_prediction.py``, NOT the exact installed ``nnunetv2>=2.5.1``) --
    computing ``current_spacing``/``target_spacing`` the same way, reverting
    cropping via the same ``acvl_utils.insert_crop_into_image``, and applying the
    same ``plans_manager.transpose_backward`` -- but instead of calling
    ``configuration_manager.resampling_fn_probabilities`` to assemble all
    channels at full resolution and *then* argmaxing (nnU-Net's own memory
    pattern, and what ``stsr2026.evaluation.nnunet_inference``'s GPU-resample fix
    still does), this resamples and argmax-folds one channel at a time via
    :func:`streaming_resample_and_argmax`, cutting peak memory for this step
    from O(65 x full-res array) (~26GB measured on real CBCT volumes, see
    docs/progress.md) to O(2 x full-res single-channel array).

    Does NOT support region-based training (``label_manager.has_regions``) or
    returning probabilities -- the Docker path only ever needs the argmaxed
    uint8 label map (see this module's docstring); this dataset is not
    region-based (65 discrete classes, plan.md section 1) so the first
    restriction is not expected to bite, but it is checked and raises loudly
    rather than silently mishandling it.

    **2026-07-15: this still requires the FULL ``predicted_logits`` array to
    already exist in memory (at whatever resolution the caller passes in) --
    it fixes the memory cost of the RESAMPLE step, not the sliding-window
    ACCUMULATION step that produces ``predicted_logits`` in the first place.**
    :func:`predict_case_streaming` no longer calls this function for its main
    (isotropic CUDA) path -- see :func:`windowed_predict_and_export`, which
    fuses accumulation into the same chunked loop so the full array never
    exists at all. This function is kept, unchanged, as: (a) the fallback for
    the anisotropic/CPU case (see :func:`windowed_predict_and_export`), (b)
    directly unit-tested here as the "already-validated" reference the new
    windowed pipeline's tests compare against, and (c) still reachable via
    :func:`streaming_export_prediction_from_logits` for any other caller that
    already has a materialized logits array.
    """
    _check_streaming_export_preconditions(label_manager)
    shape_after_cropping, current_spacing, target_spacing = _compute_spacings(
        properties_dict, plans_manager, configuration_manager
    )
    label_dtype = np.uint8 if len(label_manager.foreground_labels) < 255 else np.uint16

    # Isotropic + real CUDA device -> GPU-resident argmax fold (only the final uint8
    # label map comes back to CPU; see gpu_resample_and_argmax for why -- profiled
    # ~67s -> ~2s for case_006 on a 4090D, bit-exact vs. the CPU-fold reference).
    # Anisotropic or CPU device -> the original CPU-callback streaming path (needs an
    # explicit cpu_fallback_resample_channel for the anisotropic case, which this
    # near-isotropic dataset is not expected to hit -- see make_gpu_channel_resampler).
    use_gpu_fold = (
        getattr(device, "type", None) == "cuda"
        and not _is_anisotropic(current_spacing)
        and not _is_anisotropic(target_spacing)
    )
    if use_gpu_fold:
        label_map_cropped = gpu_resample_and_argmax(
            predicted_logits,
            target_shape=shape_after_cropping,
            device=device,
            label_dtype=label_dtype,
        )
    else:
        resample_channel = make_gpu_channel_resampler(
            device=device, current_spacing=current_spacing, new_spacing=target_spacing
        )
        label_map_cropped = streaming_resample_and_argmax(
            predicted_logits,
            target_shape=shape_after_cropping,
            resample_channel=resample_channel,
            label_dtype=label_dtype,
        )
    del predicted_logits

    return _revert_crop_and_transpose(label_map_cropped, properties_dict, plans_manager, label_dtype)


def windowed_predict_and_export(
    predictor,
    data: "torch.Tensor",
    properties_dict: dict,
    configuration_manager,
    plans_manager,
    dataset_json_dict_or_file,
    output_file_truncated: str,
    *,
    device=None,
    target_chunk_depth: "int | None" = None,
    max_chunk_logits_bytes: int = DEFAULT_MAX_CHUNK_LOGITS_BYTES,
    full_accumulator_safe_bytes: int = DEFAULT_FULL_ACCUMULATOR_SAFE_BYTES,
) -> None:
    """The real fix for the 2026-07-15 "third memory problem" (see
    docs/progress.md's 2026-07-15 entry and this module's "Windowed
    (spatially-chunked) sliding-window prediction" section comment above):
    for cases whose full accumulator does NOT safely fit in VRAM, drives
    sliding-window tile accumulation, resample, and argmax-fold as one
    depth-chunked loop via :func:`windowed_sliding_window_predict_and_argmax`,
    so nnU-Net's own full ``(num_segmentation_heads, D, H, W)`` accumulator
    (the thing that doesn't reliably fit in 23-24GB VRAM for large real
    cases, see module comment) is never built anywhere -- not on GPU, not as
    a CPU fallback.

    **2026-07-15, revised same day: hybrid fast-path/windowed-path, not
    "always windowed".** The first version of this function always windowed
    the isotropic-CUDA case, reasoning that :func:`_choose_target_chunk_depth`
    would collapse small cases to a single chunk at effectively no extra
    cost. Real-hardware validation proved that reasoning wrong: a case whose
    accumulator is small in absolute (D x H x W) terms can still have a
    WIDE target shape (e.g. ``STS26_Train-Labeled_006``, preprocessed
    (427,504,427), target (512,605,512) -- previously fast at ~34-44s) --
    depth-only chunking's overhead does not depend on absolute case size,
    only on how many *chunks* the geometry needs, and case_006 needed enough
    chunks to measure **98.4s**, a genuine ~2-3x regression on a case that
    was never part of the memory problem this task exists to fix. Measured
    directly (this task's report has the full real-A10 numbers): the TRUE
    pre-windowing fast path (``_predict_logits_keep_on_device`` + nnU-Net's
    own threaded tile accumulation, then ``gpu_resample_and_argmax``'s
    F.interpolate-based GPU fold) handles case_006 in **16.42s** at a
    comfortable **15.14GB** peak VRAM -- there was never a reason to pay the
    windowed path's overhead for this case at all.

    So: for the isotropic-CUDA case, this function now computes the exact
    byte size nnU-Net's own UN-chunked accumulator would need
    (:func:`_full_accumulator_bytes`, using the real padded shape) and, if
    it is safely under ``full_accumulator_safe_bytes`` (real-A10-measured
    default, see :data:`DEFAULT_FULL_ACCUMULATOR_SAFE_BYTES`'s derivation),
    routes to that TRUE fast path -- identical to what this repo had before
    any windowed work existed, imported here as building blocks
    (``_predict_logits_keep_on_device``, ``gpu_resample_and_argmax``), not
    reimplemented. Only cases whose accumulator exceeds that threshold fall
    through to the windowed path below. This directly addresses -- with
    real measurement, not just an increased-confidence assumption -- the
    coordinator-flagged regression: small-but-wide cases regain their
    original speed, while genuinely large cases (case015/case007-class,
    accumulator size above the threshold) keep the OOM protection this task
    was built for.

    Replaces, within :func:`predict_case_streaming`, the previous combination
    of ``_predict_logits_keep_on_device(predictor, data)`` (which called
    nnU-Net's own ``predict_sliding_window_return_logits`` -> the full
    accumulator) followed by ``streaming_export_prediction_from_logits`` --
    except now that combination is reinstated as this function's own fast
    path for cases where it's safe, rather than being replaced outright.

    The anisotropic/CPU fallback below still exists because the windowed
    pipeline's resample math (:func:`_grid_sample_resample_chunk_channel`)
    assumes independent per-axis scale factors (same assumption
    ``F.interpolate``-based trilinear resampling already makes), which is
    not correct for nnU-Net's anisotropic per-axis-then-separate-z
    resampling -- reimplementing THAT in windowed form is out of scope
    (this dataset is confirmed near-isotropic, see plan.md section 1, so
    this fallback is not expected to trigger in production).
    """
    _require_torch()
    _require_nnunetv2_export()
    device = device or _default_device()

    if isinstance(dataset_json_dict_or_file, str):
        from batchgenerators.utilities.file_and_folder_operations import load_json

        dataset_json_dict_or_file = load_json(dataset_json_dict_or_file)

    label_manager = plans_manager.get_label_manager(dataset_json_dict_or_file)
    _check_streaming_export_preconditions(label_manager)
    shape_after_cropping, current_spacing, target_spacing = _compute_spacings(
        properties_dict, plans_manager, configuration_manager
    )
    label_dtype = np.uint8 if len(label_manager.foreground_labels) < 255 else np.uint16

    use_gpu_isotropic = (
        getattr(device, "type", None) == "cuda"
        and not _is_anisotropic(current_spacing)
        and not _is_anisotropic(target_spacing)
    )

    use_fast_path = False
    if use_gpu_isotropic:
        patch_size = tuple(int(s) for s in predictor.configuration_manager.patch_size)
        padded_data, slicer_revert_padding = pad_nd_image(data, patch_size, "constant", {"value": 0}, True, None)
        num_channels = predictor.label_manager.num_segmentation_heads
        accumulator_bytes = _full_accumulator_bytes(padded_data.shape[1:], num_channels)
        use_fast_path = accumulator_bytes <= full_accumulator_safe_bytes
        # Lightweight, always-on routing-decision log (single line, cheap) --
        # added 2026-07-15 while diagnosing a real cross-case-sequence OOM
        # (see this task's report): reasoning about the byte-threshold
        # decision from code alone was not enough to explain a real failure
        # that only reproduced in a full ~15-case sequence, not in isolation
        # -- this line is what made it possible to actually SEE which branch
        # a given case took in a real multi-case Docker run, rather than
        # inferring it after an unrecoverable kernel OOM-kill (which leaves
        # no Python traceback at all). Kept permanently: cheap, and the next
        # time a case-specific memory anomaly shows up in a real run, this
        # is exactly the first thing that would be needed again.
        print(
            f"[windowed_predict_and_export] padded_shape={tuple(int(s) for s in padded_data.shape[1:])} "
            f"accumulator_bytes={accumulator_bytes} full_accumulator_safe_bytes={full_accumulator_safe_bytes} "
            f"use_fast_path={use_fast_path}",
            flush=True,
        )

    if use_gpu_isotropic and use_fast_path:
        # TRUE fast path: identical to what this repo had before any windowed
        # work existed (see docstring above) -- nnU-Net's own real
        # ``predict_sliding_window_return_logits`` (threaded tile prefetch,
        # its own network.to(device)/eval()/empty_cache()) via
        # _predict_logits_keep_on_device, then the already-validated
        # F.interpolate-based GPU-resident argmax fold. del the padded_data
        # probe copy -- not needed on this path (predict_sliding_window_
        # return_logits does its own padding internally on the ORIGINAL
        # `data`, this function's padded_data was only built to size the
        # accumulator for the fast/windowed decision above).
        del padded_data, slicer_revert_padding
        prediction = _predict_logits_keep_on_device(predictor, data)
        label_map_cropped = gpu_resample_and_argmax(
            prediction, target_shape=shape_after_cropping, device=device, label_dtype=label_dtype
        )
        del prediction
        # **Real bug found during this task's cross-case-sequence validation**
        # (see this task's report): a real 15-case-sequence Docker run OOM-
        # killed the container during PREPROCESSING of case015 (the 15th
        # case) -- but ONLY when earlier cases in the same sequence used
        # this fast path; the exact same sequence with the windowed-only
        # (pre-hybrid) code succeeded at the exact same position. Root
        # cause: this fast path's ``_predict_logits_keep_on_device`` call
        # goes through nnU-Net's own ``predict_sliding_window_return_logits``
        # -> the class-patched ``_memory_safe_internal_predict_sliding_
        # window_return_logits`` (``stsr2026.evaluation.nnunet_inference``),
        # which spins up a background ``threading.Thread`` + ``queue.Queue``
        # per case (nnU-Net's own tile-prefetch design) -- the windowed path
        # this branch is an alternative to is fully synchronous and never
        # does this. Measured: cumulative host memory crept up by a small
        # but real ~0.1GB/case regardless of which path a case took, and the
        # fast path's additional ~40MB of thread/queue-related residual
        # (not reclaimed by the time the NEXT case's own
        # ``_release_memory_between_cases`` runs) was enough to tip
        # case015's already-razor-thin preprocessing peak over the real
        # `-m 8G` limit after 14 prior cases. Fixed by forcing an immediate
        # ``gc.collect()`` right here -- as soon as this fast path's own
        # thread/queue-holding objects are out of scope -- instead of
        # deferring all reclaim to the per-case loop's end (which runs
        # AFTER this function returns, by which point the fast-path-
        # specific garbage has already had a chance to accumulate across
        # multiple cases before ever being collected).
        import gc

        gc.collect()
    elif use_gpu_isotropic:
        # WINDOWED path: accumulator judged unsafe above -- fuse tile
        # accumulation + resample + argmax into the depth-chunked loop so
        # the full accumulator is never built (see module comment).
        #
        # **Real bug found during this task's A10 validation**: nnU-Net's own
        # ``predict_sliding_window_return_logits`` (what the fast path above
        # calls, and what this windowed path replaces for large cases)
        # starts with exactly ``self.network = self.network.to(self.device);
        # self.network.eval(); empty_cache(self.device)`` (real unmodified
        # nnU-Net source) -- calling ``_internal_get_sliding_window_
        # slicers``/``_internal_maybe_mirror_and_predict`` directly, as this
        # branch does, bypasses that entirely. In production this happened
        # to still work because ``checkpoint_runner._warm_up_predictor``
        # already moves the network to ``device`` as a SIDE EFFECT of its
        # cuDNN warm-up pass, called once before the per-case loop -- but
        # that function is explicitly documented as best-effort ("any
        # failure ... must never abort or slow down the real run, only skip
        # the optimization silently"), so relying on it implicitly here was
        # fragile: a failed/skipped warm-up (e.g. a future nnunetv2 API
        # drift changing an attribute name that warm-up's broad ``except
        # Exception`` swallows) would silently leave the network on CPU and
        # crash here with a confusing "Input type (torch.cuda.FloatTensor)
        # and weight type (torch.FloatTensor) should be the same" error
        # instead of a clear one -- caught directly while instrumenting real
        # timing on the A10 box (a bare diagnostic script that skipped
        # warm-up hit exactly this). Fixed by replicating nnU-Net's own
        # three lines explicitly, so this function's correctness never
        # depends on warm-up's side effect.
        predictor.network = predictor.network.to(device)
        predictor.network.eval()
        if empty_cache is not None:
            empty_cache(device)

        slicers = predictor._internal_get_sliding_window_slicers(padded_data.shape[1:])
        gaussian = (
            compute_gaussian(patch_size, sigma_scale=1.0 / 8, value_scaling_factor=10, device=device)
            if predictor.use_gaussian
            else None
        )

        pad_below_x = slicer_revert_padding[1].start
        source_depth = slicer_revert_padding[1].stop - pad_below_x
        padded_height, padded_width = int(padded_data.shape[2]), int(padded_data.shape[3])
        target_depth = int(shape_after_cropping[0])

        chunk_depth = target_chunk_depth or _choose_target_chunk_depth(
            slicers,
            patch_size[0],
            source_depth,
            target_depth,
            padded_height,
            padded_width,
            num_channels,
            pad_below_x,
            max_chunk_logits_bytes=max_chunk_logits_bytes,
        )

        label_map_cropped = windowed_sliding_window_predict_and_argmax(
            padded_data,
            slicers,
            slicer_revert_padding,
            shape_after_cropping,
            num_channels,
            predictor._internal_maybe_mirror_and_predict,
            gaussian,
            device=device,
            target_chunk_depth=chunk_depth,
            label_dtype=label_dtype,
        )
        del padded_data
    else:
        # Anisotropic spacing or non-CUDA device -- fall back to the original
        # (pre-windowed) combined path: nnU-Net's own full accumulator, then
        # this module's streaming per-channel resample+argmax. Not expected to
        # trigger in production (see docstring above), kept for correctness
        # rather than raising outright.
        prediction = _predict_logits_keep_on_device(predictor, data)
        resample_channel = make_gpu_channel_resampler(
            device=device, current_spacing=current_spacing, new_spacing=target_spacing
        )
        label_map_cropped = streaming_resample_and_argmax(
            prediction,
            target_shape=shape_after_cropping,
            resample_channel=resample_channel,
            label_dtype=label_dtype,
        )
        del prediction

    segmentation_final = _revert_crop_and_transpose(label_map_cropped, properties_dict, plans_manager, label_dtype)
    del label_map_cropped

    rw = plans_manager.image_reader_writer_class()
    rw.write_seg(segmentation_final, output_file_truncated + dataset_json_dict_or_file["file_ending"], properties_dict)


def streaming_export_prediction_from_logits(
    predicted_array_or_file,
    properties_dict: dict,
    configuration_manager,
    plans_manager,
    dataset_json_dict_or_file,
    output_file_truncated: str,
    save_probabilities: bool = False,
    num_threads_torch: int = 1,
    *,
    device=None,
    original_export_fn: Callable | None = None,
) -> None:
    """Drop-in, memory-bounded replacement for nnU-Net's
    ``export_prediction.export_prediction_from_logits``. ASSUMPTION-heavy, see
    module docstring and :func:`streaming_convert_predicted_logits_to_segmentation_with_correct_shape`.

    ``save_probabilities=True`` is not supported (streaming discards each
    channel once folded into the running argmax, by design -- see this
    module's docstring) and falls back to ``original_export_fn`` if one was
    supplied, else raises.

    Called directly by :func:`predict_case_streaming` (no monkeypatching --
    see module docstring for why the previous ``install_streaming_export``
    module-attribute-patch approach was removed once this module started
    owning the whole preprocess/predict/export call chain itself).
    """
    if save_probabilities:
        if original_export_fn is None:
            raise InferenceError(
                "streaming export cannot produce save_probabilities=True output "
                "(each channel is discarded after folding into the running "
                "argmax) and no original_export_fn fallback was supplied to "
                "streaming_export_prediction_from_logits; the Docker path never "
                "needs probabilities (only the uint8 label map), so this should "
                "not be requested there."
            )
        original_export_fn(
            predicted_array_or_file,
            properties_dict,
            configuration_manager,
            plans_manager,
            dataset_json_dict_or_file,
            output_file_truncated,
            save_probabilities,
            num_threads_torch,
        )
        return

    if isinstance(dataset_json_dict_or_file, str):
        from batchgenerators.utilities.file_and_folder_operations import load_json

        dataset_json_dict_or_file = load_json(dataset_json_dict_or_file)

    label_manager = plans_manager.get_label_manager(dataset_json_dict_or_file)
    segmentation_final = streaming_convert_predicted_logits_to_segmentation_with_correct_shape(
        predicted_array_or_file,
        plans_manager,
        configuration_manager,
        label_manager,
        properties_dict,
        device=device or _default_device(),
    )
    del predicted_array_or_file

    rw = plans_manager.image_reader_writer_class()
    rw.write_seg(segmentation_final, output_file_truncated + dataset_json_dict_or_file["file_ending"], properties_dict)


def _file_ending(path: Path) -> str:
    return ".nii.gz" if path.name.endswith(".nii.gz") else ".nii"


def _predict_logits_keep_on_device(predictor, data: "torch.Tensor"):  # type: ignore[no-untyped-def]
    """Replicates ``nnUNetPredictor.predict_logits_from_preprocessed_data``'s
    fold-loading/averaging loop verbatim, EXCEPT it does not force the result to
    CPU after every fold.

    Why: nnU-Net's own method unconditionally calls
    ``self.predict_sliding_window_return_logits(data).to('cpu')`` inside the
    loop, with the comment "why not leave prediction on device if
    perform_everything_on_device? Because this may cause the second iteration
    to crash due to OOM" -- a defensive safeguard for multi-fold ensembling
    that costs us dearly for our actual single-fold (``folds=[0]``) production
    use: it forces the entire 65-channel, full-preprocessed-resolution logits
    tensor (fp16 -- ~12GB for the largest real holdout case) onto host RAM
    before this module's streaming exporter ever sees it, unconditionally,
    regardless of how much free system RAM is actually available. Confirmed via
    a real Docker container run on real GPU hardware under the organizers'
    exact ``-m 8G`` memory limit (2026-07-14/15) that this transfer is a
    real contributor to an OOM kill (``dmesg``: ``Memory cgroup out of memory``)
    on large cases.

    ``gpu_resample_and_argmax`` (this module, used automatically by
    :func:`streaming_convert_predicted_logits_to_segmentation_with_correct_shape`
    whenever the device is CUDA and spacing is isotropic -- true for this
    dataset/target in production) already accepts a GPU-resident torch tensor
    directly (``logits[channel_index]`` indexing plus an ``isinstance(...,
    np.ndarray)`` check before any ``torch.from_numpy`` call -- see its
    implementation) and folds the running argmax entirely on-device, bringing
    only the final uint8 label map back to host RAM. So the only change needed
    to get that memory-bounded behavior for real is to stop forcing the
    65-channel tensor off the GPU in the first place -- this function is that
    fix, isolated from the (already-validated, untouched) resample/argmax
    logic itself.

    Everything else -- per-fold ``load_state_dict`` (including the
    ``OptimizedModule``/``torch.compile`` branch), the
    ``torch.set_num_threads`` save/restore around the loop, and multi-fold
    averaging via ``prediction /= len(list_of_parameters)`` -- is preserved
    exactly as nnU-Net's own method does it, so this stays correct if
    production ever configures more than one fold, even though today it only
    uses ``folds=[0]`` (a single iteration, no averaging).
    """
    n_threads = torch.get_num_threads()
    torch.set_num_threads(default_num_processes if default_num_processes < n_threads else n_threads)
    try:
        prediction = None
        for params in predictor.list_of_parameters:
            if not isinstance(predictor.network, OptimizedModule):
                predictor.network.load_state_dict(params)
            else:
                predictor.network._orig_mod.load_state_dict(params)

            if prediction is None:
                prediction = predictor.predict_sliding_window_return_logits(data)
            else:
                prediction += predictor.predict_sliding_window_return_logits(data)

        if len(predictor.list_of_parameters) > 1:
            prediction /= len(predictor.list_of_parameters)
    finally:
        torch.set_num_threads(n_threads)
    return prediction


def predict_case_streaming(
    predictor, image_path: Path, output_dir: Path, *, output_suffix: str = ""
) -> CaseInferenceResult:
    """Docker-safe case runner: same overall shape as
    ``stsr2026.evaluation.nnunet_inference.predict_case`` (replicates the same
    single-case preprocess/predict loop, see that module's docstring for the
    CUDA-11.3/nnunetv2>=2.6.0 compatibility rationale), but calls
    :func:`windowed_predict_and_export` as the predict+export step instead of
    that module's ``predict_logits_from_preprocessed_data`` + ``export_
    prediction_from_logits`` -- so the full ``(num_segmentation_heads, D, H,
    W)`` logits array is never materialized anywhere, GPU or CPU, at any
    resolution (fixing the 2026-07-15 "third memory problem", see module's
    "Windowed (spatially-chunked)..." section comment above and docs/progress.md).

    **2026-07-15: no longer calls ``_predict_logits_keep_on_device`` +
    ``streaming_export_prediction_from_logits`` here** (that combination is
    still correct and still used internally, but only as
    :func:`windowed_predict_and_export`'s anisotropic/non-CUDA fallback path
    -- see that function's docstring for why "always windowed" was chosen
    over a small-case fast path back to the old combined-logits route).

    No monkeypatching is involved (unlike the removed ``install_streaming_export``):
    this function owns the whole preprocess -> predict -> export call chain
    itself, so there is no nnU-Net orchestration method left to intercept --
    the export function is just called like any other function.

    GPU-dependent and unverified, see module docstring.
    """
    _require_nnunetv2_export()
    _require_torch()
    output_dir.mkdir(parents=True, exist_ok=True)
    case_id = nifti_case_id(image_path)
    output_path = output_dir / f"{case_id}{output_suffix}{_file_ending(image_path)}"
    truncated_output = output_dir / f"{case_id}{output_suffix}"

    if torch is not None and torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats()
    start = time.perf_counter()

    preprocessor = predictor.configuration_manager.preprocessor_class(verbose=predictor.verbose)
    data, _seg, data_properties = preprocessor.run_case(
        [str(image_path)], None, predictor.plans_manager, predictor.configuration_manager, predictor.dataset_json
    )
    windowed_predict_and_export(
        predictor,
        torch.from_numpy(data),
        data_properties,
        predictor.configuration_manager,
        predictor.plans_manager,
        predictor.dataset_json,
        str(truncated_output),
        device=predictor.device,
    )
    elapsed = time.perf_counter() - start

    peak_mem: int | None = None
    if torch is not None and torch.cuda.is_available():
        peak_mem = int(torch.cuda.max_memory_allocated())

    if not output_path.is_file():
        raise InferenceError(
            f"windowed_predict_and_export did not produce the expected "
            f"output file {output_path} (ASSUMPTION about its output naming may be "
            "wrong -- check what filename it actually wrote under this nnunetv2 "
            "version)."
        )
    return CaseInferenceResult(case_id, str(image_path), str(output_path), elapsed, peak_mem)
