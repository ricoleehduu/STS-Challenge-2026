"""Volume-threshold cleanup of hallucinated false-positive label instances.

Context (``plan.md`` D7 Day 1, ``docs/progress-teammate.md``): the official IA
formula (``stsr2026.evaluation.metrics.compute_case_scores``, mirroring
``third_party/stsr_official_eval/compute_metrics.py``) is::

    num_matched(IoU >= 0.5) / len(union(gt_labels, pred_labels))

The numerator loop only ever iterates over ``gt_labels`` (see
``compute_case_scores``: ``for label_id in gt_labels: ...``), comparing the
*same* label id's GT mask against its prediction mask. A predicted label id
that is entirely absent from a case's ground truth can therefore never
contribute to the numerator -- it has no GT mask to be compared against --
but it always inflates the denominator by one, since the denominator is the
*union* of the two label sets. Every such "false-positive label" (a
connected component predicted under a class id the case's GT never uses at
all) is consequently pure IA damage with zero offsetting benefit; there is
no scenario in the official metric where keeping one helps the score.

This module implements the conservative half of the cleanup plan.md D7 Day 1
calls for: for each predicted label id absent from the case's GT label set,
inspect its connected components (``scipy.ndimage.label``, standard
6-connectivity) individually and relabel to background (0) only the ones
below a caller-supplied voxel-count threshold. Larger GT-absent components
are deliberately left untouched here -- plan.md requires those to go through
a separate, human-reviewed anatomical plausibility check (canal-count-prior
diagnostics against ``stsr2026.training.pseudo_label.EXPECTED_CANAL_COUNT_RANGE``)
before anyone decides whether to remove them; automatically deleting a large
structure on volume alone risks discarding a real, GT-mislabeled-but-actually-
present tooth/canal.

This function never touches a label that DOES appear somewhere in the case's
GT, no matter how small a given connected component of that label is --
small-but-real anatomical structures (e.g. a thin canal tip) must survive
untouched. The GT-presence check is per class label for the whole case, not
per component, matching how the IA formula itself operates on whole label
ids, not sub-components.

GT-FREE EXTENSION (see this module's bottom section, ``identify_gtfree_fp_candidates``
/ ``GTFreeOptions``): ``postprocessing_pipeline.py``'s module docstring documents
the real architectural gap this closes -- ``clean_or_relabel_false_positive_labels``
below needed ``gt_labels`` to pick candidates, which the real Docker inference
pipeline never has, making it a no-op in production despite a measured
holdout IA gain of +0.10 when ``gt_labels`` is available (see
``docs/experiment-log.md``'s ``Day1-TaskD-GTfree-t5000`` row -- that name is
legacy/inaccurate, it actually WAS GT-informed; this module's genuinely
GT-free replacement is documented in
``docs/research/08-gtfree-fp-cleanup-design.md``). ``clean_or_relabel_false_positive_labels``
now accepts ``gt_labels=None``, in which case it derives an equivalent
candidate set itself, GT-free, from anatomical/spatial signals in the
prediction alone (duplicate same-label components, per-quadrant FDI-slot
overcount, spatial isolation from the rest of the dental arch, and an
optional corroborating signal from ``ot_instance_assignment``'s dustbin
mechanism) instead of whole-label GT absence.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import AbstractSet

import numpy as np
from scipy import ndimage

from stsr2026.training.pseudo_label import (
    CANAL_CLASS_MAX,
    CANAL_CLASS_MIN,
    TOOTH_CLASS_MAX,
    TOOTH_CLASS_MIN,
)


@dataclass(frozen=True)
class RemovedComponent:
    """One connected component of one GT-absent predicted label, and the
    cleanup decision made for it."""

    label: int
    component_id: int
    voxel_count: int
    removed: bool


def clean_false_positive_labels(
    label_volume: np.ndarray,
    gt_labels: AbstractSet[int],
    volume_threshold: int,
) -> tuple[np.ndarray, tuple[RemovedComponent, ...]]:
    """Relabel small connected components of GT-absent predicted labels to background.

    Parameters
    ----------
    label_volume:
        3-D integer array of predicted class labels (0 = background).
    gt_labels:
        The set of non-zero class labels actually present in this case's
        ground truth. Labels found in ``label_volume`` but not in this set
        are candidates for cleanup; labels in this set are never touched by
        this function regardless of component size.
    volume_threshold:
        Connected components of a GT-absent label with fewer than this many
        voxels are cleared to background. Components with
        ``voxel_count >= volume_threshold`` are left untouched (the "large,
        needs-human-review" tier plan.md D7 Day 1 describes) -- the boundary
        is exclusive-above, so a component exactly at the threshold is kept,
        not removed.

    Returns
    -------
    A ``(cleaned_volume, records)`` pair. ``cleaned_volume`` is always a new
    array (never a view of ``label_volume``, even when nothing changes).
    ``records`` reports every GT-absent component considered, in label-then-
    component-id order, so callers can audit both what was removed and what
    was deliberately left for manual review.
    """
    if label_volume.ndim != 3:
        raise ValueError(f"label_volume must be 3-dimensional, got shape {label_volume.shape}")
    if volume_threshold < 0:
        raise ValueError(f"volume_threshold must be >= 0, got {volume_threshold}")

    cleaned = label_volume.copy()
    records: list[RemovedComponent] = []

    predicted_labels = np.unique(label_volume)
    false_positive_labels = sorted(
        int(label) for label in predicted_labels if label != 0 and int(label) not in gt_labels
    )

    for label in false_positive_labels:
        mask = label_volume == label
        component_labels, component_count = ndimage.label(mask)
        for component_id in range(1, component_count + 1):
            component_mask = component_labels == component_id
            voxel_count = int(np.count_nonzero(component_mask))
            removed = voxel_count < volume_threshold
            if removed:
                cleaned[component_mask] = 0
            records.append(
                RemovedComponent(
                    label=label,
                    component_id=component_id,
                    voxel_count=voxel_count,
                    removed=removed,
                )
            )

    return cleaned, tuple(records)


# ---------------------------------------------------------------------------
# GT-free-target variant: for LARGE GT-absent tooth components, try relabeling
# to a real spatial neighbour before falling back to clearing.
#
# Context (plan.md D7, "Task D"): a real-data comparison on the 6-case
# holdout found that for the 5 large GT-absent tooth components discovered
# there, relabeling each one to whichever *ground-truth* label it overlapped
# most (rather than clearing it to background) was strictly better on every
# metric that differed (tooth Dice_Image +0.0096 recovered, tooth
# Dice_Instance +0.0126, IA +0.0267 vs only +0.0114 for clearing) --
# supporting the hypothesis that these are duplicate copies of an
# already-correctly-segmented tooth relabeled under a wrong adjacent FDI
# position, not genuinely absent/hallucinated structures. That comparison
# used real ground truth to pick the relabel target, which is not available
# at real inference time. This function reproduces the same "relabel instead
# of clear" idea using ONLY information present in the prediction itself
# (a dilated-neighbourhood majority vote over other tooth classes actually
# predicted nearby), mirroring
# ``stsr2026.inference.lr_correction.inherit_canal_labels_from_corrected_teeth``'s
# search mechanism -- but note this is a materially different physical
# situation from why that canal function was a real, measured negative
# result: these 5 known false positives are same-quadrant, adjacent-FDI-
# position duplicates (e.g. label 20 sitting almost entirely on real label
# 21's territory), not front-teeth components straddling the midline the way
# the failed canal cases were -- so the failure mode that sank the canal
# version (dilation reaching across the midline into the wrong side) is not
# expected to apply here. That is a hypothesis, not a fact -- it must be
# (and was) re-validated on real data rather than assumed, see plan.md's
# task-D-GT-free real-data comparison recorded in the experiment notes.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class FalsePositiveDecision:
    """One connected component of one GT-absent predicted label, and what
    this function did about it."""

    label: int
    component_id: int
    voxel_count: int
    action: str  # "cleared_small" | "cleared_large_no_neighbor" | "relabeled_to_neighbor"
    new_label: int | None  # only set when action == "relabeled_to_neighbor"


def clean_or_relabel_false_positive_labels(
    label_volume: np.ndarray,
    gt_labels: AbstractSet[int] | None,
    volume_threshold: int,
    dilation_voxels: int = 2,
    *,
    affine: np.ndarray | None = None,
    gtfree_options: "GTFreeOptions | None" = None,
) -> tuple[np.ndarray, tuple[FalsePositiveDecision, ...]]:
    """Clear small GT-absent components; relabel large ones to a predicted neighbour, or clear as a fallback.

    ``gt_labels=None`` (NEW): runs GT-FREE. Instead of screening candidate
    components by whole-label GT absence, candidates are identified by
    :func:`identify_gtfree_fp_candidates` (duplicate same-label components,
    per-quadrant FDI-slot overcount, spatial isolation, and an optional
    OT-dustbin corroboration -- see that function's docstring and
    ``docs/research/08-gtfree-fp-cleanup-design.md``). ``affine`` is then
    REQUIRED (the GT-free signals need world coordinates); ``gtfree_options``
    (a :class:`GTFreeOptions`) tunes the signals, defaulting to
    :class:`GTFreeOptions`'s conservative defaults. Every candidate found this
    way is then run through the EXACT SAME small/large volume-threshold
    tiering and dilated-neighbour relabel logic documented below -- the two
    modes only differ in how a component earns candidacy in the first place,
    never in what happens to it once it has.

    When ``gt_labels`` is a real set (the ORIGINAL, unchanged behaviour):

    Behaves exactly like :func:`clean_false_positive_labels` for components
    below ``volume_threshold`` (cleared to background) and for identifying
    which labels/components are GT-absent candidates in the first place
    (same ``gt_labels``-based screening, same "never touch a label that
    appears anywhere in this case's GT" guarantee, regardless of component
    size). The difference is what happens to a GT-absent component AT OR
    ABOVE ``volume_threshold``:

    1. Dilate the component's mask by ``dilation_voxels`` (26-connectivity,
       matching :func:`~stsr2026.inference.lr_correction.inherit_canal_labels_from_corrected_teeth`'s
       search mechanism) and look at which OTHER tooth class (1-32, not the
       component's own GT-absent label) has the most voxels in that
       neighbourhood -- using only what's actually present in the
       prediction, never ground truth, so this half of the decision is
       reproducible at real inference time with no GT available.
    2. If such a neighbour is found, relabel the component to it.
    3. If no tooth-class neighbour is found within the dilated region, fall
       back to the original behaviour: clear the component to background.
       This function never "forces" a relabel onto an unreliable guess --
       per plan.md's explicit instruction not to manufacture a neighbour
       when none is clearly present.

    **The relabel attempt only ever applies to a GT-absent component whose
    OWN label is a TOOTH class (1-32).** A GT-absent CANAL-class (33-64)
    component at or above ``volume_threshold`` is cleared to background
    exactly like the small-component path, never relabeled -- this task is
    explicitly scoped to tooth false positives (plan.md's real 5-large-
    false-positive finding was 100% tooth-class), and relabeling a canal
    component onto a *tooth* class via this same tooth-neighbourhood search
    would be semantically nonsensical (canal voxels are never tooth voxels)
    and would risk repeating
    :func:`~stsr2026.inference.lr_correction.inherit_canal_labels_from_corrected_teeth`'s
    real, measured negative result for canal relabeling by a different path.
    FOUND THE HARD WAY: an earlier version of this function had no such
    restriction and, when tested with ``volume_threshold=0`` (every
    GT-absent component attempts a relabel, diagnostic-only run), silently
    relabeled small canal false-positive components onto neighbouring tooth
    classes -- caught by inspecting the real output records, not assumed
    safe.

    ``gt_labels`` itself is still required (same as
    :func:`clean_false_positive_labels`) purely to decide WHICH components
    are candidates for this treatment in the first place -- it is NOT used
    to pick the relabel target (that's the GT-free part). See this
    function's module-level docstring section for why real deployment still
    cannot supply ``gt_labels`` and what that means for wiring this into the
    production pipeline.

    Returns ``(output_volume, records)``, mirroring
    :func:`clean_false_positive_labels`'s return shape.
    """
    if label_volume.ndim != 3:
        raise ValueError(f"label_volume must be 3-dimensional, got shape {label_volume.shape}")
    if volume_threshold < 0:
        raise ValueError(f"volume_threshold must be >= 0, got {volume_threshold}")
    if gt_labels is None and affine is None:
        raise ValueError(
            "affine is required when gt_labels=None -- GT-free candidate identification "
            "(identify_gtfree_fp_candidates) needs world coordinates for its spatial signals"
        )

    output = label_volume.copy()
    records: list[FalsePositiveDecision] = []
    # Component IDENTIFICATION uses ndimage.label's default structure (implicit
    # 6-connectivity, generate_binary_structure(3, 1)) with NO explicit
    # `structure=` argument -- deliberately matching clean_false_positive_labels's
    # call exactly (which also passes no structure), so that running this
    # function with the same volume_threshold produces the exact same
    # small-component population/sizes clean_false_positive_labels does, and
    # results stay apples-to-apples comparable. FOUND THE HARD WAY: an earlier
    # version of this function passed a 26-connectivity structure to
    # ndimage.label here (matching the *dilation* neighbourhood-search
    # structure below), which is a real, material bug -- it silently merges
    # diagonally-adjacent-only false-positive blobs that
    # clean_false_positive_labels would have counted as separate components,
    # changing which components fall above/below volume_threshold. Caught by
    # a real-data run reporting 162 total false-positive components against
    # this same baseline where clean_false_positive_labels's own diagnosis
    # (fp_component_diagnosis.json) reports 257 -- not a rounding difference,
    # a real behavioural inconsistency between the two functions. Fixed here;
    # the DILATION step below (searching for a nearby tooth neighbour, a
    # different concept from "what counts as one object") is unaffected and
    # still deliberately uses the wider 26-connectivity structure.
    dilation_structure = ndimage.generate_binary_structure(3, 3)

    # `component_filter[label]` is either `None` -- meaning "every component of
    # this label is a candidate" (the original gt_labels-driven whole-label
    # screening below) -- or a `frozenset[int]` of specific component ids (the
    # GT-free path, where candidacy is decided per-component, e.g. only the
    # non-primary duplicate of a label that also has a legitimate primary
    # component). Both paths then share the exact same per-component small/
    # large decision logic below, so a candidate behaves identically no
    # matter how it earned candidacy.
    component_filter: dict[int, frozenset[int] | None]
    # `forced_relabel[(label, component_id)]` -- ONLY ever populated in
    # GT-free mode, and only for CANAL-class candidates Signal B (redundant
    # same-quadrant coverage) flagged (see identify_gtfree_fp_candidates's
    # module section on canal handling): the class id to relabel straight to,
    # bypassing the small/large volume tiering below entirely. This is the
    # "surgical same-quadrant-overlap relabel" real-data validation
    # (docs/experiment-log.md's canal over-deletion finding) required for any
    # canal cleanup that survives at all -- a canal component this signal
    # flags is real anatomical tissue sitting on a bigger same-quadrant
    # canal's territory, not noise, so it must always be RELABELED (kept as
    # foreground under the corrected id), never cleared to background
    # regardless of its size. Tooth candidates never populate this dict (they
    # keep using the dilated-neighbour-search relabel-or-clear logic below,
    # unchanged) and the gt_labels-driven path never populates it either.
    forced_relabel: dict[tuple[int, int], int] = {}
    if gt_labels is not None:
        predicted_labels = np.unique(label_volume)
        false_positive_labels = sorted(
            int(label) for label in predicted_labels if label != 0 and int(label) not in gt_labels
        )
        component_filter = {label: None for label in false_positive_labels}
    else:
        gtfree_candidates = identify_gtfree_fp_candidates(label_volume, affine, gtfree_options)
        component_filter = {}
        for candidate in gtfree_candidates:
            component_filter.setdefault(candidate.label, set()).add(candidate.component_id)  # type: ignore[union-attr]
            if candidate.suggested_relabel is not None:
                forced_relabel[(candidate.label, candidate.component_id)] = candidate.suggested_relabel
        component_filter = {label: frozenset(ids) for label, ids in component_filter.items()}  # type: ignore[arg-type]

    # PERFORMANCE, found via real-data profiling: this loop originally derived
    # a fresh FULL-VOLUME boolean mask (`label_volume == label`) and ran a
    # FULL-VOLUME `ndimage.label` for every candidate label -- on a real
    # ~512^3 case with dozens of candidate labels this is the same wasted-scan
    # problem `_enumerate_components` already documents fixing for signal
    # identification (most of the volume provably cannot contain a given
    # label). One `ndimage.find_objects` pass over the full volume gives a
    # tight bounding box for every candidate label at once; `ndimage.label`
    # then runs on that small crop. The final large-component dilation search
    # is similarly restricted to a small region padded by exactly
    # `dilation_voxels` around the component's own tight bbox (clipped to the
    # volume) instead of dilating a full-volume boolean array -- a dilation
    # with `iterations=dilation_voxels` can never reach farther than that many
    # voxels from the True region, and scipy's default `border_value=0` at a
    # true array edge is exactly what clipping the padding at the volume
    # boundary reproduces, so the neighbourhood found is byte-for-byte
    # identical to the un-cropped version. Every write below targets `output`
    # through the same small crop, never a full-volume boolean array.
    label_bboxes = ndimage.find_objects(label_volume, max_label=max(component_filter)) if component_filter else []

    for label in sorted(component_filter):
        allowed_component_ids = component_filter[label]
        bbox = label_bboxes[label - 1] if 0 < label <= len(label_bboxes) else None
        if bbox is None:
            continue  # label not actually present in the volume (defensive)

        cropped_labels = label_volume[bbox]
        mask = cropped_labels == label
        component_labels, component_count = ndimage.label(mask)  # default structure, see note above
        component_bboxes = ndimage.find_objects(component_labels)
        crop_origin = np.array([s.start for s in bbox])

        for component_id in range(1, component_count + 1):
            if allowed_component_ids is not None and component_id not in allowed_component_ids:
                continue  # GT-free mode: this specific component (e.g. a label's
                # legitimate primary instance) was not flagged by any signal --
                # leave it completely untouched, no record.
            sub_bbox = component_bboxes[component_id - 1]
            local_component_labels = component_labels[sub_bbox]
            local_mask = local_component_labels == component_id
            voxel_count = int(np.count_nonzero(local_mask))
            sub_origin = np.array([s.start for s in sub_bbox])
            global_offset = crop_origin + sub_origin
            global_slices = tuple(
                slice(int(global_offset[a]), int(global_offset[a] + local_mask.shape[a])) for a in range(3)
            )

            forced_target = forced_relabel.get((label, component_id))
            if forced_target is not None:
                output[global_slices][local_mask] = forced_target
                records.append(
                    FalsePositiveDecision(label, component_id, voxel_count, "relabeled_to_neighbor", forced_target)
                )
                continue

            if voxel_count < volume_threshold:
                output[global_slices][local_mask] = 0
                records.append(FalsePositiveDecision(label, component_id, voxel_count, "cleared_small", None))
                continue

            if not (TOOTH_CLASS_MIN <= label <= TOOTH_CLASS_MAX):
                # Large GT-absent CANAL component -- never attempt a tooth-neighbour
                # relabel (see docstring: semantically nonsensical and risks
                # reproducing inherit_canal_labels_from_corrected_teeth's real
                # negative result by a different path). Same fallback as "no
                # neighbour found", tagged separately for auditability.
                output[global_slices][local_mask] = 0
                records.append(
                    FalsePositiveDecision(label, component_id, voxel_count, "cleared_large_non_tooth", None)
                )
                continue

            low_pad = [min(dilation_voxels, global_slices[a].start) for a in range(3)]
            high_pad = [
                min(dilation_voxels, label_volume.shape[a] - global_slices[a].stop) for a in range(3)
            ]
            padded_local_mask = np.pad(
                local_mask, list(zip(low_pad, high_pad)), mode="constant", constant_values=False
            )
            dilated = ndimage.binary_dilation(padded_local_mask, structure=dilation_structure, iterations=dilation_voxels)
            neighbourhood = dilated & ~padded_local_mask
            region_slices = tuple(
                slice(global_slices[a].start - low_pad[a], global_slices[a].stop + high_pad[a]) for a in range(3)
            )
            tooth_neighbours = label_volume[region_slices][neighbourhood]
            tooth_neighbours = tooth_neighbours[
                (tooth_neighbours >= TOOTH_CLASS_MIN)
                & (tooth_neighbours <= TOOTH_CLASS_MAX)
                & (tooth_neighbours != label)
            ]

            if tooth_neighbours.size == 0:
                output[global_slices][local_mask] = 0
                records.append(
                    FalsePositiveDecision(label, component_id, voxel_count, "cleared_large_no_neighbor", None)
                )
                continue

            values, counts = np.unique(tooth_neighbours, return_counts=True)
            neighbour_class = int(values[np.argmax(counts)])
            output[global_slices][local_mask] = neighbour_class
            records.append(
                FalsePositiveDecision(label, component_id, voxel_count, "relabeled_to_neighbor", neighbour_class)
            )

    return output, tuple(records)


# ---------------------------------------------------------------------------
# GT-FREE candidate identification.
#
# Context: everything above this point needs `gt_labels` -- the real
# ground-truth label set -- purely to decide WHICH predicted labels/
# components are false-positive candidates in the first place. That is fine
# for offline holdout evaluation but, per `postprocessing_pipeline.py`'s
# module docstring, makes `clean_or_relabel_false_positive_labels` a no-op in
# the real Docker submission (no GT is ever available there), even though
# the *measured* holdout gain from that function is large (IA 0.5472 ->
# 0.6477, see docs/experiment-log.md). This section replaces the GT-presence
# screening with GT-free anatomical/spatial signals derived only from the
# prediction volume itself, so `clean_or_relabel_false_positive_labels(...,
# gt_labels=None, affine=...)` can act at real inference time too. See
# docs/research/08-gtfree-fp-cleanup-design.md for the full design rationale,
# the real-data validation command, and honest limitations.
#
# FOUR SIGNALS, DELIBERATELY NOT ALL WEIGHTED EQUALLY:
#
# (A) Duplicate same-label components -- a single FDI label id realized as
#     more than one connected component. This is exactly the failure mode
#     `clean_or_relabel_false_positive_labels`'s own docstring documents as
#     the real 5-case finding behind the +0.10 IA gain: "duplicate copies of
#     an already-correctly-segmented tooth relabeled under a wrong adjacent
#     FDI position". The largest component of each label is kept as the
#     presumed-real "primary" instance (never flagged, regardless of size --
#     a label with only one component, however small, is never touched by
#     this signal: a thin canal tip with no sibling component is not a
#     duplicate of anything); every OTHER component under that same label is
#     flagged. This is the highest-confidence signal here: it requires no
#     absolute size/distance threshold at all, only "this label already has
#     a better-supported instance elsewhere", which is true regardless of
#     case-to-case anatomical variation (missing teeth, small jaws, etc).
#
# (B) Per-quadrant redundant-coverage ("over-count") -- NOTE what this signal
#     is deliberately NOT: a naive "count distinct label ids in this
#     (category, quadrant) group and flag any beyond 8" check is mathematically
#     UNREACHABLE under the class-id-defined quadrant grouping every module in
#     this repo uses (`_category_and_quadrant` below, same convention as
#     `hungarian_instance_assignment.py`/`ot_instance_assignment.py`): each
#     quadrant's label-id range (e.g. tooth Q1 = classes 1-8) contains
#     EXACTLY 8 possible ids by construction, so "more than 8 distinct labels
#     in this group" can never be true -- this was tried first, found to be a
#     dead check by inspection (not by a failing test), and replaced with
#     what the real documented finding this task is chasing actually looks
#     like: a small label sitting almost entirely on top of a larger,
#     already-established SAME-quadrant label's territory (verbatim example
#     from `clean_or_relabel_false_positive_labels`'s own docstring: "label
#     20 sitting almost entirely on real label 21's territory"). For every
#     PAIR of primary labels in the same (category, quadrant) group, if a
#     smaller label's (dilated) territory overlaps a STRICTLY LARGER
#     same-group label's territory by at least `overcount_overlap_fraction`,
#     the smaller one is flagged -- it is anatomically implausible for two
#     distinct real teeth/canals to occupy nearly the same physical space, so
#     the smaller one is almost certainly redundant/duplicate coverage of the
#     bigger, already-plausible one rather than a second real structure.
#     Requires the OTHER label to be strictly bigger (not just "overlaps
#     something"), which rules out flagging two genuinely close, comparably-
#     sized real neighbours -- a symmetric overlap between two similar-sized
#     components never gets a "who wins" verdict from this signal.
#
# (C) Spatial isolation -- a primary component whose nearest same-category
#     primary-component neighbour (Euclidean, world mm, pooled across all
#     four quadrants so a real outermost tooth/canal near a quadrant boundary
#     still has same-jaw neighbours to compare against) is farther than
#     `isolation_distance_mm`. Only evaluated among components NOT already
#     flagged by (A)/(B), and only when at least 4 other same-category
#     primary components exist to judge isolation against (a near-empty
#     prediction has no reliable "arch" to be isolated from). This is the
#     signal we are least confident in -- see this module's docstring in
#     `identify_gtfree_fp_candidates` and docs/research/08-gtfree-fp-cleanup-design.md's
#     "Limitations" section for why a large but genuine gap (several missing
#     adjacent teeth) can in principle still trip it, and why the default
#     threshold was chosen the way it was.
#
# (D) OT-dustbin corroboration (OFF by default) -- reuses
#     `stsr2026.inference.ot_instance_assignment.assign_instances_to_fdi_slots`'s
#     GT-free dustbin mechanism as an EXTRA, non-authoritative signal: a
#     component whose dustbin reason is "routed_to_dustbin" or
#     "lost_slot_competition" (never "too_small", which duplicates this
#     module's own min_component_voxels floor) is flagged too, tuned with a
#     HIGHER dustbin_cost than that module's own default (0.5) specifically
#     because the task brief that motivated this module found the OT
#     module's default tuning over-rejects on real data. This is additive
#     only -- turning it off never removes a candidate the other three
#     signals already found; turning it on can only ADD candidates, never
#     veto one. Off by default because it triples this function's per-case
#     cost (a full Sinkhorn solve on top of everything else) for a signal
#     this module's own design note flags as the least validated of the
#     four; see the design doc for how to enable and re-tune it.
# ---------------------------------------------------------------------------
#
# REAL-DATA FINDING, POST-FIRST-VALIDATION (recorded honestly, not hidden):
# a real 6-case holdout run with only signals A+"small volume" enabled
# (duplicate + volume-threshold tiering, B and C off) CRATERED canal metrics
# -- canal Dice_Image 0.8180 -> 0.6292 (-0.19), canal Dice_Instance
# 0.4512 -> 0.3885, canal NSD 0.6074 -> 0.4919 -- even though IA rose
# (0.5472 -> 0.5780). Root cause: canals (33-64) are LEGITIMATELY thin, small,
# and naturally fragmented into many small connected components per label
# (this is real anatomy, not noise -- a single root canal's thin centerline
# annotation/prediction routinely breaks into several components from
# 1-voxel gaps, see `pseudo_label.py`'s "SKELETON-LABEL / MORPHOLOGICAL-
# CLOSING TRADEOFF" docstring section). Signal A's "largest component is
# primary, clear the rest" logic and the downstream small-volume clearing
# tier both assume a duplicate/small fragment is noise -- true for bulky
# solid teeth, FALSE for canals, where a small fragment is very often real
# canal tissue that happens to be a separate connected component. The
# GT-informed original function never had this problem because `gt_labels`
# told it exactly which whole LABELS were real false positives; a GT-free
# method has no such ground truth and a real canal fragment looks
# indistinguishable from a real false positive by shape/size alone.
#
# FIX: `GTFreeOptions.clean_classes` ("teeth" (default) | "all") gates which
# classes are even ELIGIBLE for candidacy in the first place.
#
# - `clean_classes="teeth"` (default, and what real validation now requires):
#   canal-range labels (33-64) are excluded from `identify_gtfree_fp_candidates`
#   ENTIRELY -- they never appear in any signal's candidate set, so
#   `clean_or_relabel_false_positive_labels(gt_labels=None, ...)` cannot touch
#   a single canal voxel by default. Teeth are large, solid, anatomically
#   singular structures (one real tooth per FDI slot, not naturally
#   fragmented the way canals are) -- a duplicate/redundant/isolated tooth
#   label really is almost always a genuine false positive, which is why the
#   real +0.10 IA finding this whole module chases was itself 100% tooth-class
#   (see this module's "GT-free-target variant" section header above).
# - `clean_classes="all"`: canal labels become eligible again, but ONLY via
#   signal B (redundant same-quadrant coverage) -- signals A, C, and D never
#   flag a canal component regardless of `clean_classes` (see each signal's
#   implementation below). Critically, a canal component signal B flags is
#   NOT cleared/volume-tiered like everything else -- `identify_gtfree_fp_candidates`
#   attaches a `suggested_relabel` (the bigger same-quadrant canal label it
#   overlaps) to these candidates, and `clean_or_relabel_false_positive_labels`
#   relabels straight to that target regardless of size, bypassing the
#   small-volume-clear tier entirely (see that function's `forced_relabel`
#   handling). This is deliberate: a canal component sitting almost entirely
#   inside a bigger same-quadrant canal's territory is real canal tissue under
#   the wrong label, not noise -- clearing it would delete real foreground
#   voxels (exactly the mechanism that cratered canal Dice above); relabeling
#   keeps the voxels as canal foreground under a corrected id, which can only
#   help IA/Dice_Instance, never remove real canal mass from the image-level
#   mask.
# ---------------------------------------------------------------------------

QUADRANT_SIZE = 8  # duplicated from lr_correction.py / ot_instance_assignment.py's
# own copies of the same anatomical constant (8 FDI positions per quadrant),
# for the same module-independence/auditability reason those modules give.

# Real jaw arches are on the order of 50-70mm wide; even the two farthest-
# apart same-category teeth in one arch (e.g. left vs right 3rd molar) sit
# well under this straight-line Euclidean distance in practice, since the
# arch curves back toward the midline rather than running straight out to
# the sides. Chosen conservatively high (see docs/research/08-gtfree-fp-cleanup-design.md
# for the reasoning and its acknowledged uncertainty) so that a real but
# unusually large gap (several consecutive missing teeth) does not trip this
# signal, while a genuinely stray/artifactual component (segmented well
# outside the dental arch entirely) still does.
DEFAULT_ISOLATION_DISTANCE_MM = 40.0
DEFAULT_MIN_COMPONENT_VOXELS = 5
# Minimum number of OTHER same-category primary components required before
# the isolation signal is evaluated at all -- an almost-empty prediction has
# no reliable "arch" to be isolated from, and flagging its only few
# components as mutually isolated would be nonsensical.
MIN_PEERS_FOR_ISOLATION_CHECK = 4
# Signal B (redundant same-quadrant coverage): how far to dilate the smaller
# candidate's mask before measuring overlap against a larger same-quadrant
# neighbour -- deliberately the same default as
# clean_or_relabel_false_positive_labels's own `dilation_voxels` default (2),
# since both are answering a structurally similar "does this touch/sit on
# that other predicted structure" question.
DEFAULT_OVERCOUNT_DILATION_VOXELS = 2
# Fraction of the smaller candidate's own (dilated) voxels that must overlap
# a larger same-quadrant neighbour before it is flagged redundant. 0.5 (a
# majority) is deliberately a high bar -- two real, merely-adjacent teeth
# touch at a boundary but do not majority-overlap once dilated by just 2
# voxels; the real "sitting almost entirely on" failure mode this targets
# was near-total overlap, not a grazing contact.
DEFAULT_OVERCOUNT_OVERLAP_FRACTION = 0.5


# Which classes are even eligible to be flagged at all. "teeth" (default) is
# the only setting real-data validation currently supports without canal
# damage -- see this module's "REAL-DATA FINDING, POST-FIRST-VALIDATION"
# section above before ever passing "all" on a real submission.
DEFAULT_CLEAN_CLASSES = "teeth"


@dataclass(frozen=True)
class GTFreeOptions:
    """Tunable knobs for :func:`identify_gtfree_fp_candidates`.

    Defaults are deliberately conservative -- see this module's "GT-FREE
    candidate identification" section header and
    docs/research/08-gtfree-fp-cleanup-design.md. Every flag defaults to
    "on" except the least-validated signal (OT-dustbin corroboration),
    which defaults to "off".
    """

    min_component_voxels: int = DEFAULT_MIN_COMPONENT_VOXELS
    isolation_distance_mm: float = DEFAULT_ISOLATION_DISTANCE_MM
    min_peers_for_isolation_check: int = MIN_PEERS_FOR_ISOLATION_CHECK
    overcount_dilation_voxels: int = DEFAULT_OVERCOUNT_DILATION_VOXELS
    overcount_overlap_fraction: float = DEFAULT_OVERCOUNT_OVERLAP_FRACTION
    # "teeth": canal-range labels (33-64) are never eligible for ANY signal,
    # full stop -- the only setting validated safe on real data (see this
    # module's "REAL-DATA FINDING" section header above; canals fragment
    # naturally, so duplicate/small-volume-style clearing destroys real
    # canal tissue). "all": canal labels become eligible ONLY for signal B,
    # and only via a forced relabel-to-neighbour (never a clear) -- signals
    # A, C, and D never flag a canal component regardless of this setting.
    clean_classes: str = DEFAULT_CLEAN_CLASSES
    use_duplicate_signal: bool = True
    use_quadrant_overcount_signal: bool = True
    use_spatial_isolation_signal: bool = True
    use_ot_dustbin_signal: bool = False
    ot_dustbin_cost: float = 0.9  # deliberately higher than ot_instance_assignment's
    # own DEFAULT_DUSTBIN_COST=0.5 -- see this section's header comment and the
    # design doc for why a higher (more reluctant-to-reject) cost is used here.


@dataclass(frozen=True)
class GTFreeCandidate:
    """One connected component flagged, GT-FREE, as a false-positive candidate."""

    label: int
    component_id: int
    voxel_count: int
    signal: str  # "duplicate_component" | "quadrant_overcount" | "spatially_isolated" | "ot_dustbin"
    # Only ever set for CANAL candidates signal B (redundant same-quadrant
    # coverage) flags with `clean_classes="all"` -- see this module's
    # "REAL-DATA FINDING" section header. When set,
    # clean_or_relabel_false_positive_labels relabels straight to this class
    # id regardless of size, bypassing the small-volume-clear tier (a canal
    # component flagged this way is real tissue under the wrong label, not
    # noise). Always None for every other signal/category combination.
    suggested_relabel: int | None = None


@dataclass(frozen=True)
class _ComponentInfo:
    label: int
    component_id: int
    voxel_count: int
    centroid_world: np.ndarray  # shape (3,)
    bbox: tuple[slice, slice, slice]  # GLOBAL volume coordinates, tight to this component
    local_mask: np.ndarray  # boolean, shape == bbox shape, True only for this component's own voxels


def _world_coords(indices: np.ndarray, affine: np.ndarray) -> np.ndarray:
    """Full 3-D world coordinates for an (n, 3) array of voxel indices.

    Duplicated (not imported) from lr_correction.py's / ot_instance_assignment.py's
    own single-axis ``_world_x`` helpers, for the same module-independence
    reason those modules document -- but returning all 3 axes, since a true
    Euclidean isolation-distance check (signal C) needs more than the
    left/right axis those modules only need for midline comparisons.
    """
    return indices @ affine[:3, :3].T + affine[:3, 3]


def _category_and_quadrant(label: int) -> tuple[str, int] | None:
    """``(category, quadrant_index)`` for a tooth/canal class id, or ``None``
    for background/out-of-range. Quadrant index is 0-3, matching
    ``ot_instance_assignment``'s convention (Q1=0 .. Q4=3)."""
    if TOOTH_CLASS_MIN <= label <= TOOTH_CLASS_MAX:
        return "tooth", (label - TOOTH_CLASS_MIN) // QUADRANT_SIZE
    if CANAL_CLASS_MIN <= label <= CANAL_CLASS_MAX:
        return "canal", (label - CANAL_CLASS_MIN) // QUADRANT_SIZE
    return None


def _enumerate_components(
    label_volume: np.ndarray, affine: np.ndarray, labels: list[int]
) -> dict[int, list[_ComponentInfo]]:
    """Connected components (default/6-connectivity, matching this module's
    convention throughout) for each of ``labels``, with world centroids and a
    tight per-component bounding box + local mask.

    PERFORMANCE, found via real-data validation (two rounds):

    1. A first version of this module's Signal B re-derived a fresh
       FULL-VOLUME boolean mask and ran FULL-VOLUME ``ndimage.binary_dilation``
       for every candidate label in every multi-label quadrant group -- on a
       real ~512^3 case this took roughly 24 MINUTES PER CASE. Fixed by
       computing a tight per-component bounding box + ``local_mask`` (see
       below) so Signal B never dilates/compares using a full-volume array.
    2. That fix still built each label's ``component_labels`` by running
       ``ndimage.label`` -- and then ``ndimage.find_objects`` -- on a
       FULL-VOLUME boolean mask (``label_volume == label``) for every one of
       ``labels`` (up to 32-64 times per case): most of that volume can
       provably not contain the label being searched for, so nearly all of
       the scan is wasted. This version instead makes ONE
       ``ndimage.find_objects(label_volume, max_label=...)`` pass over the
       full volume to get a tight bounding box for EVERY label in ``labels``
       at once (this is exactly what ``find_objects`` is for: a single O(volume)
       scan tracking per-label min/max index, no per-label re-scan needed),
       then runs ``ndimage.label``/``ndimage.find_objects`` on that label's
       small CROPPED region only. Cropping to a label's own tight bounding
       box before labeling never reorders or drops any of that label's
       voxels relative to a full-volume scan restricted to the same voxels --
       it only skips scanning guaranteed-empty regions outside the box -- so
       the resulting component numbering, voxel counts, and centroids are
       byte-for-byte identical to the un-cropped version, just computed over
       far fewer voxels.
    """
    result: dict[int, list[_ComponentInfo]] = {}
    if not labels:
        return result
    label_bboxes = ndimage.find_objects(label_volume, max_label=max(labels))
    for label in labels:
        bbox = label_bboxes[label - 1] if 0 < label <= len(label_bboxes) else None
        if bbox is None:
            result[label] = []
            continue
        cropped_labels = label_volume[bbox]
        mask = cropped_labels == label
        component_labels, component_count = ndimage.label(mask)
        infos = []
        if component_count > 0:
            bboxes = ndimage.find_objects(component_labels)
            crop_origin = np.array([s.start for s in bbox])
            for component_id in range(1, component_count + 1):
                sub_bbox = bboxes[component_id - 1]
                local_component_labels = component_labels[sub_bbox]
                local_mask = local_component_labels == component_id
                voxel_count = int(np.count_nonzero(local_mask))
                local_indices = np.argwhere(local_mask)
                sub_origin = np.array([s.start for s in sub_bbox])
                global_offset = crop_origin + sub_origin
                # These, in this exact order, are identical to what
                # np.argwhere(full_volume_component) would enumerate -- same
                # reasoning as lr_correction.correct_lr_confusion's docstring.
                global_indices = local_indices + global_offset
                centroid = np.mean(_world_coords(global_indices, affine), axis=0)
                global_bbox = tuple(
                    slice(int(global_offset[a]), int(global_offset[a] + local_mask.shape[a])) for a in range(3)
                )
                infos.append(_ComponentInfo(label, component_id, voxel_count, centroid, global_bbox, local_mask))
        result[label] = infos
    return result


def _mask_in_region(
    local_mask: np.ndarray, mask_bbox: tuple[slice, slice, slice], region_bbox: tuple[slice, slice, slice]
) -> np.ndarray:
    """Return a boolean array shaped like ``region_bbox``, containing
    ``local_mask``'s voxels restricted to the overlap between ``mask_bbox``
    and ``region_bbox`` in shared GLOBAL volume coordinates (``False``
    elsewhere, including when the two boxes don't overlap at all). Lets two
    components' masks be compared within a shared small region-of-interest
    without ever materializing a full-volume array -- the mechanism that
    makes Signal B's per-pair overlap check cheap (see
    :func:`_enumerate_components`'s docstring for the full-volume cost this
    replaces)."""
    region_shape = tuple(s.stop - s.start for s in region_bbox)
    out = np.zeros(region_shape, dtype=bool)
    starts = [max(mask_bbox[axis].start, region_bbox[axis].start) for axis in range(3)]
    stops = [min(mask_bbox[axis].stop, region_bbox[axis].stop) for axis in range(3)]
    if any(starts[axis] >= stops[axis] for axis in range(3)):
        return out
    local_slices = tuple(
        slice(starts[axis] - mask_bbox[axis].start, stops[axis] - mask_bbox[axis].start) for axis in range(3)
    )
    out_slices = tuple(
        slice(starts[axis] - region_bbox[axis].start, stops[axis] - region_bbox[axis].start) for axis in range(3)
    )
    out[out_slices] = local_mask[local_slices]
    return out


def _ot_dustbin_signal(
    label_volume: np.ndarray,
    affine: np.ndarray,
    options: GTFreeOptions,
    already_flagged: AbstractSet[tuple[int, int]],
) -> dict[tuple[int, int], str]:
    """Signal D: corroborating (label, component_id) pairs from
    ``ot_instance_assignment``'s dustbin, tuned with a higher (more
    reluctant-to-reject) ``dustbin_cost`` than that module's own default --
    see this file's "GT-FREE candidate identification" section header for
    why. Local import: keeps this module's default import surface free of
    the OT solver for the (default) case where this signal is disabled.

    TOOTH-CLASS ONLY, always, regardless of ``options.clean_classes`` -- same
    "never volume/duplicate clearing for canals" principle as signals A and
    C (see this module's "REAL-DATA FINDING" section header): a canal
    component this signal alone would flag has no ``suggested_relabel``
    (only Signal B computes one), so letting it through would route straight
    into the small-volume-clear tier -- exactly the real, measured canal
    damage this module's canal handling exists to prevent.
    """
    from stsr2026.inference.ot_instance_assignment import assign_instances_to_fdi_slots

    result = assign_instances_to_fdi_slots(
        label_volume,
        affine,
        dustbin_cost=options.ot_dustbin_cost,
        min_component_voxels=options.min_component_voxels,
    )
    additions: dict[tuple[int, int], str] = {}
    for entry in result.dustbin:
        if entry.reason == "too_small":
            continue  # redundant with this module's own min_component_voxels floor
        if not (TOOTH_CLASS_MIN <= entry.original_label <= TOOTH_CLASS_MAX):
            continue  # canal-range dustbin hits never corroborate here -- see docstring above
        for component_id in entry.component_ids:
            key = (entry.original_label, component_id)
            if key not in already_flagged:
                additions[key] = "ot_dustbin"
    return additions


def identify_gtfree_fp_candidates(
    label_volume: np.ndarray,
    affine: np.ndarray,
    options: GTFreeOptions | None = None,
) -> tuple[GTFreeCandidate, ...]:
    """Identify false-positive candidate components using ONLY the
    prediction volume -- no ground truth, ever (this function does not and
    cannot accept a ``gt_labels`` argument by design).

    See this module's "GT-FREE candidate identification" section header
    comment for the four signals (duplicate components, per-quadrant
    overcount, spatial isolation, optional OT-dustbin corroboration) and the
    reasoning behind each. A component earns candidacy from the FIRST signal
    that flags it (signals are evaluated in the order A, B, C, D and do not
    overwrite an earlier flag), but which signal name ends up on a given
    :class:`GTFreeCandidate` is for auditing only -- downstream handling
    (:func:`clean_or_relabel_false_positive_labels`'s small/large tiering)
    treats every candidate identically regardless of which signal found it.

    Every component of a label with NO flagged candidates keeps its label
    completely untouched by design -- this function only ever ADDS
    candidates on top of whatever a case's real anatomy already looks like;
    it never has an opinion about a label/component it did not explicitly
    flag.

    Returns candidates sorted by ``(label, component_id)`` for determinism.
    """
    if label_volume.ndim != 3:
        raise ValueError(f"label_volume must be 3-dimensional, got shape {label_volume.shape}")
    if affine.shape != (4, 4):
        raise ValueError(f"affine must have shape (4, 4), got {affine.shape}")
    if options is None:
        options = GTFreeOptions()
    if options.clean_classes not in ("teeth", "all"):
        raise ValueError(f"clean_classes must be 'teeth' or 'all', got {options.clean_classes!r}")

    all_labels = sorted(int(label) for label in np.unique(label_volume) if label != 0)
    if options.clean_classes == "teeth":
        # See this module's "REAL-DATA FINDING" section header: the default,
        # real-data-validated setting -- canal-range labels never enter
        # candidacy for ANY signal below.
        all_labels = [label for label in all_labels if TOOTH_CLASS_MIN <= label <= TOOTH_CLASS_MAX]
    components_by_label = _enumerate_components(label_volume, affine, all_labels)

    flagged: dict[tuple[int, int], str] = {}
    # Only ever populated for CANAL candidates Signal B flags -- see
    # GTFreeCandidate.suggested_relabel's docstring.
    relabel_target: dict[tuple[int, int], int] = {}

    # --- Signal A: duplicate same-label components (largest = primary, kept).
    # TOOTH-CLASS ONLY, always (see "REAL-DATA FINDING" section header) --
    # canals fragment into many small real components naturally, so "keep
    # the largest, flag the rest" would flag real canal tissue as duplicate. ---
    primary_by_label: dict[int, _ComponentInfo] = {}
    for label, infos in components_by_label.items():
        if not infos:
            continue
        primary = max(infos, key=lambda c: (c.voxel_count, -c.component_id))
        primary_by_label[label] = primary
        is_tooth = TOOTH_CLASS_MIN <= label <= TOOTH_CLASS_MAX
        if options.use_duplicate_signal and is_tooth:
            for info in infos:
                if info.component_id == primary.component_id:
                    continue
                flagged[(label, info.component_id)] = "duplicate_component"

    # --- Signal B: redundant same-quadrant coverage (see section header for
    # why this is NOT a ">8 distinct labels" count, which is unreachable
    # under this grouping). The only signal canal labels can ever be flagged
    # by (only reachable at all when clean_classes="all", since otherwise
    # canal labels were already excluded from `all_labels`/`primary_by_label`
    # above) -- a canal flagged here gets `relabel_target` set, so
    # clean_or_relabel_false_positive_labels relabels it instead of clearing
    # it, regardless of size (see "REAL-DATA FINDING" section header). ---
    if options.use_quadrant_overcount_signal:
        groups: dict[tuple[str, int], list[int]] = {}
        for label in primary_by_label:
            category_quadrant = _category_and_quadrant(label)
            if category_quadrant is None:
                continue
            groups.setdefault(category_quadrant, []).append(label)
        overcount_structure = ndimage.generate_binary_structure(3, 3)
        volume_shape = label_volume.shape
        for (category, _quadrant_index), labels_in_group in groups.items():
            if len(labels_in_group) < 2:
                continue  # nothing to be redundant with
            # Larger-first so a mid-sized label can still be flagged as
            # redundant against the single largest, without also needing a
            # separate check against every other smaller label.
            ranked = sorted(labels_in_group, key=lambda lbl: primary_by_label[lbl].voxel_count, reverse=True)
            for rank, label in enumerate(ranked):
                key = (label, primary_by_label[label].component_id)
                if key in flagged:
                    continue
                primary = primary_by_label[label]
                own_voxels = primary.voxel_count
                if own_voxels == 0:
                    continue
                # Dilate on a small, component-sized ROI (the component's own
                # tight bbox padded by overcount_dilation_voxels, clipped to
                # the volume), never the full volume -- see
                # _enumerate_components's docstring for the real ~24
                # min/case cost this replaced when the earlier version
                # dilated a fresh full-volume mask for every candidate.
                d = options.overcount_dilation_voxels
                low_pad = [min(d, primary.bbox[axis].start) for axis in range(3)]
                high_pad = [min(d, volume_shape[axis] - primary.bbox[axis].stop) for axis in range(3)]
                padded_own = np.pad(
                    primary.local_mask,
                    pad_width=list(zip(low_pad, high_pad)),
                    mode="constant",
                    constant_values=False,
                )
                dilated_own = ndimage.binary_dilation(padded_own, structure=overcount_structure, iterations=d)
                # Denominator is the DILATED footprint size, not the raw
                # component size -- dividing by the tiny undilated size would
                # trivially saturate near 1.0 for any small component merely
                # touching something bigger (found via a synthetic test: a
                # single isolated voxel touching a big neighbour has
                # own_voxels=1, so even 1 overlapping voxel after dilation
                # gives a ratio of 1.0 regardless of how much of its actual
                # neighbourhood is genuinely inside the bigger label). Using
                # the dilated footprint instead asks the intended question:
                # "of the territory immediately around this component, how
                # much is already claimed by the bigger neighbour" -- which
                # stays low for a component that merely touches a big
                # neighbour at one boundary face amid otherwise-open space,
                # and only gets high when the component is substantially
                # surrounded/engulfed by the bigger one's territory.
                dilated_voxel_count = int(np.count_nonzero(dilated_own))
                if dilated_voxel_count == 0:
                    continue
                region_bbox = tuple(
                    slice(primary.bbox[axis].start - low_pad[axis], primary.bbox[axis].stop + high_pad[axis])
                    for axis in range(3)
                )
                for other_label in ranked[:rank]:  # only strictly larger labels (by rank, ties keep both)
                    other_primary = primary_by_label[other_label]
                    if other_primary.voxel_count <= own_voxels:
                        continue
                    other_region_mask = _mask_in_region(other_primary.local_mask, other_primary.bbox, region_bbox)
                    overlap = int(np.count_nonzero(dilated_own & other_region_mask))
                    if overlap / dilated_voxel_count >= options.overcount_overlap_fraction:
                        flagged[key] = "quadrant_overcount"
                        if category == "canal":
                            relabel_target[key] = other_label
                        break

    # --- Signal C: spatial isolation, among primaries not already flagged.
    # TOOTH-CLASS ONLY, always (see "REAL-DATA FINDING" section header) --
    # canal components that are genuinely spatially separate (e.g. distinct
    # root canals of the same molar) are real anatomy, not isolated noise. ---
    if options.use_spatial_isolation_signal:
        tooth_labels_for_isolation = [
            label
            for label in primary_by_label
            if (category_quadrant := _category_and_quadrant(label)) is not None and category_quadrant[0] == "tooth"
        ]
        if len(tooth_labels_for_isolation) >= 1 + options.min_peers_for_isolation_check:
            centroids = np.stack([primary_by_label[label].centroid_world for label in tooth_labels_for_isolation])
            for i, label in enumerate(tooth_labels_for_isolation):
                primary = primary_by_label[label]
                key = (label, primary.component_id)
                if key in flagged:
                    continue
                other_centroids = np.delete(centroids, i, axis=0)
                distances = np.linalg.norm(other_centroids - centroids[i], axis=1)
                if distances.min() > options.isolation_distance_mm:
                    flagged[key] = "spatially_isolated"

    # --- Signal D: OT-dustbin corroboration (off by default; tooth-class
    # only always, see _ot_dustbin_signal's docstring) ---
    if options.use_ot_dustbin_signal:
        flagged.update(_ot_dustbin_signal(label_volume, affine, options, frozenset(flagged)))

    candidates = []
    for label, component_id in sorted(flagged):
        signal = flagged[(label, component_id)]
        voxel_count = next(
            info.voxel_count for info in components_by_label[label] if info.component_id == component_id
        )
        suggested_relabel = relabel_target.get((label, component_id))
        candidates.append(GTFreeCandidate(label, component_id, voxel_count, signal, suggested_relabel))
    return tuple(candidates)
