"""Wires a real trained nnU-Net checkpoint into the Docker ``/inputs`` ->
``/outputs`` contract.

Context: ``docker/run_inference.py`` (the Docker entrypoint) has only ever
called ``stsr2026.inference.predict.fake_predict`` (an all-background
placeholder) via ``stsr2026.inference.predict.run_inference``. A real P0
checkpoint now exists (see docs/progress.md), and this module is the actual
wiring that lets a human point the Docker entrypoint at it.

**Interface decision**: ``run_inference``'s contract is
``PredictFn = Callable[[np.ndarray], np.ndarray]`` -- a whole-volume-in,
whole-volume-out function, with geometry (affine/header) restoration done by
``run_inference`` itself around that call. ``nnUNetPredictor`` (via
``stsr2026.evaluation.nnunet_inference.load_predictor`` /
``stsr2026.inference.streaming_export.predict_case_streaming``) does not fit
that shape at all: it works from file *paths*, not in-memory arrays, writes
its own output file directly, and restores geometry itself (crop reversal,
resampling back to the original grid, transpose, affine/header via nnU-Net's
own ``image_reader_writer_class``) -- that is precisely what
``streaming_export``'s memory fix patches into. Forcing that through an
array-in/array-out adapter would mean: load the array ourselves (duplicate
I/O nnU-Net already does), hand it to a wrapped "predict_fn" that internally
still has to shell out to file-based nnU-Net APIs (sliding-window inference
is not just a pure function of one in-memory array; it needs the
preprocessing/cropping metadata nnU-Net computes from the file), then let
``run_inference`` redundantly re-wrap the returned array with a *second*,
independent geometry restoration that could disagree with nnU-Net's own if
anything about spacing/orientation handling differs. That's strictly more
code, more risk, and dishonest about who actually owns geometry restoration
(nnU-Net does, end to end). So this module takes option (b) from the task:
a new, thin per-case loop that calls ``predict_case_streaming`` directly,
never routing through ``run_inference``/``fake_predict``'s contract at all.
``stsr2026.inference.predict`` is untouched (D0's fake-predict smoke-test
path still works standalone) and this module does not import from it.

Output naming defaults to ``stsr2026.submission.validator``'s requirements
(same case ID as the input, no subdirectories). Docker callers can opt into a
suffix such as ``_mask`` via ``STSR_OUTPUT_SUFFIX`` without changing the
validation-zip path.

Per-case failure isolation (plan.md section 4, D3: "每例硬超时保护；失败时记录
错误，避免单病例拖死整个评测" -- per-case hard timeout, log errors, don't let
one case's failure kill the whole batch) was NOT implemented anywhere before
this module (neither ``docker/run_inference.py`` nor
``stsr2026.inference.predict.run_inference`` catch per-case exceptions or
enforce any timeout -- one bad case currently raises straight out of the
loop and aborts the whole run). This module adds it as a small, natural
extension of the per-case loop it already needs to write, with one explicit
limitation:

- **Exception isolation** (log the error, keep going): fully implemented
  and tested below -- a broken case's exception is caught, recorded, and the
  loop continues.
- **Hard timeout**: implemented as a *soft*, best-effort timeout via
  ``SIGALRM`` (see ``_case_timeout``), NOT a true hard-kill guarantee. A
  genuinely hard per-case timeout (preempting a stuck call unconditionally,
  including one blocked inside a long native/CUDA call) needs per-case
  subprocess isolation -- spawn a worker process per case, ``terminate()``/
  ``kill()`` it from the parent if it overruns, at the cost of reloading the
  checkpoint (or keeping a long-lived worker pool) per case. That is a
  materially bigger feature than "wire a checkpoint into the existing loop"
  and is called out here as a follow-up, not silently bundled into this
  task. The soft SIGALRM-based timeout below is disabled by default
  (``case_timeout_seconds=None`` / env var unset) because the currently
  measured real-GPU runtime (140s/case, docs/progress.md) is already over
  the eventual 60s budget -- turning on a tight timeout today would fail
  every case; it should be enabled once D2 efficiency work brings runtime
  under budget.

GPU-DEPENDENT AND UNVERIFIED, same disclaimer as
``stsr2026.evaluation.nnunet_inference`` and
``stsr2026.inference.streaming_export``: this sandbox has no GPU and no
working ``nnunetv2``/``torch``-with-CUDA install, so the actual
``predict_case_streaming``/``load_predictor`` calls this module wires
together have never executed end to end here. Everything in this module
that IS testable without a real checkpoint (env/config parsing, the
per-case loop's control flow, exception/timeout handling, output-path
bookkeeping) is unit-tested with injected fakes -- see
``tests/test_checkpoint_runner.py`` -- following the same
inject-a-callable-at-the-boundary pattern already used by
``nnunet_inference.py``/``streaming_export.py``'s own tests.
"""
from __future__ import annotations

import signal
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import AbstractSet, Callable, Mapping, Sequence

from stsr2026.data.audit import find_niftis, nifti_case_id
from stsr2026.evaluation.nnunet_inference import (
    DEFAULT_CHECKPOINT_NAME,
    CaseInferenceResult,
    load_predictor,
)
from stsr2026.inference.postprocessing_pipeline import (
    DEFAULT_DILATION_VOXELS,
    DEFAULT_SMALL_VOLUME_THRESHOLD,
    apply_postprocessing_to_prediction_file,
)
from stsr2026.inference.streaming_export import predict_case_streaming

# Environment variable names read by load_docker_config / docker/run_inference.py.
# Centralized here (not just inline strings in docker/run_inference.py) so the
# contract is documented and importable/testable in one place.
ENV_CHECKPOINT_DIR = "STSR_CHECKPOINT_DIR"
ENV_FOLDS = "STSR_CHECKPOINT_FOLDS"
ENV_CHECKPOINT_NAME = "STSR_CHECKPOINT_NAME"
ENV_TILE_STEP_SIZE = "STSR_TILE_STEP_SIZE"
ENV_USE_MIRRORING = "STSR_USE_MIRRORING"
ENV_CASE_TIMEOUT_SECONDS = "STSR_CASE_TIMEOUT_SECONDS"
ENV_OUTPUT_SUFFIX = "STSR_OUTPUT_SUFFIX"
# Post-write post-processing (plan.md D7): gates
# stsr2026.inference.postprocessing_pipeline.apply_postprocessing_chain's
# GT-free steps on every written prediction file -- step 1
# (correct_lr_confusion, tooth left/right correction, already validated on
# real Codabench GT, +0.205 Challenge_Score) AND, as of the D7 Day 1
# follow-up (2026-07-18), step 2 (GT-free teeth-only false-positive cleanup,
# real-data validated on the 6-case holdout as taskG-teeth-only: IA
# 0.5472 -> 0.5518, canal metrics EXACTLY unchanged by design -- see that
# module's docstring). Both need no ground truth, so this one flag now turns
# on the FULL GT-free chain, not just L/R correction alone -- the name
# STSR_APPLY_LR_CORRECTION predates step 2 and is kept for now to avoid
# introducing an untested new env var this late in the submission cycle; see
# docker/run_inference.py's comment at the call site for the same note.
# Deliberately does NOT expose the GT-informed false-positive-cleanup/relabel
# step (step 3 of stsr2026.inference.postprocessing_pipeline) via any env
# var -- that step needs a per-case gt_labels set that the real Docker
# pipeline has no way to supply (see that module's docstring); it stays a
# Python-level parameter of run_checkpoint_inference_for_docker for
# offline-evaluation callers (e.g. scripts/evaluate_checkpoint.py) that DO
# have ground truth, not something the Docker entrypoint can turn on for
# real submissions today.
#
# Default flipped to ON (see parse_bool_env(..., default=True) in
# load_docker_config below) for the 2026-07-24 submission: both steps are
# now real, measured, GT-free wins with no known regression path (step 1:
# +0.205 Challenge_Score on real Codabench hidden GT; step 2: net holdout
# IA/mIoU/tooth-Dice gain with zero canal-metric change). An operator can
# still force the old byte-identical-to-fake_predict-era behavior with
# STSR_APPLY_LR_CORRECTION=0/false/off if a real Docker validation run
# surfaces a problem.
ENV_APPLY_LR_CORRECTION = "STSR_APPLY_LR_CORRECTION"


class CaseTimeoutError(RuntimeError):
    """Raised when a case exceeds the configured soft per-case timeout."""


def _first_module_in_channels(module) -> "int | None":  # type: ignore[no-untyped-def]
    """First submodule (depth-first, definition order) exposing an ``in_channels``
    attribute -- for a standard nnU-Net ``PlainConvUNet``/``ResidualEncoderUNet``
    this is the network's real input channel count, read directly off the actual
    constructed model rather than re-deriving it from ``dataset_json``/
    ``plans_manager`` (whose exact attribute names have drifted across nnunetv2
    versions elsewhere in this module -- introspecting the already-built network
    sidesteps that entirely). Returns ``None`` if nothing exposes it, so the caller
    can skip the optimization rather than guess.
    """
    for m in module.modules():
        in_ch = getattr(m, "in_channels", None)
        if in_ch is not None:
            return int(in_ch)
    return None


def _warm_up_predictor(predictor) -> None:  # type: ignore[no-untyped-def]
    """Best-effort cuDNN/CUDA kernel warm-up: one dummy forward pass through the
    real network, at the real patch size, on the real device, run once when the
    predictor is built -- before any real case is processed.

    Why: real-hardware measurement (D2 margin-hardening round, 2026-07-13, see
    docs/progress.md) found a genuine ~9-12s GPU/cuDNN cold-start tax that hits
    whichever case is processed *first* in a predictor session, not a specific
    case. This repo's current assumption is that the real competition grading
    harness batches all cases through one long-lived container/predictor (see
    docker/README.md) -- in which case this warm-up costs a few hundred ms once
    and changes nothing else. But that assumption was never confirmed by the 2026
    organizers (plan.md flags it explicitly as open); if the real harness instead
    starts a fresh container per case, every case would otherwise pay this tax
    inside its own 60s budget. Running it here, at predictor-construction time
    (outside any per-case timing), absorbs the tax for free under either
    assumption -- there is no scenario where doing this makes things worse.

    Calls ``predictor._internal_maybe_mirror_and_predict`` (not a hand-rolled
    ``predictor.network(x)`` call) so the warm-up exercises the exact same code
    path -- same mirroring/autocast handling -- as every real sliding-window tile,
    for a representative warm-up rather than an approximate one.

    **Real-hardware bug found and fixed (2026-07-13, D2 margin-hardening
    follow-up validation, see docs/progress.md)**: the first version of this
    function called ``_internal_maybe_mirror_and_predict`` directly after
    ``load_predictor()`` returns, but ``initialize_from_trained_model_folder``
    leaves ``predictor.network`` on **CPU** -- nnU-Net only moves it to
    ``predictor.device`` itself, one level up, inside its own
    ``predict_sliding_window_return_logits``, which this low-level warm-up call
    never goes through. That meant every dummy forward pass raised a CPU/CUDA
    device-mismatch error, silently swallowed by the broad ``except Exception``
    below -- a real no-op that measured as a genuine ~0.23s every time (vs. a
    real cuDNN-autotuned pass, confirmed to take ~9-12s), providing zero actual
    benefit. Fixed by moving the network to ``device`` explicitly first, exactly
    mirroring what nnU-Net's own real path does -- verified on real hardware
    after the fix: warm-up itself now measures ~10s (matching the real cold-start
    tax being absorbed), and the following case's wall-clock drops from the cold
    54-56s range to the warm ~45s range, closing the gap this function exists
    for.

    Deliberately best-effort: any failure (an nnunetv2 version where an attribute
    name differs, an unexpected input shape, etc.) is caught and swallowed -- a
    failed warm-up must never abort or slow down the real run, only skip the
    optimization silently.
    """
    try:
        import torch

        device = predictor.device
        if device.type != "cuda":
            return
        patch_size = tuple(int(s) for s in predictor.configuration_manager.patch_size)
        in_channels = _first_module_in_channels(predictor.network)
        if in_channels is None:
            return
        predictor.network = predictor.network.to(device)
        dummy = torch.zeros((1, in_channels, *patch_size), dtype=torch.float32, device=device)
        with torch.no_grad():
            predictor._internal_maybe_mirror_and_predict(dummy)
        torch.cuda.synchronize(device)
        del dummy
    except Exception:  # noqa: BLE001 - deliberate: warm-up must never break the real run
        pass


def _release_memory_between_cases() -> None:
    """Best-effort memory reclaim, called after every case in the Docker
    per-case loop (see :func:`run_checkpoint_inference_for_docker`).

    Why: real-hardware validation of the ``-m 8G`` memory fixes (see
    ``docs/progress.md``/``docs/experiment-log.md``'s 2026-07-14/15 entries)
    found that a case sitting close to the 8GB ceiling in isolation (peak
    ~8.0-8.4GB unconstrained, passes fine as the *only* case in a container)
    reliably gets OOM-killed instead when it's the Nth case in a long-running
    batch, even though per-case peaks measured in isolation were already
    under budget after the resample-chunking and GPU-resident-logits fixes.
    Host RSS does not shrink back down between cases even after Python has
    garbage-collected the large numpy/torch arrays a case allocated -- glibc's
    allocator keeps freed heap arenas mapped rather than returning them to the
    OS, and PyTorch's CUDA caching allocator similarly retains freed device
    blocks in its own pool. Neither shows up as "still needed" but both still
    count against the cgroup's hard 8GB limit, so a handful of large cases in
    a row can accumulate just enough retained-but-unused memory to tip a
    later, otherwise-fine case over the edge -- confirmed via `dmesg`
    (repeated ``Memory cgroup out of memory`` kills at case #15 of a 20-case
    batch, on a case that passed cleanly as a standalone single-case run).

    Three independent reclaim calls, each best-effort and independently
    optional (missing ``torch``/no CUDA/no glibc ``malloc_trim`` must never
    abort the real run, only skip that one reclaim step):
    1. ``gc.collect()`` -- clears any Python-level reference cycles holding
       large arrays alive past when they're actually needed.
    2. ``torch.cuda.empty_cache()`` -- returns cached-but-unused blocks from
       PyTorch's CUDA allocator back to the driver (VRAM, not host RAM, but
       cheap and strictly helpful).
    3. ``ctypes``' ``malloc_trim(0)`` (glibc-specific) -- asks the C allocator
       to actually hand freed heap pages back to the OS, which is what
       ``gc.collect()`` alone does not do; this is the step that most
       directly addresses the host-RAM accumulation described above.
    """
    import gc

    gc.collect()

    try:
        import torch

        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    except Exception:  # noqa: BLE001 - deliberate: reclaim must never break the real run
        pass

    try:
        import ctypes

        ctypes.CDLL("libc.so.6").malloc_trim(0)
    except Exception:  # noqa: BLE001 - deliberate: not all platforms have glibc malloc_trim
        pass


@dataclass(frozen=True)
class CheckpointRunConfig:
    """Resolved configuration for a Docker checkpoint-inference run.

    ``checkpoint_dir is None`` means "no real checkpoint configured" -- the
    caller (``docker/run_inference.py``) is expected to fall back to
    ``fake_predict`` in that case, not treat it as an error: this sandbox and
    a not-yet-provisioned Docker image both legitimately have no checkpoint
    to point at yet.
    """

    checkpoint_dir: Path | None
    folds: list[int | str]
    checkpoint_name: str
    tile_step_size: float
    use_mirroring: bool
    case_timeout_seconds: float | None
    output_suffix: str = ""
    # Default True: see ENV_APPLY_LR_CORRECTION's comment above for why this
    # flag (despite its legacy name) now safely defaults to running the FULL
    # GT-free post-processing chain (L/R correction + teeth-only FP cleanup)
    # for a real submission.
    apply_lr_correction: bool = True


def parse_folds(value: str) -> list[int | str]:
    """Parse a comma/space-separated fold list, e.g. ``"0"``, ``"0,1,2"``,
    ``"0 1 2"``, or a non-numeric fold name like nnU-Net's ``"all"``.
    """
    parts = [p.strip() for p in value.replace(",", " ").split() if p.strip()]
    if not parts:
        raise ValueError(f"could not parse any folds from {value!r}")
    return [int(p) if p.lstrip("-").isdigit() else p for p in parts]


def parse_bool_env(value: str | None, default: bool = False) -> bool:
    if value is None or not value.strip():
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def load_docker_config(env: Mapping[str, str]) -> CheckpointRunConfig:
    """Build a :class:`CheckpointRunConfig` from an environment mapping
    (``os.environ`` in the real Docker entrypoint; an arbitrary ``dict`` in
    tests). Every field has a default matching the previous ``fake_predict``
    -equivalent behaviour except ``checkpoint_dir``, which has no sensible
    guessed default (the real path differs between this sandbox, which has
    none, and the GPU box, which does) -- see the module docstring and the
    task instructions this module was written against.
    """
    checkpoint_dir_raw = env.get(ENV_CHECKPOINT_DIR, "").strip()
    timeout_raw = env.get(ENV_CASE_TIMEOUT_SECONDS, "").strip()
    return CheckpointRunConfig(
        checkpoint_dir=Path(checkpoint_dir_raw) if checkpoint_dir_raw else None,
        folds=parse_folds(env.get(ENV_FOLDS, "0")),
        checkpoint_name=env.get(ENV_CHECKPOINT_NAME, DEFAULT_CHECKPOINT_NAME),
        tile_step_size=float(env.get(ENV_TILE_STEP_SIZE, "0.5")),
        use_mirroring=parse_bool_env(env.get(ENV_USE_MIRRORING)),
        case_timeout_seconds=float(timeout_raw) if timeout_raw else None,
        output_suffix=env.get(ENV_OUTPUT_SUFFIX, ""),
        apply_lr_correction=parse_bool_env(env.get(ENV_APPLY_LR_CORRECTION), default=True),
    )


@contextmanager
def _case_timeout(seconds: float | None):
    """Best-effort per-case soft timeout via ``SIGALRM``. See the module
    docstring's "Hard timeout" section for exactly what this does and does
    not guarantee. No-op if ``seconds`` is falsy or the platform has no
    ``SIGALRM`` (e.g. native Windows; irrelevant for the Linux Docker
    target, but keeps this importable/testable everywhere).
    """
    if not seconds or not hasattr(signal, "SIGALRM"):
        yield
        return

    def _handler(signum, frame):  # noqa: ARG001 - required signal handler signature
        raise CaseTimeoutError(f"case exceeded {seconds}s soft per-case timeout")

    previous_handler = signal.signal(signal.SIGALRM, _handler)
    signal.setitimer(signal.ITIMER_REAL, seconds)
    try:
        yield
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, previous_handler)


@dataclass(frozen=True)
class CaseRunOutcome:
    case_id: str
    input_path: str
    output_path: str | None
    status: str  # "ok" | "error" | "timeout"
    message: str | None
    wall_clock_seconds: float | None


def run_checkpoint_inference_for_docker(
    input_dir: Path,
    output_dir: Path,
    checkpoint_dir: Path,
    *,
    folds: Sequence[int | str] = (0,),
    checkpoint_name: str = DEFAULT_CHECKPOINT_NAME,
    tile_step_size: float = 0.5,
    use_mirroring: bool = False,
    case_timeout_seconds: float | None = None,
    output_suffix: str = "",
    apply_postprocessing: bool = False,
    postprocess_gt_labels_by_case: Mapping[str, AbstractSet[int]] | None = None,
    postprocess_volume_threshold: int = DEFAULT_SMALL_VOLUME_THRESHOLD,
    postprocess_dilation_voxels: int = DEFAULT_DILATION_VOXELS,
    predictor_factory: Callable[..., object] = load_predictor,
    predict_case_fn: Callable[..., CaseInferenceResult] = predict_case_streaming,
    warm_up_fn: Callable[[object], None] = _warm_up_predictor,
    postprocess_fn: Callable[..., bool] = apply_postprocessing_to_prediction_file,
) -> list[CaseRunOutcome]:
    """Run every case under ``input_dir`` through a real nnU-Net checkpoint,
    writing predictions to ``output_dir``. By default filenames match input
    case IDs (validator-compatible); ``output_suffix`` can opt into a Docker
    naming convention such as ``<case_id>_mask.nii.gz``.

    ``predictor_factory``/``predict_case_fn``/``warm_up_fn`` are injected
    (default to the real ``load_predictor``/``predict_case_streaming``/
    ``_warm_up_predictor``) so this function's control flow -- case discovery,
    the per-case try/except/timeout loop, output bookkeeping -- is fully
    unit-testable with fakes, without needing nnunetv2/torch/a GPU in this
    sandbox. See module docstring.

    Predictor construction (``predictor_factory(...)``) is called exactly
    once, outside the per-case try/except: a checkpoint that fails to load
    is a whole-run failure (propagates ``InferenceError`` with its
    actionable message intact, per the task's instruction not to swallow
    it), not a per-case one -- there is nothing case-specific to isolate
    yet. Only the per-case ``predict_case_fn`` call is isolated so one
    case's failure/timeout cannot abort the rest of the batch.

    ``warm_up_fn(predictor)`` runs once, immediately after predictor
    construction and before the per-case loop -- see :func:`_warm_up_predictor`
    for why (absorbs a real measured GPU/cuDNN cold-start cost outside any
    per-case timing window). Best-effort by design: it never raises, so a
    failure here cannot turn into a whole-run failure the way a real
    ``predictor_factory`` failure does.

    Returns an empty list (not an error) if ``input_dir`` has no NIfTI
    files, mirroring ``stsr2026.inference.predict.run_inference``'s
    existing convention -- the caller (``docker/run_inference.py``) is
    expected to treat an empty result as an error condition itself, exactly
    as it already does for the ``fake_predict`` path.

    ``apply_postprocessing`` (default ``False``, opt-in): when set, runs
    ``stsr2026.inference.postprocessing_pipeline.apply_postprocessing_to_prediction_file``
    on each case's output file immediately after ``predict_case_fn`` writes
    it, inside the same per-case try/except (a post-processing failure is
    isolated exactly like an inference failure -- recorded as an "error"
    outcome for that case, does not abort the batch). Deliberately a
    **post-write** step -- it reads the file ``predict_case_fn`` already
    wrote, applies pure/GPU-free array functions, and rewrites it -- so it
    never touches ``predict_case_streaming``'s memory-sensitive
    windowing/chunking internals (see ``postprocessing_pipeline``'s module
    docstring for why that mattered: this exact file is a high-churn area
    with multiple in-flight OOM fixes and a teammate's parallel branch also
    editing it). ``postprocess_gt_labels_by_case`` looks up each case's
    ground-truth label set by ``case_id`` for the false-positive-cleanup/
    relabel half of the chain (``None``/missing case -> that half is
    skipped, only the GT-free tooth left/right correction runs) -- the real
    Docker entrypoint has no ground truth to supply here (see
    ``postprocessing_pipeline``'s docstring for the open architectural
    question this leaves), so it never passes this argument; it exists for
    offline-evaluation callers (e.g. an ``evaluate_checkpoint.py``-style
    script with real hold-out GT) that do have it.
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    image_paths = find_niftis(input_dir)
    if not image_paths:
        return []

    predictor = predictor_factory(
        checkpoint_dir,
        folds=folds,
        checkpoint_name=checkpoint_name,
        tile_step_size=tile_step_size,
        use_mirroring=use_mirroring,
    )
    warm_up_fn(predictor)

    outcomes: list[CaseRunOutcome] = []
    for image_path in image_paths:
        case_id = nifti_case_id(image_path)
        try:
            with _case_timeout(case_timeout_seconds):
                result = predict_case_fn(predictor, image_path, output_dir, output_suffix=output_suffix)
            if apply_postprocessing and result.output_path:
                gt_labels = (postprocess_gt_labels_by_case or {}).get(case_id)
                postprocess_fn(
                    Path(result.output_path),
                    gt_labels,
                    postprocess_volume_threshold,
                    postprocess_dilation_voxels,
                )
            outcomes.append(
                CaseRunOutcome(
                    case_id, str(image_path), result.output_path, "ok", None, result.wall_clock_seconds
                )
            )
        except CaseTimeoutError as exc:
            outcomes.append(CaseRunOutcome(case_id, str(image_path), None, "timeout", str(exc), None))
        except Exception as exc:  # noqa: BLE001 - deliberate: one case must never kill the batch
            outcomes.append(
                CaseRunOutcome(case_id, str(image_path), None, "error", f"{type(exc).__name__}: {exc}", None)
            )
        _release_memory_between_cases()
    return outcomes
