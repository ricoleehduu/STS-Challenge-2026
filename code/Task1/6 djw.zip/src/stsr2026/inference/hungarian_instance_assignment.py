"""GT-free global instance-to-FDI-slot reassignment via Hungarian matching.

Context (``docs/research/06-2026-improvement-survey.md`` section 3, ``plan.md``
D7): the post-processing chain in ``postprocessing_pipeline.py`` is a fixed
sequence of *local* heuristics -- ``correct_lr_confusion`` flips a component's
label based on which side of the case's own midline its centroid sits on,
``clean_or_relabel_false_positive_labels`` relabels a GT-absent tooth
component to whichever *other* tooth class dominates its dilated
neighbourhood. Each rule was written against a specific real failure mode
found during diagnosis (left/right mirror confusion; five large same-quadrant
adjacent-position duplicate false positives) and only covers that mode.

This module implements a different, more general mechanism instead of a
fourth bespoke rule: **SOFTooth**'s FDI Order-Aware Hungarian Matching (FHM)
idea (arXiv:2512.23411, section III-D), adapted from its native modality (IOS
point clouds, matched against *ground-truth* teeth during training) to ours
(CBCT voxel connected components, matched against a **fixed 65-slot FDI
prior** at **inference time with no ground truth at all**). Instead of
writing a new if/else branch per failure mode, every predicted connected
component within a quadrant competes for that quadrant's 8 canonical FDI
slots in one joint optimal (``scipy.optimize.linear_sum_assignment``)
assignment -- extra components naturally fall out unmatched, missing
positions naturally stay empty slots, and same-quadrant position swaps (the
false_positive_cleanup.py "duplicate under an adjacent FDI position" failure
mode) are corrected by construction rather than by a hand-written neighbour
search.

WHAT THIS DOES **NOT** DO (read before using)
-----------------------------------------------
The SOFTooth paper states this explicitly and it applies here unchanged:
FDI order-aware matching only operates *along the mesiodistal axis within one
quadrant* -- it does not, and cannot, resolve a component whose current label
implies the *wrong* quadrant (left/right mirror confusion, or upper/lower jaw
confusion). Concretely:

- **Tooth classes (1-32)**: safe to trust the label's implied quadrant as the
  grouping key, because this function is designed to run *after*
  ``lr_correction.correct_lr_confusion`` (already validated, +0.205 real
  Codabench ``Challenge_Score``), which enforces -- for every component above
  its own noise floor -- that a tooth's label side matches its geometric
  side. Jaw (upper/lower) confusion was checked and never observed on real
  data (``docs/experiment-log.md``'s MISLABEL offset diagnosis: 125/139
  offset records were exactly +-8, i.e. same-jaw quadrant swaps; zero
  Q1/Q2<->Q3/Q4 crossovers).
- **Canal classes (33-64)**: canal left/right confusion is a *known, real,
  twice-failed* problem (``lr_correction.py``'s ``CANAL_SWAPPABLE_CLASS_PAIRS``
  comment: centroid-side rule made things worse; this repo's canal
  parent-tooth-inheritance function is the same class of failure per
  ``docs/research/06-2026-improvement-survey.md`` section 1's Curie-principle
  argument). This function groups canal candidates by their *own current,
  uncorrected* label's implied quadrant -- so any canal component that is
  currently on the wrong side of the mouth stays grouped with the wrong
  quadrant's slots and this function cannot fix that. This is a deliberate,
  documented scope boundary, **not a bug and not a third attempt at the
  already-closed geometric canal-LR-correction problem** -- the mechanism
  here (order-within-a-fixed-group matching) is different from the geometric
  side-of-midline judgment that failed twice; it is only being applied
  *within* whatever quadrant the canal's current label happens to imply.

GT-FREE BY CONSTRUCTION
-------------------------
The 65 FDI "slots" (1 background + 32 teeth + 32 canals) are a fixed prior
from ``stsr2026.training.pseudo_label.FDI_ORDER`` / the class-range
convention documented there -- not derived from any particular case's ground
truth. Every quantity in the cost matrix (component centroid, component
voxel count, component's own current predicted label, the case's own tooth
voxels for the midline estimate) comes from the prediction volume itself.
Unlike ``clean_or_relabel_false_positive_labels``, this function never takes
a ``gt_labels`` parameter and has no code path that could read one.

NO SOFTMAX AVAILABLE (confirmed, not assumed)
------------------------------------------------
SOFTooth's base similarity combines mask Dice *and* classification
confidence (``Scls``, softmax probability at the GT label). This repo's real
inference/evaluation path never has that available downstream of the written
prediction file: ``streaming_export.py`` explicitly refuses
``save_probabilities=True`` ("streaming export cannot produce
save_probabilities=True output"), and every real evaluation in
``docs/experiment-log.md`` (including the adopted
``LineA-PhaseB-LRfix-v2`` + FP-cleanup baseline this module is compared
against) scores hard argmax label volumes read back from disk with
``nibabel``/``SimpleITK``, never a probability tensor. The classification
term here is therefore deliberately degraded to a binary consistency check
(does the candidate's current label already equal this slot's class?) as
``plan.md``'s task description anticipated, not silently assumed away.

COST MATRIX (per quadrant, per category -- tooth or canal -- 8 slots each)
------------------------------------------------------------------------------
For each of the 4 quadrants x 2 categories = 8 independent groups (a
canal's quadrant is never compared against a tooth's quadrant, and vice
versa -- there is no anatomical reason a canal component should ever be
reassigned a tooth class or a different quadrant's class):

1. **Order cost**: every connected component (>= ``min_component_voxels``,
   reusing ``lr_correction``'s ``MIN_COMPONENT_VOXELS`` noise floor for
   consistency) whose *current* label falls in this quadrant/category is a
   candidate. Its centroid's world-X distance from the case's own midline
   (computed once, from *all* current tooth voxels 1-32 -- i.e. anchored on
   the whole arch, which ``correct_lr_confusion`` has already made
   side-consistent, rather than on this one component or this one quadrant
   alone) gives an ordering key, normalized by a **global, whole-mouth
   distance scale for this category** (the farthest any current tooth --
   or, separately, any current canal -- voxel sits from the midline
   anywhere in the case, see ``_category_distance_scale``) -- deliberately
   *not* normalized against only the candidates present in this one
   quadrant/group; an earlier version did that and a synthetic test with a
   missing tooth immediately produced a wrong relabel, since "rank among
   only what's present" silently assumes nothing is missing (see
   ``_category_distance_scale``'s docstring for the concrete failure this
   replaced). The normalized distance is compared to each slot's canonical
   position-in-quadrant (1st = central incisor nearest the midline .. 8th =
   third molar, per ``FDI_ORDER``), also normalized to [0, 1]. **This
   "distance from midline increases monotonically with position-in-quadrant"
   is a hypothesis, not a given, for a curved dental arch -- it is
   explicitly checked against real ground-truth position labels on this
   repo's 6-case holdout before this module is trusted for anything beyond
   the synthetic tests in this module's own test suite (see the real-data
   validation section of the experiment write-up this module's development
   produced for the actual correlation found); it is not guaranteed to hold
   for every case's 3rd molar, which can curve back medially.**
2. **Label-consistency cost**: 0.0 if the candidate's current label already
   equals a slot's class id (no evidence-free churn needed to keep a
   plausibly-correct label), otherwise a flat penalty
   (``label_mismatch_cost``) -- there is no finer-grained "how wrong" signal
   available without softmax, so this is intentionally binary.
3. Combined cost = ``order_weight * order_cost + label_mismatch_cost_weight``
   (default weights sum to <= 1.0, so every real cost lands in [0, 1]).

REJECT OPTION: A POST-HOC THRESHOLD ON THE PLAIN RECTANGULAR SOLVE
-----------------------------------------------------------------------
``scipy.optimize.linear_sum_assignment`` accepts the real (n_candidates x 8)
cost matrix directly (no square padding needed -- it natively returns
``min(n_candidates, 8)`` pairs for a rectangular input). This module solves
that matrix as-is, then discards any returned pair whose cost exceeds
``reject_cost_threshold``, reporting both sides of a discarded pair as
unmatched.

An earlier version of this module tried to fold the reject option *into* the
optimization itself, by augmenting the cost matrix with a same-sized block of
"opt out" dummy rows/columns each priced at ``reject_cost_threshold``, on the
claim that this mathematically guarantees every accepted real pair costs
``<= reject_cost_threshold``. **That claim was checked against a direct
counterexample and is false**: for a trivial 1-candidate/1-slot group with
real cost 0.9 and ``reject_cost_threshold=0.5``, the augmented solve picks
the real pair (total cost 0.9) over full rejection (total cost 2 x 0.5 =
1.0) -- the "both sides pay the reservation price independently" cost of
opting out is ``2 * reject_cost_threshold``, not ``reject_cost_threshold``,
so the intended guarantee does not hold in general and the earlier
implementation was silently accepting matches worse than the threshold it
claimed to enforce. Found by running the construction on a hand-picked
2x2 case during this module's own development, not assumed safe from the
construction's superficial resemblance to a standard technique.

The plain-solve-then-filter approach used here is the standard, simpler
technique in multi-object-tracking Hungarian gating (e.g. SORT/DeepSORT-style
detection-to-track assignment: solve unconstrained, then drop low-IoU
matches post-hoc) and has a correspondingly well-understood limitation,
stated plainly rather than hidden behind an incorrect proof: filtering after
the fact does not let the solver re-optimize the *rest* of a group's
assignment once a pair is dropped, so in principle a discarded high-cost
match could have "used up" a slot or candidate that a different, cheaper
pairing would have wanted. In practice, for this module's group sizes
(<= 8 candidates x 8 slots per quadrant) this is a bounded, small-magnitude
risk rather than a systemic one, but it is a real limitation of this design,
not a solved problem -- worth re-examining if real-data validation shows
groups where it matters.

WHAT HAPPENS TO UNMATCHED CANDIDATES / EMPTY SLOTS
-------------------------------------------------------
Per the task instructions this module was written against: a candidate that
doesn't get a slot (too many predicted components for one quadrant, or its
best-fit slot rejected the match as too costly) is left with its **original
label, completely untouched** -- this module does not attempt to clean it up
or delete it; that is ``false_positive_cleanup.py``'s job, applied earlier in
the chain, and re-inventing a second cleanup rule here would risk the two
disagreeing. An FDI slot that receives no candidate at all (a genuinely
missing tooth/canal, or a component the model put under a completely
different label) is simply left empty; nothing is fabricated to fill it.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy import ndimage
from scipy.optimize import linear_sum_assignment

from stsr2026.training.pseudo_label import (
    CANAL_CLASS_MAX,
    CANAL_CLASS_MIN,
    TOOTH_CLASS_MAX,
    TOOTH_CLASS_MIN,
)

# Reused verbatim from lr_correction.py's own noise floor so that a component
# too small to trust for a *left/right flip* decision is equally too small to
# trust for *this* decision -- not imported from there (this module must stay
# independently testable / auditable, and lr_correction.py's own docstring
# says its constant exists for its own module's purpose), but deliberately
# kept numerically identical rather than picking a new number.
MIN_COMPONENT_VOXELS = 5

QUADRANT_SIZE = 8
NUM_QUADRANTS = 4
CATEGORIES: tuple[str, ...] = ("tooth", "canal")

DEFAULT_ORDER_WEIGHT = 0.6
DEFAULT_LABEL_MISMATCH_COST = 0.4
DEFAULT_REJECT_COST_THRESHOLD = 0.5


def _quadrant_class_range(category: str, quadrant_index: int) -> tuple[int, int]:
    """Inclusive (start, end) class-id range for one (category, quadrant) group.

    Mirrors the quadrant convention already established and validated in
    ``lr_correction.py`` (Q1=1-8, Q2=9-16, Q3=17-24, Q4=25-32 for teeth;
    canal = tooth class id + 32) -- not re-derived independently, just
    applied here with an explicit ``quadrant_index`` (0-3) instead of that
    module's paired ``(right_start, left_start)`` tuples, since this module
    needs all four quadrants individually rather than as swappable pairs.
    """
    if category == "tooth":
        base = TOOTH_CLASS_MIN
    elif category == "canal":
        base = CANAL_CLASS_MIN
    else:
        raise ValueError(f"category must be 'tooth' or 'canal', got {category!r}")
    start = base + quadrant_index * QUADRANT_SIZE
    return start, start + QUADRANT_SIZE - 1


def _slot_class_id(category: str, quadrant_index: int, position_in_quadrant: int) -> int:
    """``position_in_quadrant`` is 1-indexed (1 = central incisor .. 8 = 3rd molar)."""
    start, _ = _quadrant_class_range(category, quadrant_index)
    return start + position_in_quadrant - 1


def _world_x(indices: np.ndarray, affine: np.ndarray) -> np.ndarray:
    """Identical formula to ``lr_correction._world_x`` -- duplicated (not
    imported) because it is a two-line affine-application, and importing a
    private (leading-underscore) helper across modules would create a
    coupling this module's docstring explicitly says to avoid.
    """
    return indices @ affine[0, :3] + affine[0, 3]


def _category_distance_scale(
    label_volume: np.ndarray, affine: np.ndarray, category: str, midline_x: float | None
) -> float | None:
    """The distance-from-midline (world-X) that this case's farthest real
    voxel of ``category`` (tooth or canal) reaches, pooled across *all four*
    quadrants -- the calibration reference the order-cost term normalizes
    every candidate's distance against.

    FOUND THE HARD WAY (synthetic validation, before any real data): an
    earlier version of this module normalized each candidate's rank by
    dividing by ``(num_candidates_in_this_group - 1)``, i.e. relative to
    only the candidates present *in that one quadrant*. That silently
    assumes whatever candidates happen to be present span the *entire*
    logical 8-position range -- true when nothing is missing, false the
    moment a real patient is missing one or more teeth in that quadrant (an
    explicitly documented common case, see ``pseudo_label.py``'s "missing
    teeth, dental crowding, incomplete eruption" docstring note). A
    synthetic test with only 3 of 8 positions present reproduced this
    concretely: the 3rd (farthest of just those 3) candidate's rank got
    stretched to 1.0 and matched against slot 8 at near-zero cost, causing
    a wrong relabel that had nothing to do with any real anatomical order
    violation. Using a *global*, whole-mouth scale for this category instead
    (computed once, not per quadrant) means a candidate near the midline
    always normalizes to a small value regardless of how many other
    positions in its own quadrant happen to be missing.

    Returns ``None`` when there are no voxels of this category anywhere in
    the volume (nothing to calibrate against) or when every such voxel sits
    exactly at the midline (scale would be 0, division is meaningless) --
    callers must treat ``None`` as "order term uninformative here", not
    divide by it.
    """
    low, high = (TOOTH_CLASS_MIN, TOOTH_CLASS_MAX) if category == "tooth" else (CANAL_CLASS_MIN, CANAL_CLASS_MAX)
    indices = np.argwhere((label_volume >= low) & (label_volume <= high))
    if indices.size == 0 or midline_x is None:
        return None
    distances = np.abs(_world_x(indices, affine) - midline_x)
    scale = float(np.max(distances))
    return scale if scale > 0 else None


@dataclass(frozen=True)
class Candidate:
    """One connected component considered for assignment within one
    (category, quadrant) group."""

    category: str
    quadrant_index: int
    original_label: int
    component_id: int
    voxel_count: int
    centroid_world_x: float


@dataclass(frozen=True)
class MatchedAssignment:
    """One candidate matched to one FDI slot by the joint Hungarian solve."""

    category: str
    quadrant_index: int
    original_label: int
    component_id: int
    voxel_count: int
    slot_class_id: int
    slot_position_in_quadrant: int  # 1-8
    order_cost: float
    label_mismatch_cost: float
    total_cost: float
    new_label: int  # == original_label when unchanged
    changed: bool


@dataclass(frozen=True)
class UnmatchedCandidate:
    """A connected component that did not receive an FDI slot -- left with
    its original label, completely untouched, per this module's design
    (see module docstring: cleanup of unmatched components is deliberately
    out of scope, handled elsewhere by false_positive_cleanup.py)."""

    category: str
    quadrant_index: int
    original_label: int
    component_id: int
    voxel_count: int
    reason: str  # "too_small" | "rejected_cost_above_threshold" | "no_slot_capacity"


@dataclass(frozen=True)
class EmptySlot:
    """An FDI slot that received no candidate component."""

    category: str
    quadrant_index: int
    slot_class_id: int
    slot_position_in_quadrant: int
    reason: str  # "no_candidate_in_group" | "rejected_cost_above_threshold" | "no_candidate_capacity"


@dataclass(frozen=True)
class HungarianAssignmentResult:
    output_volume: np.ndarray
    matched: tuple[MatchedAssignment, ...]
    unmatched_candidates: tuple[UnmatchedCandidate, ...]
    empty_slots: tuple[EmptySlot, ...]
    # Keyed by (category, quadrant_index) -> the real (n_candidates x 8)
    # cost matrix actually solved for that group, for auditing. A group with
    # zero candidates is omitted.
    cost_matrices: dict[tuple[str, int], np.ndarray]


def _collect_candidates(
    label_volume: np.ndarray,
    affine: np.ndarray,
    category: str,
    quadrant_index: int,
    min_component_voxels: int,
) -> tuple[list[Candidate], list[dict[str, object]]]:
    """Enumerate connected components for one (category, quadrant) group.

    Returns ``(candidates, too_small_records)`` -- the latter as plain dicts
    (converted to ``UnmatchedCandidate`` by the caller) for components that
    exist but fall below ``min_component_voxels``, so they are reported as
    "too small, left untouched" rather than silently disappearing from the
    audit trail.
    """
    start, end = _quadrant_class_range(category, quadrant_index)
    candidates: list[Candidate] = []
    too_small: list[dict[str, object]] = []
    for class_id in range(start, end + 1):
        mask = label_volume == class_id
        if not np.any(mask):
            continue
        # Default (6-connectivity) structure, matching
        # correct_lr_confusion's own component identification -- see that
        # module's docstring; kept consistent so the same physical blob is
        # split into the same components by both stages of the chain.
        component_labels, component_count = ndimage.label(mask)
        for component_id in range(1, component_count + 1):
            component_mask = component_labels == component_id
            voxel_count = int(np.count_nonzero(component_mask))
            if voxel_count < min_component_voxels:
                too_small.append(
                    {
                        "category": category,
                        "quadrant_index": quadrant_index,
                        "original_label": class_id,
                        "component_id": component_id,
                        "voxel_count": voxel_count,
                    }
                )
                continue
            indices = np.argwhere(component_mask)
            centroid_x = float(np.mean(_world_x(indices, affine)))
            candidates.append(
                Candidate(
                    category=category,
                    quadrant_index=quadrant_index,
                    original_label=class_id,
                    component_id=component_id,
                    voxel_count=voxel_count,
                    centroid_world_x=centroid_x,
                )
            )
    return candidates, too_small


def assign_instances_to_fdi_slots(
    label_volume: np.ndarray,
    affine: np.ndarray,
    order_weight: float = DEFAULT_ORDER_WEIGHT,
    label_mismatch_cost: float = DEFAULT_LABEL_MISMATCH_COST,
    reject_cost_threshold: float = DEFAULT_REJECT_COST_THRESHOLD,
    min_component_voxels: int = MIN_COMPONENT_VOXELS,
) -> HungarianAssignmentResult:
    """Reassign each quadrant's predicted connected components to FDI slots
    via one joint Hungarian solve per (category, quadrant) group.

    ``label_volume`` should already have had ``lr_correction.correct_lr_confusion``
    applied to its tooth classes (1-32) -- see module docstring for why this
    function's quadrant grouping (label-implied, not re-derived from
    geometry) depends on that having already run. Passing a volume that has
    not been LR-corrected is not an error (this function still runs and
    produces some result), but the "trust the label's implied quadrant"
    assumption documented above will not hold, and results should not be
    treated as validated for that case.

    Parameters
    ----------
    label_volume, affine:
        Same conventions as ``lr_correction.correct_lr_confusion``.
    order_weight, label_mismatch_cost:
        Cost-matrix weights, see module docstring. Their sum should not
        exceed 1.0 for ``reject_cost_threshold``'s default (0.5) to have its
        intended "roughly half of the worst possible real cost" meaning,
        but this is not enforced -- both are exposed for tuning during real
        -data validation, per the exploratory nature of this method.
    reject_cost_threshold:
        Applied as a post-hoc filter on the plain rectangular Hungarian
        solve (see module docstring's "REJECT OPTION" section for why this
        is a filter, not folded into the optimization itself, and what that
        implies). A solved pair costing more than this is discarded; both
        sides are reported unmatched instead.
    min_component_voxels:
        Components smaller than this are excluded from consideration
        entirely (reported as ``UnmatchedCandidate`` with
        ``reason="too_small"``), matching ``lr_correction``'s own noise
        floor.

    Returns
    -------
    :class:`HungarianAssignmentResult` -- see its docstring and the module
    docstring's "WHAT HAPPENS TO UNMATCHED CANDIDATES / EMPTY SLOTS" section.
    """
    if label_volume.ndim != 3:
        raise ValueError(f"label_volume must be 3-dimensional, got shape {label_volume.shape}")
    if affine.shape != (4, 4):
        raise ValueError(f"affine must have shape (4, 4), got {affine.shape}")
    if min_component_voxels < 1:
        raise ValueError(f"min_component_voxels must be >= 1, got {min_component_voxels}")
    if not (0.0 < reject_cost_threshold):
        raise ValueError(f"reject_cost_threshold must be > 0, got {reject_cost_threshold}")

    output = label_volume.copy()

    # Case-wide midline, anchored on *all* current tooth voxels (1-32) --
    # deliberately not recomputed per quadrant/group, so every quadrant's
    # ordering shares one consistent coordinate frame anchored on the whole
    # arch (the "use other already-corrected instances as anchors" idea from
    # the task description), matching how correct_lr_confusion itself
    # computes its midline. ``None`` only when there are no tooth voxels at
    # all in the whole volume (a genuinely empty/degenerate case) -- in that
    # situation the order term below falls back to a neutral, uninformative
    # 0.0 for every candidate (see the fallback branch), leaving only the
    # label-consistency term to do any work.
    tooth_indices = np.argwhere((label_volume >= TOOTH_CLASS_MIN) & (label_volume <= TOOTH_CLASS_MAX))
    midline_x = float(np.median(_world_x(tooth_indices, affine))) if tooth_indices.size else None

    # Per-category distance scale -- see ``_category_distance_scale``'s
    # docstring for why this must be computed globally (all four quadrants'
    # voxels pooled) rather than per quadrant/group: a per-group scale would
    # force whatever candidates happen to be present in *this* quadrant to
    # span the full [0, 1] normalized range, which silently breaks the
    # moment any position in that quadrant is missing (a common, expected
    # real scenario -- missing teeth, per ``pseudo_label.py``'s own
    # docstring). Teeth and canals get their own independent scale: canal
    # centroids sit far closer to the midline than tooth centroids do (see
    # ``lr_correction.py``'s ``CANAL_SWAPPABLE_CLASS_PAIRS`` comment, ~15mm
    # vs teeth's much larger spread on real data), so sharing one scale
    # between them would badly miscalibrate one or the other.
    category_scale = {
        category: _category_distance_scale(label_volume, affine, category, midline_x) for category in CATEGORIES
    }

    matched: list[MatchedAssignment] = []
    unmatched_candidates: list[UnmatchedCandidate] = []
    empty_slots: list[EmptySlot] = []
    cost_matrices: dict[tuple[str, int], np.ndarray] = {}

    for category in CATEGORIES:
        for quadrant_index in range(NUM_QUADRANTS):
            candidates, too_small = _collect_candidates(
                label_volume, affine, category, quadrant_index, min_component_voxels
            )
            for record in too_small:
                unmatched_candidates.append(UnmatchedCandidate(**record, reason="too_small"))

            if not candidates:
                for position in range(1, QUADRANT_SIZE + 1):
                    empty_slots.append(
                        EmptySlot(
                            category=category,
                            quadrant_index=quadrant_index,
                            slot_class_id=_slot_class_id(category, quadrant_index, position),
                            slot_position_in_quadrant=position,
                            reason="no_candidate_in_group",
                        )
                    )
                continue

            n = len(candidates)
            scale = category_scale[category]
            if midline_x is not None and scale is not None:
                # Normalized against the *global*, whole-mouth scale for
                # this category -- not against the other candidates in this
                # one quadrant -- so a candidate's normalized position
                # reflects its actual physical distance from the midline
                # regardless of how many of its quadrant's other 7 positions
                # are missing. See _category_distance_scale's docstring.
                normalized_rank = np.array(
                    [min(abs(c.centroid_world_x - midline_x) / scale, 1.0) for c in candidates]
                )
            else:
                normalized_rank = np.full(n, 0.5)  # neutral fallback, see docstring above

            real_cost = np.empty((n, QUADRANT_SIZE), dtype=np.float64)
            for i, candidate in enumerate(candidates):
                for position in range(1, QUADRANT_SIZE + 1):
                    slot_class_id = _slot_class_id(category, quadrant_index, position)
                    normalized_slot_position = (position - 1) / (QUADRANT_SIZE - 1)
                    order_cost = abs(float(normalized_rank[i]) - normalized_slot_position)
                    mismatch_cost = 0.0 if candidate.original_label == slot_class_id else 1.0
                    real_cost[i, position - 1] = (
                        order_weight * order_cost + label_mismatch_cost * mismatch_cost
                    )
            cost_matrices[(category, quadrant_index)] = real_cost

            # scipy handles a rectangular (n x 8) matrix natively, returning
            # min(n, 8) pairs -- no square padding needed. Any pair costing
            # more than reject_cost_threshold is then dropped as a post-hoc
            # filter; see the module docstring's "REJECT OPTION" section for
            # why this is a filter rather than folded into the optimization,
            # and its known limitation.
            row_idx, col_idx = linear_sum_assignment(real_cost)

            # linear_sum_assignment on an (n x 8) matrix returns exactly
            # min(n, 8) pairs -- every row/column it *doesn't* return at all
            # is a pure capacity shortfall (more candidates than slots, or
            # vice versa), distinct from a pair it did return but this
            # module's threshold then rejected on cost grounds.
            solved_rows = set(int(r) for r in row_idx)
            solved_cols = set(int(c) for c in col_idx)
            candidate_slot: dict[int, int] = {}  # candidate index -> slot position (0-indexed), only accepted pairs
            slot_candidate: dict[int, int] = {}  # slot position (0-indexed) -> candidate index, only accepted pairs
            for r, c in zip(row_idx, col_idx):
                if real_cost[r, c] <= reject_cost_threshold:
                    candidate_slot[r] = c
                    slot_candidate[c] = r

            for i, candidate in enumerate(candidates):
                if i not in candidate_slot:
                    reason = "no_slot_capacity" if i not in solved_rows else "rejected_cost_above_threshold"
                    unmatched_candidates.append(
                        UnmatchedCandidate(
                            category=category,
                            quadrant_index=quadrant_index,
                            original_label=candidate.original_label,
                            component_id=candidate.component_id,
                            voxel_count=candidate.voxel_count,
                            reason=reason,
                        )
                    )
                    continue
                position0 = candidate_slot[i]
                position = position0 + 1
                slot_class_id = _slot_class_id(category, quadrant_index, position)
                total_cost = float(real_cost[i, position0])
                order_cost = abs(
                    float(normalized_rank[i]) - (position0) / (QUADRANT_SIZE - 1)
                ) * order_weight
                mismatch_cost = total_cost - order_cost
                new_label = slot_class_id
                changed = new_label != candidate.original_label
                if changed:
                    component_labels, _ = ndimage.label(label_volume == candidate.original_label)
                    output[component_labels == candidate.component_id] = new_label
                matched.append(
                    MatchedAssignment(
                        category=category,
                        quadrant_index=quadrant_index,
                        original_label=candidate.original_label,
                        component_id=candidate.component_id,
                        voxel_count=candidate.voxel_count,
                        slot_class_id=slot_class_id,
                        slot_position_in_quadrant=position,
                        order_cost=order_cost,
                        label_mismatch_cost=mismatch_cost,
                        total_cost=total_cost,
                        new_label=new_label,
                        changed=changed,
                    )
                )

            for position in range(1, QUADRANT_SIZE + 1):
                position0 = position - 1
                if position0 not in slot_candidate:
                    reason = (
                        "no_candidate_capacity" if position0 not in solved_cols else "rejected_cost_above_threshold"
                    )
                    empty_slots.append(
                        EmptySlot(
                            category=category,
                            quadrant_index=quadrant_index,
                            slot_class_id=_slot_class_id(category, quadrant_index, position),
                            slot_position_in_quadrant=position,
                            reason=reason,
                        )
                    )

    return HungarianAssignmentResult(
        output_volume=output,
        matched=tuple(matched),
        unmatched_candidates=tuple(unmatched_candidates),
        empty_slots=tuple(empty_slots),
        cost_matrices=cost_matrices,
    )
