"""Inference, geometry restoration, and post-processing."""

