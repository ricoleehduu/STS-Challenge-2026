"""Input-channel "weight surgery" for warm-starting a checkpoint trained
with ``C_old`` input channels onto an architecture with ``C_new`` input
channels, without changing anything else about the network.

Context: plan.md's coordinate-channel experiment (see
``stsr2026.training.coord_channel``) adds a second input channel to Line A
Phase B's checkpoint (``nnUNetTrainer_STSR_PhaseB``, 1 input channel ->
``nnUNetTrainer_STSR_CoordFineTune``, 2 input channels). nnU-Net's own
``-pretrained_weights`` loading path
(``nnunetv2.run.load_pretrained_weights.load_pretrained_weights``) asserts
every non-``seg_layers`` key has an identical shape between the checkpoint
and the target network -- it does NOT skip mismatched-shape keys the way a
naive "best effort" loader might, so a plain 1-channel checkpoint cannot be
loaded directly onto a 2-channel network at all; this module produces a new
checkpoint file whose stem-layer weights are already shaped for
``C_new`` channels so that stock nnU-Net loading works unmodified.

Only the stem (first) convolution's weight tensors need reshaping -- every
other layer in a nnU-Net PlainConvUNet/ResidualEncoderUNet operates on
feature-map channel counts (32, 64, ...), never on the raw input channel
count, so exactly one logical weight (which the real checkpoint stores under
several *aliased* key names -- see below) needs surgery.

The alias subtlety (verified against a real checkpoint on a training box,
2026-07-17): nnU-Net's ``PlainConvUNet`` decoder holds a live reference to
the *same* encoder module the top-level network also owns (for skip
connections), and each ``ConvDropoutNormReLU`` block exposes its conv layer
both as ``.conv`` and as element 0 of an internal ``.all_modules``
``nn.Sequential`` -- both attribute paths point at the literal same
``nn.Parameter`` object. A ``state_dict()`` call therefore serializes that
one parameter under up to 4 distinct key strings (2 module-instance aliases
x 2 attribute-path aliases), all identical in shape and value. This module
does not assume there are exactly 4 -- it detects the alias group
generically as "every key whose stored tensor shares the exact same values
as the smallest-sorted key in its shape-``C_old``-input-channel group",
verified in :func:`surgically_expand_input_channels` before touching
anything (see that function's ``strict`` argument), and edits all of them
in lock-step so the checkpoint stays internally consistent (a real nnU-Net
network object loading this checkpoint would end up with the same
one-shared-Parameter aliasing it started with, since ``load_state_dict``
writes each named tensor into the model's already-shared parameter storage
-- this module just needs the *values* to agree across the alias group when
saved to a plain dict, which they will).
"""
from __future__ import annotations

from dataclasses import dataclass

import torch


@dataclass(frozen=True)
class StemSurgeryReport:
    """What :func:`surgically_expand_input_channels` actually changed --
    returned for the caller to log/assert against, so "the surgery ran" and
    "the surgery touched what I expected, and only that" are both checked,
    not just assumed.
    """

    stem_keys: tuple[str, ...]
    old_in_channels: int
    new_in_channels: int
    out_channels: int
    kernel_shape: tuple[int, ...]


def _find_stem_weight_keys(state_dict: dict[str, torch.Tensor], old_in_channels: int) -> tuple[str, ...]:
    """Every conv-weight key whose second dimension (``in_channels``) is
    exactly ``old_in_channels`` -- this is true only for the network's very
    first convolution (and its aliases), since every later conv operates on
    a feature-map channel count from ``features_per_stage`` (e.g. 32, 64,
    ...), never on the raw input channel count. Restricted to 5D tensors
    (``(out, in, kD, kH, kW)``) so this can't accidentally match a bias or
    norm-layer parameter that happens to have a matching size along some
    axis.
    """
    return tuple(
        key
        for key, tensor in state_dict.items()
        if tensor.dim() == 5 and tensor.shape[1] == old_in_channels
    )


def surgically_expand_input_channels(
    state_dict: dict[str, torch.Tensor],
    new_in_channels: int,
    old_in_channels: int = 1,
    new_channel_init: str = "zeros",
    seed: int = 0,
    strict: bool = True,
) -> tuple[dict[str, torch.Tensor], StemSurgeryReport]:
    """Return a new state dict (does not mutate the input) whose stem-layer
    weight keys are expanded from ``(out, old_in_channels, k, k, k)`` to
    ``(out, new_in_channels, k, k, k)``: the first ``old_in_channels`` slices
    along dim 1 are an exact copy of the original weights, and the newly
    added ``new_in_channels - old_in_channels`` slices are either all-zero
    (``new_channel_init="zeros"``, the default -- see why below) or small
    random noise (``new_channel_init="small_random"``, std ``1e-3`` scaled
    by the original weights' own std, for the "or a very small random value"
    alternative the task brief explicitly allows).

    Why zero-init is the default: with the new channel's weights at exactly
    zero, the stem convolution's output for a given input is *mathematically
    identical* to the old 1-channel network's output regardless of what the
    new coordinate channel's input values are (a zero-weighted term
    contributes exactly zero to the convolution sum) -- so the network's
    forward pass immediately after surgery should reproduce the pre-surgery
    checkpoint's predictions almost exactly (up to floating-point op-order
    noise from now doing a 2-channel instead of 1-channel convolution sum).
    That is the falsifiable claim this module's forward-pass parity check
    (see the a training box verification script, not this module) tests directly --
    zero-init makes that check meaningful; small-random-init would not (the
    new channel's tiny-but-nonzero contribution would show up as a real,
    non-floating-point-noise difference, making "does surgery preserve
    behavior" and "is small-random-init noise negligible" impossible to
    distinguish from each other).

    All keys found by :func:`_find_stem_weight_keys` are edited in lock-step
    (see module docstring's alias explanation). If ``strict`` (default),
    raises ``ValueError`` unless every found key's *tensor values* -- not
    just shape -- exactly match the first (alphabetically smallest) one,
    since editing supposedly-aliased keys independently would silently
    desynchronize the checkpoint if the alias assumption turned out to be
    wrong for some future nnU-Net version.
    """
    if new_channel_init not in ("zeros", "small_random"):
        raise ValueError(f"new_channel_init must be 'zeros' or 'small_random', got {new_channel_init!r}")
    if new_in_channels <= old_in_channels:
        raise ValueError(f"new_in_channels ({new_in_channels}) must be > old_in_channels ({old_in_channels})")

    stem_keys = _find_stem_weight_keys(state_dict, old_in_channels)
    if not stem_keys:
        raise ValueError(
            f"no 5D conv weight with in_channels=={old_in_channels} found in state_dict -- "
            "either old_in_channels is wrong or this isn't a nnU-Net 3D conv checkpoint"
        )
    stem_keys = tuple(sorted(stem_keys))

    reference = state_dict[stem_keys[0]]
    if strict:
        mismatched = [key for key in stem_keys[1:] if not torch.equal(state_dict[key], reference)]
        if mismatched:
            raise ValueError(
                f"stem weight keys {mismatched} do not have identical values to {stem_keys[0]!r} -- "
                "the alias assumption this module relies on does not hold for this checkpoint; "
                "re-examine before trusting the surgery (pass strict=False to override once you have "
                "manually confirmed these keys really are independent, not aliased)"
            )

    out_channels, _old_in, *kernel_shape = reference.shape
    generator = torch.Generator().manual_seed(seed)

    new_dict = dict(state_dict)
    for key in stem_keys:
        old_weight = state_dict[key]
        new_weight = torch.zeros(
            (out_channels, new_in_channels, *kernel_shape), dtype=old_weight.dtype
        )
        new_weight[:, :old_in_channels] = old_weight
        if new_channel_init == "small_random":
            std = float(old_weight.std()) * 1e-3
            noise = torch.randn(
                (out_channels, new_in_channels - old_in_channels, *kernel_shape),
                generator=generator,
                dtype=torch.float32,
            ).to(old_weight.dtype)
            new_weight[:, old_in_channels:] = noise * std
        new_dict[key] = new_weight

    report = StemSurgeryReport(
        stem_keys=stem_keys,
        old_in_channels=old_in_channels,
        new_in_channels=new_in_channels,
        out_channels=out_channels,
        kernel_shape=tuple(kernel_shape),
    )
    return new_dict, report
