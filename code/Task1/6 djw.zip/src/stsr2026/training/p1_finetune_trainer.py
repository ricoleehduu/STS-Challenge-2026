"""P1 short-schedule supervised fine-tune trainer.

Plan.md section 3.2's "P1" path: after generating FDI-aware offline
pseudo-labels (``pseudo_label_generation.py``) and mixing them with the 30
real labeled cases into a combined nnU-Net raw dataset
(``Dataset003_STSR_P1``), fine-tune from the Phase B checkpoint
(``LineA-PhaseB-001`` in docs/experiment-log.md -- the best checkpoint so
far) for a short, fixed epoch budget.

This trainer is deliberately trivial: it is plain, standard nnU-Net
supervised training (the unmodified Dice+CE deep-supervision loss, the
unmodified data loader, no unlabeled-batch branch at all) with exactly one
change from stock ``nnUNetTrainer`` -- a reduced ``self.num_epochs``, so that
``PolyLRScheduler`` (which reads ``self.num_epochs`` to shape its decay
curve) and the training loop's ``for epoch in range(self.current_epoch,
self.num_epochs)`` both see the short budget instead of the default 1000.
Weight initialization comes from nnU-Net's own ``-pretrained_weights`` CLI
flag (``run_training.py`` -> ``load_pretrained_weights``), not from anything
in this module.

Explicitly NOT ``ssl_trainer.py``: this trainer has no consistency
regularization, no inline pseudo-label branch, no unlabeled dataloader --
none of Phase C's machinery, which ``LineA-PhaseC-001`` in
docs/experiment-log.md already showed hurts accuracy (worst on canals). P1
tests a different hypothesis -- that *offline*, FDI-aware-filtered
pseudo-labels mixed in as if they were real training data (via
``splits_final.json``'s expanded 64-case training fold) can beat Phase B --
without reusing Phase C's already-falsified inline mechanism.

``num_epochs`` default (50) is a starting point, not tuned: Phase B ran
roughly 90-100s/epoch on a 5090 with the same ``nnUNetPlansBigMem`` plan, so
50 epochs is on the order of 75-85 minutes wall clock, well inside this
sprint's remaining time budget. Override via the constructor if a different
schedule is needed -- see ``STSR_P1_NUM_EPOCHS`` below for an environment-
variable override so the epoch budget can be tuned per launch without editing
source.
"""
from __future__ import annotations

import os

try:  # pragma: no cover - exercised only on a real nnU-Net install
    from nnunetv2.training.nnUNetTrainer.nnUNetTrainer import nnUNetTrainer

    NNUNETV2_AVAILABLE = True
except ImportError:  # pragma: no cover - the expected case in this sandbox
    nnUNetTrainer = object  # type: ignore[assignment,misc]
    NNUNETV2_AVAILABLE = False


#: Default short-schedule epoch budget. See module docstring for the timing
#: reasoning (Phase B's ~90-100s/epoch on a 5090, same plan).
DEFAULT_P1_NUM_EPOCHS = 50

#: Environment variable that overrides the default epoch budget at launch
#: time, e.g. ``STSR_P1_NUM_EPOCHS=100 nnUNetv2_train ...``. Read once, in
#: ``__init__``, exactly like nnU-Net's own env-var-configured settings
#: (``nnUNet_n_proc_DA`` etc).
_NUM_EPOCHS_ENV_VAR = "STSR_P1_NUM_EPOCHS"


def _resolve_num_epochs(default: int = DEFAULT_P1_NUM_EPOCHS) -> int:
    raw = os.environ.get(_NUM_EPOCHS_ENV_VAR)
    if raw is None or raw == "":
        return default
    try:
        value = int(raw)
    except ValueError as exc:
        raise ValueError(
            f"{_NUM_EPOCHS_ENV_VAR}={raw!r} is not a valid integer epoch count"
        ) from exc
    if value <= 0:
        raise ValueError(f"{_NUM_EPOCHS_ENV_VAR} must be positive, got {value}")
    return value


if NNUNETV2_AVAILABLE:

    class nnUNetTrainer_STSR_P1FineTune(nnUNetTrainer):  # type: ignore[misc]
        """Stock nnU-Net supervised trainer with a short, fixed epoch budget.

        Everything else (loss, data augmentation, optimizer, LR schedule
        shape, deep supervision) is inherited unmodified from
        ``nnUNetTrainer`` -- only ``self.num_epochs`` is overridden, matching
        the real installed nnunetv2 2.8.1 source
        (``nnUNetTrainer.__init__`` sets ``self.num_epochs = 1000`` alongside
        ``self.num_iterations_per_epoch = 250`` /
        ``self.num_val_iterations_per_epoch = 50``, both left at their
        defaults here). The ``__init__`` signature is copied verbatim from
        ``nnUNetTrainer`` (no ``*args``/``**kwargs``) for the same reason
        documented in ``ssl_trainer.py``: nnU-Net's base class introspects
        ``inspect.signature(self.__init__)`` against ``locals()``, which a
        pass-through signature breaks.
        """

        def __init__(
            self,
            plans: dict,
            configuration: str,
            fold: int,
            dataset_json: dict,
            device: "torch.device" = None,  # type: ignore[name-defined]  # noqa: F821
        ):
            import torch  # local import: only needed when nnunetv2 is present

            if device is None:
                device = torch.device("cuda")
            super().__init__(plans, configuration, fold, dataset_json, device=device)
            self.num_epochs = _resolve_num_epochs()

else:  # pragma: no cover - the expected case in this sandbox
    nnUNetTrainer_STSR_P1FineTune = None  # type: ignore[assignment,misc]
