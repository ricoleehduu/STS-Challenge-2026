"""Supervised and semi-supervised training components."""

