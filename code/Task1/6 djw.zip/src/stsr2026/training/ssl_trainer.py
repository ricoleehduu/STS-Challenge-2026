"""Phase B/C semi-supervised nnU-Net v2 trainer for the U-Mamba2-SSL reproduction.

This is prep code for "线A": reproducing the STSR 2025 champion
(U-Mamba2-SSL, team zhiqin1998) phase B/C training recipe as an nnU-Net v2
custom trainer, per ``docs/research/02-challenge-review.md`` section
"2. U-Mamba2-SSL 的三阶段设计". Phase A (DAE self-supervised pretraining) is
out of scope for this module.

Phase B: supervised Dice+CE (reused unmodified from nnU-Net's own
``nnUNetTrainer``) plus a consistency-regularization branch on unlabeled
batches::

    L = L_sup + w(t) * MSE(softmax(p_theta(a(x_u))), softmax(sg(p_theta(x_u))))

where ``a`` is a combined input+feature perturbation of the unlabeled sample
and ``sg`` is stop-gradient (the unperturbed branch runs under
``torch.no_grad()`` -- it is a detached target from the *same live network*,
not an EMA teacher).

Phase C: layers a pseudo-label branch on top of phase B. 25% of unlabeled
steps take the pseudo-label branch (argmax + confidence threshold + ignore
index); the other ~75% still use phase B's consistency branch.

IMPORTANT -- what has and has not been validated
--------------------------------------------------
This module was written and unit-tested on CPU, in a sandbox with **no GPU
and no working ``nnunetv2`` install**. Only the pure-math pieces below
(ramp-up weight schedule, unlabeled-usage-probability schedule, phase-C LR
schedule, feature perturbation, pseudo-label masking) are exercised by
``tests/test_ssl_trainer.py`` against hand-computed values and mock tensors.

The ``nnUNetTrainer`` subclasses at the bottom of this file (only defined
when ``nnunetv2`` is importable) wire those pieces into nnU-Net's trainer
hooks on a best-effort basis, written from knowledge of the nnU-Net v2 API
rather than by running against it. Every place an internal nnU-Net attribute
or method is assumed (e.g. ``self.network.encoder``/``self.network.decoder``
skip-connection access, ``self.num_iterations_per_epoch``, the exact
``get_training_transforms`` signature) is called out in a comment. **Before
trusting this for the real 线A run, validate the actual training loop
end-to-end on the GPU box** (see the checklist in the module docstring's
final section and in ``plan.md``).

Data-loading for unlabeled weak/strong pairs
---------------------------------------------
The champion's exact weak/strong transform configuration is not fully
specified in the research doc. This module implements the trainer-side
*consumption* of ``(data, aug_data)`` pairs (``train_step_unlabeled``
expects both), and provides ``build_weak_strong_transforms`` as a
documented interim choice: it calls nnU-Net's own
``get_training_transforms`` twice with different augmentation strengths.
This is explicitly a placeholder, not a verified reproduction of the
champion's weak/strong pipeline.
"""
from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from typing import Sequence

import torch
from torch import Tensor, nn
from torch.nn import functional as F

try:  # pragma: no cover - exercised only on a real nnU-Net install
    from nnunetv2.training.nnUNetTrainer.nnUNetTrainer import nnUNetTrainer

    NNUNETV2_AVAILABLE = True
except ImportError:  # pragma: no cover - the expected case in this sandbox
    nnUNetTrainer = object  # type: ignore[assignment,misc]
    NNUNETV2_AVAILABLE = False


# ---------------------------------------------------------------------------
# Pure-math pieces: schedules. No torch/nnunetv2 dependency, CPU-testable.
# ---------------------------------------------------------------------------

CONSISTENCY_MAX_WEIGHT = 50.0
CONSISTENCY_RAMPUP_FRACTION = 0.2
PHASE_B_UNLABELED_START_RATE = 0.1
PHASE_C_UNLABELED_START_RATE = 0.3
UNLABELED_USAGE_CAP = 0.5
PHASE_C_BASE_LR = 1e-3
PHASE_C_MIN_LR_FRACTION = 0.01
PSEUDO_LABEL_BRANCH_PROBABILITY = 0.25
PSEUDO_LABEL_LOSS_WEIGHT = 0.1
PSEUDO_LABEL_CONFIDENCE_THRESHOLD = 0.75
PSEUDO_LABEL_IGNORE_INDEX = 0
FEATURE_PERTURB_NUM_LAST = 5
FEATURE_PERTURB_DROPOUT_P = 0.5
FEATURE_PERTURB_THRESHOLD_RANGE = (0.6, 0.9)
FEATURE_PERTURB_NOISE_RANGE = (-0.3, 0.3)


def consistency_ramp_up_weight(
    current_iter: int,
    total_iters: int,
    max_weight: float = CONSISTENCY_MAX_WEIGHT,
    rampup_fraction: float = CONSISTENCY_RAMPUP_FRACTION,
) -> float:
    """Phase B consistency loss weight ``w(t)``.

    Ramps from near-zero to ``max_weight`` over the first ``rampup_fraction``
    of total training iterations, following the standard semi-supervised
    "sigmoid rampup" used e.g. in Mean Teacher: ``exp[-5*(1-s)^2]`` where
    ``s`` is the fraction of the way through the ramp-up window (``s=0`` at
    the start of ramp-up, ``s=1`` once ``current_iter`` reaches the end of
    the ramp-up window). After the window, the weight is held at
    ``max_weight``.

    ``current_iter`` and ``total_iters`` are both in units of training
    iterations (not epochs).
    """
    if total_iters <= 0:
        raise ValueError("total_iters must be positive")
    ramp_length = max(rampup_fraction * total_iters, 1e-8)
    s = min(max(current_iter / ramp_length, 0.0), 1.0)
    return max_weight * math.exp(-5.0 * (1.0 - s) ** 2)


def unlabeled_usage_probability(
    epoch: int,
    num_epochs: int,
    start: float = PHASE_B_UNLABELED_START_RATE,
    cap: float = UNLABELED_USAGE_CAP,
) -> float:
    """Per-epoch probability of running the unlabeled branch on a given step.

    Phase B: ``min(0.5, epoch/num_epochs + 0.1)`` -- ramps from 0.1 at
    epoch 0 up to a hard cap of 0.5. Phase C raises the starting rate to 0.3
    (pass ``start=PHASE_C_UNLABELED_START_RATE``); the research doc does not
    say the 0.5 cap changes in phase C, so it is left as a parameter with
    the same default.
    """
    if num_epochs <= 0:
        raise ValueError("num_epochs must be positive")
    return min(cap, epoch / num_epochs + start)


def phase_c_lr_schedule(
    current_step: int,
    total_steps: int,
    base_lr: float = PHASE_C_BASE_LR,
    min_fraction: float = PHASE_C_MIN_LR_FRACTION,
) -> float:
    """Phase C learning rate: linear decay from ``base_lr`` to
    ``base_lr * min_fraction`` (1% of base by default) over the full
    phase-C training length.
    """
    if total_steps <= 0:
        raise ValueError("total_steps must be positive")
    progress = min(max(current_step / total_steps, 0.0), 1.0)
    end_lr = base_lr * min_fraction
    return base_lr + (end_lr - base_lr) * progress


def should_use_pseudo_label_branch(
    rng: random.Random | None = None,
    probability: float = PSEUDO_LABEL_BRANCH_PROBABILITY,
) -> bool:
    """Phase C: True with probability 0.25 (pseudo-label branch), False
    otherwise (~75% of unlabeled steps, which take phase B's consistency
    branch instead).
    """
    rng = rng if rng is not None else random
    return rng.random() < probability


# ---------------------------------------------------------------------------
# Pure-math pieces: feature perturbation. Needs torch, CPU-testable.
# ---------------------------------------------------------------------------


def channel_attention_mask(feature: Tensor, threshold: float) -> Tensor:
    """Per-channel mean-activation "attention" map, thresholded.

    ``attention`` is the mean activation of each channel over all spatial
    dimensions (shape ``(B, C, 1, 1, 1)`` for a 5D ``(B, C, D, H, W)``
    feature). The returned mask is ``(attention < threshold)`` -- note this
    *keeps* the region below the threshold, which is the reverse of what
    "attention masking" usually implies by name. This is deliberate: the
    research doc explicitly warns that the champion code's mask formula is
    ``(attention < threshold)``, not a reimplementation from the method name.
    Do not "fix" this to ``>``.
    """
    spatial_dims = tuple(range(2, feature.dim()))
    attention = feature.mean(dim=spatial_dims, keepdim=True)
    return (attention < threshold).to(feature.dtype)


def perturb_feature(
    feature: Tensor,
    threshold: float,
    dropout_p: float = FEATURE_PERTURB_DROPOUT_P,
    noise_range: tuple[float, float] = FEATURE_PERTURB_NOISE_RANGE,
    training: bool = True,
    generator: torch.Generator | None = None,
) -> Tensor:
    """Apply the champion code's feature perturbation to one skip-connection
    feature map.

    Recipe (see docs/research/02-challenge-review.md, "阶段 B" table):
    ``dropout3d(p=0.5)``, then multiply by a channel-mean-attention mask
    ``(attention < threshold)`` with ``threshold`` sampled per forward pass
    from ``Uniform(0.6, 0.9)`` (see :func:`channel_attention_mask`), then a
    multiplicative ``Uniform(-0.3, 0.3)`` noise term applied on top.

    The order (dropout -> attention mask -> multiplicative noise) matches
    the order the three terms are listed in the research doc; the champion
    source was not available to confirm operator ordering byte-for-byte, so
    this is documented as an implementation choice, not a verified fact.

    ``feature`` is expected to be 5D: ``(B, C, D, H, W)``.
    """
    perturbed = F.dropout3d(feature, p=dropout_p, training=training)
    mask = channel_attention_mask(perturbed, threshold)
    perturbed = perturbed * mask
    low, high = noise_range
    noise = torch.empty_like(perturbed).uniform_(low, high, generator=generator)
    perturbed = perturbed * (1.0 + noise)
    return perturbed


def perturb_encoder_skips(
    skips: Sequence[Tensor],
    num_last: int = FEATURE_PERTURB_NUM_LAST,
    threshold_range: tuple[float, float] = FEATURE_PERTURB_THRESHOLD_RANGE,
    dropout_p: float = FEATURE_PERTURB_DROPOUT_P,
    noise_range: tuple[float, float] = FEATURE_PERTURB_NOISE_RANGE,
    training: bool = True,
    generator: torch.Generator | None = None,
) -> list[Tensor]:
    """Perturb the last ``num_last`` encoder skip-connection features
    (index ``-num_last`` to ``-1``), leaving earlier skips untouched.

    A single threshold is sampled uniformly from ``threshold_range`` for
    this call (i.e. shared across the perturbed features in one forward
    pass), per "threshold is sampled uniformly ... each forward pass" in
    the research doc.

    If ``len(skips) <= num_last``, every skip is perturbed.
    """
    if not skips:
        return []
    low, high = threshold_range
    threshold = torch.empty(()).uniform_(low, high, generator=generator).item()
    start_idx = max(len(skips) - num_last, 0)
    out: list[Tensor] = list(skips[:start_idx])
    for feature in skips[start_idx:]:
        out.append(
            perturb_feature(
                feature,
                threshold=threshold,
                dropout_p=dropout_p,
                noise_range=noise_range,
                training=training,
                generator=generator,
            )
        )
    return out


# ---------------------------------------------------------------------------
# Losses. Needs torch, CPU-testable (no nnunetv2 dependency).
# ---------------------------------------------------------------------------


class SoftmaxMSELoss(nn.Module):
    """MSE between softmax(student_logits) and softmax(teacher_logits),
    computed over *all* classes including background (mean reduction).

    The teacher branch must already have been produced under
    ``torch.no_grad()`` by the caller (that is what makes it a
    stop-gradient target rather than a second learnable network); this
    module also calls ``.detach()`` defensively.
    """

    def forward(self, student_logits: Tensor, teacher_logits: Tensor) -> Tensor:
        student_probs = F.softmax(student_logits, dim=1)
        teacher_probs = F.softmax(teacher_logits, dim=1).detach()
        return F.mse_loss(student_probs, teacher_probs, reduction="mean")


def default_deep_supervision_weights(num_outputs: int, exclude_lowest_resolution: bool = True) -> list[float]:
    """Weights for combining a deep-supervision output list, mirroring
    nnU-Net's own scheme: weight ``1 / 2**i`` for output ``i`` (``i=0`` is
    the highest-resolution/main output), the lowest-resolution output's
    weight zeroed out, then normalized to sum to 1.
    """
    if num_outputs <= 0:
        raise ValueError("num_outputs must be positive")
    weights = [1.0 / (2**i) for i in range(num_outputs)]
    if exclude_lowest_resolution and num_outputs > 1:
        weights[-1] = 0.0
    total = sum(weights)
    if total <= 0:
        raise ValueError("all deep supervision weights are zero")
    return [w / total for w in weights]


class ConsistencyDeepSupervisionWrapper(nn.Module):
    """Wraps a per-scale loss (here, :class:`SoftmaxMSELoss`) with nnU-Net's
    deep-supervision multi-scale weighting, per the research doc's
    instruction to "reuse/mirror" nnU-Net's existing DS wrapper rather than
    invent a new mechanism.

    This is a torch-only reproduction of that weighting scheme so it can be
    unit-tested without ``nnunetv2`` installed. On the GPU box, prefer
    wrapping :class:`SoftmaxMSELoss` with nnU-Net's own
    ``nnunetv2.training.loss.deep_supervision.DeepSupervisionWrapper`` for
    exact parity with the supervised loss's DS handling; this class is the
    CPU-testable fallback/equivalent used when that import is unavailable.
    """

    def __init__(self, base_loss: nn.Module, weights: Sequence[float] | None = None):
        super().__init__()
        self.base_loss = base_loss
        self._fixed_weights = list(weights) if weights is not None else None

    def forward(self, student_outputs: Sequence[Tensor], teacher_outputs: Sequence[Tensor]) -> Tensor:
        if len(student_outputs) != len(teacher_outputs):
            raise ValueError("student_outputs and teacher_outputs must have the same length")
        weights = (
            self._fixed_weights
            if self._fixed_weights is not None
            else default_deep_supervision_weights(len(student_outputs))
        )
        total = student_outputs[0].new_zeros(())
        for weight, student, teacher in zip(weights, student_outputs, teacher_outputs):
            if weight == 0:
                continue
            total = total + weight * self.base_loss(student, teacher)
        return total


# ---------------------------------------------------------------------------
# Pseudo-label masking (phase C). Needs torch, CPU-testable.
# ---------------------------------------------------------------------------


@dataclass
class PseudoLabelResult:
    """Result of :func:`build_pseudo_labels`.

    ``labels``: long tensor of class indices (no channel dim), argmax of
    the softmax probabilities with low-confidence voxels relabeled to
    ``ignore_index``.

    ``ignore_mask``: bool tensor, True wherever ``labels == ignore_index``
    -- this is exactly what the pseudo-label Dice+CE loss should ignore.
    Per the research doc, the champion code's flat-threshold implementation
    treats *all* class-0 voxels as ignored for this branch (both genuine
    background predictions and low-confidence relabels), not only the
    relabeled ones -- reproduced here faithfully even though it means the
    pseudo-label branch never supervises the background class directly.

    ``low_confidence_mask``: bool tensor, True only where a voxel's argmax
    was relabeled to ``ignore_index`` *because* of the confidence threshold
    (diagnostic only -- a strict subset of ``ignore_mask``).
    """

    labels: Tensor
    ignore_mask: Tensor
    low_confidence_mask: Tensor


def build_pseudo_labels(
    softmax_probs: Tensor,
    confidence_threshold: float = PSEUDO_LABEL_CONFIDENCE_THRESHOLD,
    ignore_index: int = PSEUDO_LABEL_IGNORE_INDEX,
    class_dim: int = 1,
) -> PseudoLabelResult:
    """Phase C pseudo-label branch: argmax the unperturbed prediction's
    softmax; any voxel whose max class probability is below
    ``confidence_threshold`` is relabeled to ``ignore_index`` (background
    class 0 by default) for loss purposes.

    CAUTION (from the research doc): a flat 0.75 threshold with hard ignore
    is likely too aggressive for the thin pulp-canal classes, which have far
    fewer high-confidence voxels than tooth classes -- this can bias the
    pseudo-label signal toward large structures and entrench root-tip false
    negatives. A concurrent workstream may add a class-aware,
    component-count-based pseudo-label filter in
    ``src/stsr2026/training/pseudo_label.py``; if that module exists, its
    acceptance rule is a natural drop-in replacement for the
    ``max_probs < confidence_threshold`` check below (see the TODO at the
    bottom of this function). As of this writing that module does not exist
    in this worktree, so only the flat-threshold version is implemented.
    """
    max_probs, labels = softmax_probs.max(dim=class_dim)
    low_confidence = max_probs < confidence_threshold

    # TODO(pseudo_label.py integration): if a class-aware / component-count
    # based acceptance rule becomes available, compute `low_confidence`
    # (or an additional rejection mask to OR into it) from that module
    # instead of / in addition to this flat per-voxel threshold, especially
    # for the pulp-canal classes.

    labels = labels.clone()
    labels[low_confidence] = ignore_index
    ignore_mask = labels == ignore_index
    return PseudoLabelResult(labels=labels, ignore_mask=ignore_mask, low_confidence_mask=low_confidence)


# ---------------------------------------------------------------------------
# nnU-Net v2 trainer wiring. Only defined when nnunetv2 is importable.
# ---------------------------------------------------------------------------

if NNUNETV2_AVAILABLE:

    @dataclass
    class _UnlabeledStepConfig:
        unlabeled_start_rate: float = PHASE_B_UNLABELED_START_RATE
        unlabeled_cap_rate: float = UNLABELED_USAGE_CAP
        consistency_max_weight: float = CONSISTENCY_MAX_WEIGHT
        consistency_rampup_fraction: float = CONSISTENCY_RAMPUP_FRACTION
        feature_perturb_num_last: int = FEATURE_PERTURB_NUM_LAST
        feature_perturb_dropout_p: float = FEATURE_PERTURB_DROPOUT_P
        feature_perturb_threshold_range: tuple[float, float] = field(
            default_factory=lambda: FEATURE_PERTURB_THRESHOLD_RANGE
        )
        feature_perturb_noise_range: tuple[float, float] = field(
            default_factory=lambda: FEATURE_PERTURB_NOISE_RANGE
        )

    class nnUNetTrainer_STSR_PhaseB(nnUNetTrainer):  # type: ignore[misc]
        """Phase B: nnU-Net's supervised Dice+CE deep-supervision loss
        (inherited unmodified) plus consistency regularization on unlabeled
        batches, per docs/research/02-challenge-review.md section 2 ("阶段
        B：监督训练 + 一致性正则化").

        NOT YET RUN end-to-end -- see module docstring. The ``__init__``
        signature below is copied verbatim from ``nnUNetTrainer`` (no
        ``*args``/``**kwargs``) because nnU-Net's base class introspects
        ``inspect.signature(self.__init__)`` against ``locals()``; a
        pass-through signature breaks that with a ``KeyError``.
        """

        def __init__(
            self,
            plans: dict,
            configuration: str,
            fold: int,
            dataset_json: dict,
            device: torch.device = torch.device("cuda"),
        ):
            super().__init__(plans, configuration, fold, dataset_json, device=device)
            self.ssl_config = _UnlabeledStepConfig()
            self._consistency_loss: ConsistencyDeepSupervisionWrapper | None = None
            self._unlabeled_probability_this_epoch = self.ssl_config.unlabeled_start_rate

        # -- schedule hooks -------------------------------------------------

        def on_train_epoch_start(self) -> None:
            super().on_train_epoch_start()
            self._unlabeled_probability_this_epoch = unlabeled_usage_probability(
                self.current_epoch,
                self.num_epochs,
                start=self.ssl_config.unlabeled_start_rate,
                cap=self.ssl_config.unlabeled_cap_rate,
            )

        def _current_iteration(self) -> int:
            # ASSUMPTION: nnUNetTrainer exposes num_iterations_per_epoch and
            # current_epoch; verify against the installed nnunetv2 version.
            return self.current_epoch * self.num_iterations_per_epoch

        def _total_iterations(self) -> int:
            return self.num_epochs * self.num_iterations_per_epoch

        def consistency_weight(self) -> float:
            return consistency_ramp_up_weight(
                self._current_iteration(),
                self._total_iterations(),
                max_weight=self.ssl_config.consistency_max_weight,
                rampup_fraction=self.ssl_config.consistency_rampup_fraction,
            )

        def should_use_unlabeled_step(self) -> bool:
            return random.random() < self._unlabeled_probability_this_epoch

        # -- loss construction ------------------------------------------------

        def _build_consistency_loss(self) -> ConsistencyDeepSupervisionWrapper:
            if self._consistency_loss is None:
                base = SoftmaxMSELoss()
                # Prefer nnU-Net's own DS wrapper for exact parity with the
                # supervised loss; fall back to the local mirror above if the
                # exact import path differs across nnunetv2 versions.
                try:
                    from nnunetv2.training.loss.deep_supervision import (
                        DeepSupervisionWrapper as _NNUNetDSWrapper,
                    )

                    weights = default_deep_supervision_weights(
                        len(self._get_deep_supervision_scales())  # type: ignore[attr-defined]
                    )
                    self._consistency_loss = _NNUNetDSWrapper(base, weights)  # type: ignore[assignment]
                except Exception:
                    self._consistency_loss = ConsistencyDeepSupervisionWrapper(base)
            return self._consistency_loss

        # -- feature perturbation --------------------------------------------

        def _forward_with_perturbed_skips(self, aug_data: Tensor) -> Tensor | list[Tensor]:
            """Runs the "a(x_u)" branch: encoder -> perturb last-5 skips ->
            decoder, on the augmented/strong input.

            ASSUMPTION: ``self.network`` exposes ``.encoder`` and
            ``.decoder`` submodules where ``encoder(x)`` returns the list of
            skip-connection feature maps consumed by ``decoder(skips)``,
            following the ``dynamic-network-architectures``
            PlainConvUNet/ResidualEncoderUNet convention nnU-Net v2 uses by
            default. Verify this against the actual network class used by
            the target plans/configuration on the GPU box -- if a different
            architecture is used, this needs adjusting.
            """
            network = self.network
            skips = network.encoder(aug_data)  # type: ignore[attr-defined]
            perturbed_skips = perturb_encoder_skips(
                skips,
                num_last=self.ssl_config.feature_perturb_num_last,
                threshold_range=self.ssl_config.feature_perturb_threshold_range,
                dropout_p=self.ssl_config.feature_perturb_dropout_p,
                noise_range=self.ssl_config.feature_perturb_noise_range,
                training=self.network.training,  # type: ignore[attr-defined]
            )
            return network.decoder(perturbed_skips)  # type: ignore[attr-defined]

        # -- weak/strong unlabeled input ---------------------------------------

        def build_unlabeled_dataloader(
            self,
            unlabeled_image_paths: Sequence,
            cache_dir,
            batch_size: int | None = None,
            num_workers: int = 4,
        ):
            """Build a torch ``DataLoader`` over unlabeled raw CBCT images,
            yielding ``{"data": weak_batch, "aug_data": strong_batch}``
            tensors ready for :meth:`train_step_unlabeled` /
            :meth:`compute_consistency_loss`.

            Uses :mod:`stsr2026.training.unlabeled_data`: each image is
            reoriented to LPS if needed (see the D0 finding that 17/299
            Train-Unlabeled cases are LAS -- pass already-reoriented paths
            if you've handled this upstream, ``ensure_lps_nifti`` is
            idempotent either way), preprocessed once via nnU-Net's own
            ``DefaultPreprocessor`` (seg_file=None path) and cached as
            ``.npy`` under ``cache_dir`` so repeat epochs don't re-run the
            expensive resample/crop/normalize pipeline, then patches are
            drawn with the documented weak/strong augmentation from
            :func:`stsr2026.training.unlabeled_data.make_weak_strong_pair`.

            VALIDATED on 2025-07-12 (real nnunetv2 install, GPU): the
            preprocessing cache and patch dataset were unit-tested in
            isolation; wiring this method into the actual epoch loop
            (calling it once before training and iterating the returned
            loader inside the unlabeled-step branch) has NOT yet been run
            end-to-end -- do that before trusting throughput/memory
            behavior for a full run.
            """
            from torch.utils.data import DataLoader

            from stsr2026.training.unlabeled_data import (
                UnlabeledPatchDataset,
                cache_preprocessed_unlabeled_case,
                ensure_lps_nifti,
            )

            lps_cache_dir = cache_dir / "lps_reoriented"
            preprocessed_cache_dir = cache_dir / "preprocessed"
            cached_case_paths = [
                cache_preprocessed_unlabeled_case(
                    ensure_lps_nifti(image_path, lps_cache_dir),
                    preprocessed_cache_dir,
                    self.plans_manager,
                    self.configuration_manager,
                    self.dataset_json,
                )
                for image_path in unlabeled_image_paths
            ]
            dataset = UnlabeledPatchDataset(
                cached_case_paths,
                patch_size=self.configuration_manager.patch_size,
            )
            return DataLoader(
                dataset,
                batch_size=batch_size or self.batch_size,
                shuffle=True,
                num_workers=num_workers,
                drop_last=True,
            )

        # -- training step -----------------------------------------------------

        def compute_consistency_loss(self, data: Tensor, aug_data: Tensor) -> Tensor:
            """``L_consistency = w(t) * MSE(softmax(p(a(x_u))), softmax(sg(p(x_u))))``.

            ``data`` is the weak/original unlabeled input, ``aug_data`` is
            the strong/augmented pair for the same sample.
            """
            with torch.no_grad():
                teacher_logits = self.network(data)
            student_logits = self._forward_with_perturbed_skips(aug_data)

            if not isinstance(teacher_logits, (list, tuple)):
                teacher_logits = [teacher_logits]
            if not isinstance(student_logits, (list, tuple)):
                student_logits = [student_logits]

            loss_fn = self._build_consistency_loss()
            raw_loss = loss_fn(list(student_logits), list(teacher_logits))
            return self.consistency_weight() * raw_loss

        def train_step_unlabeled(self, unlabeled_batch: dict) -> Tensor:
            """Consumes an unlabeled batch of the form
            ``{"data": weak_tensor, "aug_data": strong_tensor}`` and returns
            the (weighted) consistency loss to add to the supervised loss
            for this step. Callers should only invoke this when
            :meth:`should_use_unlabeled_step` returns True.
            """
            data = unlabeled_batch["data"].to(self.device, non_blocking=True).float()
            aug_data = unlabeled_batch["aug_data"].to(self.device, non_blocking=True).float()
            return self.compute_consistency_loss(data, aug_data)

        # -- main training-loop hook -------------------------------------------

        def set_unlabeled_dataloader(self, dataloader) -> None:
            """Attach the unlabeled ``DataLoader`` (from
            :meth:`build_unlabeled_dataloader`) that :meth:`train_step` pulls
            an unlabeled batch from on steps where
            :meth:`should_use_unlabeled_step` is True. Call this once after
            ``initialize()`` and before ``run_training()``; without it,
            :meth:`train_step` silently falls back to supervised-only
            (logged via ``self.print_to_log_file`` once).
            """
            self._unlabeled_dataloader = dataloader
            self._unlabeled_iterator = iter(dataloader) if dataloader is not None else None

        def _next_unlabeled_batch(self) -> dict | None:
            if getattr(self, "_unlabeled_dataloader", None) is None:
                if not getattr(self, "_warned_no_unlabeled_loader", False):
                    self.print_to_log_file(
                        "STSR SSL: should_use_unlabeled_step() was True but no unlabeled "
                        "dataloader is attached (call set_unlabeled_dataloader first); "
                        "falling back to supervised-only for this and all further steps "
                        "this run."
                    )
                    self._warned_no_unlabeled_loader = True
                return None
            try:
                return next(self._unlabeled_iterator)
            except StopIteration:
                self._unlabeled_iterator = iter(self._unlabeled_dataloader)
                return next(self._unlabeled_iterator)

        def train_step(self, batch: dict) -> dict:
            """Overrides ``nnUNetTrainer.train_step`` to add the unlabeled
            consistency (phase B) / pseudo-label (phase C, via the
            overridden :meth:`train_step_unlabeled`) branch into the SAME
            backward pass as the supervised loss, rather than a separate
            ``backward()``/``optimizer.step()`` call -- matching how the
            base trainer accumulates one combined loss per iteration.

            VALIDATED structurally against nnU-Net's own ``train_step``
            (copied its data/target movement, ``autocast``/``grad_scaler``,
            and gradient-clipping-at-12 exactly) but the combined-loss
            backward pass itself has only been smoke-tested on a 2-case
            dataset, not run for a full epoch -- watch memory/throughput on
            first real launch.
            """
            from torch import autocast

            from nnunetv2.utilities.helpers import dummy_context

            data = batch["data"].to(self.device, non_blocking=True)
            target = batch["target"]
            if isinstance(target, list):
                target = [i.to(self.device, non_blocking=True) for i in target]
            else:
                target = target.to(self.device, non_blocking=True)

            use_unlabeled = self.should_use_unlabeled_step()
            unlabeled_batch = self._next_unlabeled_batch() if use_unlabeled else None

            self.optimizer.zero_grad(set_to_none=True)
            with autocast(self.device.type, enabled=True) if self.device.type == "cuda" else dummy_context():
                output = self.network(data)
                loss = self.loss(output, target)
                if unlabeled_batch is not None:
                    loss = loss + self.train_step_unlabeled(unlabeled_batch)

            if self.grad_scaler is not None:
                self.grad_scaler.scale(loss).backward()
                self.grad_scaler.unscale_(self.optimizer)
                torch.nn.utils.clip_grad_norm_(self.network.parameters(), 12)
                self.grad_scaler.step(self.optimizer)
                self.grad_scaler.update()
            else:
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.network.parameters(), 12)
                self.optimizer.step()
            return {"loss": loss.detach().cpu().numpy()}

    class nnUNetTrainer_STSR_PhaseC(nnUNetTrainer_STSR_PhaseB):
        """Phase C: layers a pseudo-label branch on top of phase B, per
        docs/research/02-challenge-review.md section 2 ("阶段 C：在阶段 B
        目标之上引入伪标签精化").

        Adaptation note: the original three-stage pipeline continues phase
        C from a phase-B checkpoint. For this repo's P0-first workflow,
        phase C may instead start from the plain supervised P0 checkpoint
        (skipping phase B) -- this is a deliberate adaptation for the
        sprint timeline, not a claim of identical provenance to the
        original submission. Document which checkpoint was actually used
        when launching a real run.

        NOT YET RUN end-to-end -- see module docstring.
        """

        def __init__(
            self,
            plans: dict,
            configuration: str,
            fold: int,
            dataset_json: dict,
            device: torch.device = torch.device("cuda"),
        ):
            super().__init__(plans, configuration, fold, dataset_json, device=device)
            self.ssl_config.unlabeled_start_rate = PHASE_C_UNLABELED_START_RATE
            self._pseudo_label_loss = None

        def configure_lr(self, current_step: int, total_steps: int) -> float:
            return phase_c_lr_schedule(current_step, total_steps)

        def on_train_epoch_start(self) -> None:
            """Overrides the learning rate nnU-Net's base
            ``on_train_epoch_start`` -> ``self.lr_scheduler.step(...)`` just
            set (nnU-Net's default ``PolyLRScheduler``) with phase C's
            linear decay instead.

            VALIDATED: without this override, ``configure_lr``/
            ``phase_c_lr_schedule`` were dead code -- nnU-Net's own poly LR
            scheduler was silently in effect the entire time, confirmed by
            reading ``nnUNetTrainer.on_train_epoch_start`` (it always calls
            ``self.lr_scheduler.step(self.current_epoch)``, which phase C
            never touched before this fix).
            """
            super().on_train_epoch_start()
            lr = phase_c_lr_schedule(self.current_epoch, self.num_epochs)
            for param_group in self.optimizer.param_groups:
                param_group["lr"] = lr

        def _build_pseudo_label_loss(self):
            """Builds a Dice+CE loss configured with ``ignore_label=0`` for
            the pseudo-label branch, mirroring how nnU-Net's own
            ``_build_loss`` configures ``DC_and_CE_loss``.

            VALIDATED against a real nnunetv2 install (2025-07-12, on a
            2-case smoke dataset): the constructor kwargs below match
            ``nnUNetTrainer._build_loss`` exactly, including
            ``dice_class=MemoryEfficientSoftDiceLoss`` and critically
            ``'ddp': self.is_ddp`` in ``soft_dice_kwargs`` -- omitting
            ``ddp`` defaults ``SoftDiceLoss.ddp`` to ``True``, which calls
            ``AllGatherGrad.apply`` unconditionally whenever ``batch_dice``
            is on and crashes with "Default process group has not been
            initialized" outside of DDP training (confirmed by reproducing
            the crash before this fix).
            """
            if self._pseudo_label_loss is None:
                from nnunetv2.training.loss.compound_losses import DC_and_CE_loss
                from nnunetv2.training.loss.dice import MemoryEfficientSoftDiceLoss

                base = DC_and_CE_loss(
                    {
                        "batch_dice": self.configuration_manager.batch_dice,
                        "smooth": 1e-5,
                        "do_bg": False,
                        "ddp": self.is_ddp,
                    },
                    {},
                    weight_ce=1,
                    weight_dice=1,
                    ignore_label=PSEUDO_LABEL_IGNORE_INDEX,
                    dice_class=MemoryEfficientSoftDiceLoss,
                )
                try:
                    from nnunetv2.training.loss.deep_supervision import (
                        DeepSupervisionWrapper as _NNUNetDSWrapper,
                    )

                    weights = default_deep_supervision_weights(
                        len(self._get_deep_supervision_scales())  # type: ignore[attr-defined]
                    )
                    self._pseudo_label_loss = _NNUNetDSWrapper(base, weights)
                except Exception:
                    self._pseudo_label_loss = base
            return self._pseudo_label_loss

        def compute_pseudo_label_loss(self, data: Tensor) -> Tensor:
            """The pseudo-label branch: argmax + confidence-threshold the
            unperturbed prediction, then a Dice+CE loss against those
            pseudo-labels with class 0 as ignore index, scaled by 0.1.
            """
            with torch.no_grad():
                teacher_logits = self.network(data)
                teacher_main = teacher_logits[0] if isinstance(teacher_logits, (list, tuple)) else teacher_logits
                softmax_probs = F.softmax(teacher_main, dim=1)
                pseudo = build_pseudo_labels(softmax_probs)

            student_logits = self.network(data)
            loss_fn = self._build_pseudo_label_loss()
            target = pseudo.labels.unsqueeze(1)  # nnU-Net targets carry a channel dim
            if isinstance(student_logits, (list, tuple)):
                # Deep-supervision targets must be downsampled to match each
                # scale's spatial shape, not repeated at full resolution --
                # confirmed by reproducing a shape-mismatch RuntimeError
                # ("Expected index [...] to be no larger than self [...]")
                # against a real nnU-Net loss before this fix. Nearest
                # interpolation keeps pseudo-label values as hard class ids
                # (matches nnU-Net's own label-downsampling convention;
                # linear/area interpolation would blend class indices).
                targets = [
                    target if logits.shape[2:] == target.shape[2:]
                    else F.interpolate(target.float(), size=logits.shape[2:], mode="nearest").long()
                    for logits in student_logits
                ]
                raw_loss = loss_fn(student_logits, targets)
            else:
                raw_loss = loss_fn(student_logits, target)
            return PSEUDO_LABEL_LOSS_WEIGHT * raw_loss

        def train_step_unlabeled(self, unlabeled_batch: dict) -> Tensor:
            if should_use_pseudo_label_branch():
                data = unlabeled_batch["data"].to(self.device, non_blocking=True).float()
                return self.compute_pseudo_label_loss(data)
            return super().train_step_unlabeled(unlabeled_batch)

else:  # pragma: no cover - documented no-op when nnunetv2 isn't installed
    nnUNetTrainer_STSR_PhaseB = None
    nnUNetTrainer_STSR_PhaseC = None
