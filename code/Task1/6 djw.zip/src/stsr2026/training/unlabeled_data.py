"""Preprocessing and weak/strong augmentation pipeline for unlabeled CBCT
cases, feeding ``stsr2026.training.ssl_trainer``'s consistency branch (which
expects ``{"data": weak, "aug_data": strong}`` batches -- see
``nnUNetTrainer_STSR_PhaseB.train_step_unlabeled``).

This replaces ``ssl_trainer.build_weak_strong_transforms``'s
``NotImplementedError`` stub. The champion's exact weak/strong augmentation
recipe is not published (see ``docs/research/02-challenge-review.md``); the
choice here -- weak = random flips only, strong = flips + Gaussian noise +
gamma + Gaussian blur -- is a documented interim choice, not a verified
reproduction, per plan.md section 3.3's own artifact-simulation list
("局部高亮/暗带、条纹、噪声、gamma、模糊").

Also handles the D0 finding that 17/299 Train-Unlabeled cases are
LAS-oriented instead of LPS like the rest of the dataset (see plan.md's D0
section): :func:`ensure_lps_nifti` reorients before preprocessing, or those
cases' consistency/pseudo-label targets would be silently mirrored on the
A/P axis.
"""
from __future__ import annotations

import random
from pathlib import Path
from typing import Sequence

import nibabel as nib
import numpy as np
from scipy.ndimage import gaussian_filter

try:  # pragma: no cover - exercised only on a real nnU-Net install
    from nnunetv2.preprocessing.preprocessors.default_preprocessor import DefaultPreprocessor

    NNUNETV2_AVAILABLE = True
except ImportError:  # pragma: no cover - the expected case without nnunetv2
    DefaultPreprocessor = None  # type: ignore[assignment,misc]
    NNUNETV2_AVAILABLE = False


# ---------------------------------------------------------------------------
# LPS reorientation (D0 finding: 17/299 Train-Unlabeled cases are LAS).
# ---------------------------------------------------------------------------

LPS = ("L", "P", "S")


def reorient_to_lps(image: nib.Nifti1Image) -> nib.Nifti1Image:
    """Reorient a NIfTI image to LPS if it isn't already; no-op otherwise."""
    if nib.aff2axcodes(image.affine) == LPS:
        return image
    orig_ornt = nib.orientations.io_orientation(image.affine)
    target_ornt = nib.orientations.axcodes2ornt(LPS)
    transform = nib.orientations.ornt_transform(orig_ornt, target_ornt)
    data = np.asanyarray(image.dataobj)
    reoriented_data = nib.orientations.apply_orientation(data, transform)
    reoriented_affine = image.affine @ nib.orientations.inv_ornt_aff(transform, data.shape)
    return nib.Nifti1Image(reoriented_data, reoriented_affine, image.header)


def ensure_lps_nifti(source_path: Path, cache_dir: Path) -> Path:
    """Return a path to an LPS-oriented copy of ``source_path``.

    If the source is already LPS, returns ``source_path`` unchanged (no
    copy made). Otherwise writes (or reuses a previously written) LPS copy
    under ``cache_dir`` and returns that path instead.
    """
    image = nib.load(str(source_path))
    if nib.aff2axcodes(image.affine) == LPS:
        return source_path
    cache_dir.mkdir(parents=True, exist_ok=True)
    cached = cache_dir / source_path.name
    if not cached.exists():
        nib.save(reorient_to_lps(image), str(cached))
    return cached


# ---------------------------------------------------------------------------
# nnU-Net-consistent preprocessing for an unlabeled (no-seg) case.
# ---------------------------------------------------------------------------


def preprocess_unlabeled_case(
    image_path: Path,
    plans_manager,
    configuration_manager,
    dataset_json: dict,
) -> np.ndarray:
    """Run nnU-Net's own preprocessing (resample/crop/normalize) on a single
    unlabeled image, via ``DefaultPreprocessor.run_case(..., seg_file=None)``
    -- its own documented "test case" path -- so unlabeled cases see exactly
    the same intensity/spacing pipeline the network was trained on.

    Returns a ``(C, D, H, W)`` float array.

    VALIDATED against a real nnunetv2 install: passing ``seg_file=None``
    does NOT make ``run_case`` return ``seg=None`` -- internally,
    ``crop_to_nonzero`` always generates a foreground/background bookkeeping
    mask (used to track the crop bounding box) regardless of whether a real
    segmentation was supplied, and that mask comes back as ``seg``. This is
    not a real label map for our unlabeled case, so it's discarded; only
    ``data`` (the resampled/cropped/normalized image) is used.
    """
    if not NNUNETV2_AVAILABLE:
        raise RuntimeError("nnunetv2 is required for preprocess_unlabeled_case")
    from stsr2026.evaluation.nnunet_inference import install_skip_unused_seg_resample

    install_skip_unused_seg_resample()
    preprocessor = DefaultPreprocessor()
    data, _seg, _properties = preprocessor.run_case(
        [str(image_path)], None, plans_manager, configuration_manager, dataset_json
    )
    return data


# ---------------------------------------------------------------------------
# Random patch extraction.
# ---------------------------------------------------------------------------


def random_patch(
    data: np.ndarray,
    patch_size: Sequence[int],
    rng: random.Random | None = None,
) -> np.ndarray:
    """Extract a random ``patch_size`` crop from a ``(C, *spatial)`` array,
    zero-padding first if the array is smaller than ``patch_size`` along any
    spatial axis (mirrors nnU-Net's own handling of undersized volumes).
    """
    rng = rng if rng is not None else random
    patch_size = tuple(patch_size)
    spatial = data.shape[1:]
    if len(spatial) != len(patch_size):
        raise ValueError(f"data has {len(spatial)} spatial dims, patch_size has {len(patch_size)}")

    pad_width = [(0, 0)] + [(0, max(patch - size, 0)) for size, patch in zip(spatial, patch_size)]
    if any(p != (0, 0) for p in pad_width[1:]):
        data = np.pad(data, pad_width, mode="constant", constant_values=0)
        spatial = data.shape[1:]

    starts = [rng.randint(0, size - patch) if size > patch else 0 for size, patch in zip(spatial, patch_size)]
    slices = tuple(slice(start, start + patch) for start, patch in zip(starts, patch_size))
    return data[(slice(None),) + slices]


# ---------------------------------------------------------------------------
# Weak/strong augmentation.
# ---------------------------------------------------------------------------


def _random_flips(patch: np.ndarray, rng: random.Random) -> np.ndarray:
    out = patch
    for axis in range(1, out.ndim):  # skip channel axis 0
        if rng.random() < 0.5:
            out = np.flip(out, axis=axis)
    return out


def weak_augment(patch: np.ndarray, rng: random.Random | None = None) -> np.ndarray:
    """Weak view: random axis flips only, no intensity perturbation."""
    rng = rng if rng is not None else random
    return np.ascontiguousarray(_random_flips(patch, rng))


def _gamma_correct(patch: np.ndarray, gamma: float, epsilon: float = 1e-7) -> np.ndarray:
    """Standard gamma augmentation for already-normalized data: rescale
    per-channel to [0, 1] via min/max, apply ``x ** gamma``, rescale back to
    the original range. This is the same min-max-then-power approach used by
    nnU-Net's own gamma augmentation, and works regardless of the input's
    absolute scale (e.g. Z-score-normalized CBCT intensities).
    """
    out = np.empty_like(patch)
    for c in range(patch.shape[0]):
        channel = patch[c]
        lo, hi = channel.min(), channel.max()
        scale = hi - lo
        if scale < epsilon:
            out[c] = channel
            continue
        normalized = (channel - lo) / scale
        out[c] = normalized**gamma * scale + lo
    return out


def strong_augment(
    patch: np.ndarray,
    rng: random.Random | None = None,
    noise_std: float = 0.1,
    gamma_range: tuple[float, float] = (0.7, 1.5),
    blur_sigma_range: tuple[float, float] = (0.5, 1.5),
    blur_probability: float = 0.5,
) -> np.ndarray:
    """Strong view: the same flips as :func:`weak_augment`, plus Gaussian
    noise, gamma correction, and (with 50% probability per call) Gaussian
    blur. Documented interim choice, not a verified reproduction of the
    champion's exact strong-augmentation recipe (unpublished).
    """
    rng = rng if rng is not None else random
    # dtype is pinned to patch.dtype throughout: numpy silently promotes
    # float32 + float64 to float64 (np.random.default_rng().normal()
    # defaults to double), and a float64 batch reaching the network under
    # torch.autocast's half-precision weights crashes with "Input type
    # (double) and bias type (c10::Half) should be the same" -- reproduced
    # and confirmed via a real training-loop run before this fix.
    dtype = patch.dtype
    out = _random_flips(patch, rng)
    noise = np.random.default_rng(rng.randrange(2**32)).normal(0.0, noise_std, out.shape).astype(dtype)
    out = out + noise
    gamma = rng.uniform(*gamma_range)
    out = _gamma_correct(out, gamma).astype(dtype)
    if rng.random() < blur_probability:
        sigma = rng.uniform(*blur_sigma_range)
        out = np.stack([gaussian_filter(out[c], sigma=sigma) for c in range(out.shape[0])]).astype(dtype)
    return np.ascontiguousarray(out)


# ---------------------------------------------------------------------------
# Preprocessing cache: preprocess each unlabeled case once (nnU-Net's own
# resample/crop/normalize is not cheap -- e.g. a full head-volume CBCT --
# and re-running it on every dataloader __getitem__ call would dominate
# training wall-clock. Mirrors nnU-Net's own supervised-data caching model,
# just for unlabeled cases via preprocess_unlabeled_case's seg_file=None path.
# ---------------------------------------------------------------------------


def cache_preprocessed_unlabeled_case(
    image_path: Path,
    cache_dir: Path,
    plans_manager,
    configuration_manager,
    dataset_json: dict,
) -> Path:
    """Preprocess ``image_path`` once via :func:`preprocess_unlabeled_case`
    and cache the result as ``cache_dir/<stem>.npy``. Reuses an existing
    cached file without touching ``image_path`` again if one is already
    present (idempotent, like :func:`ensure_lps_nifti`).
    """
    cache_dir.mkdir(parents=True, exist_ok=True)
    stem = image_path.name.removesuffix(".nii.gz").removesuffix(".nii")
    cached = cache_dir / f"{stem}.npy"
    if not cached.exists():
        data = preprocess_unlabeled_case(image_path, plans_manager, configuration_manager, dataset_json)
        np.save(cached, data)
    return cached


class UnlabeledPatchDataset:
    """Torch-compatible dataset (duck-typed: implements ``__len__`` and
    ``__getitem__``, avoiding a hard ``torch.utils.data.Dataset`` import
    requirement in this module) over a list of cached preprocessed unlabeled
    cases. Each item is one random ``(weak, strong)`` patch pair, as numpy
    arrays shaped ``(C, *patch_size)`` -- convert to tensors in the
    collate/training step, matching how ``ssl_trainer.train_step_unlabeled``
    consumes ``{"data": ..., "aug_data": ...}`` batches.
    """

    def __init__(
        self,
        cached_case_paths: Sequence[Path],
        patch_size: Sequence[int],
        seed: int | None = None,
    ):
        if not cached_case_paths:
            raise ValueError("cached_case_paths must not be empty")
        self.cached_case_paths = list(cached_case_paths)
        self.patch_size = tuple(patch_size)
        self._rng = random.Random(seed)

    def __len__(self) -> int:
        return len(self.cached_case_paths)

    def __getitem__(self, index: int) -> dict[str, np.ndarray]:
        case = np.load(self.cached_case_paths[index], mmap_mode="r")
        weak, strong = make_weak_strong_pair(case, self.patch_size, rng=self._rng)
        return {"data": weak, "aug_data": strong}


def make_weak_strong_pair(
    preprocessed_case: np.ndarray,
    patch_size: Sequence[int],
    rng: random.Random | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    """Extract one random patch from a preprocessed unlabeled case and
    return ``(weak, strong)`` views of it, ready to stack into a training
    batch (each shaped ``(C, *patch_size)``).
    """
    rng = rng if rng is not None else random
    patch = random_patch(preprocessed_case, patch_size, rng=rng)
    return weak_augment(patch, rng=rng), strong_augment(patch, rng=rng)
