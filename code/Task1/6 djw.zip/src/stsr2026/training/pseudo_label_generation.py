"""P1 offline pseudo-label generation: run a trained checkpoint (Phase B, per
plan.md section 5's decision -- see docs/experiment-log.md) over unlabeled
CBCT cases, filter with :mod:`stsr2026.training.pseudo_label`'s FDI-aware
component-count logic, and write the result as a real label NIfTI at the
*original* image resolution/geometry -- ready to sit in an nnU-Net
``labelsTr`` directory next to the 30 real labeled cases for a standard
supervised fine-tune.

This is plan.md section 3.2's "P1" path, explicitly distinct from
``ssl_trainer.py``'s Phase C inline pseudo-label branch (flat 0.75
threshold, already shown to hurt accuracy -- see the LineA-PhaseC-001 row in
docs/experiment-log.md): P1 generates pseudo-labels once, offline, with the
better FDI-aware filter, and treats the result like real training data
(standard nnU-Net supervised loss on the combined real+pseudo dataset),
never touching the SSL trainer's consistency/inline-pseudo-label machinery.

**Geometry pipeline**: mirrors nnU-Net's own
``export_prediction.convert_predicted_logits_to_segmentation_with_correct_shape``
(crop reversal via ``insert_crop_into_image``, transpose via
``plans_manager.transpose_backward``) with one deliberate difference: instead
of resampling multi-channel *probabilities* back to original resolution and
then arg-maxing (nnU-Net's approach, order=1 per channel), this resamples the
*already-decided, already-filtered* pseudo-label map (a single-channel array
of discrete class IDs plus the ``ignore_label`` marker) with **nearest-
neighbor** interpolation. This is a deliberate, simpler choice for this use
case: nearest-neighbor never blends two different discrete values (e.g. a
real class ID with the ``ignore_label`` sentinel), which linear/cubic
interpolation would -- there is no equivalent "per-channel one-hot then
argmax" trick available here because the filtering decision (confidence
threshold, component-count gating) has already collapsed the class dimension
before this resample happens.

**2026-07-13: validated end-to-end on real GPU hardware (a GPU box, RTX 5090,
Phase B checkpoint)** against 2 real unlabeled cases -- one normal-LPS
(``STS26_Train-Unlabeled_001``), one from the D0-audit-confirmed LAS-oriented
17 (``STS26_Train-Unlabeled_159``), specifically to exercise the
LPS-reorientation path too. Both completed cleanly: output shape/affine
matched the source image exactly (`np.allclose` on the affine, confirmed via
nibabel), class distributions were non-degenerate (40+ distinct classes
present per case) and consistent with the earlier 15-case flat probe's
accept-rate pattern, and per-canal component-count decisions showed real,
varied accept/reject behavior (not all-accept or all-reject).

**Real correctness pitfall found and must be handled by the caller assembling
the final training dataset** (not yet a bug in this module -- a downstream
integration hazard this module's output makes visible): for the LAS-oriented
cases, the written pseudo-label's affine is **LPS** (this module reorients
via ``ensure_lps_nifti`` before preprocessing, matching how the SSL trainer's
existing unlabeled pipeline already handles this D0 finding) -- but the
*original* raw image file for that case is still LAS. Whoever assembles the
final ``imagesTr``/``labelsTr`` pair for nnU-Net's standard preprocessing
**must pair each pseudo-label with the LPS-reoriented copy of its image**
(``ensure_lps_nifti``'s return value), not the original raw file, or
image/label geometry will silently mismatch for those 17 cases and corrupt
training. Confirmed via direct affine/axcodes inspection of both probe
outputs (see docs/progress.md).
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from stsr2026.data.audit import nifti_case_id
from stsr2026.training import pseudo_label as pl
from stsr2026.training.unlabeled_data import ensure_lps_nifti

try:  # pragma: no cover - exercised only on a real nnU-Net + torch install
    import torch
    import torch.nn.functional as F
    from acvl_utils.cropping_and_padding.bounding_boxes import insert_crop_into_image

    NNUNETV2_AVAILABLE = True
except ImportError:  # pragma: no cover - the expected case in this sandbox
    torch = None  # type: ignore[assignment]
    F = None  # type: ignore[assignment]
    insert_crop_into_image = None  # type: ignore[assignment]
    NNUNETV2_AVAILABLE = False


class PseudoLabelGenerationError(RuntimeError):
    """Raised when pseudo-label generation can't run (missing nnunetv2/torch)."""


def _require_nnunetv2() -> None:
    if not NNUNETV2_AVAILABLE:
        raise PseudoLabelGenerationError(
            "nnunetv2/torch/acvl_utils are not installed in this environment -- pseudo-label "
            "generation needs a real GPU box, see module docstring."
        )


@dataclass(frozen=True)
class PseudoLabelGenerationResult:
    case_id: str
    output_path: str
    wall_clock_seconds: float
    accepted_foreground_voxels: int
    ignored_voxels: int
    canal_decisions: tuple  # tuple[pseudo_label.ComponentDecision, ...]


def _nearest_resample_label_map(labels: "np.ndarray", target_shape, *, device) -> "np.ndarray":  # type: ignore[no-untyped-def]
    """Resample a single-channel integer label map (may contain
    ``PseudoLabelConfig.ignore_label``) to ``target_shape`` via GPU
    nearest-neighbor interpolation. Never blends two distinct label values
    (unlike linear/cubic), so it's safe for discrete class IDs mixed with the
    ignore-label sentinel. No-op (returns ``labels`` unchanged) if already at
    the target shape.
    """
    target = [int(s) for s in target_shape]
    if list(labels.shape) == target:
        return labels

    src_dtype = labels.dtype
    with torch.no_grad():
        patch = torch.from_numpy(labels).to(device=device, dtype=torch.float32).unsqueeze(0).unsqueeze(0)
        resampled = F.interpolate(patch, size=target, mode="nearest")
        out = resampled[0, 0].to("cpu").numpy().astype(src_dtype)
        del patch, resampled
    if getattr(device, "type", None) == "cuda":
        torch.cuda.empty_cache()
    return out


def generate_pseudo_label_for_case(
    predictor,
    image_path: Path,
    lps_cache_dir: Path,
    config: pl.PseudoLabelConfig = pl.PseudoLabelConfig(),
) -> tuple["np.ndarray", dict, PseudoLabelGenerationResult]:  # type: ignore[type-arg]
    """Run the full offline pseudo-label pipeline for one unlabeled case:
    LPS reorientation -> nnU-Net preprocessing -> sliding-window inference ->
    softmax -> FDI-aware filtering (:func:`pseudo_label.filter_pseudo_labels`)
    -> geometry reversal back to the *original* image's resolution/affine.

    Returns ``(label_map, data_properties, result_metadata)`` -- the caller
    (see :func:`write_pseudo_label_nifti`) is responsible for actually
    writing the NIfTI, so this function stays easy to unit-test/inspect
    without needing to touch disk beyond the LPS-reorientation cache.

    ASSUMPTION (unverified without a real GPU box, see module docstring):
    ``predictor.predict_logits_from_preprocessed_data`` returns logits at
    *preprocessed* resolution matching ``data.shape`` -- same contract
    already relied on (and GPU-validated) by ``nnunet_inference.predict_case``.
    """
    _require_nnunetv2()
    start = time.perf_counter()
    case_id = nifti_case_id(image_path)
    lps_path = ensure_lps_nifti(image_path, lps_cache_dir)

    preprocessor = predictor.configuration_manager.preprocessor_class(verbose=False)
    data, _seg, properties = preprocessor.run_case(
        [str(lps_path)], None, predictor.plans_manager, predictor.configuration_manager, predictor.dataset_json
    )

    with torch.no_grad():
        logits = predictor.predict_logits_from_preprocessed_data(torch.from_numpy(data))
        probabilities = torch.softmax(logits.float(), dim=0).numpy()
    del logits

    labels_pp, confidence_pp = pl.labels_and_confidence_from_probabilities(probabilities)
    del probabilities
    result = pl.filter_pseudo_labels(labels_pp, confidence_pp, config=config)
    del labels_pp, confidence_pp

    shape_after_cropping = properties["shape_after_cropping_and_before_resampling"]
    labels_cropped = _nearest_resample_label_map(result.labels, shape_after_cropping, device=predictor.device)

    segmentation_reverted_cropping = np.zeros(properties["shape_before_cropping"], dtype=np.int64)
    segmentation_reverted_cropping = insert_crop_into_image(
        segmentation_reverted_cropping, labels_cropped, properties["bbox_used_for_cropping"]
    )
    segmentation_final = segmentation_reverted_cropping.transpose(predictor.plans_manager.transpose_backward)

    elapsed = time.perf_counter() - start
    metadata = PseudoLabelGenerationResult(
        case_id=case_id,
        output_path="",  # filled in by write_pseudo_label_nifti
        wall_clock_seconds=elapsed,
        accepted_foreground_voxels=result.accepted_foreground_voxels,
        ignored_voxels=result.ignored_voxels,
        canal_decisions=result.canal_decisions,
    )
    return segmentation_final, properties, metadata


def write_pseudo_label_nifti(
    predictor,
    label_map: "np.ndarray",
    properties: dict,
    output_path: Path,
) -> None:
    """Write ``label_map`` (already in original-image orientation, see
    :func:`generate_pseudo_label_for_case`) as a NIfTI, reusing nnU-Net's own
    ``image_reader_writer_class`` + the preprocessing ``properties`` dict so
    the affine/spacing/header exactly match the source image -- same pattern
    ``export_prediction_from_logits`` uses for real predictions.
    """
    _require_nnunetv2()
    rw = predictor.plans_manager.image_reader_writer_class()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    truncated = str(output_path)[: -len(predictor.dataset_json["file_ending"])]
    rw.write_seg(label_map, truncated + predictor.dataset_json["file_ending"], properties)
