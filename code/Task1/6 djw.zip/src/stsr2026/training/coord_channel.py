"""Absolute-position coordinate-channel generation for the CoordConv-style
left/right-confusion fix (Liu et al. 2018's "CoordConv" idea, per plan.md's
D3.5 "备选、未执行" model-side direction, now being executed).

Background (see docs/experiment-log.md's MISLABEL analysis and
``stsr2026.inference.lr_correction``): both tooth and canal predictions show
a systematic "spatially correct, laterality wrong" failure mode -- nnU-Net's
sliding-window convolutional network has no explicit signal for *where in
the head* a patch sits, so on near-mirror-symmetric left/right anatomy it
can pick the wrong same-shape-different-side class. The tooth side of this
was fixed post-hoc with geometry (``lr_correction.correct_lr_confusion``,
+0.205 real Challenge_Score) using each case's own predicted tooth centroids
to estimate a midline; the canal side of that post-hoc fix has failed twice
(see ``lr_correction.py``'s ``CANAL_SWAPPABLE_CLASS_PAIRS`` comment) because
a canal's own geometry does not reliably separate left/right. This module
takes the model-side fix instead: bake a normalized absolute left-right
world coordinate into a second input channel, so the network can *read*
where a patch is instead of only seeing local, side-ambiguous texture.

Design constraints (from the task brief, restated because they drive every
choice below):

1. Must be computable at real inference time from the raw CBCT image alone
   -- no segmentation output, no model, no ground truth. Everything here
   only reads ``nib.load(image_path)``.
2. Must not silently break nnU-Net's own ``crop_to_nonzero`` foreground
   cropping when this channel is stacked as ``_0001`` next to the real image
   ``_0000`` and run through nnU-Net's standard multi-channel preprocessing.
   See :func:`compute_coord_channel`'s docstring for why this is a real risk
   (not a hypothetical one) and how the implementation avoids it.
3. LPS axis mapping is verified against real training data (see
   ``verify_world_x_axis`` and the run log this module's authoring session
   recorded in the report to the user), not assumed: for this dataset's
   real ``STS26_Train-Labeled_001`` case, ``nib.load(...).affine`` is exactly
   diagonal (``[[-0.25,0,0,0],[0,-0.25,0,0],[0,0,0.25,0],[0,0,0,1]]``,
   axcodes ``('L','P','S')``), so array axis 0 is the sole determinant of
   nibabel's world-X coordinate (``world_x = affine[0,0]*i + affine[0,3]``).
   This matches ``stsr2026.inference.lr_correction._world_x``'s existing
   ``indices @ affine[0, :3] + affine[0, 3]`` convention exactly, so "world
   X" here is defined identically to what the already-validated tooth LR
   post-processing already uses. This module does not hard-assume the
   diagonal special case, though -- it uses the full affine dot product
   (see below), so it stays correct even for a case with a small rotation.
"""
from __future__ import annotations

from pathlib import Path

import nibabel as nib
import numpy as np
from scipy.ndimage import binary_fill_holes

# ---------------------------------------------------------------------------
# nnU-Net-equivalent foreground bounding box.
#
# Reimplemented (not imported) so this module has zero nnunetv2 dependency
# and is CPU-testable in a sandbox with no GPU/nnunetv2 install (this
# project's established convention -- see unlabeled_data.py, ssl_trainer.py
# module docstrings). The algorithm below is a byte-for-byte port of
# nnunetv2.preprocessing.cropping.cropping.create_nonzero_mask/
# get_bbox_from_mask (read from a real nnunetv2 2.8.1 install on a training box while
# authoring this module, 2026-07-17) -- any single-channel case run through
# both this function and the real nnU-Net function must produce the same
# bounding box, which is the property :func:`compute_coord_channel` depends
# on to avoid disturbing nnU-Net's own crop (see that function's docstring).
# ---------------------------------------------------------------------------


def nonzero_foreground_mask(image: np.ndarray) -> np.ndarray:
    """``binary_fill_holes(image != 0)`` -- nnU-Net's own single-channel
    foreground mask (``create_nonzero_mask`` with one channel; nnU-Net's
    multi-channel OR is irrelevant here since this always runs on the raw
    single-channel CBCT image, never on the coordinate channel itself).
    """
    return binary_fill_holes(image != 0)


def bbox_from_mask(mask: np.ndarray) -> tuple[tuple[int, int], ...]:
    """Tightest axis-aligned half-open bounding box ``((lo0,hi0), (lo1,hi1),
    ...)`` containing every ``True`` voxel of ``mask``, one ``(lo, hi)`` pair
    per array axis, ``hi`` exclusive (matches nnU-Net's own
    ``get_bbox_from_mask`` convention exactly, including for an all-``False``
    mask: nnU-Net's version leaves each axis at ``(0, size)`` in that case,
    reproduced identically below).
    """
    bbox: list[tuple[int, int]] = []
    for axis in range(mask.ndim):
        other_axes = tuple(a for a in range(mask.ndim) if a != axis)
        projection = np.any(mask, axis=other_axes) if other_axes else mask
        nonzero_positions = np.flatnonzero(projection)
        if nonzero_positions.size == 0:
            bbox.append((0, mask.shape[axis]))
        else:
            bbox.append((int(nonzero_positions[0]), int(nonzero_positions[-1]) + 1))
    return tuple(bbox)


# ---------------------------------------------------------------------------
# Coordinate channel.
# ---------------------------------------------------------------------------


def compute_coord_channel(image: np.ndarray, affine: np.ndarray, axis_row: int = 0) -> np.ndarray:
    """Normalized absolute world coordinate channel for one array axis of a
    raw CBCT image (default ``axis_row=0`` = nibabel's world-X row of the
    affine, i.e. the left-right anatomical axis for this LPS dataset -- see
    module docstring).

    Returns a ``float32`` array the same shape as ``image``. Inside the
    foreground bounding box (nnU-Net's own ``crop_to_nonzero`` region, see
    :func:`bbox_from_mask`), the value at each voxel is that voxel's world
    coordinate (``affine[axis_row, :3] @ [i, j, k] + affine[axis_row, 3]``)
    linearly rescaled so the bounding box's own min/max map to ``[-1, 1]``.
    Outside the bounding box, the value is exactly ``0.0``.

    Why "exactly 0.0 outside the bounding box, not a continuous coordinate
    field everywhere" -- this is not a cosmetic choice, it is required for
    correctness: nnU-Net's ``crop_to_nonzero`` computes ONE shared foreground
    mask across all channels of a case via
    ``nonzero_mask = OR_c(data[c] != 0)`` and then crops every channel
    (including this one) to that mask's bounding box. If this channel were
    nonzero almost everywhere (which any naive "normalized world coordinate"
    field would be -- world coordinates are essentially never exactly zero),
    the OR'd mask would cover nearly the entire volume and nnU-Net's
    foreground crop would collapse to a no-op, silently breaking the
    training/inference pipeline's existing ROI-cropping behavior for every
    case, tooth-side LR-correction included. Zeroing this channel outside
    the *same* bounding box nnU-Net would already compute from channel 0
    alone guarantees the OR'd mask's bounding box is identical to the
    channel-0-only case (this channel's nonzero support is a subset of that
    box by construction), so stacking this channel as ``_0001`` cannot
    change nnU-Net's crop at all -- verified by a direct unit test
    (``test_coord_channel.py::test_stacking_channel_does_not_expand_crop_bbox``),
    not just argued here.
    """
    if image.ndim != 3:
        raise ValueError(f"image must be 3-dimensional, got shape {image.shape}")
    if affine.shape != (4, 4):
        raise ValueError(f"affine must have shape (4, 4), got {affine.shape}")

    mask = nonzero_foreground_mask(image)
    bbox = bbox_from_mask(mask)
    slices = tuple(slice(lo, hi) for lo, hi in bbox)

    shape = image.shape
    ii = np.arange(shape[0], dtype=np.float64)[:, None, None]
    jj = np.arange(shape[1], dtype=np.float64)[None, :, None]
    kk = np.arange(shape[2], dtype=np.float64)[None, None, :]
    row = affine[axis_row, :3]
    world = row[0] * ii + row[1] * jj + row[2] * kk + affine[axis_row, 3]

    region = world[slices]
    lo_val, hi_val = float(region.min()), float(region.max())

    coord = np.zeros(shape, dtype=np.float32)
    if hi_val > lo_val:
        coord[slices] = ((region - lo_val) * (2.0 / (hi_val - lo_val)) - 1.0).astype(np.float32)
    # else: degenerate case (a bounding box that is a single voxel thick
    # along every axis, or an all-background image) -- leave at 0.0 inside
    # the box too, since there is no meaningful range to normalize against.
    return coord


AXIS_ROW_BY_NAME = {"x": 0, "y": 1, "z": 2}


def generate_coord_channel_file(
    image_path: Path,
    output_path: Path,
    axes: str = "x",
) -> Path:
    """Read ``image_path`` (a raw, single-channel ``_0000``-style CBCT
    NIfTI), compute the coordinate channel(s) named in ``axes`` (any subset
    of ``"xyz"``, e.g. ``"x"`` for the single-channel default, ``"xyz"`` for
    the 3-axis ablation), and write the result to ``output_path`` with the
    exact same affine/header as the source image (so nnU-Net's own
    crop/resample pipeline, run once on the whole multi-channel stack, keeps
    every channel in voxel-for-voxel spatial alignment automatically --
    plan.md's "天然保持空间对齐" reasoning for using nnU-Net's native
    ``_0000``/``_0001`` multi-channel convention instead of a bespoke
    side-channel mechanism).

    ``axes="x"`` writes one 3D volume. ``axes="xyz"`` (or any multi-character
    string) writes a 4D volume with one coordinate component per requested
    axis, in the given order -- nibabel/nnU-Net both accept a 4D NIfTI here
    exactly the way a real multi-channel MRI sequence would be stored, but
    this repo's dataset-generation script splits a requested ``"xyz"`` axis
    set into three separate ``_0001``/``_0002``/``_0003`` single-channel
    files instead (nnU-Net's own convention), never a 4D file -- this
    function stays axis-count-agnostic and lets the caller decide.

    IMPORTANT (found by running this against real CBCT data, not a
    hypothetical concern): the output is written with a *fresh* NIfTI
    header, deliberately NOT ``image_nii.header`` reused verbatim. CBCT
    source files in this dataset are stored on disk as ``uint16`` (see
    ``nib.load(...).header.get_data_dtype()``); reusing that header for a
    float coordinate array makes nibabel silently write the float data
    through the header's integer datatype/auto-scaling, quantizing it to
    ~65536 levels AND -- critically -- corrupting the "exactly 0.0 outside
    the foreground bounding box" invariant :func:`compute_coord_channel`'s
    docstring depends on: 0.0 does not survive a uint16 round-trip exactly
    when the auto-computed scale/intercept doesn't happen to hit it (in the
    case that surfaced this, background voxels came back as
    ``1.52587891e-05`` instead of ``0.0``). A background voxel that is
    merely "very close to zero" instead of exactly zero would have been
    picked up by nnU-Net's own ``data != 0`` foreground test and silently
    expanded the crop bounding box -- exactly the failure mode this
    module's docstring already calls out as the reason the "always zero
    outside the bbox" property must hold exactly, not approximately.
    """
    image_nii = nib.load(str(image_path))
    image = np.asanyarray(image_nii.dataobj)
    affine = image_nii.affine

    channels = [compute_coord_channel(image, affine, axis_row=AXIS_ROW_BY_NAME[axis]) for axis in axes]
    if len(channels) == 1:
        out_array = channels[0]
    else:
        out_array = np.stack(channels, axis=-1)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    out_nii = nib.Nifti1Image(out_array.astype(np.float32), affine)
    out_nii.header.set_data_dtype(np.float32)
    nib.save(out_nii, str(output_path))
    return output_path


def coord_channel_paths_for_case(image_path: Path, cache_dir: Path, axes: str = "x") -> list[Path]:
    """Return the list of single-channel coordinate-channel file paths for
    ``image_path`` (one file per axis in ``axes``, nnU-Net's own
    ``_0001``/``_0002``/... convention -- never the 4D-stack form
    :func:`generate_coord_channel_file` also supports), generating and
    caching them under ``cache_dir`` the first time each case is seen.

    This is the glue :func:`stsr2026.evaluation.nnunet_inference.run_batch_inference`'s
    ``extra_channel_paths_fn`` hook expects: a function of one raw case
    image path returning the extra per-case channel files to hand to nnU-Net's
    preprocessor alongside the main image. Caching (skip regeneration if the
    output file already exists) matters because evaluation scripts may be
    re-run repeatedly against the same hold-out set while iterating on other
    parts of the pipeline -- regenerating a coordinate channel is cheap
    per-case, but there is no reason to pay it twice.
    """
    stem = image_path.name.removesuffix(".nii.gz").removesuffix(".nii")
    file_ending = ".nii.gz" if image_path.name.endswith(".nii.gz") else ".nii"
    paths = []
    for channel_index, axis in enumerate(axes, start=1):
        out_path = cache_dir / f"{stem}_{channel_index:04d}{file_ending}"
        if not out_path.is_file():
            generate_coord_channel_file(image_path, out_path, axes=axis)
        paths.append(out_path)
    return paths
