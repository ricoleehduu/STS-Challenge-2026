"""Short-schedule supervised fine-tune trainer for the coordinate-channel
(CoordConv-style) experiment -- see ``stsr2026.training.coord_channel`` and
``stsr2026.training.coord_weight_surgery`` for the "why" and the checkpoint
warm-start mechanics; this module is deliberately the trivial last piece.

Mirrors ``p1_finetune_trainer.py``'s pattern exactly (see that module's
docstring for the reasoning this one reuses verbatim): stock
``nnUNetTrainer`` -- the unmodified Dice+CE deep-supervision loss, the
unmodified data loader/augmentation, no unlabeled-batch branch -- with
exactly one change, a reduced ``self.num_epochs`` so ``PolyLRScheduler`` and
the training loop both see the short budget. Weight initialization comes
from nnU-Net's own ``-pretrained_weights`` CLI flag pointed at the
surgically-expanded checkpoint produced by
``scripts/coord_channel_weight_surgery.py``, not from anything in this
module.

Explicitly NOT ``ssl_trainer.py`` and NOT ``p1_finetune_trainer.py`` reused
directly (even though the class bodies are near-identical): the task this
trainer serves is isolated on purpose -- "does adding a coordinate input
channel reduce left/right confusion" is the only variable being tested here.
Reusing Phase B/C's consistency regularization, inline pseudo-labels, or
P1's offline pseudo-label data mixing would add confounding variables that
make a negative or positive result impossible to attribute cleanly (see the
task brief's explicit instruction to keep this experiment to one variable).
A plain Dice+CE supervised fine-tune on the 30 real labeled cases (2-channel
Dataset004_STSR_Coord) is the entire training recipe.

``num_epochs`` default (50) matches P1's starting point for the same reason
documented there: this is a short first probe to see whether the direction
is worth pursuing at all before committing to a long run, not a tuned
schedule.
"""
from __future__ import annotations

import os

try:  # pragma: no cover - exercised only on a real nnU-Net install
    from nnunetv2.training.nnUNetTrainer.nnUNetTrainer import nnUNetTrainer

    NNUNETV2_AVAILABLE = True
except ImportError:  # pragma: no cover - the expected case in this sandbox
    nnUNetTrainer = object  # type: ignore[assignment,misc]
    NNUNETV2_AVAILABLE = False


#: Default short-schedule epoch budget -- see module docstring.
DEFAULT_COORD_FINETUNE_NUM_EPOCHS = 50

#: Environment variable that overrides the default epoch budget at launch
#: time, e.g. ``STSR_COORD_FINETUNE_NUM_EPOCHS=100 nnUNetv2_train ...``. Read
#: once, in ``__init__``, exactly like ``p1_finetune_trainer.py``'s
#: ``STSR_P1_NUM_EPOCHS``.
_NUM_EPOCHS_ENV_VAR = "STSR_COORD_FINETUNE_NUM_EPOCHS"


def _resolve_num_epochs(default: int = DEFAULT_COORD_FINETUNE_NUM_EPOCHS) -> int:
    raw = os.environ.get(_NUM_EPOCHS_ENV_VAR)
    if raw is None or raw == "":
        return default
    try:
        value = int(raw)
    except ValueError as exc:
        raise ValueError(
            f"{_NUM_EPOCHS_ENV_VAR}={raw!r} is not a valid integer epoch count"
        ) from exc
    if value <= 0:
        raise ValueError(f"{_NUM_EPOCHS_ENV_VAR} must be positive, got {value}")
    return value


if NNUNETV2_AVAILABLE:

    class nnUNetTrainer_STSR_CoordFineTune(nnUNetTrainer):  # type: ignore[misc]
        """Stock nnU-Net supervised trainer with a short, fixed epoch budget.

        Identical in spirit to ``nnUNetTrainer_STSR_P1FineTune``: only
        ``self.num_epochs`` is overridden, everything else (loss,
        augmentation, optimizer, LR schedule shape, deep supervision)
        inherited unmodified. The ``__init__`` signature is copied verbatim
        from ``nnUNetTrainer`` (no ``*args``/``**kwargs``) for the same
        reason documented in ``ssl_trainer.py``/``p1_finetune_trainer.py``:
        nnU-Net's base class introspects
        ``inspect.signature(self.__init__)`` against ``locals()``, which a
        pass-through signature breaks.

        This trainer does not itself do anything special for the 2-channel
        input -- the number of input channels is entirely determined by
        ``dataset_json['channel_names']``/the plans file it's launched
        against (``Dataset004_STSR_Coord``'s 2-channel plans), the same way
        nnU-Net always determines it. The only reason a *new* trainer class
        exists at all (instead of just launching
        ``nnUNetTrainer_STSR_P1FineTune`` against the new dataset) is
        documentation/experiment-tracking clarity in the trainer name
        itself and in ``docs/experiment-log.md``'s Config column -- and so
        this experiment's epoch-budget env var doesn't collide with a
        concurrent P1-style run using the same env var name.
        """

        def __init__(
            self,
            plans: dict,
            configuration: str,
            fold: int,
            dataset_json: dict,
            device: "torch.device" = None,  # type: ignore[name-defined]  # noqa: F821
        ):
            import torch  # local import: only needed when nnunetv2 is present

            if device is None:
                device = torch.device("cuda")
            super().__init__(plans, configuration, fold, dataset_json, device=device)
            self.num_epochs = _resolve_num_epochs()

else:  # pragma: no cover - the expected case in this sandbox
    nnUNetTrainer_STSR_CoordFineTune = None  # type: ignore[assignment,misc]
