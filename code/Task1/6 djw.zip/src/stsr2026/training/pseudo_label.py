"""Confidence- and anatomy-aware pseudo-label filtering for P1 self-training.

The STSR2025 champion (U-Mamba2-SSL, see ``docs/research/02-challenge-review.md``
section "阶段 C") uses one flat rule for all 64 foreground classes: take
``argmax(softmax)``, and if the winning class probability is below 0.75,
relabel the voxel to background/ignore. That note explicitly flags this as
likely too aggressive for the 32 pulp-canal classes, which are thin,
low-confidence-by-nature structures compared to the bulky tooth classes they
sit inside -- a flat threshold suppresses canal pseudo-labels disproportionately.

This module keeps the champion's flat-threshold behaviour for tooth classes
(1-32) but replaces it for canal classes (33-64) with a two-part gate:

1. The same kind of per-voxel confidence threshold (tunable separately from
   teeth, per plan.md 3.2 "牙髓阈值单独调节").
2. A connected-component-count check against a per-FDI-position expected
   canal count range, inspired by the ToothFairy semi-supervised "exactly two
   connected components" pseudo-label selection prior described in
   ``docs/research/04-structure-and-ios-review.md`` ("Connectivity-Based
   Selective Re-training").

CLINICAL PLACEHOLDER WARNING
-----------------------------
``EXPECTED_CANAL_COUNT_RANGE`` below encodes typical root-canal counts per
FDI tooth position from general endodontic literature consensus (e.g. molars
usually have more canals than incisors, mandibular incisors are often
under-counted at 1 canal when a second is present, third molars are highly
variable). These are *not* verified against this challenge's actual label
distribution, and have *not* been reviewed by a dentist or endodontic
literature specific to this dataset. Treat every value as a placeholder that
must be sanity-checked by someone with dental domain knowledge before this
module gates a real D2 pseudo-labeling run. See plan.md section 3.2 for the
tracking note.

FDI CLASS-INDEX MAPPING ASSUMPTION
------------------------------------
``stsr2026.data.convert.nnunet_dataset_json`` currently emits placeholder
label names (``class_1`` .. ``class_64``); the official class-index-to-FDI
mapping has not been published or confirmed anywhere in this repo yet. This
module assumes classes 1-32 are teeth and 33-64 are the matching pulp
canals, both walking the canonical FDI order used in ``FDI_ORDER`` below
(quadrant 1 then 2 then 3 then 4, each quadrant central incisor through
third molar), with canal class ``32 + i`` corresponding to tooth class
``i``. Revisit this mapping the moment the organizers' real ``dataset.json``
or label spec is available -- if the true convention differs, every FDI
lookup in this module will be silently wrong.

SKELETON-LABEL / MORPHOLOGICAL-CLOSING TRADEOFF
--------------------------------------------------
The D0 label audit found canal annotations are effectively 1-voxel-wide
centerlines rather than dense volumetric masks. A single true canal can
therefore appear as more than one connected component just from 1-voxel
gaps in a thin annotation or prediction. ``PseudoLabelConfig.closing_iterations``
optionally bridges such gaps with a morphological closing *before counting
components only* -- the actual accepted voxels written to the output are
always taken from the original (unclosed) prediction, never from voxels
added by the closing step. Turning closing on reduces spurious fragment
counts but risks merging two anatomically distinct, closely spaced canals
(e.g. mesial and distal canals of a molar) into a single counted component,
undercounting real canals. It defaults to off; enable it only after
inspecting real P0 predictions.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from scipy import ndimage

TOOTH_CLASS_MIN = 1
TOOTH_CLASS_MAX = 32
CANAL_CLASS_MIN = 33
CANAL_CLASS_MAX = 64
BACKGROUND_CLASS = 0

FDI_ORDER: tuple[int, ...] = (
    11, 12, 13, 14, 15, 16, 17, 18,
    21, 22, 23, 24, 25, 26, 27, 28,
    31, 32, 33, 34, 35, 36, 37, 38,
    41, 42, 43, 44, 45, 46, 47, 48,
)


class PseudoLabelError(RuntimeError):
    """Raised when pseudo-label filtering inputs violate an invariant."""


@dataclass(frozen=True)
class FDIPosition:
    fdi_number: int
    quadrant: int
    position_in_quadrant: int


def fdi_to_position(fdi_number: int) -> FDIPosition:
    if fdi_number not in FDI_ORDER:
        raise PseudoLabelError(f"not a recognised permanent-dentition FDI number: {fdi_number}")
    return FDIPosition(fdi_number, quadrant=fdi_number // 10, position_in_quadrant=fdi_number % 10)


def is_tooth_class(class_id: int) -> bool:
    return TOOTH_CLASS_MIN <= class_id <= TOOTH_CLASS_MAX


def is_canal_class(class_id: int) -> bool:
    return CANAL_CLASS_MIN <= class_id <= CANAL_CLASS_MAX


def tooth_class_to_fdi(class_id: int) -> int:
    if not is_tooth_class(class_id):
        raise PseudoLabelError(f"class {class_id} is not a tooth class in [{TOOTH_CLASS_MIN}, {TOOTH_CLASS_MAX}]")
    return FDI_ORDER[class_id - TOOTH_CLASS_MIN]


def canal_class_to_fdi(class_id: int) -> int:
    if not is_canal_class(class_id):
        raise PseudoLabelError(f"class {class_id} is not a canal class in [{CANAL_CLASS_MIN}, {CANAL_CLASS_MAX}]")
    return FDI_ORDER[class_id - CANAL_CLASS_MIN]


def corresponding_tooth_class_id(canal_class_id: int) -> int:
    if not is_canal_class(canal_class_id):
        raise PseudoLabelError(f"class {canal_class_id} is not a canal class")
    return canal_class_id - (CANAL_CLASS_MIN - TOOTH_CLASS_MIN)


# TODO(dental-review): placeholder root-canal-count ranges, see module docstring.
EXPECTED_CANAL_COUNT_RANGE: dict[int, tuple[int, int]] = {
    11: (1, 1), 21: (1, 1),  # maxillary central incisor
    12: (1, 1), 22: (1, 1),  # maxillary lateral incisor
    13: (1, 1), 23: (1, 1),  # maxillary canine
    14: (1, 3), 24: (1, 3),  # maxillary 1st premolar (commonly 2)
    15: (1, 2), 25: (1, 2),  # maxillary 2nd premolar
    16: (3, 4), 26: (3, 4),  # maxillary 1st molar (MB1/MB2/DB/P)
    17: (2, 4), 27: (2, 4),  # maxillary 2nd molar
    18: (1, 4), 28: (1, 4),  # maxillary 3rd molar, highly variable
    31: (1, 2), 41: (1, 2),  # mandibular central incisor (2nd canal often missed)
    32: (1, 2), 42: (1, 2),  # mandibular lateral incisor
    33: (1, 2), 43: (1, 2),  # mandibular canine
    34: (1, 2), 44: (1, 2),  # mandibular 1st premolar
    35: (1, 2), 45: (1, 2),  # mandibular 2nd premolar
    36: (3, 4), 46: (3, 4),  # mandibular 1st molar (2 mesial + 1-2 distal)
    37: (2, 4), 47: (2, 4),  # mandibular 2nd molar
    38: (1, 4), 48: (1, 4),  # mandibular 3rd molar, highly variable
}


def expected_canal_count_range(fdi_number: int, table: dict[int, tuple[int, int]]) -> tuple[int, int]:
    if fdi_number not in table:
        raise PseudoLabelError(f"no expected canal count range configured for FDI {fdi_number}")
    return table[fdi_number]


@dataclass(frozen=True)
class PseudoLabelConfig:
    tooth_confidence_threshold: float = 0.75
    canal_confidence_threshold: float = 0.5
    ignore_label: int = 255
    connectivity: int = 3
    closing_iterations: int = 0
    min_component_voxels: int = 2
    instance_overlap_threshold: float = 0.0
    instance_dilation_voxels: int = 1
    expected_canal_counts: dict[int, tuple[int, int]] = field(
        default_factory=lambda: dict(EXPECTED_CANAL_COUNT_RANGE)
    )


@dataclass(frozen=True)
class ComponentDecision:
    class_id: int
    fdi_number: int
    expected_range: tuple[int, int]
    raw_component_count: int
    kept_component_count: int
    accepted: bool
    reason: str
    component_sizes: tuple[int, ...]


def labels_and_confidence_from_probabilities(probabilities: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Split a ``(num_classes, *spatial)`` softmax volume into argmax labels and confidence."""
    if probabilities.ndim < 2:
        raise PseudoLabelError(f"expected a (num_classes, *spatial) array, got shape {probabilities.shape}")
    labels = np.argmax(probabilities, axis=0).astype(np.int64)
    confidence = np.take_along_axis(probabilities, labels[np.newaxis, ...], axis=0)[0]
    return labels, confidence.astype(np.float64, copy=False)


def _label_components(mask: np.ndarray, connectivity: int, closing_iterations: int) -> tuple[np.ndarray, int]:
    structure = ndimage.generate_binary_structure(mask.ndim, connectivity)
    if closing_iterations > 0:
        closed = ndimage.binary_closing(mask, structure=structure, iterations=closing_iterations)
        grouping, _ = ndimage.label(closed, structure=structure)
        component_labels = np.where(mask, grouping, 0)
    else:
        component_labels, _ = ndimage.label(mask, structure=structure)
    raw_count = int(np.unique(component_labels[component_labels > 0]).size)
    return component_labels, raw_count


def _drop_small_components(component_labels: np.ndarray, min_voxels: int) -> np.ndarray:
    if min_voxels <= 1:
        return component_labels
    labels, counts = np.unique(component_labels[component_labels > 0], return_counts=True)
    keep = labels[counts >= min_voxels]
    if keep.size == labels.size:
        return component_labels
    return np.where(np.isin(component_labels, keep), component_labels, 0)


def _drop_low_overlap_components(
    component_labels: np.ndarray,
    teeth_instance_map: np.ndarray,
    tooth_class_id: int,
    threshold: float,
    dilation_voxels: int,
) -> np.ndarray:
    instance_mask = teeth_instance_map == tooth_class_id
    if dilation_voxels > 0:
        structure = ndimage.generate_binary_structure(instance_mask.ndim, 3)
        instance_mask = ndimage.binary_dilation(instance_mask, structure=structure, iterations=dilation_voxels)
    labels, totals = np.unique(component_labels[component_labels > 0], return_counts=True)
    keep = []
    for label, total in zip(labels, totals):
        overlap = np.count_nonzero((component_labels == label) & instance_mask)
        if total > 0 and overlap / total >= threshold:
            keep.append(int(label))
    if len(keep) == labels.size:
        return component_labels
    if not keep:
        return np.zeros_like(component_labels)
    return np.where(np.isin(component_labels, keep), component_labels, 0)


def evaluate_canal_components(
    mask: np.ndarray,
    class_id: int,
    teeth_instance_map: np.ndarray | None,
    config: PseudoLabelConfig,
) -> tuple[ComponentDecision, np.ndarray]:
    """Decide whether a canal class's (already confidence-gated) voxel mask is trustworthy.

    Returns the audit decision plus the boolean mask of voxels that survive
    the size-floor and (optional) instance-overlap component filters --
    independent of the final accept/reject call, so callers can distinguish
    "dropped as noise" voxels from "dropped because the whole class failed
    the component-count prior for this FDI position" voxels.
    """
    fdi_number = canal_class_to_fdi(class_id)
    expected_lo, expected_hi = expected_canal_count_range(fdi_number, config.expected_canal_counts)

    component_labels, raw_count = _label_components(mask, config.connectivity, config.closing_iterations)
    component_labels = _drop_small_components(component_labels, config.min_component_voxels)
    if teeth_instance_map is not None and config.instance_overlap_threshold > 0:
        component_labels = _drop_low_overlap_components(
            component_labels,
            teeth_instance_map,
            corresponding_tooth_class_id(class_id),
            config.instance_overlap_threshold,
            config.instance_dilation_voxels,
        )

    kept_labels, sizes = np.unique(component_labels[component_labels > 0], return_counts=True)
    kept_count = int(kept_labels.size)
    accepted = expected_lo <= kept_count <= expected_hi
    reason = (
        f"kept component count {kept_count} within expected [{expected_lo}, {expected_hi}] for FDI {fdi_number}"
        if accepted
        else f"kept component count {kept_count} outside expected [{expected_lo}, {expected_hi}] for FDI {fdi_number}"
    )
    decision = ComponentDecision(
        class_id=class_id,
        fdi_number=fdi_number,
        expected_range=(expected_lo, expected_hi),
        raw_component_count=raw_count,
        kept_component_count=kept_count,
        accepted=accepted,
        reason=reason,
        component_sizes=tuple(int(s) for s in sizes),
    )
    kept_mask = component_labels > 0
    return decision, kept_mask


@dataclass
class PseudoLabelResult:
    labels: np.ndarray
    canal_decisions: tuple[ComponentDecision, ...]
    accepted_foreground_voxels: int
    ignored_voxels: int


def filter_pseudo_labels(
    class_map: np.ndarray,
    confidence: np.ndarray,
    teeth_instance_map: np.ndarray | None = None,
    config: PseudoLabelConfig = PseudoLabelConfig(),
) -> PseudoLabelResult:
    """Filter one case's argmax pseudo-labels using confidence and (for canals) component priors.

    ``class_map`` is the per-voxel argmax class (0-64), ``confidence`` the
    matching winning-class probability. Tooth classes (1-32) follow the
    champion's flat confidence threshold. Canal classes (33-64) are first
    confidence-gated per voxel with a separately tunable threshold, then the
    surviving voxels for each canal class are accepted or rejected as a
    whole based on their connected-component count against the expected
    range for that FDI position (see ``EXPECTED_CANAL_COUNT_RANGE``).
    Background (class 0) voxels are left untouched, matching the champion
    baseline where a 0 argmax with low confidence is already a no-op.
    ``teeth_instance_map``, if given, is only used for the optional
    instance-overlap component filter (disabled by default via
    ``PseudoLabelConfig.instance_overlap_threshold == 0.0``).
    """
    if class_map.shape != confidence.shape:
        raise PseudoLabelError(f"class_map shape {class_map.shape} != confidence shape {confidence.shape}")
    if teeth_instance_map is not None and teeth_instance_map.shape != class_map.shape:
        raise PseudoLabelError(f"teeth_instance_map shape {teeth_instance_map.shape} != class_map shape {class_map.shape}")

    output = class_map.astype(np.int64, copy=True)

    tooth_low_confidence = (
        (class_map >= TOOTH_CLASS_MIN)
        & (class_map <= TOOTH_CLASS_MAX)
        & (confidence < config.tooth_confidence_threshold)
    )
    output[tooth_low_confidence] = config.ignore_label

    decisions: list[ComponentDecision] = []
    canal_classes = sorted(int(c) for c in np.unique(class_map) if is_canal_class(int(c)))
    for class_id in canal_classes:
        raw_mask = class_map == class_id
        confident_mask = raw_mask & (confidence >= config.canal_confidence_threshold)
        output[raw_mask & ~confident_mask] = config.ignore_label

        decision, kept_mask = evaluate_canal_components(confident_mask, class_id, teeth_instance_map, config)
        decisions.append(decision)
        output[confident_mask & ~kept_mask] = config.ignore_label
        if not decision.accepted:
            output[kept_mask] = config.ignore_label

    ignored_voxels = int(np.count_nonzero(output == config.ignore_label))
    accepted_foreground_voxels = int(np.count_nonzero((output != BACKGROUND_CLASS) & (output != config.ignore_label)))
    return PseudoLabelResult(
        labels=output,
        canal_decisions=tuple(decisions),
        accepted_foreground_voxels=accepted_foreground_voxels,
        ignored_voxels=ignored_voxels,
    )
