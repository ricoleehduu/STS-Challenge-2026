"""Submission validation and challenge runtime interfaces."""

