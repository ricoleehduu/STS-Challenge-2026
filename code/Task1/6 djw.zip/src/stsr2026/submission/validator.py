"""Strict, geometry-aware validation of STSR prediction files."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import nibabel as nib
import numpy as np

from stsr2026.data.audit import find_niftis, nifti_case_id


class SubmissionValidationError(RuntimeError):
    """Raised when a prediction is incompatible with the official input."""


@dataclass(frozen=True)
class PredictionAudit:
    case_id: str
    prediction: str
    non_background_voxels: int
    classes: tuple[int, ...]


def validate_predictions(inputs_dir: Path, predictions_dir: Path) -> list[PredictionAudit]:
    inputs = {nifti_case_id(p): p for p in find_niftis(inputs_dir)}
    predictions = {nifti_case_id(p): p for p in find_niftis(predictions_dir)}
    if not inputs:
        raise SubmissionValidationError("no input cases found")
    if set(inputs) != set(predictions):
        raise SubmissionValidationError(
            f"prediction names differ; missing={sorted(set(inputs) - set(predictions))}, "
            f"extra={sorted(set(predictions) - set(inputs))}"
        )
    results: list[PredictionAudit] = []
    for case_id, input_path in sorted(inputs.items()):
        source, pred = nib.load(str(input_path)), nib.load(str(predictions[case_id]))
        source_data, pred_data = np.asanyarray(source.dataobj), np.asanyarray(pred.dataobj)
        if pred_data.shape != source_data.shape:
            raise SubmissionValidationError(f"{case_id}: prediction shape {pred_data.shape} != {source_data.shape}")
        if not np.allclose(pred.affine, source.affine, atol=1e-4):
            raise SubmissionValidationError(f"{case_id}: prediction affine differs from input")
        if not np.isfinite(pred_data).all() or not np.equal(pred_data, np.rint(pred_data)).all():
            raise SubmissionValidationError(f"{case_id}: prediction must contain finite integer labels")
        classes = np.unique(pred_data.astype(np.int64, copy=False))
        if classes.size and (classes.min() < 0 or classes.max() > 64):
            raise SubmissionValidationError(f"{case_id}: predicted labels outside [0, 64]: {classes.tolist()}")
        results.append(PredictionAudit(case_id, str(predictions[case_id]), int(np.count_nonzero(pred_data)), tuple(map(int, classes))))
    return results


def create_validation_zip(predictions_dir: Path, output_zip: Path, expected_cases: int = 20) -> None:
    files = find_niftis(predictions_dir)
    if len(files) != expected_cases:
        raise SubmissionValidationError(f"expected exactly {expected_cases} predictions, found {len(files)}")
    output_zip.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(output_zip, "w", compression=ZIP_DEFLATED) as archive:
        for path in files:
            archive.write(path, arcname=path.name)
