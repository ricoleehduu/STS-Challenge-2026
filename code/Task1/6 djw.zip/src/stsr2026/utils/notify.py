"""WeChat status notifications via AutoDL's relay API."""
from __future__ import annotations

import os
from dataclasses import dataclass

import requests

NOTIFY_URL = "https://www.autodl.com/api/v1/wechat/message/send"
TOKEN_ENV_VAR = "AUTODL_API_TOKEN"


class NotifyError(RuntimeError):
    """Raised when a WeChat notification cannot be sent."""


@dataclass(frozen=True)
class Notification:
    title: str
    name: str
    content: str


def resolve_token(token: str | None = None) -> str:
    token = token or os.environ.get(TOKEN_ENV_VAR)
    if not token:
        raise NotifyError(f"no token provided and {TOKEN_ENV_VAR} is not set")
    return token


def send_wechat_notification(title: str, name: str, content: str, token: str | None = None) -> dict:
    resolved_token = resolve_token(token)
    notification = Notification(title=title, name=name, content=content)
    response = requests.post(
        NOTIFY_URL,
        json={"title": notification.title, "name": notification.name, "content": notification.content},
        headers={"Authorization": resolved_token},
    )
    if response.status_code != 200:
        raise NotifyError(f"AutoDL notify request failed: HTTP {response.status_code}: {response.text}")
    try:
        return response.json()
    except ValueError as exc:
        raise NotifyError(f"AutoDL notify response was not valid JSON: {response.text}") from exc
