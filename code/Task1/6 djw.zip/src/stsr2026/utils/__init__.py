"""Shared utilities."""

