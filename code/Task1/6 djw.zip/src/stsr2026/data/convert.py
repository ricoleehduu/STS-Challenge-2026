"""Convert STSR raw NIfTI cases into an nnU-Net v2 raw dataset layout.

nnU-Net v2 expects, per training case, a single input channel named
``<case_id>_0000<ext>`` under ``imagesTr/`` and a label map named
``<case_id><ext>`` under ``labelsTr/``, plus a ``dataset.json`` describing
channels, labels, and case count. This module only copies files and writes
that manifest; no resampling or intensity normalization happens here (that
is nnU-Net's own preprocessing stage).
"""
from __future__ import annotations

import json
import shutil
from pathlib import Path

from stsr2026.data.audit import find_niftis, nifti_case_id

NUM_CLASSES = 65  # background + 32 teeth + 32 pulp canals


def _file_ending(path: Path) -> str:
    return ".nii.gz" if path.name.endswith(".nii.gz") else ".nii"


def nnunet_dataset_json(num_training: int, file_ending: str = ".nii.gz") -> dict[str, object]:
    labels = {"background": 0}
    labels.update({f"class_{i}": i for i in range(1, NUM_CLASSES)})
    return {
        "channel_names": {"0": "CBCT"},
        "labels": labels,
        "numTraining": num_training,
        "file_ending": file_ending,
    }


def convert_labeled_dataset(
    images_dir: Path,
    labels_dir: Path,
    output_dir: Path,
    case_ids: list[str] | None = None,
) -> Path:
    """Populate ``output_dir`` with an nnU-Net v2 raw training dataset.

    If ``case_ids`` is given, only those cases are converted (useful for a
    fast single-case smoke test); otherwise every image/label pair found is
    converted.
    """
    images = {nifti_case_id(p): p for p in find_niftis(images_dir)}
    labels = {nifti_case_id(p): p for p in find_niftis(labels_dir)}
    selected = sorted(case_ids) if case_ids is not None else sorted(images)
    missing_images = [c for c in selected if c not in images]
    missing_labels = [c for c in selected if c not in labels]
    if missing_images or missing_labels:
        raise ValueError(f"missing images={missing_images}, missing labels={missing_labels}")

    endings = {_file_ending(images[c]) for c in selected} | {_file_ending(labels[c]) for c in selected}
    if len(endings) > 1:
        raise ValueError(f"mixed NIfTI file endings are not supported: {sorted(endings)}")
    file_ending = endings.pop()

    images_out = output_dir / "imagesTr"
    labels_out = output_dir / "labelsTr"
    images_out.mkdir(parents=True, exist_ok=True)
    labels_out.mkdir(parents=True, exist_ok=True)

    for case_id in selected:
        shutil.copyfile(images[case_id], images_out / f"{case_id}_0000{file_ending}")
        shutil.copyfile(labels[case_id], labels_out / f"{case_id}{file_ending}")

    dataset_json = nnunet_dataset_json(num_training=len(selected), file_ending=file_ending)
    (output_dir / "dataset.json").write_text(json.dumps(dataset_json, indent=2) + "\n")
    return output_dir
