"""Dataset auditing for STSR NIfTI inputs and labels."""

from __future__ import annotations

from collections import Counter
from dataclasses import asdict, dataclass
from pathlib import Path
import nibabel as nib
import numpy as np


class DatasetAuditError(RuntimeError):
    """Raised when an STSR dataset violates a required invariant."""


@dataclass(frozen=True)
class CaseAudit:
    case_id: str
    image: str
    shape: tuple[int, ...]
    spacing: tuple[float, ...]
    orientation: tuple[str, ...]
    intensity_percentiles: tuple[float, float, float, float, float]
    label: str | None = None
    label_values: tuple[int, ...] | None = None
    non_background_voxels: int | None = None


def nifti_case_id(path: Path) -> str:
    """Return a filename stem while preserving names such as ``case_001``."""
    return path.name.removesuffix(".nii.gz").removesuffix(".nii")


def find_niftis(directory: Path) -> list[Path]:
    if not directory.is_dir():
        raise DatasetAuditError(f"directory does not exist: {directory}")
    return sorted(p for p in directory.iterdir() if p.name.endswith((".nii", ".nii.gz")))


def _load(path: Path) -> nib.Nifti1Image:
    try:
        return nib.load(str(path))
    except Exception as exc:  # nibabel's concrete exceptions vary by version
        raise DatasetAuditError(f"cannot read NIfTI file {path}: {exc}") from exc


def audit_case(image_path: Path, label_path: Path | None = None) -> CaseAudit:
    image = _load(image_path)
    data = np.asanyarray(image.dataobj)
    if data.ndim != 3:
        raise DatasetAuditError(f"{image_path}: expected a 3-D image, got shape {data.shape}")
    if not np.isfinite(data).all():
        raise DatasetAuditError(f"{image_path}: image contains NaN or infinity")
    header = image.header
    record = CaseAudit(
        case_id=nifti_case_id(image_path),
        image=str(image_path),
        shape=tuple(int(x) for x in data.shape),
        spacing=tuple(float(x) for x in header.get_zooms()[:3]),
        orientation=tuple(str(x) for x in nib.aff2axcodes(image.affine)),
        intensity_percentiles=tuple(float(x) for x in np.percentile(data, [0, 1, 50, 99, 100])),
    )
    if label_path is None:
        return record
    label = _load(label_path)
    values = np.asanyarray(label.dataobj)
    if values.shape != data.shape:
        raise DatasetAuditError(f"{label_path}: shape {values.shape} differs from {image_path}: {data.shape}")
    if not np.allclose(label.affine, image.affine, atol=1e-4):
        raise DatasetAuditError(f"{label_path}: affine differs from image {image_path}")
    if not np.isfinite(values).all() or not np.equal(values, np.rint(values)).all():
        raise DatasetAuditError(f"{label_path}: labels must be finite integers")
    unique = np.unique(values.astype(np.int64, copy=False))
    if unique.size and (unique.min() < 0 or unique.max() > 64):
        raise DatasetAuditError(f"{label_path}: labels must be in [0, 64], got {unique.tolist()}")
    fields = asdict(record)
    fields.update(
        label=str(label_path),
        label_values=tuple(int(x) for x in unique),
        non_background_voxels=int(np.count_nonzero(values)),
    )
    return CaseAudit(**fields)


def audit_dataset(images_dir: Path, labels_dir: Path | None = None) -> dict[str, object]:
    """Audit matching files and return a JSON-serialisable report."""
    images = find_niftis(images_dir)
    if not images:
        raise DatasetAuditError(f"no NIfTI files found in {images_dir}")
    labels = {nifti_case_id(p): p for p in find_niftis(labels_dir)} if labels_dir else {}
    image_ids = {nifti_case_id(p) for p in images}
    if labels_dir and image_ids != set(labels):
        missing = sorted(image_ids - set(labels))
        extra = sorted(set(labels) - image_ids)
        raise DatasetAuditError(f"image/label case IDs differ; missing labels={missing}, extra labels={extra}")
    cases = [audit_case(path, labels.get(nifti_case_id(path))) for path in images]
    frequency: Counter[int] = Counter()
    for case in cases:
        if case.label:
            arr = np.asanyarray(_load(Path(case.label)).dataobj).astype(np.int64, copy=False)
            frequency.update(dict(zip(*np.unique(arr, return_counts=True))))
    return {
        "num_cases": len(cases),
        "num_labeled_cases": sum(case.label is not None for case in cases),
        "class_voxels": {str(key): int(value) for key, value in sorted(frequency.items())},
        "cases": [asdict(case) for case in cases],
    }
