"""Fixed hold-out split for the P0 supervised baseline.

Stratifies on two proxies available from :mod:`stsr2026.data.audit` case
records: whether the case likely contains metal artifacts (very high
intensity outliers) and whether its dentition looks complete (most of the
64 foreground classes present). This keeps the hold-out set representative
instead of accidentally all-clean or all-edentulous.
"""
from __future__ import annotations

import random

METAL_HU_THRESHOLD = 3000.0
COMPLETE_CLASS_FRACTION = 0.75
NUM_FOREGROUND_CLASSES = 64


def stratify_key(case: dict[str, object]) -> tuple[bool, bool]:
    """Return (has_metal_proxy, is_complete_dentition) for one audited case."""
    percentiles = case["intensity_percentiles"]
    has_metal = float(percentiles[4]) >= METAL_HU_THRESHOLD
    label_values = case.get("label_values") or ()
    n_foreground = max(len(label_values) - 1, 0)
    is_complete = n_foreground >= COMPLETE_CLASS_FRACTION * NUM_FOREGROUND_CLASSES
    return has_metal, is_complete


def build_holdout_split(
    cases: list[dict[str, object]], val_fraction: float = 0.2, seed: int = 42
) -> dict[str, list[str]]:
    """Build a deterministic train/val split stratified by :func:`stratify_key`."""
    if not cases:
        raise ValueError("no cases to split")

    groups: dict[tuple[bool, bool], list[str]] = {}
    for case in cases:
        groups.setdefault(stratify_key(case), []).append(str(case["case_id"]))

    rng = random.Random(seed)
    train: list[str] = []
    val: list[str] = []
    for key in sorted(groups):
        ids = sorted(groups[key])
        rng.shuffle(ids)
        n_val = round(len(ids) * val_fraction)
        val.extend(ids[:n_val])
        train.extend(ids[n_val:])

    if not val:
        val.append(train.pop())
    return {"train": sorted(train), "val": sorted(val)}
