"""Minimal image-domain metal-artifact mitigation for CBCT volumes.

Scope, per ``plan.md`` section 3.3 and ``docs/research/03-mar-review.md``:
MAR is a segmentation-robustness lever, not a second deliverable output, and
the STSR 2026 submission only scores the 65-class mask. Heavier options
(DuDoNet needs raw sinogram/projection data we do not have; ADN's unpaired
image-domain training risks "structural hallucination" on thin pulp-canal
structures; 3D diffusion MAR is expensive) are explicitly out of scope for
this pass. This module implements the simplest defensible baseline from the
MAR literature: detect very-high-HU voxels as a metal mask, dilate to cover
the immediately adjacent streak-affected neighborhood, and fill that region
by nearest-neighbor interpolation from surrounding non-metal voxels followed
by light smoothing ("interpolation + smoothing", the classic linear-
interpolation MAR baseline's image-domain analogue). It is intentionally not
a trained model.

Threshold rationale (see ``plan.md`` D0 findings from the real dataset
audit): artifact-free cases top out at roughly 2600-3900 HU (dense tooth
enamel/bone), while cases with visible metal climb to 8000-13900 HU. The
default threshold of 5000 HU sits well above the artifact-free ceiling and
well below the observed metal floor, but is a tunable parameter, not a
hardcoded assumption -- callers with different scanners/calibrations should
pass their own value.

This module has NOT been validated against downstream segmentation metrics
(Dice/NSD on the metal-artifact subset, apex/root-tip recall, centerline
connectivity) -- see docs/experiment-log.md. Doing so requires a trained
segmentation model to A/B against, which does not exist yet.
"""
from __future__ import annotations

import warnings

import numpy as np
from scipy import ndimage

# Artifact-free cases observed up to ~3900 HU; metal cases observed from
# ~8000 HU (see plan.md D0 audit). 5000 HU leaves margin on both sides.
DEFAULT_METAL_HU_THRESHOLD = 5000.0

# Metal streak artifacts extend beyond the metal itself; a small dilation
# margin covers the immediately adjacent streaked neighborhood without
# eating into unrelated anatomy.
DEFAULT_DILATION_ITERATIONS = 2

# Light smoothing to avoid a blocky nearest-neighbor fill; kept small so it
# does not bleed into anatomy just outside the affected region.
DEFAULT_SMOOTHING_SIGMA = 1.0


def detect_metal_mask(
    volume: np.ndarray,
    hu_threshold: float = DEFAULT_METAL_HU_THRESHOLD,
) -> np.ndarray:
    """Return a boolean mask of voxels above ``hu_threshold``.

    A simple intensity threshold, justified against the real dataset's
    observed HU ranges (see module docstring). Not a learned model.
    """
    if volume.ndim != 3:
        raise ValueError(f"expected a 3-D volume, got shape {volume.shape}")
    return volume > hu_threshold


def _dilate(mask: np.ndarray, iterations: int) -> np.ndarray:
    if iterations <= 0:
        return mask
    return ndimage.binary_dilation(mask, iterations=iterations)


def mitigate_metal_streaks(
    volume: np.ndarray,
    metal_mask: np.ndarray | None = None,
    hu_threshold: float = DEFAULT_METAL_HU_THRESHOLD,
    dilation_iterations: int = DEFAULT_DILATION_ITERATIONS,
    smoothing_sigma: float = DEFAULT_SMOOTHING_SIGMA,
) -> np.ndarray:
    """Fill metal-affected voxels (and their streak neighborhood) by
    nearest-neighbor interpolation from surrounding non-metal voxels, then
    lightly smooth the filled region.

    If ``metal_mask`` is not given it is derived via
    :func:`detect_metal_mask` using ``hu_threshold``. A volume with no
    metal-range voxels is returned unchanged (no-op). Voxels outside the
    dilated affected region are left bit-for-bit untouched.

    This is a no-reference, image-domain heuristic (linear-interpolation-
    style MAR), not a trained restoration model -- see module docstring for
    scope and validation status.
    """
    if volume.ndim != 3:
        raise ValueError(f"expected a 3-D volume, got shape {volume.shape}")

    if metal_mask is None:
        metal_mask = detect_metal_mask(volume, hu_threshold)
    else:
        metal_mask = np.asarray(metal_mask, dtype=bool)
        if metal_mask.shape != volume.shape:
            raise ValueError(f"metal_mask shape {metal_mask.shape} != volume shape {volume.shape}")

    if not metal_mask.any():
        return volume.copy()

    affected = _dilate(metal_mask, dilation_iterations)

    if affected.all():
        warnings.warn(
            "metal-affected region covers the entire volume after dilation; "
            "no non-metal voxels available to interpolate from, returning input unchanged",
            stacklevel=2,
        )
        return volume.copy()

    original_dtype = volume.dtype
    work = volume.astype(np.float32, copy=True)

    # For every affected voxel, find the nearest non-affected voxel and copy
    # its value in -- the image-domain analogue of linear-interpolation MAR.
    _, nearest_indices = ndimage.distance_transform_edt(affected, return_distances=True, return_indices=True)
    nearest_values = work[tuple(nearest_indices)]
    work[affected] = nearest_values[affected]

    if smoothing_sigma > 0:
        smoothed = ndimage.gaussian_filter(work, sigma=smoothing_sigma)
        work[affected] = smoothed[affected]

    if np.issubdtype(original_dtype, np.floating):
        return work.astype(original_dtype, copy=False)
    return np.round(work).astype(original_dtype)
