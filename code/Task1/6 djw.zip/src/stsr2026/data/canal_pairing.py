"""Audit whether each GT canal instance sits inside the tooth its class implies.

WHY THIS EXISTS
---------------
This repo's label convention (``docs/deep-research-report(1)(1).md`` section 1.1,
``training/pseudo_label.py``) is "classes 1-32 are teeth, 33-64 are the
*corresponding* canals", i.e. canal class ``c`` belongs to tooth class ``c-32``.
Root canals are anatomically inside the tooth root, so on ground truth that
correspondence should hold essentially always.

It does not.  Measured over all 30 labeled cases (603 canal instances), canal
``c`` sits inside tooth ``c-32`` only **53.9%** of the time; **43.8%** of the
time it sits inside the *contralateral* tooth instead -- the same slot in the
mirrored quadrant (Q1<->Q2, Q3<->Q4).  The split is per-instance, not a global
offset error, and it is not predictable from the NIfTI affine (all 30 cases are
LPS).  Some cases are clean in one direction (case 001: 1/15 identity; cases
022-030: 100% identity), others are genuinely mixed (case 021: 12/12).

This was confirmed three independent ways, which is why it is stated as fact
rather than as a hypothesis:

  1. index-space bbox containment (603 instances, 1 needed a fallback),
  2. world-space centroid distance (identity cases ~2mm, swapped ~25-30mm),
  3. voxel overlap against the dilated tooth mask -- case 001 gives 0.000
     overlap with the assumed parent and 1.000 with the contralateral tooth
     for 14 of 15 canals; case 028 gives ~1.000/0.000 for all 23.

WHAT IT MEANS FOR MODELING
--------------------------
Every canal-identity fix attempted in this project reduces to "the canal takes
its parent tooth's side" (centroid flip, parent-tooth inheritance x3 across two
people, Hungarian matching, Sinkhorn OT, mirror-remap fusion, CoordConv v1/v2).
Any such rule is bounded above by the IDENTITY rate: **43.3% on the 6-case
holdout**.  The shipped model already labels 72/141 = **51.1%** of holdout canal
instances correctly, so it is *already above* that bound -- which is the
mechanical reason all of those attempts came back net-harmful rather than a
matter of the heuristics being insufficiently clever.

The same bound applies to the deep-research report's top-priority proposal
(section 27, "tooth ROI -> local binary canal network -> backfill as parent
FDI + 32"): the backfill step *is* the tooth-consistent rule, so however good
the local segmentation gets, its instance labels are capped at 43.3% on the
holdout -- below where the current model already is.  See
``docs/research/07-canal-label-convention-inconsistency.md``.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

import numpy as np

from stsr2026.inference.lr_correction import (
    QUADRANT_CLASS_COUNT,
    TOOTH_SWAPPABLE_CLASS_PAIRS,
)
from stsr2026.training.pseudo_label import (
    CANAL_CLASS_MAX,
    CANAL_CLASS_MIN,
    TOOTH_CLASS_MAX,
    TOOTH_CLASS_MIN,
)

#: Minimum fraction of a canal's voxels that must fall inside a tooth's bbox
#: before that tooth is accepted as the containing tooth.  Instances below this
#: are reported as UNMATCHED rather than forced into a verdict.
MIN_CONTAINMENT = 0.5


class Pairing(str, Enum):
    """How a GT canal instance relates to the tooth class its own class implies."""

    IDENTITY = "IDENTITY"      # canal c is inside tooth c-32, as the convention claims
    SWAPPED = "SWAPPED"        # canal c is inside the contralateral tooth
    OTHER = "OTHER"            # inside some third tooth
    UNMATCHED = "UNMATCHED"    # no tooth bbox contains >= MIN_CONTAINMENT of it


@dataclass(frozen=True)
class CanalPairing:
    canal_class: int
    assumed_parent: int
    matched_tooth: int | None
    containment: float
    pairing: Pairing


def mirror_tooth_class(tooth_class: int) -> int:
    """Return the same tooth slot in the contralateral quadrant.

    Derived from ``TOOTH_SWAPPABLE_CLASS_PAIRS`` rather than hardcoded so this
    stays tied to the one place the quadrant layout is defined -- note the
    right/left polarity deliberately flips between the upper and lower pairs
    (see that constant's comment in ``lr_correction.py``).
    """
    if not TOOTH_CLASS_MIN <= tooth_class <= TOOTH_CLASS_MAX:
        raise ValueError(f"{tooth_class} is not a tooth class")
    for a, b in TOOTH_SWAPPABLE_CLASS_PAIRS:
        for lo, hi in ((a, b), (b, a)):
            if lo <= tooth_class < lo + QUADRANT_CLASS_COUNT:
                return hi + (tooth_class - lo)
    raise ValueError(f"no quadrant pair covers tooth class {tooth_class}")


def _bboxes(label_volume: np.ndarray) -> dict[int, tuple[np.ndarray, np.ndarray]]:
    boxes: dict[int, tuple[np.ndarray, np.ndarray]] = {}
    present = set(np.unique(label_volume).tolist())
    for tooth in range(TOOTH_CLASS_MIN, TOOTH_CLASS_MAX + 1):
        if tooth not in present:
            continue
        idx = np.argwhere(label_volume == tooth)
        boxes[tooth] = (idx.min(axis=0), idx.max(axis=0) + 1)
    return boxes


def audit_case(label_volume: np.ndarray) -> list[CanalPairing]:
    """Classify every canal instance in one GT label volume.

    Matching is by fraction of canal voxels inside each tooth's bbox.  bbox
    rather than mask is deliberate: GT tooth masks exclude the pulp cavity, so
    a canal is largely voxel-*disjoint* from its own parent tooth mask while
    still being spatially interior to it.  The bbox proxy was cross-checked
    against dilated-mask overlap on the two extreme cases (see module docstring)
    and agreed on every instance.
    """
    boxes = _bboxes(label_volume)
    present = set(np.unique(label_volume).tolist())
    results: list[CanalPairing] = []

    for canal in range(CANAL_CLASS_MIN, CANAL_CLASS_MAX + 1):
        if canal not in present:
            continue
        idx = np.argwhere(label_volume == canal)
        if idx.size == 0:
            continue

        best_tooth: int | None = None
        best_frac = 0.0
        for tooth, (lo, hi) in boxes.items():
            frac = float(np.all((idx >= lo) & (idx < hi), axis=1).mean())
            if frac > best_frac:
                best_tooth, best_frac = tooth, frac

        assumed = canal - (CANAL_CLASS_MIN - TOOTH_CLASS_MIN)
        if best_tooth is None or best_frac < MIN_CONTAINMENT:
            pairing = Pairing.UNMATCHED
        elif best_tooth == assumed:
            pairing = Pairing.IDENTITY
        elif best_tooth == mirror_tooth_class(assumed):
            pairing = Pairing.SWAPPED
        else:
            pairing = Pairing.OTHER

        results.append(CanalPairing(
            canal_class=canal,
            assumed_parent=assumed,
            matched_tooth=best_tooth if best_frac >= MIN_CONTAINMENT else None,
            containment=best_frac,
            pairing=pairing,
        ))
    return results


def identity_rate(pairings: list[CanalPairing]) -> float:
    """Upper bound on any "canal inherits its parent tooth's identity" rule.

    This is the number that makes parent-tooth canal relabeling a dead end:
    0.433 on the 6-case holdout, versus the shipped model's measured 0.511.
    """
    if not pairings:
        return float("nan")
    n_identity = sum(1 for p in pairings if p.pairing is Pairing.IDENTITY)
    return n_identity / len(pairings)
