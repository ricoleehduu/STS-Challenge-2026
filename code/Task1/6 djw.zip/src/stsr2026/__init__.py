"""STSR 2026 Task 1 pipeline."""

__version__ = "0.1.0"

