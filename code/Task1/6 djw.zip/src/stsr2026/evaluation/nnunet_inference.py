"""Real nnU-Net v2 inference for evaluating a trained checkpoint.

Replaces the need to hand-roll sliding-window inference: nnU-Net v2 ships
its own ``nnUNetPredictor`` (``nnunetv2.inference.predict_from_raw_data``),
which is the officially correct way to run a trained checkpoint -- it
handles sliding-window prediction, mirroring/TTA (off by default here, per
plan.md 3.1 "先禁用 TTA"), and restoring the original image geometry
(affine/spacing/shape) itself. This module is a thin wrapper around it that
follows this repo's existing inference I/O convention (same output
filename as input, see ``stsr2026.inference.predict.run_inference``) and
adds per-case wall-clock/peak-GPU-memory measurement, which plan.md section
6 ("预测审计"/"本地精度指标") requires reporting per checkpoint.

**2026-07-13: stopped calling ``predictor.predict_from_files_sequential``.**
That method only exists from nnunetv2>=2.6.0, which in turn requires
torch>=2.1.2 -- and torch never published an official CUDA 11.3 wheel past
1.12.1 (verified against real PyPI/download.pytorch.org metadata, see
docs/progress.md). The competition's stated Docker target is CUDA 11.3, so
depending on ``predict_from_files_sequential`` made this module impossible
to run under any nnunetv2 version that could actually install against a
real CUDA-11.3 torch wheel. Fix: ``predict_case`` now replicates the
single-case body of ``predict_from_files_sequential``'s loop directly
(extracted from a real nnunetv2 2.8.1 install, see docs/progress.md) using
three lower-level primitives confirmed present in nnunetv2 2.3.1 -- the
newest version still compatible with a real CUDA-11.3 torch wheel --
by downloading its actual sdist and grepping the source:
``configuration_manager.preprocessor_class``,
``predictor.predict_logits_from_preprocessed_data``, and
``nnunetv2.inference.export_prediction.export_prediction_from_logits``.
This removes the hard nnunetv2>=2.6.0 floor while keeping identical
behavior (same primitives nnU-Net's own sequential path uses internally,
just called directly instead of through that wrapper). The GPU-resample fix
below (:func:`_gpu_resample_to_shape`) is unaffected by this change: it
patches ``ConfigurationManager.resampling_fn_probabilities`` at the class
level, and ``export_prediction_from_logits`` (called directly now) reads
that same patched property exactly as it did when invoked indirectly via
``predict_from_files_sequential``.

GPU-DEPENDENT AND UNVERIFIED (mirrors how ``stsr2026.training.ssl_trainer``
documented its own nnUNetTrainer subclass before real-GPU validation --
see ``git log`` for that module's "prep" commits vs. its later "validate
against real nnU-Net internals, fix 2 bugs" follow-up commit).  This
sandbox has no GPU and no working ``nnunetv2``/``torch`` install (see
``pyproject.toml``'s ``training`` extra), so nothing in this module has
ever executed against a real checkpoint. Every ``ASSUMPTION`` comment below
is a specific claim about the ``nnUNetPredictor``/preprocessor API that must
be checked on a real GPU box before trusting this for D1/D2 checkpoint
comparisons -- do not treat any of this as validated. In particular, the
2026-07-12 GPU validation of this module's *previous*
``predict_from_files_sequential``-based ``predict_case`` (bit-exact output,
20.55GB peak VRAM, see docs/progress.md) does NOT carry over to this new
call mechanism -- the goal is identical output via a different internal
code path, and that equivalence has not yet been re-checked on a real
checkpoint/GPU.
"""
from __future__ import annotations

import functools
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Sequence

from stsr2026.data.audit import find_niftis, nifti_case_id

try:  # pragma: no cover - exercised only on a real nnU-Net + torch install
    import torch
    from nnunetv2.inference.export_prediction import export_prediction_from_logits
    from nnunetv2.inference.predict_from_raw_data import nnUNetPredictor
    from nnunetv2.inference.sliding_window_prediction import compute_gaussian
    from nnunetv2.utilities.helpers import empty_cache
    from queue import Queue as _Queue
    from threading import Thread as _Thread
    from tqdm import tqdm as _tqdm

    NNUNETV2_AVAILABLE = True
except ImportError:  # pragma: no cover - the expected case in this sandbox
    torch = None  # type: ignore[assignment]
    export_prediction_from_logits = None  # type: ignore[assignment,misc]
    nnUNetPredictor = None  # type: ignore[assignment,misc]
    compute_gaussian = None  # type: ignore[assignment]
    empty_cache = None  # type: ignore[assignment]
    _Queue = None  # type: ignore[assignment,misc]
    _Thread = None  # type: ignore[assignment,misc]
    _tqdm = None  # type: ignore[assignment,misc]
    NNUNETV2_AVAILABLE = False


DEFAULT_CHECKPOINT_NAME = "checkpoint_final.pth"

# Set at install time by _install_gpu_probability_resampling; read by the class-level
# resampling_fn_probabilities wrapper. Single-process inference, so a module global is fine.
_GPU_RESAMPLE_DEVICE = None


class InferenceError(RuntimeError):
    """Raised when nnU-Net inference can't run (missing install, bad checkpoint dir, ...)."""


def _require_nnunetv2() -> None:
    if not NNUNETV2_AVAILABLE:
        raise InferenceError(
            "nnunetv2/torch are not installed in this environment. On the GPU "
            "box, install the 'training' extra (pip install -e '.[training]') "
            "before running real checkpoint inference; this sandbox intentionally "
            "does not have a working nnunetv2 install (see pyproject.toml)."
        )


def _file_ending(path: Path) -> str:
    return ".nii.gz" if path.name.endswith(".nii.gz") else ".nii"


@dataclass(frozen=True)
class CaseInferenceResult:
    case_id: str
    input_path: str
    output_path: str
    wall_clock_seconds: float
    peak_gpu_memory_bytes: int | None


def load_predictor(
    model_training_output_dir: Path,
    folds: Sequence[int | str] = (0,),
    checkpoint_name: str = DEFAULT_CHECKPOINT_NAME,
    device: "torch.device | None" = None,  # type: ignore[name-defined]
    tile_step_size: float = 0.5,
    use_mirroring: bool = False,
    perform_everything_on_device: bool = True,
    verbose: bool = False,
) -> "nnUNetPredictor":  # type: ignore[name-defined]
    """Build and initialize an ``nnUNetPredictor`` from a trained checkpoint
    folder (an nnU-Net "trainer output" directory, e.g.
    ``.../Dataset002_STSR/nnUNetTrainer_STSR_PhaseC__nnUNetPlansBigMem__3d_fullres/``,
    containing ``fold_<n>/checkpoint_final.pth`` + ``plans.json`` +
    ``dataset.json``).

    ASSUMPTION (unverified, see module docstring): the ``nnUNetPredictor``
    constructor accepts ``tile_step_size``, ``use_gaussian``,
    ``use_mirroring``, ``perform_everything_on_device``, ``device``,
    ``verbose``, ``verbose_preprocessing``, ``allow_tqdm`` as keyword
    arguments, and ``initialize_from_trained_model_folder`` takes
    ``(model_training_output_dir: str, use_folds: Sequence, checkpoint_name:
    str)`` -- matching nnunetv2's public inference API as documented in its
    ``readme``/``predict_from_raw_data.py`` module docstring at the time
    this was written. This constructor/init pair is not the part of the API
    this repo had to work around for CUDA 11.3 compatibility (see module
    docstring) -- only ``predict_case``'s use of
    ``predict_from_files_sequential`` was version-constrained to
    nnunetv2>=2.6.0; the predictor object built here is used across a much
    wider nnunetv2 version range (2.3.1 through 2.8.1 confirmed, see module
    docstring). ``use_mirroring=False`` disables
    TTA/flip-mirroring, matching plan.md 3.1's baseline ("先禁用 TTA");
    flip this on deliberately for a later TTA experiment (plan.md section
    5, P2), not as this function's default.
    """
    _require_nnunetv2()
    device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
    predictor = nnUNetPredictor(
        tile_step_size=tile_step_size,
        use_gaussian=True,
        use_mirroring=use_mirroring,
        perform_everything_on_device=perform_everything_on_device,
        device=device,
        verbose=verbose,
        verbose_preprocessing=False,
        allow_tqdm=False,
    )
    predictor.initialize_from_trained_model_folder(str(model_training_output_dir), folds, checkpoint_name)
    _install_memory_safe_sliding_window(predictor)
    install_skip_unused_seg_resample()
    install_parallel_data_resampling()
    return predictor


def _gpu_resample_to_shape(data, new_shape, current_spacing, new_spacing, *, device, orig_fn, anisotropy_threshold: int = 3):  # type: ignore[no-untyped-def]
    """Drop-in replacement for nnU-Net's ``resampling_fn_probabilities`` that runs
    the interpolation on the GPU instead of CPU scipy.

    Root cause of the eval "hang" (root-caused 2026-07-12, see docs/progress.md): the
    default ``resampling_fn_probabilities`` resamples the full 65-channel logit volume
    back to the original ~512x512x400 grid one channel at a time with scipy on CPU,
    which takes >4 min and ~47GB RAM per case for these large CBCT volumes -- and would
    blow both the 28GB-RAM and 60s-per-case Docker budget (plan.md section 1).

    This is a semantically exact swap, NOT an approximation: nnU-Net configures
    ``resampling_fn_probabilities`` with ``order=1`` (linear) and ``anti_aliasing`` off
    (verified against this dataset's ``plans.json``), so GPU trilinear interpolation
    (``align_corners=False``) computes the same thing, just on the 5090 in seconds.
    Interpolation is done channel-by-channel to bound GPU memory to one channel at a
    time (the assembled full-res output still lives on CPU, where nnU-Net's unchanged
    ``convert_logits_to_segmentation`` argmaxes it). Everything downstream -- argmax,
    crop reversal, transpose, geometry/affine restore, file write -- stays nnU-Net's
    own tested code.

    Falls back to ``orig_fn`` (the original CPU path) if nnU-Net would resample
    separately along an anisotropic z axis, to stay bit-for-bit compatible in that
    branch. This dataset is 0.25/0.30mm near-isotropic (D0 audit), so the fallback is
    not expected to trigger here.
    """
    import numpy as np
    import torch.nn.functional as F

    target = [int(s) for s in new_shape]

    def _is_anisotropic(spacing) -> bool:
        vals = [float(x) for x in spacing]
        lo = min(vals)
        return lo > 0 and (max(vals) / lo) > anisotropy_threshold

    if _is_anisotropic(current_spacing) or _is_anisotropic(new_spacing):
        return orig_fn(data, new_shape, current_spacing, new_spacing)

    src = torch.from_numpy(data) if isinstance(data, np.ndarray) else data
    if list(src.shape[1:]) == target:
        return data

    channels = int(src.shape[0])
    out = torch.empty((channels, *target), dtype=torch.float32)
    with torch.no_grad():
        for c in range(channels):
            patch = src[c : c + 1].unsqueeze(0).to(device=device, dtype=torch.float32)  # [1,1,X,Y,Z]
            resampled = F.interpolate(patch, size=target, mode="trilinear", align_corners=False)
            out[c] = resampled[0, 0].to("cpu")
            del patch, resampled
    if getattr(device, "type", None) == "cuda":
        torch.cuda.empty_cache()
    return out


def _install_gpu_probability_resampling(predictor: "nnUNetPredictor") -> None:  # type: ignore[name-defined]
    """Route ``ConfigurationManager.resampling_fn_probabilities`` through the GPU
    implementation above. Idempotent. See :func:`_gpu_resample_to_shape`.

    ``resampling_fn_probabilities`` is a read-only ``@property`` (no setter), so we
    wrap it at the *class* level: a new property whose getter calls the original
    property to obtain nnU-Net's real ``functools.partial`` (order=1, the exact CPU
    behaviour) and returns a GPU wrapper that falls back to it for the anisotropic
    branch. The prediction device is recorded in a module global at install time
    (inference here is single-process, so this is safe and avoids threading device
    state through a property getter that has no access to the predictor).
    """
    global _GPU_RESAMPLE_DEVICE
    _GPU_RESAMPLE_DEVICE = predictor.device

    from nnunetv2.utilities.plans_handling.plans_handler import ConfigurationManager

    if getattr(ConfigurationManager, "_stsr_gpu_resample_installed", False):
        return
    original_property = ConfigurationManager.resampling_fn_probabilities

    def _fget(self):  # type: ignore[no-untyped-def]
        original_partial = original_property.fget(self)
        return functools.partial(_gpu_resample_to_shape, device=_GPU_RESAMPLE_DEVICE, orig_fn=original_partial)

    ConfigurationManager.resampling_fn_probabilities = property(_fget)  # type: ignore[assignment]
    ConfigurationManager._stsr_gpu_resample_installed = True  # type: ignore[attr-defined]


def _skip_seg_resample(seg, new_shape, current_spacing, new_spacing):  # type: ignore[no-untyped-def]
    """Drop-in replacement for ``resampling_fn_seg`` that skips the real resample
    and returns a small placeholder instead. See :func:`install_skip_unused_seg_resample`
    for why this is safe: every caller of ``DefaultPreprocessor.run_case`` in this
    repo passes ``seg_file=None`` and discards the returned ``seg``.
    """
    import numpy as np

    return np.zeros((int(seg.shape[0]), *[int(s) for s in new_shape]), dtype=seg.dtype)


def install_skip_unused_seg_resample() -> None:
    """Patch ``ConfigurationManager.resampling_fn_seg`` at the class level (idempotent)
    to skip the real resample and return a cheap placeholder instead.

    Root cause this works around (profiled 2026-07-13 on real A10 hardware,
    case_006, see docs/progress.md): ``DefaultPreprocessor.run_case_npy`` calls
    ``configuration_manager.resampling_fn_seg(seg, ...)`` **unconditionally**, even
    when the caller passed ``seg_file=None`` -- ``crop_to_nonzero`` always
    synthesizes a foreground/background bookkeeping mask as ``seg`` regardless of
    whether a real label map was supplied (documented behavior, see
    ``stsr2026.training.unlabeled_data.preprocess_unlabeled_case``'s docstring,
    which discovered this independently). For case_006 this resample (order=1,
    single channel) measured **10.43s** -- about a fifth of the ~48s preprocessing
    total -- computing a value that is thrown away: every call site in this repo
    (``nnunet_inference.predict_case``, ``streaming_export.predict_case_streaming``,
    ``unlabeled_data.preprocess_unlabeled_case``) passes ``seg_file=None`` and
    discards the returned ``seg`` (assigned to ``_seg``, never read). Skipping the
    real computation cannot change ``data`` (the only return value anyone uses) --
    ``resampling_fn_data`` and ``resampling_fn_seg`` are independent calls on
    independent arrays, this only changes the discarded one.

    Safe to install unconditionally, process-wide: every module in this repo that
    triggers real ``nnunetv2`` preprocessing goes through one of the three call
    sites above, all inference/pseudo-label-generation, never training (training
    preprocessing -- real ``nnUNetv2_plan_and_preprocess`` -- runs as nnU-Net's own
    separate CLI process on the GPU boxes, never imports this repo's Python code).
    """
    from nnunetv2.utilities.plans_handling.plans_handler import ConfigurationManager

    if getattr(ConfigurationManager, "_stsr_skip_seg_resample_installed", False):
        return
    ConfigurationManager.resampling_fn_seg = property(lambda self: _skip_seg_resample)  # type: ignore[assignment]
    ConfigurationManager._stsr_skip_seg_resample_installed = True  # type: ignore[attr-defined]


def _cgroup_cpu_quota() -> int | None:
    """Real CPU core quota from the cgroup, NOT ``os.cpu_count()``/``nproc`` (which
    report the physical host's core count even inside a heavily-quota'd container --
    e.g. on an AutoDL rental box, ``os.cpu_count()`` can report 112 while the real
    cgroup v2 quota (``/sys/fs/cgroup/cpu.max``) is 14 -- see docs/progress.md's D2
    efficiency entries). Tries cgroup v2 first, then falls back to cgroup v1's
    ``cpu.cfs_quota_us``/``cpu.cfs_period_us``. Returns ``None`` if no quota is set
    (unlimited) or neither path is readable, so the caller can fall back to
    ``os.cpu_count()`` in that case.
    """
    v2_path = Path("/sys/fs/cgroup/cpu.max")
    try:
        raw = v2_path.read_text().strip()
        quota_str, period_str = raw.split()
        if quota_str != "max":
            quota, period = int(quota_str), int(period_str)
            if period > 0:
                return max(1, quota // period)
    except (OSError, ValueError):
        pass

    try:
        quota = int(Path("/sys/fs/cgroup/cpu/cpu.cfs_quota_us").read_text().strip())
        period = int(Path("/sys/fs/cgroup/cpu/cpu.cfs_period_us").read_text().strip())
        if quota > 0 and period > 0:
            return max(1, quota // period)
    except (OSError, ValueError):
        pass
    return None


def _default_resample_n_threads(max_threads_cap: int = 16) -> int:
    """``min(real cgroup CPU quota, os.cpu_count(), max_threads_cap)``, at least 1.

    Re-derived at call time (never hardcoded to a specific box's measured value) so
    this behaves correctly on a differently-provisioned box -- including the real
    competition Docker container, whose real quota is unknown ahead of time.
    ``max_threads_cap`` guards against over-allocating threads on a much larger box
    than any tested so far (14 vs 16 threads measured within noise of each other on
    the a GPU box dev box used to validate this, see docs/progress.md's D2 entries -- 16
    is a reasonable ceiling, not a precision-tuned value).
    """
    import os

    cgroup_quota = _cgroup_cpu_quota()
    candidates = [c for c in (cgroup_quota, os.cpu_count(), max_threads_cap) if c]
    return max(1, min(candidates)) if candidates else 1


def _parallel_resample_channel(img, new_shape: tuple, order: int, ndi_mode: str, n_threads: int, *, max_chunk_coord_bytes: int = 1 * 1024 * 1024):  # type: ignore[no-untyped-def]
    """Bit-exact parallel reimplementation of ``skimage.transform.resize(img,
    new_shape, order, mode=<skimage mode>, anti_aliasing=False)`` for a single
    channel, i.e. of the ``order=3`` branch of ``scipy.ndimage.zoom(img, zoom,
    order=order, mode=ndi_mode, grid_mode=True)`` that ``skimage.resize`` reduces to
    when ``anti_aliasing=False``. ``ndi_mode`` is the already-translated ndimage mode
    string (e.g. ``'nearest'`` for skimage's ``'edge'`` -- see
    ``skimage.transform._warps._to_ndimage_mode``).

    ``scipy.ndimage.zoom`` with ``order=3`` internally does two separable phases: (1)
    a GLOBAL per-axis IIR B-spline coefficient prefilter over the entire padded array
    -- genuinely cannot be spatially chunked without approximation, so it stays one
    single, unchunked call, exactly nnU-Net's own computation; (2) a LOCAL
    per-output-voxel evaluation of the B-spline coefficients at each output
    coordinate via the public ``scipy.ndimage.map_coordinates(..., prefilter=False)``,
    using nnU-Net's own pixel-center-alignment formula (its ``do_separate_z`` branch
    already uses this identical formula). Because every output voxel is evaluated
    independently from the SAME already-fully-computed shared coefficient array,
    splitting the output coordinate grid into chunks and evaluating each chunk with
    its own ``map_coordinates`` call (its C implementation releases the GIL, so plain
    ``threading.Thread`` workers get near-linear speedup with none of
    multiprocessing's pickling/IPC overhead) is bit-exact BY CONSTRUCTION -- there is
    no cross-chunk boundary effect once the global prefilter is done, no
    overlap-padding/crop-center trick needed. Verified bit-exact
    (``np.array_equal`` True, max abs diff 0.0) against real ``ndi.zoom(...,
    grid_mode=True)`` and the real ``resample_data_or_seg`` reference directly, at
    production scale on real 3090 hardware -- see docs/progress.md's D2 entries.

    To keep peak memory bounded (fixing real-hardware OOM on large cases under memory
    limits, see docs/progress.md's D2 entries), the output grid is chunked along the
    first spatial axis (axis 0) into small sub-ranges, and the coordinate arrays
    (``grids`` and ``coords``) are built per-chunk rather than for the full output
    all at once. Each chunk's ``grids[d]`` for indices start:end is constructed via
    ``np.mgrid[start:end, 0:output_shape[1], 0:output_shape[2]][d]``, which produces
    the identical values (same floating-point sequence, same operand order in the
    coordinate formula) as would slicing the full-array version at the same range,
    so the output is still bit-exact by construction. Concurrent chunks are bounded
    via ``concurrent.futures.ThreadPoolExecutor(max_workers=n_threads)`` so that
    regardless of how many total chunks exist, at most ``n_threads`` chunks' worth of
    per-chunk coordinate memory is live at once, keeping peak memory O(n_threads ×
    chunk_size) rather than O(full output size).

    ``img`` must already be float (``resample_data_or_seg`` always does
    ``data.astype(float, copy=False)`` before calling the resize function -- this
    reimplementation matches that exactly).

    ``max_chunk_coord_bytes`` controls the per-chunk memory budget for the coordinates
    array (default 1 MB -- tuned down from an initial 64MB after a real Docker
    `-m 8G` test on case_006 still peaked at ~8.5GB with 64MB chunks and 8
    concurrent threads on the real target hardware, see docs/progress.md). Later
    real-hardware testing on a larger validation-set case found this specific
    parameter is NOT the bottleneck for larger cases (see docs/progress.md's
    2026-07-15 entry) -- the value is kept conservative but further tuning here
    has diminishing returns; the real remaining bottleneck is the sliding-window
    tile accumulator's VRAM footprint (open issue, see docs/progress.md).
    Chunk depth is automatically calculated to keep a single
    chunk's ``coords`` array within this budget, clamped to the range [1, output_shape[0]].
    """
    from concurrent.futures import ThreadPoolExecutor
    import numpy as np
    from scipy import ndimage as ndi
    from scipy.ndimage._interpolation import _prepad_for_spline_filter

    padded, npad = _prepad_for_spline_filter(img, ndi_mode, 0)
    if order > 1:
        coeffs = ndi.spline_filter(padded, order=order, output=np.float64, mode=ndi_mode)
    else:
        coeffs = padded

    output_shape = tuple(int(s) for s in new_shape)
    zoom_div = np.array(output_shape, dtype=np.float64)
    zoom_nominator = np.array(img.shape, dtype=np.float64)
    zoom_factors = np.divide(zoom_nominator, zoom_div, out=np.ones_like(zoom_nominator), where=zoom_div != 0)

    # Preallocate the final output array once
    output = np.empty(output_shape, dtype=coeffs.dtype)

    # Calculate chunk depth to keep each chunk's coords array within max_chunk_coord_bytes.
    # Each chunk's coords array size: 3 * chunk_depth * output_shape[1] * output_shape[2] * 8 bytes
    bytes_per_row = 3 * output_shape[1] * output_shape[2] * 8
    chunk_depth = max(1, max_chunk_coord_bytes // bytes_per_row) if bytes_per_row > 0 else 1
    chunk_depth = min(chunk_depth, output_shape[0])

    # Build list of (start, end) chunk ranges along axis 0
    chunk_ranges = []
    for start in range(0, output_shape[0], chunk_depth):
        end = min(start + chunk_depth, output_shape[0])
        chunk_ranges.append((start, end))

    n_workers = max(1, min(n_threads, output_shape[0]))

    def process_chunk(start_end_pair):  # type: ignore[no-untyped-def]
        start, end = start_end_pair
        # Build grids for just this chunk's range, preserving the exact formula
        chunk_grids = np.mgrid[start:end, 0:output_shape[1], 0:output_shape[2]].astype(np.float64)
        chunk_coords = np.empty((3, end - start, output_shape[1], output_shape[2]))
        for d in range(3):
            chunk_coords[d] = zoom_factors[d] * (chunk_grids[d] + 0.5) - 0.5 + npad
        # Evaluate map_coordinates for this chunk
        chunk_result = ndi.map_coordinates(coeffs, chunk_coords, order=order, mode=ndi_mode, cval=0, prefilter=False)
        return start, chunk_result

    # Use ThreadPoolExecutor to limit concurrent chunks in flight
    with ThreadPoolExecutor(max_workers=n_workers) as executor:
        for start, chunk_result in executor.map(process_chunk, chunk_ranges):
            end = start + chunk_result.shape[0]
            output[start:end] = chunk_result

    return output


def parallel_resample_data(data, new_shape, order: int, skimage_mode: str, n_threads: int):  # type: ignore[no-untyped-def]
    """Bit-exact parallel drop-in for the non-anisotropic (``do_separate_z=False``)
    branch of ``nnunetv2.preprocessing.resampling.default_resampling.
    resample_data_or_seg`` when ``is_seg=False``: same per-channel loop, same
    ``mode='edge', anti_aliasing=False`` semantics, but each channel's local
    B-spline evaluation is spread across ``n_threads`` threads. ``data`` must be
    ``(C, X, Y, Z)`` (nnU-Net's own convention).
    """
    import numpy as np
    from skimage._shared.utils import _validate_interpolation_order
    from skimage.transform._warps import _clip_warp_output, _to_ndimage_mode

    assert data.ndim == 4, "data must be (c, x, y, z)"
    shape = np.array(data[0].shape)
    new_shape_arr = np.array(new_shape)
    if not np.any(shape != new_shape_arr):
        return data  # exactly mirrors resample_data_or_seg's no-op short circuit

    # dtype_out must be captured from the ORIGINAL (pre-cast) dtype, exactly like
    # resample_data_or_seg does (it sets dtype_out = data.dtype *before* the
    # `data = data.astype(float, copy=False)` line below) -- getting this order
    # backwards silently leaves the output as float64 instead of the real function's
    # float32, which is not bit-exact once compared (values only agree to float32
    # precision, not identical bits).
    dtype_out = data.dtype
    reshaped_final = np.zeros((data.shape[0], *new_shape_arr), dtype=dtype_out)

    data = data.astype(float, copy=False)
    ndi_mode = _to_ndimage_mode(skimage_mode)
    order_v = _validate_interpolation_order(data.dtype, order)
    for c in range(data.shape[0]):
        img = data[c]
        out = _parallel_resample_channel(img, tuple(int(s) for s in new_shape_arr), order_v, ndi_mode, n_threads)
        _clip_warp_output(img, out, skimage_mode, 0, True)
        reshaped_final[c] = out
    return reshaped_final


def _parallel_resample_data_to_shape(  # type: ignore[no-untyped-def]
    data,
    new_shape,
    current_spacing,
    new_spacing,
    *,
    orig_fn,
    is_seg: bool = False,
    order: int = 3,
    order_z: int = 0,
    force_separate_z=None,
    separate_z_anisotropy_threshold: float = 3,
    n_threads: "int | None" = None,
):
    """Drop-in replacement matching ``ConfigurationManager.resampling_fn_data``'s
    call signature (``fn(data, new_shape, current_spacing, new_spacing)``, with the
    rest bound via the real ``functools.partial`` kwargs at install time -- see
    :func:`install_parallel_data_resampling`).

    Falls back to ``orig_fn`` (nnU-Net's real, untouched function) for every branch
    this has not reimplemented/validated: ``is_seg=True`` (this patch only targets
    ``resampling_fn_data``, never ``resampling_fn_seg``, which
    :func:`install_skip_unused_seg_resample` already handles separately), and
    ``do_separate_z=True`` (anisotropic spacing -- not reimplemented; this dataset is
    0.3mm near-isotropic per its real ``plans.json``, so this branch is not expected
    to trigger in production). Both fallbacks are exactly nnU-Net's original code
    path, so they stay bit-exact by definition, just without the speedup.
    """
    from nnunetv2.preprocessing.resampling.default_resampling import determine_do_sep_z_and_axis

    if is_seg:
        return orig_fn(data, new_shape, current_spacing, new_spacing)

    do_separate_z, _axis = determine_do_sep_z_and_axis(
        force_separate_z, current_spacing, new_spacing, separate_z_anisotropy_threshold
    )
    if do_separate_z:
        return orig_fn(data, new_shape, current_spacing, new_spacing)

    if torch is not None and isinstance(data, torch.Tensor):
        data = data.numpy()
    assert data.ndim == 4, "data must be c x y z"

    threads = n_threads if n_threads is not None else _default_resample_n_threads()
    return parallel_resample_data(data, new_shape, order, "edge", threads)


def install_parallel_data_resampling(n_threads: "int | None" = None) -> None:
    """Patch ``ConfigurationManager.resampling_fn_data`` at the class level
    (idempotent) to route through :func:`_parallel_resample_data_to_shape`.

    Mirrors the exact pattern already used for ``resampling_fn_probabilities``
    (:func:`_install_gpu_probability_resampling`) and ``resampling_fn_seg``
    (:func:`install_skip_unused_seg_resample`) in this module: wrap the *class-level*
    property so the getter calls the original property to obtain nnU-Net's real,
    already-bound ``functools.partial`` (used both as the exact-fallback ``orig_fn``
    and as the source of the real ``is_seg``/``order``/``order_z``/
    ``force_separate_z`` kwargs from this dataset's actual ``plans.json`` -- never
    hardcoded here).

    Targets the D2 efficiency bottleneck profiled 2026-07-13 on real A10 hardware
    (see docs/progress.md): ``resampling_fn_data`` (order=3 cubic-spline resample of
    the raw CBCT image) cost 31.5s of the ~37.3s total preprocessing time per case,
    single-threaded -- the single largest remaining D2 cost after
    :func:`install_skip_unused_seg_resample` closed the (unrelated, free) seg-resample
    waste. Real cgroup-quota-derived thread count measured 2.66x speedup (37-38s ->
    ~14s on a 14-vCPU quota box) with bit-exact output vs. the reference on real
    production-scale data -- see docs/progress.md's D2 entries for the full writeup.

    ``n_threads=None`` (default) re-derives the thread count from the real cgroup
    CPU quota at every call (see :func:`_default_resample_n_threads`) rather than
    freezing it at install time, so behavior stays correct even if this process's
    quota can change. Pass an explicit int to override (e.g. for testing).
    """
    from nnunetv2.utilities.plans_handling.plans_handler import ConfigurationManager

    if getattr(ConfigurationManager, "_stsr_parallel_data_resample_installed", False):
        return
    original_property = ConfigurationManager.resampling_fn_data

    def _fget(self):  # type: ignore[no-untyped-def]
        original_partial = original_property.fget(self)
        kwargs = dict(original_partial.keywords)
        return functools.partial(
            _parallel_resample_data_to_shape,
            orig_fn=original_partial,
            n_threads=n_threads,
            **kwargs,
        )

    ConfigurationManager.resampling_fn_data = property(_fget)  # type: ignore[assignment]
    ConfigurationManager._stsr_parallel_data_resample_installed = True  # type: ignore[attr-defined]


def _chunked_tensor_has_inf(tensor: "torch.Tensor", channels_per_chunk: int = 4) -> bool:  # type: ignore[name-defined]
    """``torch.any(torch.isinf(tensor))`` for a ``[C, X, Y, Z]`` tensor, but checking
    ``channels_per_chunk`` channels at a time instead of the whole tensor in one call.

    Root cause this works around (confirmed 2026-07-13 via an instrumented real A10
    run, see docs/progress.md): nnU-Net's own ``_internal_predict_sliding_window_
    return_logits`` -- not our code -- ends with exactly ``if torch.any(torch.isinf(
    predicted_logits)):`` on the full, un-chunked accumulator. For case_006's
    ``(65, 427, 504, 427)`` fp16 accumulator, that single line was caught red-handed
    spiking host RSS from a stable 13.70GB straight to the real kernel OOM-kill point
    (~28.65GB anon-rss, confirmed via ``dmesg``) -- i.e. this diagnostic safety check
    (whose only job is to detect a numerical-overflow edge case from the Gaussian
    ``value_scaling_factor=10`` weighting) was itself responsible for roughly doubling
    peak memory right at the end of sliding-window prediction, before our own
    already-validated streaming export (``stsr2026.inference.streaming_export``) ever
    gets a chance to process the result one channel at a time. Chunking this specific
    check bounds its extra memory to O(``channels_per_chunk``) instead of O(whole
    tensor), with byte-identical semantics: same ``any(isinf(...))`` truth value,
    checked in pieces instead of at once.
    """
    for start in range(0, int(tensor.shape[0]), channels_per_chunk):
        chunk = tensor[start : start + channels_per_chunk]
        if torch.any(torch.isinf(chunk)):
            return True
    return False


def _memory_safe_internal_predict_sliding_window_return_logits(self, data, slicers, do_on_device=True):  # type: ignore[no-untyped-def]
    """Drop-in replacement for ``nnUNetPredictor._internal_predict_sliding_window_
    return_logits``, identical to nnU-Net's real 2.8.1 implementation (same
    producer-thread patch queue, same Gaussian-weighted overlap-add accumulation,
    same final division) with exactly one change: the final inf-check calls
    :func:`_chunked_tensor_has_inf` instead of ``torch.any(torch.isinf(predicted_
    logits))`` on the whole tensor. See that function's docstring for the real-
    hardware root-cause finding this fixes. Installed via
    :func:`_install_memory_safe_sliding_window`.
    """
    predicted_logits = n_predictions = prediction = gaussian = workon = None
    results_device = self.device if do_on_device else torch.device("cpu")

    def producer(d, slh, q):
        for s in slh:
            q.put((torch.clone(d[s][None], memory_format=torch.contiguous_format).to(self.device), s))
        q.put("end")

    try:
        empty_cache(self.device)
        data = data.to(results_device)
        queue = _Queue(maxsize=2)
        t = _Thread(target=producer, args=(data, slicers, queue), daemon=True)
        t.start()

        predicted_logits = torch.zeros(
            (self.label_manager.num_segmentation_heads, *data.shape[1:]), dtype=torch.half, device=results_device
        )
        n_predictions = torch.zeros(data.shape[1:], dtype=torch.half, device=results_device)

        if self.use_gaussian:
            gaussian = compute_gaussian(
                tuple(self.configuration_manager.patch_size), sigma_scale=1.0 / 8, value_scaling_factor=10, device=results_device
            )
        else:
            gaussian = 1

        with _tqdm(desc=None, total=len(slicers), disable=not self.allow_tqdm) as pbar:
            while True:
                item = queue.get()
                if item == "end":
                    queue.task_done()
                    break
                workon, sl = item
                prediction = self._internal_maybe_mirror_and_predict(workon)[0].to(results_device)

                if self.use_gaussian:
                    prediction *= gaussian
                predicted_logits[sl] += prediction
                n_predictions[sl[1:]] += gaussian
                queue.task_done()
                pbar.update()
        queue.join()

        torch.div(predicted_logits, n_predictions, out=predicted_logits)
        if _chunked_tensor_has_inf(predicted_logits):
            raise RuntimeError(
                "Encountered inf in predicted array. Aborting... If this problem persists, "
                "reduce value_scaling_factor in compute_gaussian or increase the dtype of "
                "predicted_logits to fp32"
            )
        return predicted_logits
    except Exception as e:
        del predicted_logits, n_predictions, prediction, gaussian, workon
        empty_cache(self.device)
        empty_cache(results_device)
        raise e


def _install_memory_safe_sliding_window(predictor: "nnUNetPredictor") -> None:  # type: ignore[name-defined]
    """Patch ``nnUNetPredictor._internal_predict_sliding_window_return_logits`` at
    the class level (idempotent) to use :func:`_memory_safe_internal_predict_sliding_
    window_return_logits`. See that function's and :func:`_chunked_tensor_has_inf`'s
    docstrings for why: this is THE fix for the CRITICAL real-hardware OOM crash
    (docs/progress.md, tmp/HANDOFF.md), not a tuning knob -- always installed, no
    opt-out flag (unlike :func:`_install_gpu_probability_resampling`, which trades
    off bit-exactness in an untested anisotropic-spacing branch and so stays
    opt-out-able), since this only changes *how* a diagnostic safety-check is
    computed, never *what* it computes.
    """
    if getattr(nnUNetPredictor, "_stsr_memory_safe_sliding_window_installed", False):
        return
    nnUNetPredictor._internal_predict_sliding_window_return_logits = torch.inference_mode()(
        _memory_safe_internal_predict_sliding_window_return_logits
    )
    nnUNetPredictor._stsr_memory_safe_sliding_window_installed = True  # type: ignore[attr-defined]


def predict_case(
    predictor: "nnUNetPredictor",  # type: ignore[name-defined]
    image_path: Path,
    output_dir: Path,
    *,
    gpu_resample: bool = True,
    extra_channel_paths: Sequence[Path] | None = None,
) -> CaseInferenceResult:
    """Run inference for one raw case, writing ``output_dir/<same filename
    as image_path>`` -- this repo's existing inference I/O convention (see
    ``stsr2026.inference.predict.run_inference``), not nnU-Net's own
    ``_0000`` training-channel-suffix convention (that suffix only matters
    when nnU-Net scans an input *folder* itself; it's irrelevant here since
    we pass explicit file paths).

    Replicates the single-case body of ``nnUNetPredictor.predict_from_files_sequential``'s
    loop directly (see module docstring for why -- that method requires
    nnunetv2>=2.6.0/torch>=2.1.2, which has no real CUDA 11.3 wheel) instead of
    calling it:

    1. ``preprocessor = predictor.configuration_manager.preprocessor_class(verbose=...)``
    2. ``data, _seg, data_properties = preprocessor.run_case([str(image_path)], None, ...)``
       (``seg_from_prev_stage_files`` is always ``None`` here -- this repo never uses
       cascaded/previous-stage segmentations)
    3. ``prediction = predictor.predict_logits_from_preprocessed_data(torch.from_numpy(data)).cpu()``
    4. ``export_prediction_from_logits(prediction, data_properties, ...)`` -- nnU-Net's
       own export function, called directly rather than through the sequential
       wrapper. This still routes through
       ``configuration_manager.resampling_fn_probabilities``, so the
       :func:`_install_gpu_probability_resampling` class-level patch still takes
       effect exactly as it did when invoked indirectly (no change to that fix).

    ASSUMPTION (ports of this module's earlier ``predict_from_files_sequential``-era
    verification, re-checked only at the API level, NOT re-run on a GPU -- see module
    docstring): ``preprocessor_class``, ``predict_logits_from_preprocessed_data``, and
    ``export_prediction_from_logits`` have the signatures used here across both
    nnunetv2 2.3.1 (the newest version with a real CUDA 11.3-compatible torch wheel)
    and 2.8.1 (confirmed by reading real source from both, see docs/progress.md);
    the *sequential loop's per-case behavior* being bit-exact to what this function
    now does inline has NOT been re-verified against a real checkpoint/GPU since this
    refactor -- that is the next required validation step.

    Deliberate simplification vs. ``predict_from_files_sequential``: this no longer
    writes the courtesy ``predict_from_raw_data_args.json``/``dataset.json``/
    ``plans.json`` bookkeeping files nnU-Net's own sequential path drops into
    ``output_dir`` for reproducibility. Checked: nothing in this repo (submission
    validator, evaluation metrics, or their tests) reads those files -- both
    ``stsr2026.submission.validator`` and ``stsr2026.data.audit.find_niftis`` only
    look at ``.nii``/``.nii.gz`` files -- so dropping them is safe and avoids
    reimplementing nnU-Net's own bookkeeping logic for no consumer.

    ``extra_channel_paths`` (default ``None`` -- existing single-channel
    behavior is completely unchanged when omitted): additional per-case
    channel files (e.g. ``_0001``, ``_0002``, ...) to pass to
    ``preprocessor.run_case`` alongside ``image_path``, in order. Added for
    the coordinate-channel experiment
    (``stsr2026.training.coord_channel``/``scripts/evaluate_checkpoint.py``'s
    ``--coord-channel-cache-dir``) -- a checkpoint trained with N input
    channels requires exactly N channel files here, or nnU-Net's own
    preprocessing/network forward pass will raise a shape-mismatch error;
    this function does not itself validate N against the checkpoint (nnU-Net
    does, downstream).
    """
    _require_nnunetv2()
    output_dir.mkdir(parents=True, exist_ok=True)
    case_id = nifti_case_id(image_path)
    output_path = output_dir / f"{case_id}{_file_ending(image_path)}"
    truncated_output = output_dir / case_id

    if gpu_resample:
        _install_gpu_probability_resampling(predictor)

    if torch is not None and torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats()
    start = time.perf_counter()

    channel_paths = [str(image_path)] + [str(p) for p in (extra_channel_paths or [])]
    preprocessor = predictor.configuration_manager.preprocessor_class(verbose=predictor.verbose)
    data, _seg, data_properties = preprocessor.run_case(
        channel_paths, None, predictor.plans_manager, predictor.configuration_manager, predictor.dataset_json
    )
    prediction = predictor.predict_logits_from_preprocessed_data(torch.from_numpy(data)).cpu()
    export_prediction_from_logits(
        prediction,
        data_properties,
        predictor.configuration_manager,
        predictor.plans_manager,
        predictor.dataset_json,
        str(truncated_output),
        save_probabilities=False,
    )
    elapsed = time.perf_counter() - start

    peak_mem: int | None = None
    if torch is not None and torch.cuda.is_available():
        peak_mem = int(torch.cuda.max_memory_allocated())

    if not output_path.is_file():
        raise InferenceError(
            f"export_prediction_from_logits did not produce the expected output file "
            f"{output_path} (ASSUMPTION about its output naming may be wrong -- check "
            "what filename it actually wrote under this nnunetv2 version)."
        )
    return CaseInferenceResult(case_id, str(image_path), str(output_path), elapsed, peak_mem)


def run_batch_inference(
    predictor: "nnUNetPredictor",  # type: ignore[name-defined]
    image_paths: Sequence[Path],
    output_dir: Path,
    *,
    extra_channel_paths_fn: Callable[[Path], Sequence[Path]] | None = None,
) -> list[CaseInferenceResult]:
    """Run :func:`predict_case` for each image, one case at a time (rather
    than a single batched ``predict_from_files`` call over the whole list)
    specifically so each case gets its own wall-clock/peak-memory
    measurement, which plan.md section 6 requires reporting per case (max
    and median runtime, peak VRAM) -- a single batched call would only give
    us a combined total.

    ``extra_channel_paths_fn`` (default ``None`` -- unchanged single-channel
    behavior): if given, called once per ``image_path`` to resolve that
    case's additional channel files, forwarded to :func:`predict_case`'s
    ``extra_channel_paths``. See that function's docstring.
    """
    return [
        predict_case(
            predictor,
            image_path,
            output_dir,
            extra_channel_paths=extra_channel_paths_fn(image_path) if extra_channel_paths_fn else None,
        )
        for image_path in image_paths
    ]


def run_checkpoint_inference(
    model_training_output_dir: Path,
    image_paths: Sequence[Path],
    output_dir: Path,
    folds: Sequence[int | str] = (0,),
    checkpoint_name: str = DEFAULT_CHECKPOINT_NAME,
    device: "torch.device | None" = None,  # type: ignore[name-defined]
    tile_step_size: float = 0.5,
    use_mirroring: bool = False,
    extra_channel_paths_fn: Callable[[Path], Sequence[Path]] | None = None,
) -> list[CaseInferenceResult]:
    """Convenience one-shot: load the predictor once, run every case.

    Used by ``scripts/evaluate_checkpoint.py``. ``extra_channel_paths_fn``:
    see :func:`run_batch_inference`.
    """
    predictor = load_predictor(
        model_training_output_dir,
        folds=folds,
        checkpoint_name=checkpoint_name,
        device=device,
        tile_step_size=tile_step_size,
        use_mirroring=use_mirroring,
    )
    return run_batch_inference(predictor, image_paths, output_dir, extra_channel_paths_fn=extra_channel_paths_fn)


def find_case_images(images_dir: Path, case_ids: Sequence[str] | None = None) -> list[Path]:
    """Resolve the raw image paths to run inference on, optionally
    restricted to ``case_ids`` (the hold-out subset use case). Raises
    :class:`InferenceError` listing any requested case not found, rather
    than silently skipping it.
    """
    images = {nifti_case_id(p): p for p in find_niftis(images_dir)}
    if case_ids is None:
        return [images[c] for c in sorted(images)]
    missing = [c for c in case_ids if c not in images]
    if missing:
        raise InferenceError(f"requested case IDs not found under {images_dir}: {missing}")
    return [images[c] for c in case_ids]
