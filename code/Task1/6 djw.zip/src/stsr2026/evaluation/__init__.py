"""Local accuracy and efficiency evaluation."""

