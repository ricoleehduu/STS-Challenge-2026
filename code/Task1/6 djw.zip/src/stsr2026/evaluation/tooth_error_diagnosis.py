"""Break down the residual tooth-numbering errors that remain after LRfix + cleanup.

WHY THIS EXISTS
---------------
``docs/research/07-canal-label-convention-inconsistency.md`` established that
canal instance identity is capped by a ground-truth label defect (43.3% ceiling
on holdout for any parent-tooth rule, versus the model's existing 51.1%), so no
further canal identity work can pay.  Decomposing ``Dice_Instance`` -- which
averages over present classes, roughly half teeth and half canals -- then puts
the remaining leaderboard gap squarely on the tooth side:

    Dice_Instance ~= (tooth component + canal component) / 2

    ours    : 2 * 0.6774 - 0.4512 = 0.904   (measured tooth component: 0.9077)
    thisxu  : 2 * 0.7525 - ~0.50  ~= 1.00

The identity that reproduces our own measured tooth number to within 0.004 is
what makes the estimate for the leader credible: their teeth are essentially
perfect, ours are at ~0.91, and that ~0.10 is the whole remaining gap.

This module classifies *what kind* of error the residual teeth are, because the
fix differs sharply by category:

  * ``MISLABEL_CONTRALATERAL`` -- LRfix already targets this; leftovers mean
    the midline estimate or the component filter failed on specific cases.
  * ``MISLABEL_ARCH_NEIGHBOR`` -- off-by-one along the arch.  This is what the
    deep-research report's section 15 arch-position DP decoding is designed for,
    and unlike its canal proposal that idea is *not* invalidated: tooth GT is
    self-consistent (verified across all 30 cases).
  * ``MISSING`` / ``PARTIAL`` -- detection or boundary problems, not numbering;
    a numbering fix cannot help these.
  * ``SPURIOUS`` -- predicted tooth labels with no GT counterpart.  These hurt
    IA directly through its ``|GT labels union predicted labels|`` denominator.
  * ``SPLIT`` -- one class predicted as several disconnected components.

Only if ARCH_NEIGHBOR and CONTRALATERAL dominate is a sequence-decoding fix
worth building with the sprint time that remains.
"""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from enum import Enum

import numpy as np
from scipy import ndimage

from stsr2026.data.canal_pairing import mirror_tooth_class
from stsr2026.training.pseudo_label import TOOTH_CLASS_MAX, TOOTH_CLASS_MIN

#: IoU at or above which a GT tooth counts as correctly segmented AND numbered.
#: Matches the official IA metric's own hit threshold (see evaluation/metrics.py).
CORRECT_IOU = 0.5
#: A predicted class must overlap this fraction of a GT tooth to be considered
#: "the class the model put here" when the correct class is missing.
CLAIM_FRACTION = 0.2
#: Components below this many voxels are ignored when counting splits, matching
#: MIN_COMPONENT_VOXELS in inference/lr_correction.py.
MIN_COMPONENT_VOXELS = 5
#: Quadrant width in class ids.
QUADRANT = 8


class ToothError(str, Enum):
    CORRECT = "CORRECT"
    PARTIAL = "PARTIAL"
    MISLABEL_CONTRALATERAL = "MISLABEL_CONTRALATERAL"
    MISLABEL_ARCH_NEIGHBOR = "MISLABEL_ARCH_NEIGHBOR"
    MISLABEL_OTHER = "MISLABEL_OTHER"
    MISSING = "MISSING"


@dataclass(frozen=True)
class ToothFinding:
    gt_class: int
    error: ToothError
    iou_same_class: float
    claimed_by: int | None       # predicted tooth class occupying this GT tooth
    claimed_fraction: float


@dataclass(frozen=True)
class CaseDiagnosis:
    findings: list[ToothFinding]
    spurious_classes: list[int]      # predicted tooth classes absent from GT
    split_classes: dict[int, int]    # predicted class -> component count (>1)


def _same_quadrant(a: int, b: int) -> bool:
    return (a - TOOTH_CLASS_MIN) // QUADRANT == (b - TOOTH_CLASS_MIN) // QUADRANT


def is_arch_neighbor(gt_class: int, pred_class: int) -> bool:
    """True when the predicted class is an adjacent slot in the same quadrant.

    Deliberately quadrant-scoped: classes 8 and 9 are numerically adjacent but
    sit in opposite quadrants (different sides of the midline), so calling them
    arch neighbours would conflate an off-by-one slide with an L/R error.
    """
    return _same_quadrant(gt_class, pred_class) and abs(gt_class - pred_class) == 1


def diagnose_case(prediction: np.ndarray, ground_truth: np.ndarray) -> CaseDiagnosis:
    """Classify every GT tooth in one case, plus spurious and split predictions."""
    if prediction.shape != ground_truth.shape:
        raise ValueError(
            f"shape mismatch: prediction {prediction.shape} vs GT {ground_truth.shape}")

    gt_classes = {
        c for c in np.unique(ground_truth).tolist()
        if TOOTH_CLASS_MIN <= c <= TOOTH_CLASS_MAX
    }
    pred_classes = {
        c for c in np.unique(prediction).tolist()
        if TOOTH_CLASS_MIN <= c <= TOOTH_CLASS_MAX
    }

    findings: list[ToothFinding] = []
    for gt_class in sorted(gt_classes):
        gt_mask = ground_truth == gt_class
        gt_voxels = int(gt_mask.sum())
        same = prediction == gt_class
        union = int((gt_mask | same).sum())
        iou = float((gt_mask & same).sum()) / union if union else 0.0

        # which predicted tooth class actually occupies this GT tooth?
        claimed_by, claimed_fraction = None, 0.0
        occupying = prediction[gt_mask]
        counts = Counter(
            int(c) for c in occupying
            if TOOTH_CLASS_MIN <= int(c) <= TOOTH_CLASS_MAX
        )
        if counts:
            top_class, top_count = counts.most_common(1)[0]
            claimed_by, claimed_fraction = top_class, top_count / max(gt_voxels, 1)

        if iou >= CORRECT_IOU:
            error = ToothError.CORRECT
        elif claimed_by is None or claimed_fraction < CLAIM_FRACTION:
            error = ToothError.MISSING
        elif claimed_by == gt_class:
            error = ToothError.PARTIAL
        elif claimed_by == mirror_tooth_class(gt_class):
            error = ToothError.MISLABEL_CONTRALATERAL
        elif is_arch_neighbor(gt_class, claimed_by):
            error = ToothError.MISLABEL_ARCH_NEIGHBOR
        else:
            error = ToothError.MISLABEL_OTHER

        findings.append(ToothFinding(
            gt_class=gt_class, error=error, iou_same_class=iou,
            claimed_by=claimed_by, claimed_fraction=claimed_fraction,
        ))

    split_classes: dict[int, int] = {}
    for pred_class in sorted(pred_classes):
        labelled, count = ndimage.label(prediction == pred_class)
        if count <= 1:
            continue
        sizes = ndimage.sum(np.ones_like(labelled), labelled, range(1, count + 1))
        big = int((np.asarray(sizes) >= MIN_COMPONENT_VOXELS).sum())
        if big > 1:
            split_classes[pred_class] = big

    return CaseDiagnosis(
        findings=findings,
        spurious_classes=sorted(pred_classes - gt_classes),
        split_classes=split_classes,
    )


def summarize(diagnoses: dict[str, CaseDiagnosis]) -> Counter:
    """Aggregate error categories across cases, plus spurious/split totals."""
    total: Counter = Counter()
    for diagnosis in diagnoses.values():
        total.update(f.error.value for f in diagnosis.findings)
        total["SPURIOUS"] += len(diagnosis.spurious_classes)
        total["SPLIT"] += len(diagnosis.split_classes)
    return total
