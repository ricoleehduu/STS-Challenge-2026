"""Local accuracy metrics wrapping the vendored official STSR-2025 scorer.

``plan.md`` section 0 flagged local metrics as the actual sprint bottleneck:
four GPUs are producing checkpoints (P0 / Line A phase B / phase C) with no
code able to numerically compare them. The metric *definitions* themselves
are no longer a guessing game -- ``third_party/stsr_official_eval/`` vendors
the organizers' real ``compute_metrics.py`` + ``SurfaceDice.py`` (see that
directory's ``README.md``). This module must not reimplement that metric
math; it imports the vendored functions directly and re-runs the *same*
per-label loop the official script runs, just partitioned into the
tooth (class 1-32) / canal (class 33-64) groups plan.md section 4/5
requires reporting separately (grounded in
``docs/research/02-challenge-review.md``'s finding that the champion's
tooth Dice_Image 0.8701 and canal Dice_Image 0.6409 differ by 0.23, and
image-level 0.9176 vs instance-level 0.6668 differ by 0.25 -- neither gap
may be hidden behind a single averaged number).

Class-range constants (``TOOTH_CLASS_MIN/MAX``, ``CANAL_CLASS_MIN/MAX``) are
imported from ``stsr2026.training.pseudo_label`` rather than redefined here
-- see that module's "FDI CLASS-INDEX MAPPING ASSUMPTION" docstring section
for the caveat that this mapping is this repo's own convention pending an
official label spec, which applies equally to every tooth/canal split this
module produces.

KNOWN HAZARD, found while writing this module: the official script's own
CLI/``evaluate()`` entrypoint matches prediction and ground-truth files by
``filename.split('_')[-2]`` (a documented "loose fallback", per
``third_party/stsr_official_eval/README.md``) -- for this repo's real STSR
filenames (e.g. ``STS26_Train-Labeled_001.nii.gz``,
``STS26_Validation_001_with-artifacts.nii.gz``) this key is *not*
case-unique (every ``STS26_Train-Labeled_*`` file parses to the same key,
``"Train-Labeled"``), so invoking the official script's own file-matching
over a real multi-case directory silently collapses multiple hold-out
cases down to whichever file a given key last resolves to during
``os.listdir()`` iteration -- most cases would be dropped without any
error. Verified interactively; see this module's tests. Consequently:

- :func:`evaluate_predictions` (the real per-case, per-class-split scoring
  path used by ``scripts/evaluate_checkpoint.py``) never uses the official
  script's ``create_file_map``/``evaluate()``; it matches files by exact
  stem via ``stsr2026.data.audit.nifti_case_id``, the same convention
  already enforced by ``stsr2026.submission.validator``.
- :func:`run_official_scorer` (a subprocess cross-check against the
  *unmodified* official CLI, for comparing this module's aggregate numbers
  against an untouched reference run) refuses to run over more than one
  case unless every candidate filename's ``split('_')[-2]`` token is
  already unique across the case set -- otherwise it raises rather than
  silently scoring a collapsed subset.
"""
from __future__ import annotations

import importlib
import json
import os
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType
from typing import Sequence

import numpy as np
import SimpleITK as sitk

from stsr2026.data.audit import find_niftis, nifti_case_id
from stsr2026.training.pseudo_label import (
    CANAL_CLASS_MAX,
    CANAL_CLASS_MIN,
    TOOTH_CLASS_MAX,
    TOOTH_CLASS_MIN,
)


class EvaluationError(RuntimeError):
    """Raised when the official scorer can't be loaded/run, or inputs are invalid."""


# ---------------------------------------------------------------------------
# Loading the vendored official module.
# ---------------------------------------------------------------------------

_OFFICIAL_MODULE_CACHE: dict[str, ModuleType] = {}


def _default_official_eval_dir() -> Path:
    env = os.environ.get("STSR_OFFICIAL_EVAL_DIR")
    if env:
        return Path(env)
    # src/stsr2026/evaluation/metrics.py -> repo root is 3 parents up.
    return Path(__file__).resolve().parents[3] / "third_party" / "stsr_official_eval"


def _ensure_numpy_legacy_aliases() -> None:
    """Restore numpy<2.0's ``np.NaN``/``np.Inf`` aliases if the installed
    numpy doesn't have them.

    REAL BUG, reproduced (not a guessed risk): the vendored
    ``third_party/stsr_official_eval/SurfaceDice.py`` uses ``np.NaN``
    (in ``compute_dice_coefficient``/``compute_iou_score`` -- hit whenever
    a class is absent from both ground truth and prediction, which is an
    entirely normal case here given per-case missing teeth, see the D0
    dataset audit in plan.md) and ``np.Inf`` (in
    ``compute_surface_distances``'s empty-border fallback). Both aliases
    were removed in NumPy 2.0. This repo's ``pyproject.toml`` pins
    ``numpy>=1.26`` with no upper bound, so a fresh install resolves
    numpy>=2.0 (confirmed: this sandbox's venv installed 2.5.1) and the
    official script crashes with ``AttributeError`` the first time a
    genuinely empty class mask is scored -- reproduced by this module's own
    test suite before this fix (``test_compute_case_scores_perfect_match_and_nan_canal``).

    Per ``third_party/stsr_official_eval/README.md`` ("leave these as an
    unmodified, diffable reference to the official source"), the fix lives
    here instead of editing the vendored file: restore the removed aliases
    on the ``numpy`` module before importing ``compute_metrics``/
    ``SurfaceDice``. This is semantically a no-op either way -- ``np.NaN``
    was always exactly ``np.nan`` and ``np.Inf`` always exactly ``np.inf``,
    so this changes no computed value, only whether the attribute lookup
    succeeds.
    """
    if not hasattr(np, "NaN"):
        np.NaN = np.nan  # type: ignore[attr-defined]
    if not hasattr(np, "Inf"):
        np.Inf = np.inf  # type: ignore[attr-defined]


def load_official_compute_metrics(official_eval_dir: Path | None = None) -> ModuleType:
    """Import the vendored ``compute_metrics.py`` as a module and return it.

    Verified import-safe by reading the file: every module-level statement
    is an import, the ``NSD_TOLERANCE_MM`` constant, or a ``def`` -- the
    only side-effecting code (argparse, calling ``evaluate()``) lives
    inside ``if __name__ == '__main__':``, so importing this module runs
    nothing beyond defining functions.

    ``compute_metrics.py`` itself does ``from SurfaceDice import ...`` as a
    flat, non-package top-level import, so its directory must be on
    ``sys.path`` first. This function adds it (once, cached) rather than
    editing the vendored file in place, per that directory's ``README.md``
    ("leave these as an unmodified, diffable reference to the official
    source").
    """
    _ensure_numpy_legacy_aliases()
    directory = official_eval_dir or _default_official_eval_dir()
    script = directory / "compute_metrics.py"
    if not script.is_file():
        raise EvaluationError(f"official eval script not found under {directory}")
    key = str(directory)
    if key not in _OFFICIAL_MODULE_CACHE:
        if key not in sys.path:
            sys.path.insert(0, key)
        _OFFICIAL_MODULE_CACHE[key] = importlib.import_module("compute_metrics")
    return _OFFICIAL_MODULE_CACHE[key]


# ---------------------------------------------------------------------------
# Per-case, per-label scoring (reuses the official module's own metric math).
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class LabelScore:
    """One class label's Dice/IoU/NSD for one case (official "instance" == class label)."""

    label: int
    dice: float
    iou: float
    nsd: float
    matched: bool  # official IA criterion: iou >= 0.5


@dataclass(frozen=True)
class CaseScores:
    case_id: str
    tooth_dice_image: float
    tooth_iou_image: float
    tooth_nsd_image: float
    canal_dice_image: float
    canal_iou_image: float
    canal_nsd_image: float
    overall_dice_image: float
    overall_iou_image: float
    overall_nsd_image: float
    ia: float
    label_scores: tuple[LabelScore, ...]

    def tooth_label_scores(self) -> tuple[LabelScore, ...]:
        return tuple(ls for ls in self.label_scores if TOOTH_CLASS_MIN <= ls.label <= TOOTH_CLASS_MAX)

    def canal_label_scores(self) -> tuple[LabelScore, ...]:
        return tuple(ls for ls in self.label_scores if CANAL_CLASS_MIN <= ls.label <= CANAL_CLASS_MAX)


def _binary_group_scores(
    gt_mask: np.ndarray, pred_mask: np.ndarray, spacing_zyx: Sequence[float], official: ModuleType
) -> tuple[float, float, float]:
    """Dice/IoU/NSD for one binary mask pair, via the official module's own
    functions -- exactly the per-metric calls ``evaluate()`` makes for its
    whole-volume ``gt_np > 0`` mask, just applied to a restricted mask here
    (tooth-only, canal-only, or overall). Dice can come back NaN (official
    ``compute_dice_coefficient`` semantics: both masks empty); IoU/NSD never
    do (official's ``calculate_iou``/``calculate_nsd_robust`` return 1.0 for
    both-empty, 0.0 for exactly-one-empty). NaN is preserved here and only
    resolved at aggregation time by the official ``robust_mean``, matching
    how the official script itself defers NaN-handling to aggregation.
    """
    dice = float(official.compute_dice_coefficient(gt_mask, pred_mask))
    iou = float(official.calculate_iou(gt_mask, pred_mask))
    nsd = float(official.calculate_nsd_robust(gt_mask, pred_mask, spacing_zyx, official.NSD_TOLERANCE_MM))
    return dice, iou, nsd


def compute_case_scores(gt_path: Path, pred_path: Path, official: ModuleType | None = None) -> CaseScores:
    """Score one prediction against its ground truth, official-script-exact.

    Replicates ``compute_metrics.py``'s ``evaluate()`` inner per-case loop
    (same resampling-if-grid-mismatch step, same image-level and per-label
    instance-level metric calls) but keeps every intermediate value instead
    of immediately flattening into the official script's global lists, so
    tooth/canal partitioning can happen afterwards without touching the
    metric math itself.
    """
    official = official or load_official_compute_metrics()
    case_id = nifti_case_id(gt_path)

    gt_itk = sitk.ReadImage(str(gt_path))
    pred_itk = sitk.ReadImage(str(pred_path))
    if gt_itk.GetSize() != pred_itk.GetSize() or gt_itk.GetSpacing() != pred_itk.GetSpacing():
        pred_itk = official.resample_to_reference_grid(pred_itk, gt_itk)

    gt_np = sitk.GetArrayFromImage(gt_itk).astype(np.int64, copy=False)
    pred_np = sitk.GetArrayFromImage(pred_itk).astype(np.int64, copy=False)
    spacing_zyx = list(reversed(gt_itk.GetSpacing()))

    tooth_dice, tooth_iou, tooth_nsd = _binary_group_scores(
        (gt_np >= TOOTH_CLASS_MIN) & (gt_np <= TOOTH_CLASS_MAX),
        (pred_np >= TOOTH_CLASS_MIN) & (pred_np <= TOOTH_CLASS_MAX),
        spacing_zyx,
        official,
    )
    canal_dice, canal_iou, canal_nsd = _binary_group_scores(
        (gt_np >= CANAL_CLASS_MIN) & (gt_np <= CANAL_CLASS_MAX),
        (pred_np >= CANAL_CLASS_MIN) & (pred_np <= CANAL_CLASS_MAX),
        spacing_zyx,
        official,
    )
    overall_dice, overall_iou, overall_nsd = _binary_group_scores(gt_np > 0, pred_np > 0, spacing_zyx, official)

    gt_labels = np.unique(gt_np[gt_np > 0])
    pred_labels = np.unique(pred_np[pred_np > 0])
    label_scores: list[LabelScore] = []
    num_matched = 0
    for label_id in gt_labels:
        gt_mask = gt_np == label_id
        pred_mask = pred_np == label_id
        dice = float(official.compute_dice_coefficient(gt_mask, pred_mask))
        iou = float(official.calculate_iou(gt_mask, pred_mask))
        nsd = float(official.calculate_nsd_robust(gt_mask, pred_mask, spacing_zyx, official.NSD_TOLERANCE_MM))
        matched = iou >= 0.5
        num_matched += int(matched)
        label_scores.append(LabelScore(int(label_id), dice, iou, nsd, matched))

    union_label_count = len(set(gt_labels.tolist()) | set(pred_labels.tolist()))
    ia = 1.0 if union_label_count == 0 else num_matched / union_label_count

    return CaseScores(
        case_id=case_id,
        tooth_dice_image=tooth_dice,
        tooth_iou_image=tooth_iou,
        tooth_nsd_image=tooth_nsd,
        canal_dice_image=canal_dice,
        canal_iou_image=canal_iou,
        canal_nsd_image=canal_nsd,
        overall_dice_image=overall_dice,
        overall_iou_image=overall_iou,
        overall_nsd_image=overall_nsd,
        ia=ia,
        label_scores=tuple(label_scores),
    )


# ---------------------------------------------------------------------------
# File matching (this repo's own exact-stem convention, NOT the official
# script's collision-prone split('_')[-2] fallback -- see module docstring).
# ---------------------------------------------------------------------------


def match_cases(
    predictions_dir: Path, groundtruth_dir: Path, case_ids: Sequence[str] | None = None
) -> dict[str, tuple[Path, Path]]:
    """Pair up ground-truth/prediction files by exact filename stem.

    If ``case_ids`` is given, only those cases are required/returned (the
    hold-out subset use case); otherwise every ground-truth case must have
    a matching prediction. Raises :class:`EvaluationError` listing any
    missing case rather than silently skipping or mismatching cases.
    """
    gt_files = {nifti_case_id(p): p for p in find_niftis(groundtruth_dir)}
    pred_files = {nifti_case_id(p): p for p in find_niftis(predictions_dir)}
    selected = sorted(case_ids) if case_ids is not None else sorted(gt_files)
    if not selected:
        raise EvaluationError("no cases to evaluate")
    missing_gt = [c for c in selected if c not in gt_files]
    missing_pred = [c for c in selected if c not in pred_files]
    if missing_gt or missing_pred:
        raise EvaluationError(
            f"case ID mismatch between {groundtruth_dir} and {predictions_dir}: "
            f"missing_ground_truth={missing_gt}, missing_predictions={missing_pred}"
        )
    return {c: (gt_files[c], pred_files[c]) for c in selected}


# ---------------------------------------------------------------------------
# Aggregation across cases.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class EvaluationSummary:
    """Aggregate scores over a case set, tooth/canal and image/instance kept apart.

    Field naming maps directly onto ``docs/experiment-log.md``'s columns:
    ``*_dice_image`` -> "Dice_Image (tooth/canal)", ``*_dice_instance`` ->
    "Dice_Instance (tooth/canal)", ``*_nsd_instance`` -> "NSD (tooth/canal)"
    (NSD is reported at the instance/per-class level per plan.md section 5's
    column list, not image-level, though both are computed and available
    here), ``ia`` -> "IA", ``miou`` -> "mIoU".

    ``miou`` ASSUMPTION: plan.md's experiment-log column list has a single
    unsplit "mIoU" column (no tooth/canal variant, unlike every accuracy
    metric next to it). Defined here as the mean per-label IoU across *all*
    64 classes pooled together -- i.e. numerically identical to what the
    unmodified official script would report as its overall ``IoU_Instance``
    aggregate (see ``third_party/stsr_official_eval/compute_metrics.py``).
    This is a documented interpretation of an underspecified column, not a
    confirmed convention -- revisit if the actual leaderboard/organizers
    define "mIoU" differently (plan.md section 8, question 2).
    """

    num_cases: int
    tooth_dice_image: float
    canal_dice_image: float
    overall_dice_image: float
    tooth_iou_image: float
    canal_iou_image: float
    overall_iou_image: float
    tooth_nsd_image: float
    canal_nsd_image: float
    overall_nsd_image: float
    tooth_dice_instance: float
    canal_dice_instance: float
    tooth_iou_instance: float
    canal_iou_instance: float
    tooth_nsd_instance: float
    canal_nsd_instance: float
    ia: float
    miou: float
    cases: tuple[CaseScores, ...]

    def to_json_dict(self) -> dict[str, object]:
        return {
            "num_cases": self.num_cases,
            "tooth_dice_image": self.tooth_dice_image,
            "canal_dice_image": self.canal_dice_image,
            "overall_dice_image": self.overall_dice_image,
            "tooth_iou_image": self.tooth_iou_image,
            "canal_iou_image": self.canal_iou_image,
            "overall_iou_image": self.overall_iou_image,
            "tooth_nsd_image": self.tooth_nsd_image,
            "canal_nsd_image": self.canal_nsd_image,
            "overall_nsd_image": self.overall_nsd_image,
            "tooth_dice_instance": self.tooth_dice_instance,
            "canal_dice_instance": self.canal_dice_instance,
            "tooth_iou_instance": self.tooth_iou_instance,
            "canal_iou_instance": self.canal_iou_instance,
            "tooth_nsd_instance": self.tooth_nsd_instance,
            "canal_nsd_instance": self.canal_nsd_instance,
            "ia": self.ia,
            "miou": self.miou,
            "case_ids": [c.case_id for c in self.cases],
        }


def aggregate_case_scores(cases: Sequence[CaseScores], official: ModuleType | None = None) -> EvaluationSummary:
    """Aggregate per-case scores using the official script's own ``robust_mean``
    (mean over non-NaN values, 0.0 if every value is NaN) -- the same
    aggregation semantics ``evaluate()`` applies to its own flat lists,
    applied here to each tooth/canal/overall group and to labels pooled
    across the whole case set.
    """
    if not cases:
        raise EvaluationError("no case scores to aggregate")
    official = official or load_official_compute_metrics()
    mean = official.robust_mean

    tooth_labels = [ls for c in cases for ls in c.tooth_label_scores()]
    canal_labels = [ls for c in cases for ls in c.canal_label_scores()]
    all_labels = [ls for c in cases for ls in c.label_scores]

    return EvaluationSummary(
        num_cases=len(cases),
        tooth_dice_image=mean([c.tooth_dice_image for c in cases]),
        canal_dice_image=mean([c.canal_dice_image for c in cases]),
        overall_dice_image=mean([c.overall_dice_image for c in cases]),
        tooth_iou_image=mean([c.tooth_iou_image for c in cases]),
        canal_iou_image=mean([c.canal_iou_image for c in cases]),
        overall_iou_image=mean([c.overall_iou_image for c in cases]),
        tooth_nsd_image=mean([c.tooth_nsd_image for c in cases]),
        canal_nsd_image=mean([c.canal_nsd_image for c in cases]),
        overall_nsd_image=mean([c.overall_nsd_image for c in cases]),
        tooth_dice_instance=mean([ls.dice for ls in tooth_labels]),
        canal_dice_instance=mean([ls.dice for ls in canal_labels]),
        tooth_iou_instance=mean([ls.iou for ls in tooth_labels]),
        canal_iou_instance=mean([ls.iou for ls in canal_labels]),
        tooth_nsd_instance=mean([ls.nsd for ls in tooth_labels]),
        canal_nsd_instance=mean([ls.nsd for ls in canal_labels]),
        ia=mean([c.ia for c in cases]),
        miou=mean([ls.iou for ls in all_labels]),
        cases=tuple(cases),
    )


def evaluate_predictions(
    predictions_dir: Path,
    groundtruth_dir: Path,
    case_ids: Sequence[str] | None = None,
    official_eval_dir: Path | None = None,
) -> EvaluationSummary:
    """End-to-end: match cases, score each, aggregate. The main entry point
    used by ``scripts/evaluate_checkpoint.py``.
    """
    official = load_official_compute_metrics(official_eval_dir)
    matched = match_cases(predictions_dir, groundtruth_dir, case_ids)
    cases = [compute_case_scores(gt, pred, official) for gt, pred in matched.values()]
    return aggregate_case_scores(cases, official)


# ---------------------------------------------------------------------------
# Optional cross-check: run the unmodified official CLI via subprocess.
# ---------------------------------------------------------------------------


def run_official_scorer(
    predictions_dir: Path,
    groundtruth_dir: Path,
    output_json: Path,
    official_eval_dir: Path | None = None,
) -> dict[str, float]:
    """Run the vendored, unmodified ``compute_metrics.py`` via subprocess
    and return its parsed ``scores.json`` -- a cross-check against a
    completely untouched copy of the official scorer, independent of any
    logic in this module.

    Refuses to run (raises :class:`EvaluationError`) if the official
    script's own ``filename.split('_')[-2]`` case-matching would collide
    two or more of the given ground-truth filenames onto the same key --
    see this module's docstring for why that happens with real STSR
    filenames and why silently proceeding would drop cases from the score
    without any error from the official script itself.

    Runs the official ``evaluate()`` function via ``python -c`` rather than
    ``python compute_metrics.py`` as a plain script: this still executes
    the identical, unmodified official function (argparse is bypassed, not
    the logic it drives), but lets us apply :func:`_ensure_numpy_legacy_aliases`
    in the child process first -- a plain script invocation would hit the
    same ``np.NaN``/``np.Inf`` crash documented on that function, just in a
    subprocess where this module's in-process monkeypatch doesn't apply.
    """
    directory = official_eval_dir or _default_official_eval_dir()
    script = directory / "compute_metrics.py"
    if not script.is_file():
        raise EvaluationError(f"official eval script not found: {script}")

    gt_files = find_niftis(groundtruth_dir)
    if not gt_files:
        raise EvaluationError(f"no ground-truth NIfTI files found in {groundtruth_dir}")
    fallback_keys = [p.name.split("_")[-2] if len(p.name.split("_")) >= 2 else p.name for p in gt_files]
    if len(set(fallback_keys)) != len(gt_files):
        raise EvaluationError(
            "refusing to run the official CLI: its own filename.split('_')[-2] "
            f"case key collides for these files under {groundtruth_dir} "
            f"(keys={fallback_keys}); this would silently drop cases instead of "
            "scoring all of them. Use evaluate_predictions() instead, which "
            "matches files by exact stem."
        )

    output_json.parent.mkdir(parents=True, exist_ok=True)
    code = (
        "import sys, numpy as np\n"
        f"sys.path.insert(0, {str(directory)!r})\n"
        "if not hasattr(np, 'NaN'): np.NaN = np.nan\n"
        "if not hasattr(np, 'Inf'): np.Inf = np.inf\n"
        "import compute_metrics as m\n"
        f"m.evaluate({str(predictions_dir)!r}, {str(groundtruth_dir)!r}, {str(output_json)!r})\n"
    )
    result = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True)
    if result.returncode != 0:
        raise EvaluationError(
            f"official compute_metrics.evaluate() failed (exit {result.returncode}):\n{result.stderr}"
        )
    return json.loads(output_json.read_text())
