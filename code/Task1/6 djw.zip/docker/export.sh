#!/usr/bin/env bash
set -euo pipefail

TEAM_NAME="djw"

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
IMAGE_NAME="${TEAM_NAME}:latest"
OUTPUT_FILE="${REPO_ROOT}/submissions/${TEAM_NAME}.tar.gz"

mkdir -p "${REPO_ROOT}/submissions"
echo "Exporting Docker image ${IMAGE_NAME} to ${OUTPUT_FILE}"
docker save "${IMAGE_NAME}" | gzip -c > "${OUTPUT_FILE}"

size_bytes=$(stat -f%z "${OUTPUT_FILE}" 2>/dev/null || stat -c%s "${OUTPUT_FILE}")
size_gb=$(awk -v b="${size_bytes}" 'BEGIN { printf "%.2f", b / 1073741824 }')
echo "Export complete: ${OUTPUT_FILE} (${size_gb} GB)"
awk -v b="${size_bytes}" 'BEGIN { if (b >= 5*1073741824) { print "WARNING: exceeds the 5GB submission limit"; exit 1 } }'
