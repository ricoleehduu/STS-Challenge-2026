#!/usr/bin/env bash
set -euo pipefail

TEAM_NAME="djw"

# Build context is the repo root so the Dockerfile can COPY src/, pyproject.toml,
# and docker/*; run this script from the repository root, not from docker/.
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

echo "Building Docker image: ${TEAM_NAME}:latest"
docker build -t "${TEAM_NAME}:latest" -f "${REPO_ROOT}/docker/Dockerfile" "${REPO_ROOT}"
