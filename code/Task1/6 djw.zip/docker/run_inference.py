#!/usr/bin/env python3
"""Docker entrypoint: read /inputs, write /outputs, preserving NIfTI geometry.

Real-checkpoint mode: set the ``STSR_CHECKPOINT_DIR`` environment variable to
an nnU-Net trainer-output directory (e.g.
``.../Dataset002_STSR/nnUNetTrainer__nnUNetPlans__3d_fullres`` -- must
contain ``fold_<n>/<checkpoint_name>`` + ``plans.json`` + ``dataset.json``)
to run real inference via a real ``nnUNetPredictor``
(``stsr2026.inference.checkpoint_runner`` +
``stsr2026.inference.streaming_export.predict_case_streaming``, which keeps
peak export memory bounded for the 28GB-RAM Docker target -- see that
module's docstring for what is and isn't GPU-validated). Optional env vars:
``STSR_CHECKPOINT_FOLDS`` (default ``"0"``, space/comma-separated),
``STSR_CHECKPOINT_NAME`` (default ``"checkpoint_final.pth"``),
``STSR_TILE_STEP_SIZE`` (default ``0.5``), ``STSR_USE_MIRRORING`` (default
off -- TTA, per plan.md 3.1), ``STSR_CASE_TIMEOUT_SECONDS`` (default unset =
no timeout; see ``checkpoint_runner``'s docstring for why a tight default is
premature before D2 efficiency work lands), ``STSR_OUTPUT_SUFFIX``
(default ``""``; the modern Docker image sets ``"_mask"`` for the official
final-ranking output convention), and ``STSR_APPLY_LR_CORRECTION`` (default
**on** as of the D7 Day 1 follow-up -- despite its legacy name this now gates
the FULL GT-free post-processing chain: tooth left/right correction AND
GT-free teeth-only false-positive cleanup, see ``_run_real_checkpoint``'s
comment and ``stsr2026.inference.postprocessing_pipeline``'s module
docstring; set to ``"0"``/``"false"``/``"off"`` to disable and reproduce the
pre-D7 raw-prediction behavior).

D0 fallback mode: if ``STSR_CHECKPOINT_DIR`` is unset, falls back to
stsr2026's all-background ``fake_predict`` placeholder (unchanged from the
original skeleton), so the I/O smoke test keeps working without a
GPU/checkpoint.
"""
from __future__ import annotations

import os
import time
from pathlib import Path

from stsr2026.inference.checkpoint_runner import load_docker_config, run_checkpoint_inference_for_docker
from stsr2026.inference.predict import fake_predict, run_inference

INPUT_DIR = Path("/inputs")
OUTPUT_DIR = Path("/outputs")


def _run_fake_predict(start: float) -> None:
    written = run_inference(INPUT_DIR, OUTPUT_DIR, predict_fn=fake_predict)
    elapsed = time.monotonic() - start
    if not written:
        print(f"Error: no .nii.gz files found in {INPUT_DIR}")
        raise SystemExit(1)
    for path in written:
        print(f"wrote {path}")
    print(f"{len(written)} case(s) in {elapsed:.2f}s")


def _run_real_checkpoint(start: float, config) -> None:
    print(
        f"real checkpoint inference: checkpoint_dir={config.checkpoint_dir} "
        f"folds={config.folds} checkpoint_name={config.checkpoint_name} "
        f"tile_step_size={config.tile_step_size} use_mirroring={config.use_mirroring} "
        f"case_timeout_seconds={config.case_timeout_seconds} output_suffix={config.output_suffix!r} "
        f"apply_lr_correction={config.apply_lr_correction}"
    )
    # apply_postprocessing=config.apply_lr_correction wires the FULL GT-free
    # post-processing chain into the real submission (see
    # stsr2026.inference.postprocessing_pipeline.apply_postprocessing_chain's
    # module docstring for the exact steps):
    #   step 1: tooth left/right correction (already validated on real
    #     Codabench hidden GT, +0.205 Challenge_Score).
    #   step 2: GT-free teeth-only false-positive cleanup (D7 Day 1
    #     follow-up, real-data validated on the 6-case holdout as
    #     taskG-teeth-only -- IA 0.5472 -> 0.5518, mIoU +0.006, tooth
    #     Dice_Instance up, all four canal metrics EXACTLY unchanged).
    # Both need no ground truth and both now run unconditionally whenever
    # this flag is on -- neither needs postprocess_gt_labels_by_case, which
    # stays deliberately unset (None) here. The GT-INFORMED false-positive-
    # cleanup/relabel step (step 3 of postprocessing_pipeline) is NOT wired
    # here and never will be for the real Docker entrypoint: it needs a
    # per-case ground-truth label set this container has no way to supply
    # for the organizers' hidden test cases.
    #
    # Default is now STSR_APPLY_LR_CORRECTION unset -> True (see
    # checkpoint_runner.ENV_APPLY_LR_CORRECTION's comment for the full
    # rationale) -- both steps are real, measured, GT-free wins. Set
    # STSR_APPLY_LR_CORRECTION=0 to force the old pre-D7 byte-identical
    # behavior if a real Docker build/run validation pass (plan.md D7 Day 2,
    # see scripts/build_submission_container.sh /
    # scripts/validate_submission_container.sh) surfaces a problem.
    outcomes = run_checkpoint_inference_for_docker(
        INPUT_DIR,
        OUTPUT_DIR,
        config.checkpoint_dir,
        folds=config.folds,
        checkpoint_name=config.checkpoint_name,
        tile_step_size=config.tile_step_size,
        use_mirroring=config.use_mirroring,
        case_timeout_seconds=config.case_timeout_seconds,
        output_suffix=config.output_suffix,
        apply_postprocessing=config.apply_lr_correction,
    )
    elapsed = time.monotonic() - start
    if not outcomes:
        print(f"Error: no .nii.gz files found in {INPUT_DIR}")
        raise SystemExit(1)

    num_ok = sum(1 for outcome in outcomes if outcome.status == "ok")
    for outcome in outcomes:
        if outcome.status == "ok":
            print(f"wrote {outcome.output_path} ({outcome.wall_clock_seconds:.1f}s)")
        else:
            print(f"FAILED case {outcome.case_id} [{outcome.status}]: {outcome.message}")
    print(f"{num_ok}/{len(outcomes)} case(s) succeeded in {elapsed:.2f}s")
    if num_ok == 0:
        raise SystemExit(1)


def main() -> None:
    start = time.monotonic()
    config = load_docker_config(os.environ)

    if config.checkpoint_dir is None:
        print(
            "STSR_CHECKPOINT_DIR not set: falling back to the fake_predict "
            "all-background placeholder. Set STSR_CHECKPOINT_DIR to a real "
            "nnU-Net trainer-output directory to run real inference (see "
            "docker/README.md and stsr2026.inference.checkpoint_runner)."
        )
        _run_fake_predict(start)
        return

    _run_real_checkpoint(start, config)


if __name__ == "__main__":
    main()
