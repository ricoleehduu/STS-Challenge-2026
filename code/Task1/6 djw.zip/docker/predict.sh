#!/bin/bash
set -e
python run_inference.py
