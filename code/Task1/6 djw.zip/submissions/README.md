# Generated submissions

验证集 zip、Docker image tar.gz、校验和与本地 sanity-test 输出放在此目录，生成文件不进入 Git。

验证 zip 必须在根目录直接包含 20 个 `.nii.gz`，不得包含子目录或系统隐藏文件。

