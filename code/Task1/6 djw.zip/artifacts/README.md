# Local artifacts

此目录用于本地生成的 checkpoint、预测和日志，内容默认不进入 Git：

```text
artifacts/
  checkpoints/
  predictions/
  logs/
```

需要共享的小型指标表或实验结论应整理到 `docs/`，而不是直接提交大型训练产物。

