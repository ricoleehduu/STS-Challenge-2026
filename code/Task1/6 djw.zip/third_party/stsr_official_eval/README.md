# Official STSR-2025 local evaluation scripts (vendored)

Source: `github.com/ricoleehduu/STSR-Challenge`, path
`STSR-2025/evaluation/Task1/{compute_metrics.py,SurfaceDice.py}`,
commit `bb10b433bf134414426b10ca2a2eb83223fbb0b4`, fetched 2026-07-12.
License: MIT (repo-level `LICENSE`).

`SurfaceDice.py` is DeepMind's well-known `surface_distance` implementation
(the same code used across many medical-segmentation challenges); `compute_metrics.py`
is the organizers' own wrapper defining exactly how STSR turns it into the
challenge metrics. Do not edit these files in place — if a fix is needed,
patch in `src/stsr2026/evaluation/` and leave these as an unmodified,
diffable reference to the official source.

## What this resolves

`plan.md` section 0 flagged the exact definitions of Dice_Image, Dice_Instance,
IoU_Image/Instance, NSD_Image/Instance, and IA as an open risk (no official
scorer had been reviewed). Reading `compute_metrics.py` directly gives the
real definitions:

- **Image-level** (`dice_image`, `iou_image`, `nsd_image`): binary
  foreground-vs-background (`gt > 0` vs `pred > 0`) over the whole volume —
  collapses all 64 foreground classes into one mask before scoring. NSD
  tolerance is a fixed **2.0mm**.
- **Instance-level** (`dice_instance`, `iou_instance`, `nsd_instance`): **not**
  connected-component instances — computed **per unique class label value**
  present in the ground truth (`gt_np == label_id` vs `pred_np == label_id`),
  one Dice/IoU/NSD per label, then averaged across all labels and all cases.
  So "instance" here means "FDI class id", matching this repo's own class
  scheme, not a blob-detection notion of instance.
- **IA** (Instance Agreement): for each case, count how many GT labels have a
  matching prediction with IoU >= 0.5, divide by `len(set(gt_labels) | set(pred_labels))`
  (union of the label sets actually present, not a fixed 64). Averaged across
  cases.
- **Final score**: `All_Average` is an unweighted mean of the 7 metrics above
  (Dice_Image, IoU_Image, NSD_Image, Dice_Instance, IoU_Instance, NSD_Instance, IA).
  This is what the *local* script reports — plan.md's open question about
  whether the public leaderboard ranks by raw score or by per-metric rank
  (organizer question 2 in section 8) is still unresolved; this script's
  `All_Average` is a reasonable local proxy, not a confirmed reproduction of
  the leaderboard's aggregation.
- **Filename matching**: the official README says prediction filenames must
  match ground-truth filenames exactly (the code's `split('_')[-2]` fallback
  parsing is a convenience, not the documented contract) — matches this
  repo's own convention already enforced by `stsr2026.submission.validator`.

## Usage

```bash
pip install numpy simpleitk scipy
python third_party/stsr_official_eval/compute_metrics.py \
  -p /path/to/predictions -g /path/to/ground_truth -o scores.json
```

`src/stsr2026/evaluation/` should call into this rather than reimplementing
metric math, to guarantee parity with the official numbers.
