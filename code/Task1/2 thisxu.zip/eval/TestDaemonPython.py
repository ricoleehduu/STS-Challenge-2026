import argparse
import time
import json
import psutil as p
import os
from pynvml import *
from multiprocessing import Manager, Process

manager = Manager()
gpu_list = manager.list()
cpu_list = manager.list()
ram_list = manager.list()

def nvsmi_query(gpu_id):
    nvmlInit()
    handle = nvmlDeviceGetHandleByIndex(gpu_id)
    info = nvmlDeviceGetMemoryInfo(handle)
    nvmlShutdown()
    gpu_memory = info.used / 1024 / 1024
    return gpu_memory

def cpu_usage():
    t = p.cpu_times()
    return [t.user, t.system, t.idle]

before = cpu_usage()
def get_cpu_usage():
    global before
    now = cpu_usage()
    delta = [now[i] - before[i] for i in range(len(now))]
    total = sum(delta)
    before = now
    return [(100.0*dt)/(total+0.1) for dt in delta]

def daemon_process(time_interval = 0.1, gpu_id = 0):
    while True:
        gpu_memory = nvsmi_query(gpu_id = gpu_id)
        cpu_usage = get_cpu_usage()
        RAM = p.virtual_memory().used/1048576  # 1048576 = 1024 * 1024
        gpu_list.append(gpu_memory)
        ram_list.append(RAM)
        cpu_list.append(cpu_usage)
        time.sleep(time_interval)

def save_result(start_time, json_path, gpu_list_copy, cpu_list_copy, ram_list_copy):
    js = dict()
    infer_time = time.time() - start_time
    with open(json_path, mode = "w", encoding = "utf-8") as f:
        js["gpu_memory"] = gpu_list_copy
        js["cpu_list"] = cpu_list_copy
        js["ram_list"] = ram_list_copy

        js["time"] = infer_time
        js["gpu_memory_max"] = max(gpu_list_copy)
        js["cpu_list_max"] = max(cpu_list_copy)
        js["ram_list_max"] = max(ram_list_copy)
        json.dump(js, f, indent = 4)

    infer_time = time.time() - start_time
    with open(json_path, mode = "r", encoding = "utf-8") as f:
        js = json.load(f)
    with open(json_path, mode = "w", encoding = "utf-8") as f:
        js["time"] = infer_time
        json.dump(js, f, indent = 4)
    time.sleep(2)
    print("save result end")
    
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-time_interval", default = 0.1, help = "GPU usage sampling interval")
    parser.add_argument('-gpu_id', default=0, help='CUDA_VISIBLE_DEVICE')
    parser.add_argument("-python", default = "test.py", help = "python script")
    args = parser.parse_args()

    start_time = time.time()
    try:
        # Start record
        p1 = Process(target = daemon_process, args = (args.time_interval, args.gpu_id,))
        p1.daemon = True
        p1.start()
        cmd = "python {}".format(args.python)
        print(f"cmd is : {cmd}")
        os.system(cmd)
        # Save result
        ram_list = list(ram_list)
        ram_list_copy = ram_list.copy()
        cpu_list = list(cpu_list)
        cpu_list_copy = cpu_list.copy()
        gpu_list = list(gpu_list)
        gpu_list_copy = gpu_list.copy()

        json_path = "daemon.json"
        save_result(start_time, json_path, gpu_list_copy, cpu_list_copy, ram_list_copy)
        time.sleep(5)
    except Exception as error:
        print(error)
