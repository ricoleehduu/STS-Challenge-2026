import torch
from fvcore.nn import FlopCountAnalysis, parameter_count_table
from batchgenerators.utilities.file_and_folder_operations import load_json, join
from nnunetv2.utilities.get_network_from_plans import get_network_from_plans
from nnunetv2.utilities.plans_handling.plans_handler import PlansManager, ConfigurationManager
from nnunetv2.utilities.label_handling.label_handling import determine_num_input_channels
from nnunetv2.utilities.find_objects import recursive_find_trainer_class_by_name

model_training_output_dir = "./nnUNet_results/Dataset916_MICCAIUnlabeled/nnUNetTrainer__nnUNetPlans__3d_new"
# model_training_output_dir = "./nnUNet_results/Dataset1221_MICCAIUnlabeled/nnUNetTrainer_DASegOrd0_NoMirroring__nnUNetPlans__3d_new"
# model_training_output_dir = "./nnUNet_results/Dataset821_MICCAIUnlabeled/nnUNetTrainer_DASegOrd0_NoMirroring__nnUNetPlans__3d_new"
checkpoint_path = model_training_output_dir + "/fold_0/checkpoint_final.pth"
checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only = False)

dataset_json = load_json(join(model_training_output_dir, "dataset.json"))
plans = load_json(join(model_training_output_dir, "plans.json"))
configuration_name = checkpoint["init_args"]["configuration"]

plans_manager = PlansManager(plans)
configuration_manager = plans_manager.get_configuration(configuration_name)
num_input_channels = determine_num_input_channels(plans_manager, configuration_manager, dataset_json)
num_output_channels = plans_manager.get_label_manager(dataset_json).num_segmentation_heads

trainer_name = checkpoint["trainer_name"]
trainer_class = recursive_find_trainer_class_by_name(trainer_name)
network = trainer_class.build_network_architecture(
    plans_manager,
    configuration_manager,
    num_input_channels,
    num_output_channels,
    enable_deep_supervision = False,
)

network.load_state_dict(checkpoint["network_weights"])
network.eval()

patch_size = configuration_manager.patch_size
dummy_input = torch.randn(1, num_input_channels, *patch_size)

flops = FlopCountAnalysis(network, dummy_input)
print(f"GFLOPs (10^9 FLOPs): {flops.total() / 1e9:.2f} GFLOPs")
num_params = sum(p.numel() for p in network.parameters() if p.requires_grad)
print(f"Parameters: {num_params / (1024 * 1024):.2f} M")
