import multiprocessing as mp
from concurrent.futures import ProcessPoolExecutor

import numpy as np
import torch
from pathlib import Path
import time

from batchgenerators.utilities.file_and_folder_operations import join
from nnunetv2.inference.predict_from_raw_data import nnUNetPredictor
from nnunetv2.paths import nnUNet_results, nnUNet_raw
import SimpleITK as sitk

import cupy as cp
from cucim.core.operations.morphology import distance_transform_edt
from cucim.skimage.feature import peak_local_max
from cucim.skimage.measure import label
from skimage.segmentation import watershed

def init_predictors(cuda = 0, verbose = False):
    predictor916 = nnUNetPredictor(
        # tile_step_size = 0.5,
        tile_step_size = 0.8,
        use_gaussian = True,
        # use_mirroring = True,
        use_mirroring = False,
        perform_everything_on_device = True,
        device = torch.device("cuda", cuda),
        verbose = False,
        verbose_preprocessing = False,
        allow_tqdm = verbose,
    )
    predictor916.initialize_from_trained_model_folder(
        join(nnUNet_results, "Dataset916_MICCAIUnlabeled/nnUNetTrainer__nnUNetPlans__3d_new"),
        use_folds = (0,),
        checkpoint_name = "checkpoint_final.pth",
    )

    predictor1121 = nnUNetPredictor(
        tile_step_size = 0.5,
        use_gaussian = True,
        use_mirroring = False,
        perform_everything_on_device = True,
        device = torch.device("cuda", cuda),
        verbose = False,
        verbose_preprocessing = False,
        allow_tqdm = verbose,
    )
    predictor1121.initialize_from_trained_model_folder(
        join(nnUNet_results, "Dataset1221_MICCAIUnlabeled/nnUNetTrainer_DASegOrd0_NoMirroring__nnUNetPlans__3d_new"),
        use_folds=(0,),
        checkpoint_name="checkpoint_final.pth",
    )
    return predictor916, predictor1121

def resample_image(image_sitk, target_spacing, target_size = None, is_label = False):
    original_size = image_sitk.GetSize()
    original_spacing = image_sitk.GetSpacing()
    original_origin = image_sitk.GetOrigin()

    if target_size is None:
        target_size = tuple(
            int(np.round(original_size[i] * original_spacing[i] / target_spacing[i]))
            for i in range(len(original_size))
        )

    # print(f"resample_image spacing from {original_spacing} to {target_spacing} and size from {original_size} to {target_size}.")
    resampler = sitk.ResampleImageFilter()
    resampler.SetOutputSpacing(target_spacing)
    resampler.SetSize(target_size)
    resampler.SetOutputOrigin(image_sitk.GetOrigin())
    resampler.SetOutputDirection(image_sitk.GetDirection())
    resampler.SetTransform(sitk.Transform())

    if is_label:
        resampler.SetInterpolator(sitk.sitkLabelLinear)
        resampler.SetDefaultPixelValue(0)
    else:
        resampler.SetInterpolator(sitk.sitkLinear)
        resampler.SetDefaultPixelValue(image_sitk.GetPixelIDValue())
    image = resampler.Execute(image_sitk)

    new_origin = [
        int(np.round(original_origin[i] * original_size[i] / target_size[i]))
        for i in range(len(original_origin))
    ]
    image.SetOrigin(new_origin)
    return image

def resample_np(image_np, image_spacing, target_spacing, target_size = None, is_label = False):
    itk_result = sitk.GetImageFromArray(image_np.astype(np.uint8))
    itk_result.SetSpacing(image_spacing)
    itk_result = resample_image(
        itk_result,
        target_spacing = target_spacing,
        target_size = target_size,
        is_label = is_label,
    )
    result_np = sitk.GetArrayFromImage(itk_result)
    return result_np

def rotate_volume(volume):
    array = sitk.GetArrayFromImage(volume)
    rotated_array = array
    rotated_array = np.flip(rotated_array, axis = (0,))
    rotated_volume = sitk.GetImageFromArray(rotated_array)

    # Copy basic information (spacing, origin)
    rotated_volume.SetSpacing(volume.GetSpacing())
    rotated_volume.SetOrigin(volume.GetOrigin())
    # print('OriginalDirection:', rotated_volume.GetDirection())
    lps_direction = (1.0, 0.0, 0.0,  # X axis: Right to Left (negative)
                     0.0, 1.0, 0.0,  # Y axis: Anterior to Posterior (negative)
                     0.0, 0.0, 1.0)  # Z axis: Inferior to Superior (positive)
    rotated_volume.SetDirection(lps_direction)
    return rotated_volume

def check_spacing(input_image, target_spacing):
    original_spacing = input_image.GetSpacing()
    if all([round(i, 3) == j for i, j in zip(original_spacing, target_spacing)]):
        return False
    else:
        return True

def watershed_segmentation(mask, min_distance = 8):
    mask = cp.asarray(mask, dtype = cp.uint8)
    mask = mask > 0
    distance = distance_transform_edt(mask)

    peaks = peak_local_max(
        distance,
        min_distance = min_distance,
        labels = mask,
    )
    markers = cp.zeros_like(mask, dtype = cp.int32)
    markers[tuple(peaks.T)] = 1
    markers = label(markers)
    # seg = watershed(-distance, markers, mask = mask)
    seg = watershed(-distance.get(), markers.get(), mask = mask.get())

    return seg.astype(np.int8)

def seg_by_water(source_np, ref_np, watershed_np, is_mirror_pulp = False, count_bg = True):
    # watershed_np = watershed_segmentation(source_np)
    labels = np.unique(watershed_np[watershed_np != 0])
    out_seg = np.zeros_like(source_np, dtype = np.uint8)
    source_mask = ref_np > 0
    for area_idx in labels:
        block_mask = watershed_np == area_idx
        if not count_bg:
            block_mask &= source_mask
        out_id = 0
        if block_mask.size > 0:
            ids, counts = np.unique(ref_np[block_mask], return_counts = True)
            out_id = ids[counts.argmax()]
        pulp_id = get_pulp_id(out_id, is_mirror = is_mirror_pulp)
        out_seg[block_mask] = np.where(source_np[block_mask] == 1, out_id, pulp_id)
    return out_seg

def get_pulp_id(tooth_id, is_mirror = False, pulp_diff = 32):
    pulp_id = tooth_id + pulp_diff
    if is_mirror:
        if 33 <= pulp_id < 41 or 49 <= pulp_id < 57:
            pulp_id += 8
        elif 41 <= pulp_id < 49 or 57 <= pulp_id < 65:
            pulp_id -= 8
    return pulp_id

def infer_np(predictor, image_np, image_spacing):
    props = {
        "spacing": image_spacing,
    }
    image_np = image_np[np.newaxis, :]
    result_np = predictor.predict_single_npy_array(image_np, props, None, None, False)
    return result_np

def infer_itk(predictor, image_sitk, infer_spacing = None, local_resample = False, recover_spacing = False):
    origin_spacing = image_sitk.GetSpacing()
    origin_size = image_sitk.GetSize()

    use_resample = False

    if local_resample and infer_spacing is not None:
        use_resample = check_spacing(image_sitk, infer_spacing)
        if use_resample:
            image_sitk = resample_image(image_sitk, infer_spacing, is_label = False)
    else:
        infer_spacing = list(image_sitk.GetSpacing())[::-1]

    image_np = sitk.GetArrayFromImage(image_sitk)
    result_np = infer_np(predictor, image_np, infer_spacing)

    if type(recover_spacing) is tuple:
        if infer_spacing == recover_spacing:
            use_resample = False
        else:
            origin_size = tuple(
                int(np.round(origin_size[i] * origin_spacing[i] / recover_spacing[i]))
                for i in range(len(origin_size))
            )
            origin_spacing = recover_spacing

    if recover_spacing is not False and use_resample:
        result_np = resample_np(
            image_np = result_np,
            image_spacing = infer_spacing,
            target_spacing = origin_spacing,
            target_size = origin_size,
            is_label = True,
        )
    return result_np

def read_image(file, has_reverse = True):
    itk_image = sitk.ReadImage(file)

    is_reverse = has_reverse and itk_image.GetPixelID() == sitk.sitkFloat64
    itk_image = sitk.Cast(itk_image, sitk.sitkInt16)
    itk_image = sitk.Clamp(itk_image, upperBound = 5000)

    if is_reverse:
        itk_image = rotate_volume(itk_image)

    return itk_image, is_reverse

def infer_tooth(predictor916, predictor821, image_sitk, name, pool, local_resample = True, verbose = False):
    start_time = time.time()
    infer916_spacing = (0.3, 0.3, 0.3)
    infer821_spacing = (1.0, 1.0, 1.0)
    origin_size = image_sitk.GetSize()
    origin_spacing = image_sitk.GetSpacing()

    use_resample = local_resample and check_spacing(image_sitk, infer916_spacing)

    job916 = pool.submit(
        infer_itk,
        predictor916,
        image_sitk,
        infer_spacing = infer916_spacing,
        local_resample = local_resample,
        recover_spacing = False,
    )
    job821 = pool.submit(
        infer_itk,
        predictor821,
        image_sitk,
        infer_spacing = infer821_spacing,
        local_resample = local_resample,
        recover_spacing = infer916_spacing,
    )

    ret916_np = job916.result()
    if verbose:
        print(f"{name} time step0 {(time.time() - start_time):.2f}s")
    watershed_np = watershed_segmentation(ret916_np)
    if verbose:
        print(f"{name} time step1 {(time.time() - start_time):.2f}s")
    ret821_np = job821.result()
    if verbose:
        print(f"{name} time step2 {(time.time() - start_time):.2f}s")

    # output_np = seg_by_water(ret916_np, ret821_np, watershed_np, is_mirror_pulp = True)
    output_np = seg_by_water(ret916_np, ret821_np, watershed_np, is_mirror_pulp = False)
    if use_resample:
        output_np = resample_np(
            image_np = output_np,
            image_spacing = infer916_spacing,
            target_spacing = origin_spacing,
            target_size = origin_size,
            is_label = True,
        )
    if verbose:
        print(f"{name} time step3 {(time.time() - start_time):.2f}s")
    return output_np

def process_by_pool(predictors, image_path, output_path, name, pool, verbose = False):
    image_sitk, is_reverse = read_image(image_path, has_reverse = True)

    predictor916, predictor821 = predictors

    output_np = infer_tooth(predictor916, predictor821, image_sitk, name, pool, verbose = verbose)

    result_itk = sitk.GetImageFromArray(output_np)
    if is_reverse:
        result_itk = rotate_volume(result_itk)
    result_itk.CopyInformation(image_sitk)
    sitk.WriteImage(result_itk, output_path)

def main(input_dir, output_dir, verbose = False):
    input_path = Path(input_dir)
    output_path = Path(output_dir)
    output_path.mkdir(exist_ok = True, parents = True)

    predictors = init_predictors(verbose = verbose)
    with ProcessPoolExecutor(max_workers = 2, mp_context = mp.get_context("spawn")) as pool:
        for file in input_path.glob("*.nii.gz"):
            process_by_pool(
                predictors,
                str(file),
                str(output_path / file.name).replace("_0000", ""),
                file.name,
                pool,
                verbose = verbose,
            )
if __name__ == "__main__":
    main(
        input_dir = "/home/data2/xrs/dataset/MICCAI-Chllenge-STS26-Task1/Validation/images/",
        output_dir = "./pred_test5",
        verbose = True,
    )
    print("ok")
