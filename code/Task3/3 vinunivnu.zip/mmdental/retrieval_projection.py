#!/usr/bin/env python3
"""
Metric-trained CBCT retrieval for STSR Task 3.

The script starts from cached image features (Med3DVLM, M3D-CLIP, AE, or
hand-crafted), trains a small projection head so cases with similar clinical
reports become close, then builds field-wise predictions:

  - Oral Check / Diagnosis / Treatment plan / Handle: retrieved top-k neighbor(s)
  - Doctor advices: mode or medoid prior
  - Main appeal / Present medical history: medoid, empty, or confident neighbor

This is retrieval-first: it does not ask a VLM to generate free-form reports.
"""
import argparse
import json
import re
import zipfile
from collections import Counter
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from config import AE_FEATS, FEATURES, M3D_FEATS, MED3DVLM_FEATS, OUT, case_dirs
from eval_harness import TARGETS, bleu_n, icd, load_cases, prf, rouge_l, score_case, teeth


CLINICAL_FIELDS = ["Oral Check", "Diagnosis", "Treatment plan", "Handle"]
SPARSE_FIELDS = ["Main appeal", "Present medical history"]
FIELD_GROUPS = {
    "all": TARGETS,
    "clinical": CLINICAL_FIELDS,
    "core": CLINICAL_FIELDS + ["Doctor advices"],
    "none": [],
}


def clean_values(values):
    out, seen = [], set()
    for value in values:
        value = str(value).strip()
        if value and value not in seen:
            out.append(value)
            seen.add(value)
    return out


def text_metric(a, b, objective="bleu_rouge"):
    if objective == "rouge":
        return rouge_l(a, b)
    bleu = bleu_n(a, b)
    bscore = sum(bleu) / len(bleu)
    if objective == "bleu":
        return bscore
    if objective == "bleu_rouge":
        return 0.5 * bscore + 0.5 * rouge_l(a, b)
    raise ValueError(f"unknown objective: {objective}")


def field_medoid(values, objective="bleu_rouge"):
    values = clean_values(values)
    if not values:
        return ""
    if len(values) == 1:
        return values[0]
    best, best_score = values[0], -1.0
    for i, value in enumerate(values):
        score = 0.0
        for j, other in enumerate(values):
            if i == j:
                continue
            score += text_metric(value, other, objective=objective)
        score /= max(1, len(values) - 1)
        if score > best_score:
            best, best_score = value, score
    return best


def mode_value(values):
    values = clean_values(values)
    if not values:
        return ""
    return Counter(values).most_common(1)[0][0]


def parse_field_group(text):
    if text in FIELD_GROUPS:
        return FIELD_GROUPS[text]
    return [x.strip() for x in text.split(",") if x.strip()]


def safe_name(text):
    return re.sub(r"[^A-Za-z0-9]+", "-", str(text)).strip("-")


def base_prediction(train_reports, args):
    pred = {
        field: field_medoid((case[field] for case in train_reports.values()), objective=args.prior_objective)
        for field in TARGETS
    }
    if args.doctor == "mode":
        pred["Doctor advices"] = mode_value(case["Doctor advices"] for case in train_reports.values())
    elif args.doctor == "empty":
        pred["Doctor advices"] = ""

    if args.sparse == "empty":
        for field in SPARSE_FIELDS:
            pred[field] = ""
    return pred


def aggregate_field(values, agg, objective):
    values = clean_values(values)
    if not values:
        return ""
    if agg == "top1":
        return values[0]
    if agg == "mode":
        return mode_value(values)
    if agg == "concat":
        return " ".join(values)
    return field_medoid(values, objective=objective)


def set_f1_nonempty(a, b):
    if not a and not b:
        return 0.0
    return prf(a, b)[2]


def report_pair_similarity(a, b, fields, objective):
    text_scores = []
    for field in fields:
        av, bv = a.get(field, ""), b.get(field, "")
        text_scores.append(0.5 * text_metric(av, bv, objective) + 0.5 * text_metric(bv, av, objective))
    text_score = sum(text_scores) / max(1, len(text_scores))

    a_text = " ".join(a.get(field, "") for field in fields)
    b_text = " ".join(b.get(field, "") for field in fields)
    tooth_score = set_f1_nonempty(teeth(a_text), teeth(b_text))
    icd_score = set_f1_nonempty(icd(a.get("Diagnosis", "")), icd(b.get("Diagnosis", "")))
    return 0.70 * text_score + 0.15 * tooth_score + 0.15 * icd_score


def target_matrix(cases, ids, fields, objective):
    n = len(ids)
    y = np.eye(n, dtype=np.float32)
    for i in range(n):
        for j in range(i + 1, n):
            sim = report_pair_similarity(cases[ids[i]], cases[ids[j]], fields, objective)
            y[i, j] = sim
            y[j, i] = sim
    return y


class ProjectionHead(nn.Module):
    def __init__(self, in_dim, out_dim):
        super().__init__()
        hidden = max(out_dim, min(1024, in_dim))
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden),
            nn.LayerNorm(hidden),
            nn.GELU(),
            nn.Dropout(0.05),
            nn.Linear(hidden, out_dim),
        )

    def forward(self, x):
        return self.net(x)


class FeatureProjector:
    def __init__(self, model, mean, std, device):
        self.model = model
        self.mean = mean.astype(np.float32)
        self.std = std.astype(np.float32)
        self.device = device

    def transform_one(self, vec):
        x = ((np.asarray(vec, dtype=np.float32) - self.mean) / self.std)[None]
        if self.model is None:
            z = x[0]
        else:
            with torch.no_grad():
                xt = torch.from_numpy(x).to(self.device)
                z = self.model(xt)[0].detach().cpu().numpy()
        return z.astype(np.float32) / (np.linalg.norm(z) + 1e-8)


def fit_projector(features, cases, ids, args):
    x = np.stack([features[cid].astype(np.float32) for cid in ids])
    mean = x.mean(axis=0)
    std = x.std(axis=0) + 1e-6
    x = (x - mean) / std
    if args.epochs <= 0:
        return FeatureProjector(None, mean, std, torch.device("cpu"))

    device = torch.device(args.device if torch.cuda.is_available() or args.device == "cpu" else "cpu")
    xt = torch.from_numpy(x).to(device)
    target_fields = parse_field_group(args.target_fields)
    yt = torch.from_numpy(target_matrix(cases, ids, target_fields, args.target_objective)).to(device)
    model = ProjectionHead(x.shape[1], args.proj_dim).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)

    for epoch in range(args.epochs):
        z = F.normalize(model(xt), dim=1)
        pred = (z @ z.T + 1.0) * 0.5
        loss = F.mse_loss(pred, yt)
        opt.zero_grad()
        loss.backward()
        opt.step()
        if args.verbose and ((epoch + 1) % 100 == 0 or epoch == 0):
            print(f"  proj epoch {epoch + 1}/{args.epochs} loss={loss.item():.5f}", flush=True)
    model.eval()
    return FeatureProjector(model, mean, std, device)


def cos(a, b):
    return float(a @ b / ((np.linalg.norm(a) * np.linalg.norm(b)) + 1e-8))


def top_neighbors(query_z, train_z, k):
    sims = sorted(((cos(query_z, vec), cid) for cid, vec in train_z.items()), reverse=True)
    return sims[:k]


def predict_from_neighbors(query_z, train_reports, train_z, args):
    pred = base_prediction(train_reports, args)
    neigh = top_neighbors(query_z, train_z, args.k)
    top_ids = [cid for _, cid in neigh]
    override_fields = parse_field_group(args.override_fields)
    for field in override_fields:
        pred[field] = aggregate_field([train_reports[cid][field] for cid in top_ids], args.agg, args.prior_objective)

    if args.sparse == "neighbor" and neigh and neigh[0][0] >= args.sparse_threshold:
        for field in SPARSE_FIELDS:
            value = train_reports[neigh[0][1]].get(field, "").strip()
            if value:
                pred[field] = value
    return pred


def feature_dir(kind):
    if kind == "med3dvlm":
        return MED3DVLM_FEATS
    if kind == "m3d":
        return M3D_FEATS
    if kind == "ae":
        return AE_FEATS
    if kind == "hand":
        return FEATURES
    raise ValueError(kind)


def load_cached_features(kind, split):
    if kind == "hand":
        from retrieval import feats_for_split

        return feats_for_split(split)

    root = feature_dir(kind)
    out = {}
    missing = []
    for case in case_dirs(split):
        path = root / f"{split}_{case.name}.npy"
        if path.exists():
            out[case.name] = np.load(path).astype(np.float32)
        else:
            missing.append(path)
    if missing:
        sample = "\n".join(str(p) for p in missing[:5])
        raise FileNotFoundError(
            f"Missing {len(missing)} cached {kind} feature files for {split}. "
            f"First missing files:\n{sample}"
        )
    return out


def score_predictions(preds, cases):
    totals = Counter()
    for cid, pred in preds.items():
        score = score_case(pred, cases[cid])
        for key, value in score.items():
            totals[key] += value
    n = len(preds)
    means = {key: totals[key] / n for key in totals}
    means["proxy_weighted_score"] = sum(means.values()) / len(means)
    return means


def print_score(label, score):
    print(
        f"{label:24s} proxy={score['proxy_weighted_score']:.4f} "
        f"b1={score['bleu_1']:.4f} b4={score['bleu_4']:.4f} rL={score['rouge_l']:.4f} "
        f"tooth={score['tooth_f1']:.4f} dx={score['dx_f1']:.4f}",
        flush=True,
    )


def loo(args, cases, features):
    ids = sorted([cid for cid in cases if cid in features], key=int)
    preds = {}
    if args.loo_mode == "fast":
        projector = fit_projector(features, cases, ids, args)
        z_all = {cid: projector.transform_one(features[cid]) for cid in ids}
        for cid in ids:
            train_ids = [oid for oid in ids if oid != cid]
            train_reports = {oid: cases[oid] for oid in train_ids}
            train_z = {oid: z_all[oid] for oid in train_ids}
            preds[cid] = predict_from_neighbors(z_all[cid], train_reports, train_z, args)
    else:
        for idx, cid in enumerate(ids, 1):
            train_ids = [oid for oid in ids if oid != cid]
            train_reports = {oid: cases[oid] for oid in train_ids}
            projector = fit_projector(features, cases, train_ids, args)
            train_z = {oid: projector.transform_one(features[oid]) for oid in train_ids}
            query_z = projector.transform_one(features[cid])
            preds[cid] = predict_from_neighbors(query_z, train_reports, train_z, args)
            if args.verbose:
                print(f"  LOO {idx}/{len(ids)} case={cid}", flush=True)
    score = score_predictions(preds, cases)
    print_score(f"loo {args.features}", score)
    print(json.dumps(score, indent=2))


def submit(args, cases, train_features, val_features):
    ids = sorted([cid for cid in cases if cid in train_features], key=int)
    projector = fit_projector(train_features, cases, ids, args)
    train_reports = {cid: cases[cid] for cid in ids}
    train_z = {cid: projector.transform_one(train_features[cid]) for cid in ids}
    preds = {}
    for cid in sorted(val_features, key=int):
        query_z = projector.transform_one(val_features[cid])
        preds[cid] = predict_from_neighbors(query_z, train_reports, train_z, args)

    OUT.mkdir(parents=True, exist_ok=True)
    stem = (
        f"{args.features}_proj_k{args.k}_{args.agg}_e{args.epochs}_{args.sparse}"
        f"_override-{safe_name(args.override_fields)}"
        f"_target-{safe_name(args.target_fields)}"
        f"_prior-{args.prior_objective}"
    )
    pj = OUT / f"predictions_retrieval_{stem}.json"
    zp = OUT / f"submission_task3_retrieval_{stem}.zip"
    pj.write_text(json.dumps(preds, ensure_ascii=False, indent=2), encoding="utf-8")
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.write(pj, "predictions.json")
    print(f"wrote {zp} ({len(preds)} cases)")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["loo", "submit"], default="loo")
    ap.add_argument("--features", choices=["med3dvlm", "m3d", "ae", "hand"], default="med3dvlm")
    ap.add_argument("--loo-mode", choices=["fast", "strict"], default="fast")
    ap.add_argument("--epochs", type=int, default=300)
    ap.add_argument("--proj-dim", type=int, default=256)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--weight-decay", type=float, default=1e-4)
    ap.add_argument("--k", type=int, default=3)
    ap.add_argument("--agg", choices=["top1", "medoid", "mode", "concat"], default="medoid")
    ap.add_argument("--override-fields", default="clinical")
    ap.add_argument("--target-fields", default="clinical", help="fields used to train projection target similarity")
    ap.add_argument("--prior-objective", choices=["bleu", "rouge", "bleu_rouge"], default="bleu_rouge")
    ap.add_argument("--target-objective", choices=["bleu", "rouge", "bleu_rouge"], default="bleu_rouge")
    ap.add_argument("--sparse", choices=["medoid", "empty", "neighbor"], default="medoid")
    ap.add_argument("--sparse-threshold", type=float, default=0.80)
    ap.add_argument("--doctor", choices=["mode", "medoid", "empty", "neighbor"], default="mode")
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args()

    cases = load_cases()
    train_features = load_cached_features(args.features, "Train-Labeled")
    if args.mode == "loo":
        loo(args, cases, train_features)
        return
    val_features = load_cached_features(args.features, "Validation")
    submit(args, cases, train_features, val_features)


if __name__ == "__main__":
    main()
