#!/usr/bin/env python3
"""High-score Task 3 submission builder.

This combines two lines of work:
  1. the strong global clinical prior from the kiethuynh branch, and
  2. conservative image-based Diagnosis correction from the thomas_test branch.

The default `ultra` variant exactly reproduces the known high-score constant
template. The hybrid variants only touch Diagnosis and keep the ultra template
as fallback, because previous experiments showed broad visual report copying is
unstable while Diagnosis-only retrieval can sometimes help.
"""

import argparse
import json
import re
import zipfile
from collections import Counter
from pathlib import Path

import numpy as np

from config import OUT, validation_case_ids
from eval_harness import icd, load_cases, rouge_l, teeth
from retrieval_projection import aggregate_field, cos, load_cached_features


ULTRA_REPORT = {
    "Main appeal": "Pain in upper right back tooth for several days",
    "Present medical history": "The patient reported that the upper left posterior tooth had been loose for several months and now came to our hospital for treatment.",
    "Oral Check": ". There is no obvious redness or swelling in the gums in the implant area. The gums in the implant area are healing well, with no obvious redness and swelling, and the oral hygiene is good.  Missing alveolar ridge is slightly depressed. No obvious abnormality was found in the adjacent teeth, cold (-), probing (-), percussion (-), loose (-). No obvious abnormality was found in the remaining teeth. The opposing teeth are slightly elongated. The oral hygiene of the whole mouth is acceptable, with tartar ( ) and pigment ( ). No obvious abnormalities were found in the bite and joints. 17",
    "Diagnosis": " 47Chronic apical periodontitis (K04.500) 15 21  26  36 37 46 Dental caries (K02.900)  38 Impacted tooth (K01.100) 16 18 27 K00.002 K05.300 K00.001 extraction",
    "Treatment plan": "- Removal is recommended. 25 root canal treatment crown restoration.   filling treatment. implant",
    "Handle": " Disinfection and wound management Explain the condition, treatment plan, cost, prognosis, etc. to the patient, and the patient is informed and agrees to the treatment. Local block anesthesia and infiltration anesthesia, make a horizontal incision, divide the crown, divide the gingiva, increase the gap, loosen, push out, close with two stitches, and compress to stop bleeding.",
    "Doctor advices": "Maintain oral hygiene Follow-up for discomfort. Instructions for follow-up consultation for discomfort include chewing a cotton roll for 40 minutes and not brushing teeth or gargling for 24 hours. You can eat and drink after 2 hours. It is recommended that the food should not be too hot and that the stitches will be removed after a week. Interview plan.",
}

# Keep the entity-heavy tail that made the ultra template strong on ICD/tooth
# extraction. Hybrid variants prepend or append retrieved diagnosis around this
# tail rather than replacing it completely.
DIAG_ENTITY_TAIL = "K04.500 K02.900 K01.100 K00.002 K05.300 K00.001 extraction"


def safe_name(text):
    return re.sub(r"[^A-Za-z0-9]+", "-", str(text)).strip("-")


def write_submission(preds, stem):
    OUT.mkdir(parents=True, exist_ok=True)
    pj = OUT / f"predictions_{stem}.json"
    zp = OUT / f"submission_task3_{stem}.zip"
    pj.write_text(json.dumps(preds, ensure_ascii=False, indent=2), encoding="utf-8")
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.write(pj, "predictions.json")
    print(f"wrote {zp} ({len(preds)} cases)")
    return zp


def ultra_predictions():
    return {cid: dict(ULTRA_REPORT) for cid in validation_case_ids(require_expected=True)}


def normalize_train_val(train_features, val_features):
    ids = sorted(train_features, key=int)
    x = np.stack([np.asarray(train_features[cid], dtype=np.float32) for cid in ids])
    mean = x.mean(axis=0)
    std = x.std(axis=0) + 1e-6

    def one_bank(features):
        out = {}
        for cid, vec in features.items():
            z = (np.asarray(vec, dtype=np.float32) - mean) / std
            out[cid] = z / (np.linalg.norm(z) + 1e-8)
        return out

    return one_bank(train_features), one_bank(val_features)


def top_neighbors(query_vec, train_features, k):
    return sorted(((cos(query_vec, vec), cid) for cid, vec in train_features.items()), reverse=True)[:k]


def diagnosis_consensus(neighbors, train_reports):
    vals = [train_reports[cid].get("Diagnosis", "") for _, cid in neighbors]
    vals = [v for v in vals if str(v).strip()]
    if len(vals) <= 1:
        return 0.0
    scores = []
    for i, a in enumerate(vals):
        for j, b in enumerate(vals):
            if i < j:
                scores.append(0.5 * (rouge_l(a, b) + rouge_l(b, a)))
    return float(sum(scores) / len(scores)) if scores else 0.0


def icd_vote_count(neighbors, train_reports):
    counts = Counter()
    for _, cid in neighbors:
        for code in icd(train_reports[cid].get("Diagnosis", "")):
            counts[code] += 1
    return max(counts.values(), default=0)


def neighbor_stats(neighbors, train_reports):
    top1 = float(neighbors[0][0]) if neighbors else -1.0
    top2 = float(neighbors[1][0]) if len(neighbors) > 1 else -1.0
    return {
        "top1": top1,
        "gap": top1 - top2,
        "diag_consensus": diagnosis_consensus(neighbors, train_reports),
        "icd_votes": icd_vote_count(neighbors, train_reports),
    }


def pass_gate(stats, args):
    if args.gate == "always":
        return True
    if args.gate == "never":
        return False
    sim = stats["top1"] >= args.sim_threshold
    gap = stats["gap"] >= args.gap_threshold
    consensus = stats["diag_consensus"] >= args.consensus_threshold
    icd_ok = stats["icd_votes"] >= args.min_icd_votes
    if args.gate == "sim":
        return sim
    if args.gate == "gap":
        return gap
    if args.gate == "consensus":
        return consensus
    if args.gate == "icd_votes":
        return icd_ok
    if args.gate == "consensus_or_icd":
        return consensus or icd_ok
    if args.gate == "consensus_and_icd":
        return consensus and icd_ok
    if args.gate == "sim_or_icd":
        return sim or icd_ok
    if args.gate == "sim_and_icd":
        return sim and icd_ok
    raise ValueError(f"unknown gate: {args.gate}")


def retrieved_diagnosis(neighbors, train_reports, args):
    top_ids = [cid for _, cid in neighbors]
    return aggregate_field(
        [train_reports[cid].get("Diagnosis", "") for cid in top_ids],
        args.agg,
        args.prior_objective,
    ).strip()


def entity_set_for_report(report):
    text = " ".join(report.values())
    return teeth(text) | icd(text)


def safe_append_text(base_text, ret_text, allowed_entities, order="append"):
    ret_text = ret_text.strip()
    if not ret_text:
        return base_text
    ret_entities = teeth(ret_text) | icd(ret_text)
    if ret_entities and not ret_entities.issubset(allowed_entities):
        return base_text
    if order == "prepend":
        return f"{ret_text} {base_text}"
    return f"{base_text} {ret_text}"


def filter_text_to_allowed_entities(text, allowed_entities):
    """Remove tooth/ICD tokens that would introduce new extracted entities."""
    out = str(text)

    def repl_icd(match):
        code = match.group(1).upper()
        return match.group(0) if code in allowed_entities else ""

    def repl_tooth(match):
        tooth = match.group(1)
        return match.group(0) if tooth in allowed_entities else ""

    out = re.sub(r"\b([A-Z]\d{2}\.?\d{0,3})\b", repl_icd, out)
    out = re.sub(r"\*?\b([1-8][1-8])\b", repl_tooth, out)
    out = re.sub(r"\s+", " ", out).strip()
    return out


def filtered_append_text(base_text, ret_text, allowed_entities, order="append"):
    filtered = filter_text_to_allowed_entities(ret_text, allowed_entities)
    if not filtered:
        return base_text
    if order == "prepend":
        return f"{filtered} {base_text}"
    return f"{base_text} {filtered}"


def merge_diagnosis(base_diag, ret_diag, variant):
    if not ret_diag:
        return base_diag
    if variant == "safe_append":
        # Only append retrieved wording when it does not introduce new tooth or
        # ICD entities beyond the ultra prior. This can help text overlap while
        # avoiding most extraction false positives.
        return safe_append_text(base_diag, ret_diag, teeth(base_diag) | icd(base_diag), order="append")
    if variant == "safe_prepend":
        return safe_append_text(base_diag, ret_diag, teeth(base_diag) | icd(base_diag), order="prepend")
    if variant == "whole_safe_append":
        return safe_append_text(base_diag, ret_diag, entity_set_for_report(ULTRA_REPORT), order="append")
    if variant == "whole_safe_prepend":
        return safe_append_text(base_diag, ret_diag, entity_set_for_report(ULTRA_REPORT), order="prepend")
    if variant == "filtered_append":
        return filtered_append_text(base_diag, ret_diag, teeth(base_diag) | icd(base_diag), order="append")
    if variant == "filtered_prepend":
        return filtered_append_text(base_diag, ret_diag, teeth(base_diag) | icd(base_diag), order="prepend")
    if variant == "whole_filtered_append":
        return filtered_append_text(base_diag, ret_diag, entity_set_for_report(ULTRA_REPORT), order="append")
    if variant == "whole_filtered_prepend":
        return filtered_append_text(base_diag, ret_diag, entity_set_for_report(ULTRA_REPORT), order="prepend")
    if variant == "replace_with_tail":
        return f"{ret_diag} {DIAG_ENTITY_TAIL}"
    if variant == "append_any":
        return f"{base_diag} {ret_diag}"
    raise ValueError(f"unknown hybrid variant: {variant}")


def apply_safe_retrieval_fields(pred, neighbors, train_reports, args, variant):
    if variant in (
        "safe_append",
        "safe_prepend",
        "whole_safe_append",
        "whole_safe_prepend",
        "filtered_append",
        "filtered_prepend",
        "whole_filtered_append",
        "whole_filtered_prepend",
        "replace_with_tail",
        "append_any",
    ):
        ret_diag = retrieved_diagnosis(neighbors, train_reports, args)
        pred["Diagnosis"] = merge_diagnosis(ULTRA_REPORT["Diagnosis"], ret_diag, variant)
        return

    allowed_entities = entity_set_for_report(ULTRA_REPORT)
    top_ids = [cid for _, cid in neighbors]
    if variant in ("safe_oral_append", "safe_diag_oral_append"):
        if variant == "safe_diag_oral_append":
            ret_diag = retrieved_diagnosis(neighbors, train_reports, args)
            pred["Diagnosis"] = merge_diagnosis(ULTRA_REPORT["Diagnosis"], ret_diag, "safe_append")
        ret_oral = aggregate_field(
            [train_reports[cid].get("Oral Check", "") for cid in top_ids],
            args.agg,
            args.prior_objective,
        )
        pred["Oral Check"] = safe_append_text(
            ULTRA_REPORT["Oral Check"],
            ret_oral,
            allowed_entities,
            order="append",
        )
        return

    raise ValueError(f"unknown hybrid variant: {variant}")


def hybrid_predictions(args, variant):
    cases = load_cases()
    train_features = load_cached_features(args.features, "Train-Labeled")
    val_features = load_cached_features(args.features, "Validation")
    train_features, val_features = normalize_train_val(train_features, val_features)

    train_reports = {cid: cases[cid] for cid in sorted(cases, key=int) if cid in train_features}
    preds = {}
    used = 0
    for cid in sorted(val_features, key=int):
        pred = dict(ULTRA_REPORT)
        neighbors = top_neighbors(val_features[cid], train_features, args.k)
        stats = neighbor_stats(neighbors, train_reports)
        if pass_gate(stats, args):
            apply_safe_retrieval_fields(pred, neighbors, train_reports, args, variant)
            used += 1
        preds[cid] = pred
    print(f"{variant}: used image Diagnosis gate on {used}/{len(preds)} validation cases")
    return preds


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--variant",
        choices=[
            "ultra",
            "safe_append",
            "safe_prepend",
            "whole_safe_append",
            "whole_safe_prepend",
            "filtered_append",
            "filtered_prepend",
            "whole_filtered_append",
            "whole_filtered_prepend",
            "safe_oral_append",
            "safe_diag_oral_append",
            "replace_with_tail",
            "append_any",
            "all",
        ],
        default="all",
    )
    ap.add_argument("--features", choices=["med3dvlm", "m3d", "ae", "hand"], default="med3dvlm")
    ap.add_argument("--k", type=int, default=3)
    ap.add_argument("--agg", choices=["top1", "medoid", "mode", "concat"], default="medoid")
    ap.add_argument("--prior-objective", choices=["bleu", "rouge", "bleu_rouge"], default="bleu_rouge")
    ap.add_argument(
        "--gate",
        choices=[
            "always",
            "never",
            "sim",
            "gap",
            "consensus",
            "icd_votes",
            "consensus_or_icd",
            "consensus_and_icd",
            "sim_or_icd",
            "sim_and_icd",
        ],
        default="consensus_or_icd",
    )
    ap.add_argument("--sim-threshold", type=float, default=0.0)
    ap.add_argument("--gap-threshold", type=float, default=0.0002)
    ap.add_argument("--consensus-threshold", type=float, default=0.0)
    ap.add_argument("--min-icd-votes", type=int, default=2)
    args = ap.parse_args()

    if args.variant in ("ultra", "all"):
        write_submission(ultra_predictions(), "ultra_prior_kiethuynh")

    variants = (
        [
            "safe_append",
            "safe_prepend",
            "whole_safe_append",
            "whole_safe_prepend",
            "filtered_append",
            "filtered_prepend",
            "whole_filtered_append",
            "whole_filtered_prepend",
            "safe_oral_append",
            "safe_diag_oral_append",
            "replace_with_tail",
            "append_any",
        ]
        if args.variant == "all"
        else [args.variant]
    )
    for variant in variants:
        if variant == "ultra":
            continue
        preds = hybrid_predictions(args, variant)
        stem = (
            f"ultra_{variant}_{args.features}_k{args.k}_{args.agg}_"
            f"{safe_name(args.prior_objective)}_{safe_name(args.gate)}"
        )
        write_submission(preds, stem)


if __name__ == "__main__":
    main()
