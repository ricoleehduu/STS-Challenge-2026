#!/usr/bin/env python3
"""
Self-contained offline eval harness for Task 3 (no external libs, no pretrained, no extra data).

Implements an APPROXIMATION of the challenge metrics for relative comparison + leave-one-out (LOO)
evaluation on the 50 labeled training cases, so we can iterate without spending Codabench submissions.

Metrics: BLEU-1..4 (smoothed), ROUGE-L, plus dental-specific extraction F1
(tooth FDI notations, ICD diagnosis codes). A proxy 'weighted_score' = mean of the components.
NOTE: official Weighted_Score weights are unknown; use this for RELATIVE comparison + calibration
against the known leaderboard medoid score (0.2463).
"""
import re, json
from collections import Counter
import pandas as pd
from config import CSV

TARGETS = ["Main appeal", "Present medical history", "Oral Check",
           "Diagnosis", "Treatment plan", "Handle", "Doctor advices"]

# ---------- tokenization ----------
def tok(s):
    return re.findall(r"[a-z0-9]+", str(s).lower())

# ---------- BLEU (sentence, smoothed method-1) ----------
def _ngram_counts(toks, n):
    return Counter(tuple(toks[i:i+n]) for i in range(len(toks)-n+1))

def bleu_n(cand, ref, nmax=4):
    c, r = tok(cand), tok(ref)
    if not c:
        return [0.0]*nmax
    precisions = []
    for n in range(1, nmax+1):
        cc, rc = _ngram_counts(c, n), _ngram_counts(r, n)
        overlap = sum(min(v, rc.get(g, 0)) for g, v in cc.items())
        total = max(1, sum(cc.values()))
        # add-1 smoothing
        p = (overlap + 1) / (total + 1) if n > 1 else overlap / total if total else 0.0
        precisions.append(p)
    # brevity penalty
    bp = 1.0 if len(c) > len(r) else (2.718281828 ** (1 - len(r)/max(1, len(c))))
    # cumulative BLEU-n = bp * geomean(p_1..p_n)
    out = []
    for n in range(1, nmax+1):
        ps = precisions[:n]
        if min(ps) <= 0:
            out.append(0.0)
        else:
            g = 1.0
            for p in ps: g *= p
            out.append(bp * g**(1.0/n))
    return out

# ---------- ROUGE-L ----------
def lcs(a, b):
    n, m = len(a), len(b)
    if n == 0 or m == 0: return 0
    prev = [0]*(m+1)
    for i in range(1, n+1):
        cur = [0]*(m+1); ai = a[i-1]
        for j in range(1, m+1):
            cur[j] = prev[j-1]+1 if ai == b[j-1] else max(prev[j], cur[j-1])
        prev = cur
    return prev[m]

def rouge_l(cand, ref):
    c, r = tok(cand), tok(ref)
    if not c or not r: return 0.0
    l = lcs(c, r)
    if l == 0: return 0.0
    p, rec = l/len(c), l/len(r)
    return 2*p*rec/(p+rec)

# ---------- dental extraction ----------
def teeth(s):
    s = str(s)
    # FDI permanent 11-48 and deciduous 51-85, optionally prefixed by '*'
    return set(re.findall(r"\*?\b([1-8][1-8])\b", s))

def icd(s):
    return set(m.upper() for m in re.findall(r"\b([A-Z]\d{2}\.?\d{0,3})\b", str(s)))

def prf(pred_set, gt_set):
    if not pred_set and not gt_set: return 1.0, 1.0, 1.0
    if not pred_set or not gt_set: return 0.0, 0.0, 0.0
    tp = len(pred_set & gt_set)
    p = tp/len(pred_set); r = tp/len(gt_set)
    f = 2*p*r/(p+r) if (p+r) else 0.0
    return p, r, f

# ---------- per-case GT aggregation ----------
def load_cases():
    """Return {case_id: {field: aggregated_text}} joining unique non-empty visit values."""
    df = pd.read_csv(CSV)
    cases = {}
    for cid, grp in df.groupby("Filename"):
        rec = {}
        for f in TARGETS:
            vals, seen = [], set()
            for v in grp[f].dropna():
                v = str(v).strip()
                if v and v not in seen:
                    seen.add(v); vals.append(v)
            rec[f] = " ".join(vals)
        cases[str(cid)] = rec
    return cases

# ---------- scoring ----------
def score_case(pred, gt):
    """pred, gt: dict field->text.
    Text metrics (BLEU/ROUGE) averaged over the 7 fields; dental extraction (tooth/ICD)
    computed once at case level over the concatenated record (avoids per-field empty-set inflation)."""
    agg = {"bleu_1":0,"bleu_2":0,"bleu_3":0,"bleu_4":0,"rouge_l":0}
    for f in TARGETS:
        b = bleu_n(pred.get(f,""), gt.get(f,""))
        agg["bleu_1"]+=b[0]; agg["bleu_2"]+=b[1]; agg["bleu_3"]+=b[2]; agg["bleu_4"]+=b[3]
        agg["rouge_l"]+=rouge_l(pred.get(f,""), gt.get(f,""))
    for k in agg: agg[k]/=len(TARGETS)
    pred_all = " ".join(pred.get(f,"") for f in TARGETS)
    gt_all   = " ".join(gt.get(f,"")   for f in TARGETS)
    agg["tooth_f1"] = prf(teeth(pred_all), teeth(gt_all))[2]
    agg["dx_f1"]    = prf(icd(pred_all),  icd(gt_all))[2]
    return agg

def evaluate(predictor, cases=None, verbose=True):
    """predictor: fn(held_out_id, train_cases_dict) -> pred dict field->text. LOO over all cases."""
    if cases is None: cases = load_cases()
    ids = list(cases)
    totals = Counter(); n = 0
    for cid in ids:
        train = {k:v for k,v in cases.items() if k != cid}
        pred = predictor(cid, train)
        sc = score_case(pred, cases[cid])
        for k,v in sc.items(): totals[k]+=v
        n += 1
    means = {k: totals[k]/n for k in totals}
    means["proxy_weighted_score"] = sum(means.values())/len(means)
    if verbose:
        print(f"LOO over {n} cases:")
        for k in ["bleu_1","bleu_2","bleu_3","bleu_4","rouge_l","tooth_f1","dx_f1","proxy_weighted_score"]:
            print(f"  {k:22s}: {means[k]:.4f}")
    return means

# ---------- predictors ----------
def make_medoid_predictor(cases):
    """Constant medoid per field (the Phase-0 baseline), computed from ALL cases."""
    field_pred = {}
    for f in TARGETS:
        vals = sorted({c[f] for c in cases.values() if c[f].strip()})
        toks = [tok(v) for v in vals]
        best, bs = vals[0] if vals else "", -1
        for i, ti in enumerate(toks):
            s = sum(rouge_l(vals[i], vals[j]) for j in range(len(vals)) if i!=j)/max(1,len(vals)-1)
            if s > bs: bs, best = s, vals[i]
        field_pred[f] = best
    return lambda cid, train: dict(field_pred)


if __name__ == "__main__":
    cases = load_cases()
    print("=== HIỆU CHUẨN: baseline medoid (LOO) — kỳ vọng gần 0.246 ===")
    evaluate(make_medoid_predictor(cases), cases)
