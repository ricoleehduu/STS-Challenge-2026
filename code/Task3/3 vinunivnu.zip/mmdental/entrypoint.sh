#!/usr/bin/env bash
set -euo pipefail

exec python /opt/mmdental/run_task3.py "$@"
