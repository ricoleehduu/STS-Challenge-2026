#!/usr/bin/env python3
"""
Cache Med3DVLM image embeddings for STSR Task 3 CBCT volumes.

This script is intentionally defensive because Med3DVLM uses custom Hugging Face
code and the public model variants expose slightly different attribute names.
It first tries to load the model with trust_remote_code, then looks for a vision
encoder method/module and pools the returned features into one vector per case.

Typical use:
  CUDA_VISIBLE_DEVICES=0 python med3dvlm_embed.py --splits Train-Labeled Validation

If this cannot load the partial model, download the full model or use
retrieval_projection.py with --features m3d while the Med3DVLM download finishes.
"""
import argparse
import os
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

from config import HF_HOME, MED3DVLM_FEATS, MED3DVLM_MODEL, case_dirs


def parse_shape(text):
    vals = [int(x.strip()) for x in str(text).split(",") if x.strip()]
    if len(vals) != 3:
        raise argparse.ArgumentTypeError("shape must be D,H,W, e.g. 128,256,256")
    return tuple(vals)


def load_volume(nii_path: Path, target_shape, layout="bcdhw"):
    import nibabel as nib

    img = nib.load(str(nii_path))
    vol = np.asarray(img.dataobj, dtype=np.float32)
    finite = np.isfinite(vol)
    if not finite.all():
        vol = np.where(finite, vol, 0.0)

    lo, hi = np.percentile(vol, [0.5, 99.5])
    if hi <= lo:
        lo, hi = float(vol.min()), float(vol.max())
    vol = np.clip(vol, lo, hi)
    vol = (vol - lo) / (hi - lo + 1e-8)

    x = torch.from_numpy(vol)[None, None]  # B,C,D,H,W as a generic 3D tensor.
    x = F.interpolate(x, size=target_shape, mode="trilinear", align_corners=False)
    if layout == "bchwd":
        x = x.permute(0, 1, 3, 4, 2).contiguous()
    return x


def load_hf_model(model_dir, device, dtype, load_4bit=False):
    os.environ.setdefault("HF_HOME", str(HF_HOME))
    from transformers import AutoModel, AutoModelForCausalLM

    kwargs = {
        "trust_remote_code": True,
        "local_files_only": True,
        "torch_dtype": dtype,
    }
    if load_4bit:
        from transformers import BitsAndBytesConfig

        kwargs["quantization_config"] = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=dtype,
            bnb_4bit_use_double_quant=True,
        )
        kwargs["device_map"] = "auto"

    errors = []
    for cls in (AutoModel, AutoModelForCausalLM):
        try:
            model = cls.from_pretrained(str(model_dir), **kwargs)
            if not load_4bit:
                model = model.to(device)
            model.eval()
            return model
        except Exception as exc:  # noqa: BLE001
            errors.append(f"{cls.__name__}: {type(exc).__name__}: {exc}")
    joined = "\n".join(errors)
    raise RuntimeError(
        "Could not load Med3DVLM from local files. If you downloaded only "
        "vision_encoder.safetensors, the custom architecture may still need the "
        "full repository files. Loader errors:\n" + joined
    )


def resolve_attr(obj, dotted):
    cur = obj
    for part in dotted.split("."):
        if not hasattr(cur, part):
            return None
        cur = getattr(cur, part)
    return cur


def unwrap_output(out):
    if isinstance(out, dict):
        for key in ("image_embeds", "last_hidden_state", "hidden_states", "logits"):
            if key in out:
                return out[key]
    if hasattr(out, "image_embeds"):
        return out.image_embeds
    if hasattr(out, "last_hidden_state"):
        return out.last_hidden_state
    if isinstance(out, (tuple, list)):
        return out[0]
    return out


def pool_features(feat, pool="mean"):
    feat = unwrap_output(feat)
    if isinstance(feat, (tuple, list)):
        feat = unwrap_output(feat)
    if not torch.is_tensor(feat):
        raise TypeError(f"vision encoder returned unsupported type: {type(feat)}")
    feat = feat.float()
    if feat.ndim == 2:
        return feat[0]
    if feat.ndim == 3:
        if pool == "cls":
            return feat[0, 0]
        return feat[0].mean(dim=0)
    if feat.ndim >= 4:
        dims = tuple(range(2, feat.ndim))
        return feat.mean(dim=dims)[0]
    return feat.flatten()


@torch.no_grad()
def encode_image(model, x, pool="mean"):
    candidates = [
        "encode_image",
        "get_image_features",
        "vision_encoder",
        "vision_tower",
        "model.vision_encoder",
        "model.vision_tower",
        "base_model.vision_encoder",
        "base_model.vision_tower",
    ]
    errors = []
    for name in candidates:
        obj = resolve_attr(model, name)
        if obj is None:
            continue
        try:
            if callable(obj):
                return pool_features(obj(x), pool=pool)
            return pool_features(obj(x), pool=pool)
        except Exception as exc:  # noqa: BLE001
            errors.append(f"{name}: {type(exc).__name__}: {exc}")

    if hasattr(model, "get_vision_tower"):
        try:
            tower = model.get_vision_tower()
            return pool_features(tower(x), pool=pool)
        except Exception as exc:  # noqa: BLE001
            errors.append(f"get_vision_tower(): {type(exc).__name__}: {exc}")

    raise RuntimeError(
        "Could not find a usable vision encoder on the loaded model. Tried: "
        + ", ".join(candidates)
        + "\nErrors:\n"
        + "\n".join(errors)
    )


def case_nii(case_dir: Path):
    direct = case_dir / f"{case_dir.name}.nii.gz"
    if direct.exists():
        return direct
    return next(case_dir.glob("*.nii.gz"))


def embed_split(model, split, args, device):
    out = {}
    for case in case_dirs(split):
        cache = MED3DVLM_FEATS / f"{split}_{case.name}.npy"
        if cache.exists() and not args.overwrite:
            out[case.name] = np.load(cache)
            continue
        x = load_volume(case_nii(case), args.target_shape, layout=args.input_layout)
        x = x.to(device=device, dtype=args.dtype)
        emb = encode_image(model, x, pool=args.pool)
        vec = emb.detach().cpu().numpy().astype(np.float32)
        vec = vec / (np.linalg.norm(vec) + 1e-8)
        np.save(cache, vec)
        out[case.name] = vec
        print(f"  emb {split}/{case.name}: dim={vec.shape[0]}", flush=True)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=Path, default=MED3DVLM_MODEL)
    ap.add_argument("--splits", nargs="+", default=["Train-Labeled", "Validation"])
    ap.add_argument("--target-shape", type=parse_shape, default=(128, 256, 256), help="D,H,W before optional layout permute")
    ap.add_argument("--input-layout", choices=["bcdhw", "bchwd"], default="bcdhw")
    ap.add_argument("--pool", choices=["mean", "cls"], default="mean")
    ap.add_argument("--dtype", choices=["float16", "bfloat16", "float32"], default="float16")
    ap.add_argument("--load-4bit", action="store_true", help="load full VLM in 4-bit if the full model is present")
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--overwrite", action="store_true")
    args = ap.parse_args()

    dtype_map = {
        "float16": torch.float16,
        "bfloat16": torch.bfloat16,
        "float32": torch.float32,
    }
    args.dtype = dtype_map[args.dtype]
    device = torch.device(args.device if torch.cuda.is_available() or args.device == "cpu" else "cpu")

    MED3DVLM_FEATS.mkdir(parents=True, exist_ok=True)
    print(f"model: {args.model}")
    print(f"cache: {MED3DVLM_FEATS}")
    model = load_hf_model(args.model, device=device, dtype=args.dtype, load_4bit=args.load_4bit)
    for split in args.splits:
        embed_split(model, split, args, device)


if __name__ == "__main__":
    main()
