"""Shared paths for STSR Task 3 scripts.

Set MMDENTAL_ROOT on a new machine if the default paths do not match.
"""
import os
from pathlib import Path


PROJECT_DIR = Path(__file__).resolve().parent
SERVER_ROOT = Path("/media02/lnnam01/miccai_stsr")
SERVER_DATA = SERVER_ROOT / "data_downloads" / "mmdental_drive"
SERVER_MODEL_DIR = SERVER_ROOT / "src_code" / "models"
SERVER_HF_HOME = SERVER_MODEL_DIR / "hf_cache"
SERVER_QWEN3VL_MODEL = SERVER_MODEL_DIR / "Qwen3-VL-8B-Instruct"


def _env_path(name, default):
    value = os.environ.get(name)
    return Path(value).expanduser() if value else Path(default).expanduser()


def _default_root():
    value = os.environ.get("MMDENTAL_ROOT")
    if value:
        return Path(value).expanduser()

    candidates = [
        SERVER_ROOT,
        Path("/mnt/disk1/backup_user/nhi.nny/miccai"),
        PROJECT_DIR.parent.parent,
        PROJECT_DIR.parent,
    ]
    for candidate in candidates:
        if (candidate / "sts26_data").exists() or (candidate / "src_code").exists():
            return candidate
    return PROJECT_DIR.parent


ROOT = _default_root()
DATA = _env_path("MMDENTAL_DATA", SERVER_DATA if ROOT == SERVER_ROOT else ROOT / "sts26_data")
OUT = _env_path("MMDENTAL_OUT", ROOT / "task3" / "outputs")
FEATURES = _env_path("MMDENTAL_FEATURES", ROOT / "task3" / "features")
M3D_FEATS = _env_path("MMDENTAL_M3D_FEATS", ROOT / "task3" / "m3d_feats")
MED3DVLM_FEATS = _env_path("MMDENTAL_MED3DVLM_FEATS", ROOT / "task3" / "med3dvlm_feats")
CONCEPT_FEATS = _env_path("MMDENTAL_CONCEPT_FEATS", ROOT / "task3" / "concept_feats")
VOL_CACHE = _env_path("MMDENTAL_VOL_CACHE", ROOT / "task3" / "vol_cache")
AE_FEATS = _env_path("MMDENTAL_AE_FEATS", ROOT / "task3" / "ae_feats")
AE_CKPT = _env_path("MMDENTAL_AE_CKPT", ROOT / "task3" / "ae.pt")
SSL_FEATS = _env_path("MMDENTAL_SSL_FEATS", ROOT / "task3" / "ssl_contrast_feats")
SSL_CKPT = _env_path("MMDENTAL_SSL_CKPT", ROOT / "task3" / "ssl_contrast.pt")
MODEL_DIR = _env_path("MMDENTAL_MODEL_DIR", SERVER_MODEL_DIR if ROOT == SERVER_ROOT else ROOT / "src_code" / "models")
HF_HOME = _env_path("HF_HOME", SERVER_HF_HOME if MODEL_DIR == SERVER_MODEL_DIR else MODEL_DIR / "hf_cache")
CSV = _env_path("MMDENTAL_TRAIN_CSV", DATA / "Train-Labeled" / "Train-Labeled.csv")
QWEN3VL_MODEL = _env_path("QWEN3VL_MODEL", SERVER_QWEN3VL_MODEL if MODEL_DIR == SERVER_MODEL_DIR else MODEL_DIR / "Qwen3-VL-8B-Instruct")
QWEN3VL_ADAPTER = _env_path("QWEN3VL_ADAPTER", ROOT / "task3" / "qwen3vl_lora")
MED3DVLM_MODEL = _env_path("MED3DVLM_MODEL", MODEL_DIR / "Med3DVLM-Qwen-2.5-7B")
EXPECTED_VAL_CASES = int(os.environ.get("MMDENTAL_EXPECTED_VAL_CASES", "0"))


SPLIT_ALIASES = {
    "Train-Labeled": ("Train-Labeled",),
    "Train-Unlabeled": ("Train-Unlabeled", "Train-Unlabel"),
    "Validation": ("Validation", "Validation-Public"),
}


def split_dir(split):
    """Return the data directory for a canonical split name."""
    names = SPLIT_ALIASES.get(split, (split,))
    for name in names:
        path = DATA / name
        if path.exists():
            return path
    return DATA / names[0]


def case_dirs(split):
    """Return numeric case directories for a split, sorted by case id."""
    path = split_dir(split)
    return sorted([p for p in path.iterdir() if p.is_dir() and p.name.isdigit()], key=lambda p: int(p.name))


def validation_case_ids(require_expected=True):
    ids = [p.name for p in case_dirs("Validation")]
    if require_expected and EXPECTED_VAL_CASES and len(ids) != EXPECTED_VAL_CASES:
        raise RuntimeError(
            f"Expected {EXPECTED_VAL_CASES} validation case directories under {split_dir('Validation')}, "
            f"but found {len(ids)}. Check whether one case folder/zip was not downloaded or extracted."
        )
    return ids
