#!/usr/bin/env python3
"""Container entrypoint for STSR 2026 Task 3 inference.

The default method reproduces the submitted 0.3134 configuration:
Med3DVLM embeddings + safe Diagnosis append, k=1/top1, BLEU-ROUGE prior.
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path


APP_DIR = Path("/opt/mmdental")
FIELDS = [
    "Main appeal",
    "Present medical history",
    "Oral Check",
    "Diagnosis",
    "Treatment plan",
    "Handle",
    "Doctor advices",
]


def command(cmd: list[str], env: dict[str, str]) -> None:
    print("[command] " + " ".join(cmd), flush=True)
    subprocess.run(cmd, cwd=APP_DIR, env=env, check=True)


def resolve_split(data_dir: Path, names: tuple[str, ...]) -> Path | None:
    for name in names:
        path = data_dir / name
        if path.is_dir():
            return path
    return None


def numeric_cases(split_dir: Path) -> list[Path]:
    return sorted(
        [path for path in split_dir.iterdir() if path.is_dir() and path.name.isdigit()],
        key=lambda path: int(path.name),
    )


def case_nii(case_dir: Path) -> Path:
    direct = case_dir / f"{case_dir.name}.nii.gz"
    if direct.is_file():
        return direct
    files = sorted(case_dir.glob("*.nii.gz"))
    if not files:
        raise FileNotFoundError(f"No .nii.gz file under {case_dir}")
    return files[0]


def verify_source(validation_dir: Path) -> list[str]:
    cases = numeric_cases(validation_dir)
    if not cases:
        raise RuntimeError(f"No numeric case directories found under {validation_dir}")

    source = case_nii(cases[0])
    try:
        import nibabel as nib

        image = nib.load(str(source))
        print(
            "[source] CBCT loaded successfully: "
            f"case={cases[0].name} path={source} shape={tuple(image.shape)} "
            f"voxel_spacing={tuple(round(float(x), 4) for x in image.header.get_zooms()[:3])}",
            flush=True,
        )
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError(f"Could not load CBCT source {source}: {exc}") from exc

    ids = [path.name for path in cases]
    print(f"[source] validation_cases={len(ids)} first_ids={','.join(ids[:5])}", flush=True)
    return ids


def feature_files_present(cache_dir: Path, split: str, case_ids: list[str]) -> bool:
    return all((cache_dir / f"{split}_{case_id}.npy").is_file() for case_id in case_ids)


def ensure_model(model_dir: Path, repo_id: str, allow_download: bool) -> Path:
    """Return a full local Med3DVLM snapshot, downloading public weights if allowed."""
    if (model_dir / "config.json").is_file():
        print(f"[model] using mounted/local checkpoint: {model_dir}", flush=True)
        return model_dir
    if not allow_download:
        raise FileNotFoundError(
            f"Med3DVLM checkpoint is missing at {model_dir}. Mount a full model directory "
            "or omit --no-download-model so the public checkpoint can be downloaded."
        )

    print(f"[model] downloading public checkpoint {repo_id} to {model_dir}", flush=True)
    print("[model] this needs approximately 35 GB of free runtime disk and Internet access", flush=True)
    try:
        from huggingface_hub import snapshot_download

        snapshot_download(repo_id=repo_id, local_dir=str(model_dir))
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError(
            "Could not download Med3DVLM. Mount the full checkpoint at "
            f"{model_dir}, or provide Internet/HF_TOKEN access. Original error: {exc}"
        ) from exc
    if not (model_dir / "config.json").is_file():
        raise RuntimeError(f"Downloaded model snapshot at {model_dir} has no config.json")
    return model_dir


def expected_prediction_json(run_dir: Path) -> Path:
    matches = sorted(run_dir.glob("predictions_*.json"), key=lambda path: path.stat().st_mtime)
    if not matches:
        raise FileNotFoundError(f"No predictions JSON produced under {run_dir}")
    return matches[-1]


def publish_prediction(prediction_json: Path, output_dir: Path, expected_ids: list[str]) -> None:
    payload = json.loads(prediction_json.read_text(encoding="utf-8"))
    if sorted(payload, key=int) != sorted(expected_ids, key=int):
        raise RuntimeError(
            f"Prediction case IDs do not match input. expected={len(expected_ids)} got={len(payload)}"
        )
    for case_id, record in payload.items():
        missing = [field for field in FIELDS if field not in record]
        if missing:
            raise RuntimeError(f"Case {case_id} misses required fields: {missing}")

    output_dir.mkdir(parents=True, exist_ok=True)
    final_json = output_dir / "predictions.json"
    final_zip = output_dir / "submission_task3.zip"
    shutil.copy2(prediction_json, final_json)
    with zipfile.ZipFile(final_zip, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.write(final_json, "predictions.json")

    with zipfile.ZipFile(final_zip) as archive:
        if archive.namelist() != ["predictions.json"]:
            raise RuntimeError("Submission zip must contain exactly predictions.json at the archive root")
    print(f"[output] predictions={final_json}", flush=True)
    print(f"[output] submission_zip={final_zip} cases={len(payload)}", flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-dir", type=Path, default=Path("/input"))
    parser.add_argument("--output-dir", type=Path, default=Path("/output"))
    parser.add_argument("--feature-cache", type=Path, default=Path("/cache"))
    parser.add_argument("--model-dir", type=Path, default=Path("/models/Med3DVLM-Qwen-2.5-7B"))
    parser.add_argument("--model-id", default="MagicXin/Med3DVLM-Qwen-2.5-7B")
    parser.add_argument(
        "--method",
        choices=["exact_829030", "ultra_prior"],
        default="exact_829030",
        help="exact_829030 reproduces the submitted Med3DVLM k=1/top1 run; ultra_prior is model-free sanity fallback.",
    )
    parser.add_argument(
        "--no-download-model",
        action="store_true",
        help="Fail if the checkpoint is not mounted locally instead of downloading the public Med3DVLM snapshot.",
    )
    parser.add_argument("--force-embed", action="store_true", help="Recompute embeddings even when the cache is complete.")
    args = parser.parse_args()

    data_dir = args.input_dir.resolve()
    validation_dir = resolve_split(data_dir, ("Validation", "Validation-Public"))
    if validation_dir is None:
        raise FileNotFoundError(
            f"Expected {data_dir}/Validation or {data_dir}/Validation-Public. "
            "Mount the official data root, not an individual NIfTI file."
        )
    validation_ids = verify_source(validation_dir)

    # Keep intermediate predictions out of the mounted result directory. The
    # evaluator-visible directory should contain only the final JSON and ZIP.
    run_dir = Path("/tmp/mmdental_runtime")
    if run_dir.exists():
        shutil.rmtree(run_dir)
    run_dir.mkdir(parents=True)
    args.feature_cache.mkdir(parents=True, exist_ok=True)

    env = os.environ.copy()
    env.update(
        {
            "MMDENTAL_DATA": str(data_dir),
            "MMDENTAL_OUT": str(run_dir),
            "MMDENTAL_MED3DVLM_FEATS": str(args.feature_cache.resolve()),
            "HF_HOME": "/tmp/hf_cache",
        }
    )

    if args.method == "exact_829030":
        train_dir = resolve_split(data_dir, ("Train-Labeled",))
        if train_dir is None or not (train_dir / "Train-Labeled.csv").is_file():
            raise FileNotFoundError(
                "exact_829030 requires /input/Train-Labeled/Train-Labeled.csv and its numeric case directories."
            )
        train_ids = [path.name for path in numeric_cases(train_dir)]
        cached = feature_files_present(args.feature_cache, "Train-Labeled", train_ids) and feature_files_present(
            args.feature_cache, "Validation", validation_ids
        )
        if args.force_embed or not cached:
            model_dir = ensure_model(args.model_dir, args.model_id, not args.no_download_model)
            env["MED3DVLM_MODEL"] = str(model_dir.resolve())
            print("[embed] cache incomplete; creating Med3DVLM embeddings", flush=True)
            command(
                [
                    sys.executable,
                    "med3dvlm_embed.py",
                    "--model",
                    str(model_dir),
                    "--splits",
                    "Train-Labeled",
                    "Validation",
                    "--target-shape",
                    "128,256,256",
                    "--input-layout",
                    "bcdhw",
                    "--pool",
                    "mean",
                    "--load-4bit",
                ],
                env,
            )
        else:
            print("[embed] complete feature cache found; reusing it", flush=True)

        command(
            [
                sys.executable,
                "max_accuracy_hybrid.py",
                "--variant",
                "safe_append",
                "--features",
                "med3dvlm",
                "--k",
                "1",
                "--agg",
                "top1",
                "--prior-objective",
                "bleu_rouge",
                "--gate",
                "consensus_or_icd",
                "--min-icd-votes",
                "2",
            ],
            env,
        )
    else:
        command([sys.executable, "max_accuracy_hybrid.py", "--variant", "ultra"], env)

    publish_prediction(expected_prediction_json(run_dir), args.output_dir.resolve(), validation_ids)


if __name__ == "__main__":
    main()
