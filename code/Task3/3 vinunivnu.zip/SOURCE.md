# vinunivnu — STS 2026 Task 3 submission (`mmdental`)

This package was extracted from the Docker image that team **vinunivnu** submitted for
STS 2026 Task 3. The original archive is a 3.1 GB OCI image export named `vinunivnu.tar.gz`:

- Google Drive: <https://drive.google.com/file/d/1xFapoEOu8BOPA6b9mE0qQ37X9KjOJbCv/view?usp=sharing>
- size: 3,363,717,233 bytes, downloaded 2026-09-21

Only the team's own files were kept here; the remaining ~3.1 GB of the image is a
`pytorch/pytorch:2.5.1-cuda12.1-cudnn9-runtime` environment (CUDA libraries, PyTorch,
the pip packages listed in `requirements-runtime.txt`) and is **not** redistributed.

## Contents

| path in this package | origin in the image | notes |
| --- | --- | --- |
| `mmdental/entrypoint.sh` | `/opt/mmdental/entrypoint.sh` | image `ENTRYPOINT`, runs `run_task3.py` |
| `mmdental/run_task3.py` | `/opt/mmdental/run_task3.py` | container entrypoint for Task 3 inference |
| `mmdental/config.py` | `/opt/mmdental/config.py` | path configuration (`MMDENTAL_ROOT`) |
| `mmdental/eval_harness.py` | `/opt/mmdental/eval_harness.py` | offline approximation of the challenge metrics (BLEU-1..4, ROUGE-L, FDI/ICD extraction F1) |
| `mmdental/med3dvlm_embed.py` | `/opt/mmdental/med3dvlm_embed.py` | caches Med3DVLM image embeddings for the CBCT volumes |
| `mmdental/retrieval_projection.py` | `/opt/mmdental/retrieval_projection.py` | metric-trained CBCT retrieval + field-wise prediction |
| `mmdental/max_accuracy_hybrid.py` | `/opt/mmdental/max_accuracy_hybrid.py` | builds the submitted report (clinical prior + conservative image-based `Diagnosis` correction) |
| `requirements-runtime.txt` | `/tmp/requirements-runtime.txt` | pip packages installed on top of the base image |
| `image/index.json`, `image/manifest.json`, `image/image-config.json` | OCI index / manifest / image config blobs | entrypoint, workdir, env, layer list |
| `image/provenance.json`, `image/attestation-manifest.json` | SLSA v1 provenance attestation | build source and revision (see below) |

The default entrypoint reproduces the submitted configuration: Med3DVLM embeddings +
safe `Diagnosis` append, `k=1`/top-1, BLEU-ROUGE prior (score 0.3134 as documented in
`run_task3.py`).

## Build provenance

From the SLSA provenance attestation embedded in the image:

- source repository: `https://github.com/NhiNguyen34/sts26-task3-mmdental.git` (not publicly accessible as of 2026-09-21)
- source revision: `4def33f061f8c4ef293ee531ba77133fcfdee8d6`
- build context directory: `vinunivnu_submission`
- builder: BuildKit (`dockerfile.v0`), base image `pytorch/pytorch@sha256:831247999fbf7e08f61b3e39f6d77ee434f38f6f07f769d00db451e853878067`
- image created: 2026-07-16T15:58:10Z, platform `linux/amd64`

## Image layers (compressed)

| # | digest (`sha256:`) | size | content |
| --- | --- | --- | --- |
| 1 | `7478e0ac…` | 30.4 MB | Ubuntu 22.04 base |
| 2 | `ea22b8ac…` | 7.2 MB | development headers, OpenSSL |
| 3 | `7afb8cf0…` | 3.11 GB | CUDA 12.1 / PyTorch 2.5.1 conda environment |
| 4 | `4f4fb700…` | 32 B | empty layer marker |
| 5 | `afa41b9a…` | 99 B | empty layer marker |
| 6 | `20b43ae7…` | 116 B | creates `/opt/mmdental` |
| 7 | `4aad8379…` | 308 B | `COPY requirements-runtime.txt /tmp/` |
| 8 | `53f09ce9…` | 222.5 MB | pip install of the runtime requirements |
| 9 | `7c585fb0…` | 14.1 KB | `config.py`, `eval_harness.py`, `retrieval_projection.py`, `med3dvlm_embed.py`, `max_accuracy_hybrid.py` |
| 10 | `6a5bdbd3…` | 3.6 KB | `run_task3.py`, `entrypoint.sh` (+`chmod +x`) |
| 11 | `4f4fb700…` | 32 B | empty layer marker |

## Runtime notes

- Model weights (Qwen3-VL-8B-Instruct, Med3DVLM and other feature extractors) are **not** inside
  the image; `config.py` expects them under a `models/` directory reachable via the
  `MMDENTAL_ROOT` environment variable.
- The image targets `linux/amd64` with an NVIDIA runtime (`nvidia_driver` label, CUDA 12.1).
