# STSR Task 3 Inference

This directory contains the inference code for STSR 2026 Task 3.

## Requirements

- Linux
- Python 3.12
- The required Python packages for the inference scripts
- Access to the Qwen VLM, embedding, and reranking model services

## Configuration

Set the following environment variables before running:

```bash
export QWEN_BASE_URL="..."
export QWEN_MODEL="..."
export QWEN_API_KEY="..."
export EMBEDDING_BASE_URL="..."
export EMBEDDING_MODEL="..."
export EMBEDDING_API_KEY="..."
export RERANK_BASE_URL="..."
export RERANK_MODEL="..."
export RERANK_API_KEY="..."
```

Example model configuration:

```bash
export QWEN_MODEL="Qwen3.6-35B-A3B"
export EMBEDDING_MODEL="Qwen3-Embedding-4B"
export RERANK_MODEL="Qwen3-Reranker-4B"
```

The model services may be deployed locally with vLLM or provided through compatible API endpoints.

API keys are read only from environment variables and are not stored in this directory.

## Input and Output

The parent directory must provide the competition input data under:

```text
input/Train-Labeled/
input/Validation/
```

Generated files are written to `output/`, including the final prediction archive.

## Run

From the parent directory containing `code/` and `input/`, run:

```bash
python code/pipeline.py
```

To continue an interrupted run:

```bash
python code/pipeline.py --resume
```

The final submission archive is generated as `output/predictions.zip`.
