#!/usr/bin/env python3
import argparse
import json
import re
import zipfile
from pathlib import Path

from case_utils import case_sort_key

FIELDS = {
    "Main appeal",
    "Present medical history",
    "Oral Check",
    "Diagnosis",
    "Treatment plan",
    "Handle",
    "Doctor advices",
}
VALID_FDI = [f"{quadrant}{position}" for quadrant in range(1, 5) for position in range(1, 9)]


def tooth_set(record):
    text = " ".join(record.values())
    return {
        tooth
        for tooth in VALID_FDI
        if re.search(rf"(?<!\d){tooth}(?!\d)", text)
    }


def location_conflict(record):
    appeal = record["Main appeal"]
    history = record["Present medical history"]
    pairs = [(r"upper|maxillary", r"lower|mandibular"), (r"left", r"right")]
    return any(
        (re.search(left, appeal, re.I) and re.search(right, history, re.I))
        or (re.search(right, appeal, re.I) and re.search(left, history, re.I))
        for left, right in pairs
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("submission", type=Path)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()

    errors = []
    expected = {
        path.name
        for path in (args.root / "input" / "Validation").iterdir()
        if path.is_dir()
    }
    if not args.submission.is_file():
        raise SystemExit(f"Missing submission: {args.submission}")
    with zipfile.ZipFile(args.submission) as bundle:
        members = bundle.namelist()
        if members != ["predictions.json"]:
            errors.append(f"ZIP members must be exactly ['predictions.json'], got {members}")
        bad_crc = bundle.testzip()
        if bad_crc:
            errors.append(f"ZIP CRC failure: {bad_crc}")
        raw = bundle.read("predictions.json")

    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        errors.append(f"predictions.json is not UTF-8: {exc}")
        text = "{}"
    if text.startswith("\ufeff"):
        errors.append("predictions.json must not contain a UTF-8 BOM")
    try:
        predictions = json.loads(text)
    except json.JSONDecodeError as exc:
        errors.append(f"Invalid JSON: {exc}")
        predictions = {}

    if not isinstance(predictions, dict):
        errors.append("JSON root must be an object")
        predictions = {}
    actual = set(predictions)
    if actual != expected:
        errors.append(
            f"Case IDs differ: missing={sorted(expected-actual, key=case_sort_key)}, "
            f"extra={sorted(actual-expected, key=case_sort_key)}"
        )
    for case_id, record in predictions.items():
        if not isinstance(case_id, str) or not case_id.strip():
            errors.append(f"Invalid case ID: {case_id!r}")
        if not isinstance(record, dict):
            errors.append(f"Case {case_id} must map to an object")
            continue
        if set(record) != FIELDS:
            errors.append(
                f"Case {case_id} fields differ: missing={FIELDS-set(record)}, "
                f"extra={set(record)-FIELDS}"
            )
        for field, value in record.items():
            if not isinstance(value, str):
                errors.append(f"Case {case_id} field {field!r} is not a string")
            elif not value.strip():
                errors.append(f"Case {case_id} field {field!r} is empty")
            elif "\x00" in value:
                errors.append(f"Case {case_id} field {field!r} contains NUL")
            elif re.search(r"\(\s*\)", value):
                errors.append(f"Case {case_id} field {field!r} contains empty parentheses")
            elif "\\n" in value:
                errors.append(f"Case {case_id} field {field!r} contains escaped newlines")
        if set(record) == FIELDS:
            if location_conflict(record):
                errors.append(f"Case {case_id} has conflicting locations in appeal and history")
            history = record["Present medical history"].strip()
            if history.lower().startswith("no additional information available.") and history != (
                "No additional information available."
            ):
                errors.append(f"Case {case_id} appends history after a no-information statement")

    print(f"submission={args.submission}")
    print(f"zip_bytes={args.submission.stat().st_size}")
    print(f"json_bytes={len(raw)}")
    print(f"cases={len(predictions)} expected={len(expected)}")
    print(f"fields_per_case={len(FIELDS)}")
    if errors:
        print("VALIDATION_FAILED")
        for error in errors:
            print(f"- {error}")
        raise SystemExit(1)
    print("VALIDATION_OK")


if __name__ == "__main__":
    main()
