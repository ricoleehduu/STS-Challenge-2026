#!/usr/bin/env python3
import argparse
import sys
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "vendor"))

import nibabel as nib
import numpy as np
from PIL import Image, ImageDraw, ImageFont

from case_utils import case_directories, find_volume


PLANE_CONFIG = {
    "sagittal": (0, 0.10, 0.90),
    "coronal": (1, 0.32, 0.92),
    "axial": (2, 0.25, 0.78),
}


def normalize(array, low, high):
    array = np.nan_to_num(array.astype(np.float32), nan=low, posinf=high, neginf=low)
    scaled = np.clip((array - low) / max(high - low, 1.0), 0, 1)
    return (scaled * 255).astype(np.uint8)


def make_case_sheets(source, output_dir):
    image = nib.load(str(source))
    shape = image.shape[:3]
    volume = np.asanyarray(image.dataobj)
    steps = tuple(max(1, int(np.ceil(size / 80))) for size in shape)
    sample = volume[:: steps[0], :: steps[1], :: steps[2]]
    finite = sample[np.isfinite(sample)]
    low, high = np.percentile(finite, [0.5, 99.5])
    font = ImageFont.load_default()

    output_dir.mkdir(parents=True, exist_ok=True)
    outputs = []
    for plane_name, (axis, start, stop) in PLANE_CONFIG.items():
        indices = np.rint(np.linspace(start, stop, 16) * (shape[axis] - 1)).astype(int)
        sheet = Image.new("RGB", (4 * 256, 4 * 256), "black")
        for tile_index, slice_index in enumerate(indices):
            slices = [slice(None)] * 3
            slices[axis] = int(slice_index)
            array = volume[tuple(slices)]
            array = np.rot90(normalize(array, low, high))
            tile = Image.fromarray(array).resize(
                (256, 256), Image.Resampling.BILINEAR
            ).convert("RGB")
            draw = ImageDraw.Draw(tile)
            label = f"{plane_name.title()} {slice_index}/{shape[axis]}"
            draw.rectangle((0, 0, 150, 20), fill=(0, 0, 0))
            draw.text((4, 3), label, fill=(255, 255, 255), font=font)
            if plane_name in ("coronal", "axial"):
                draw.text((4, 122), "R", fill=(255, 255, 0), font=font)
                draw.text((244, 122), "L", fill=(255, 255, 0), font=font)
            else:
                draw.text((4, 122), "P", fill=(255, 255, 0), font=font)
                draw.text((244, 122), "A", fill=(255, 255, 0), font=font)
            draw.text((124, 24), "S", fill=(255, 255, 0), font=font)
            draw.text((124, 242), "I", fill=(255, 255, 0), font=font)
            sheet.paste(tile, ((tile_index % 4) * 256, (tile_index // 4) * 256))
        destination = output_dir / f"{plane_name}.jpg"
        sheet.save(destination, quality=94, subsampling=0)
        outputs.append(destination)
    return outputs


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--workers", type=int, default=6)
    parser.add_argument(
        "--splits", nargs="+", default=["Train-Labeled", "Validation"]
    )
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    jobs = []
    for split in args.splits:
        for case_dir in case_directories(ROOT / split):
            source = find_volume(case_dir)
            output_dir = ROOT / "diagnostic_sheets" / split / case_dir.name
            complete = all(
                (output_dir / f"{plane}.jpg").is_file() for plane in PLANE_CONFIG
            )
            if source is not None and (args.force or not complete):
                jobs.append((source, output_dir))

    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        futures = {
            pool.submit(make_case_sheets, source, output_dir): output_dir
            for source, output_dir in jobs
        }
        for index, future in enumerate(as_completed(futures), start=1):
            output_dir = futures[future]
            future.result()
            print(f"[{index}/{len(jobs)}] {output_dir.relative_to(ROOT)}", flush=True)


if __name__ == "__main__":
    main()
