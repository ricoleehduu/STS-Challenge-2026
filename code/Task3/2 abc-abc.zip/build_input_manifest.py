#!/usr/bin/env python3
import hashlib
import json
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(4 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main():
    paths = []
    for pattern in ["input/**/*.nii.gz", "input/*.csv", "code/*.py", "config/*.json"]:
        paths.extend(path for path in ROOT.glob(pattern) if path.is_file())
    paths.extend(
        path for path in [ROOT / "requirements.txt", ROOT / "README.md", ROOT / "Dockerfile"]
        if path.is_file()
    )
    paths = sorted(set(paths))
    with ThreadPoolExecutor(max_workers=8) as pool:
        hashes = list(pool.map(sha256, paths))
    manifest = {
        str(path.relative_to(ROOT)): {
            "bytes": path.stat().st_size,
            "sha256": digest,
        }
        for path, digest in zip(paths, hashes)
    }
    output = ROOT / "input_manifest.json"
    output.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(f"wrote={output} files={len(manifest)}")


if __name__ == "__main__":
    main()
