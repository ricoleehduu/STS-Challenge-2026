#!/usr/bin/env python3
import argparse
import sys
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "vendor"))

import nibabel as nib
import numpy as np
from PIL import Image, ImageDraw, ImageFont

from case_utils import case_directories, find_volume


def normalize(array, low=-300, high=2500):
    array = np.clip(array.astype(np.float32), low, high)
    return np.round((array - low) / (high - low) * 255).astype(np.uint8)


def orient_projection(array):
    return np.rot90(normalize(array))


def curved_panorama(volume, thickness=28):
    size_x, size_y, size_z = volume.shape
    x = np.arange(size_x)
    center_y = 0.79 * size_y - 0.0048 * (x - (size_x - 1) / 2.0) ** 2
    center_y = np.clip(np.rint(center_y).astype(int), thickness, size_y - thickness - 1)
    panorama = np.empty((size_x, size_z), dtype=volume.dtype)
    for xi, yi in enumerate(center_y):
        panorama[xi] = volume[xi, yi - thickness : yi + thickness + 1, :].max(axis=0)
    return orient_projection(panorama)


def tile(array, title):
    image = Image.fromarray(array).resize(
        (512, 384), Image.Resampling.BILINEAR
    ).convert("RGB")
    draw = ImageDraw.Draw(image)
    font = ImageFont.load_default()
    draw.rectangle((0, 0, 190, 22), fill=(0, 0, 0))
    draw.text((5, 4), title, fill=(255, 255, 255), font=font)
    draw.text((5, 190), "R", fill=(255, 255, 0), font=font)
    draw.text((500, 190), "L", fill=(255, 255, 0), font=font)
    draw.text((250, 26), "S", fill=(255, 255, 0), font=font)
    draw.text((250, 370), "I", fill=(255, 255, 0), font=font)
    return image


def make_view(source, destination):
    volume = np.asanyarray(nib.load(str(source)).dataobj)
    size_y = volume.shape[1]
    views = [
        tile(curved_panorama(volume), "Curved dental-arch MIP"),
        tile(orient_projection(volume.max(axis=1)), "Full frontal MIP"),
        tile(
            orient_projection(volume[:, int(0.62 * size_y) : int(0.88 * size_y), :].max(axis=1)),
            "Anterior dental slab MIP",
        ),
        tile(
            orient_projection(volume[:, int(0.38 * size_y) : int(0.68 * size_y), :].max(axis=1)),
            "Posterior dental slab MIP",
        ),
    ]
    sheet = Image.new("RGB", (1024, 768), "black")
    for index, view in enumerate(views):
        sheet.paste(view, ((index % 2) * 512, (index // 2) * 384))
    destination.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(destination, quality=94, subsampling=0)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--splits", nargs="+", default=["Train-Labeled", "Validation"])
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    jobs = []
    for split in args.splits:
        for case_dir in case_directories(ROOT / split):
            source = find_volume(case_dir)
            destination = ROOT / "dental_arch_views" / split / f"{case_dir.name}.jpg"
            if source is not None and (args.force or not destination.is_file()):
                jobs.append((source, destination))

    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        futures = {
            pool.submit(make_view, source, destination): destination
            for source, destination in jobs
        }
        for index, future in enumerate(as_completed(futures), start=1):
            destination = futures[future]
            future.result()
            print(f"[{index}/{len(jobs)}] {destination.relative_to(ROOT)}", flush=True)


if __name__ == "__main__":
    main()
