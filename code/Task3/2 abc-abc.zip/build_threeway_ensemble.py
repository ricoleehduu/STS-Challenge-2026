#!/usr/bin/env python3
import json
import re
from pathlib import Path

from case_utils import case_sort_key


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "work"
FIELDS = [
    "Main appeal",
    "Present medical history",
    "Oral Check",
    "Diagnosis",
    "Treatment plan",
    "Handle",
    "Doctor advices",
]
NARRATIVE_FIELDS = {"Main appeal", "Present medical history", "Doctor advices"}
VALID_FDI = {f"{quadrant}{position}" for quadrant in range(1, 5) for position in range(1, 9)}
SOURCE_PRIORITY = {"broad": 2, "focus": 1, "vlm": 0}


def read(name):
    return json.loads((WORK / name).read_text())


def strip_codes(text):
    text = re.sub(r"(?i)\s*\(?\b(?:K|LC)\d{2}(?:\.\d+)?\b\)?", "", text)
    return re.sub(r"\s+", " ", text).strip(" ,;")


def tooth_set(report):
    text = " ".join(str(report.get(field, "")) for field in FIELDS)
    return {
        tooth
        for tooth in VALID_FDI
        if re.search(rf"(?<!\d){tooth}(?!\d)", text)
    }


def agreement(left, right):
    if not left or not right:
        return 0.0
    return 2 * len(left & right) / (len(left) + len(right))


def choose_clinical_source(reports):
    teeth = {name: tooth_set(report) for name, report in reports.items()}
    scores = {
        name: sum(
            agreement(values, other_values)
            for other_name, other_values in teeth.items()
            if other_name != name
        )
        for name, values in teeth.items()
    }
    selected = max(
        reports,
        key=lambda name: (scores[name], SOURCE_PRIORITY[name]),
    )
    return selected, scores, teeth


def build_ensemble(broad, focus, vlm, expected_case_ids):
    ensemble = {}
    choices = {}
    for case_id in sorted(expected_case_ids, key=case_sort_key):
        reports = {
            name: source[case_id]
            for name, source in (("broad", broad), ("focus", focus), ("vlm", vlm))
            if case_id in source
        }
        if not reports:
            raise RuntimeError(f"No prediction source is available for case {case_id}")
        clinical_name, scores, teeth = choose_clinical_source(reports)
        narrative_name = "vlm" if "vlm" in reports else clinical_name
        report = {}
        for field in FIELDS:
            source_name = narrative_name if field in NARRATIVE_FIELDS else clinical_name
            value = str(reports[source_name].get(field, "")).strip()
            if not value:
                value = str(reports[clinical_name].get(field, "")).strip()
            report[field] = value or "Further clinical evaluation is recommended."
        report["Diagnosis"] = strip_codes(report["Diagnosis"])
        ensemble[case_id] = report
        choices[case_id] = {
            "narrative": narrative_name,
            "clinical": clinical_name,
            "clinical_agreement": {name: round(score, 6) for name, score in scores.items()},
            "source_teeth": {name: sorted(values, key=int) for name, values in teeth.items()},
        }
    return ensemble, choices


def main():
    broad = read("qwen_broad_validation.json")
    focus = read("qwen_focus_validation.json")
    vlm = read("qwen_vlm_validation.json")
    expected_case_ids = {
        path.name for path in (ROOT / "Validation").iterdir() if path.is_dir()
    }
    ensemble, choices = build_ensemble(broad, focus, vlm, expected_case_ids)

    output = WORK / "predictions_final_threeway.json"
    output.write_text(json.dumps(ensemble, ensure_ascii=False, indent=2), encoding="utf-8")
    (WORK / "predictions_final_threeway_choices.json").write_text(
        json.dumps(choices, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"wrote={output} cases={len(ensemble)}")


if __name__ == "__main__":
    main()
