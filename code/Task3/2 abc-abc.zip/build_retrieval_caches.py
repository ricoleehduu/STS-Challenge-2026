#!/usr/bin/env python3
import json
import os
from pathlib import Path

import numpy as np
import requests

from refine_pipeline import (
    field_text,
    latest_train_records,
)
from runtime_config import load_config
from api_client import auth_headers, retry
from case_utils import case_sort_key


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "work"
ARTIFACTS = ROOT / "artifacts"
CONFIG = load_config()


def api_endpoint(base_url, path):
    base = base_url.rstrip("/")
    if base.endswith("/v1"):
        return f"{base}/{path.lstrip('/')}"
    return f"{base}/v1/{path.lstrip('/')}"


def post(url, payload, api_key="", timeout=180):
    headers = auth_headers(api_key)

    def request():
        response = requests.post(url, json=payload, headers=headers, timeout=(15, timeout))
        response.raise_for_status()
        return response.json()

    return retry(request, "Embedding request")


def embed(texts):
    rows = []
    url = api_endpoint(CONFIG["embedding_base_url"], "embeddings")
    batch_size = max(1, int(os.environ.get("EMBEDDING_BATCH_SIZE", "20")))
    for start in range(0, len(texts), batch_size):
        data = post(
            url,
            {
                "model": CONFIG["embedding_model"],
                "input": texts[start : start + batch_size],
            },
            CONFIG["embedding_api_key"],
        )
        batch = data["data"]
        expected = len(texts[start : start + batch_size])
        if len(batch) != expected:
            raise RuntimeError(
                f"Embedding response count mismatch: expected={expected} actual={len(batch)}"
            )
        indexes = [item.get("index") for item in batch]
        if any(index is not None for index in indexes):
            try:
                numeric_indexes = [int(index) for index in indexes]
            except (TypeError, ValueError) as exc:
                raise RuntimeError(f"Invalid embedding response indexes: {indexes}") from exc
            if sorted(numeric_indexes) != list(range(expected)):
                raise RuntimeError(f"Invalid embedding response indexes: {indexes}")
            batch = [
                item
                for _, item in sorted(
                    zip(numeric_indexes, batch), key=lambda pair: pair[0]
                )
            ]
        rows.extend(item["embedding"] for item in batch)
    return np.asarray(rows, dtype=np.float32)


def main():
    ARTIFACTS.mkdir(parents=True, exist_ok=True)
    templates = latest_train_records()
    train_ids = sorted(templates, key=case_sort_key)
    train_queries = json.loads((WORK / "qwen_broad_train.json").read_text())
    validation_queries = json.loads(
        (WORK / "predictions_final_threeway.json").read_text()
    )
    train_arrays = {"case_ids": np.asarray(train_ids)}
    validation_ids = sorted(validation_queries, key=case_sort_key)
    validation_arrays = {"case_ids": np.asarray(validation_ids)}
    field = "Handle"
    template_texts = [field_text(templates[case_id], field) for case_id in train_ids]
    train_texts = [field_text(train_queries[case_id], field) for case_id in train_ids]
    validation_texts = [
        field_text(validation_queries[case_id], field) for case_id in validation_ids
    ]
    train_arrays["template"] = embed(template_texts)
    train_arrays["query"] = embed(train_texts)
    validation_arrays["query"] = embed(validation_texts)
    print(f"embedded={field}", flush=True)
    np.savez_compressed(ARTIFACTS / "train_field_embeddings.npz", **train_arrays)
    np.savez_compressed(
        ARTIFACTS / "validation_field_embeddings.npz", **validation_arrays
    )
    print("embedding_caches=complete")


if __name__ == "__main__":
    main()
