from pathlib import Path


def case_sort_key(value):
    text = value.name if isinstance(value, Path) else str(value)
    return (0, int(text)) if text.isdigit() else (1, text)


def case_directories(root):
    return sorted(
        [path for path in Path(root).iterdir() if path.is_dir()],
        key=case_sort_key,
    )


def find_volume(case_dir):
    case_dir = Path(case_dir)
    expected = case_dir / f"{case_dir.name}.nii.gz"
    if expected.is_file():
        return expected
    candidates = sorted(case_dir.glob("*.nii.gz"))
    if len(candidates) == 1:
        return candidates[0]
    if not candidates:
        return None
    raise RuntimeError(f"Multiple NIfTI files found in {case_dir}")
