import math
import re
from collections import Counter

import numpy as np


def tokenize(text):
    return re.findall(r"[a-z0-9]+", str(text).lower())


def bm25_scores(documents, query, k1=1.5, b=0.75):
    corpus = [Counter(tokenize(document)) for document in documents]
    lengths = np.asarray([sum(document.values()) for document in corpus], dtype=np.float32)
    average_length = float(lengths.mean()) if len(lengths) else 0.0
    scores = np.zeros(len(corpus), dtype=np.float32)
    if not average_length:
        return scores

    document_frequency = Counter()
    for document in corpus:
        document_frequency.update(document.keys())
    size = len(corpus)
    for token in set(tokenize(query)):
        frequency = document_frequency.get(token, 0)
        if not frequency:
            continue
        inverse_frequency = math.log(
            1.0 + (size - frequency + 0.5) / (frequency + 0.5)
        )
        term_frequency = np.asarray(
            [document.get(token, 0) for document in corpus], dtype=np.float32
        )
        denominator = term_frequency + k1 * (
            1.0 - b + b * lengths / average_length
        )
        scores += inverse_frequency * term_frequency * (k1 + 1.0) / np.clip(
            denominator, 1e-8, None
        )
    return scores


def minmax(values):
    values = np.asarray(values, dtype=np.float32)
    low, high = float(values.min()), float(values.max())
    return (values - low) / (high - low) if high > low else np.zeros_like(values)


def normalized_rows(matrix):
    matrix = np.asarray(matrix, dtype=np.float32)
    norms = np.linalg.norm(matrix, axis=1, keepdims=True)
    return matrix / np.clip(norms, 1e-8, None)
