#!/usr/bin/env python3
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from case_utils import case_sort_key


ROOT = Path(__file__).resolve().parents[1]
QUADRANTS = {
    "Q1": (0, 0, 296, 224),
    "Q2": (216, 0, 512, 224),
    "Q3": (216, 160, 512, 384),
    "Q4": (0, 160, 296, 384),
}
LABELS = {
    "Q1": "Q1 upper right: teeth 11-18",
    "Q2": "Q2 upper left: teeth 21-28",
    "Q3": "Q3 lower left: teeth 31-38",
    "Q4": "Q4 lower right: teeth 41-48",
}
VIEW_TILES = {
    "Curved arch": (0, 0),
    "Full frontal": (512, 0),
    "Anterior slab": (0, 384),
    "Posterior slab": (512, 384),
}


def make_quadrants(source, output_dir):
    sheet = Image.open(source).convert("RGB")
    font = ImageFont.load_default()
    output_dir.mkdir(parents=True, exist_ok=True)
    for quadrant, box in QUADRANTS.items():
        panel = Image.new("RGB", (1024, 768), "black")
        for index, (view_name, (offset_x, offset_y)) in enumerate(VIEW_TILES.items()):
            left, top, right, bottom = box
            crop = sheet.crop(
                (offset_x + left, offset_y + top, offset_x + right, offset_y + bottom)
            ).resize((512, 384), Image.Resampling.BICUBIC)
            draw = ImageDraw.Draw(crop)
            draw.rectangle((0, 0, 310, 24), fill=(0, 0, 0))
            draw.text(
                (5, 4),
                f"{LABELS[quadrant]} | {view_name}",
                fill=(255, 255, 0),
                font=font,
            )
            panel.paste(crop, ((index % 2) * 512, (index // 2) * 384))
        panel.save(output_dir / f"{quadrant}.jpg", quality=96, subsampling=0)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--splits", nargs="+", default=["Train-Labeled", "Validation"])
    args = parser.parse_args()
    jobs = []
    for split in args.splits:
        for source in sorted(
            (ROOT / "dental_arch_views" / split).glob("*.jpg"), key=lambda path: case_sort_key(path.stem)
        ):
            jobs.append(
                (source, ROOT / "multiview_quadrant_views" / split / source.stem)
            )
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        futures = {
            pool.submit(make_quadrants, source, output_dir): output_dir
            for source, output_dir in jobs
        }
        for index, future in enumerate(as_completed(futures), 1):
            future.result()
            print(f"[multiview {index}/{len(futures)}] {futures[future].relative_to(ROOT)}", flush=True)


if __name__ == "__main__":
    main()
