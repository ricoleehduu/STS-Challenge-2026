import os


def load_config():
    variables = {
        "qwen_base_url": "QWEN_BASE_URL",
        "qwen_model": "QWEN_MODEL",
        "qwen_api_key": "QWEN_API_KEY",
        "embedding_base_url": "EMBEDDING_BASE_URL",
        "embedding_model": "EMBEDDING_MODEL",
        "embedding_api_key": "EMBEDDING_API_KEY",
        "rerank_base_url": "RERANK_BASE_URL",
        "rerank_model": "RERANK_MODEL",
        "rerank_api_key": "RERANK_API_KEY",
    }
    config = {key: os.environ.get(variable, "").strip() for key, variable in variables.items()}
    required = [key for key in variables if not key.endswith("_api_key")]
    missing = [key for key in required if not config[key]]
    if missing:
        raise RuntimeError(f"Missing API configuration: {', '.join(missing)}")
    return config
