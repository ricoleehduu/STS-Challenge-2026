#!/usr/bin/env python3
import argparse
import base64
import json
import os
import re
import threading
import zipfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import requests
import json_repair

from api_client import auth_headers, retry
from case_utils import case_directories, case_sort_key
from no_image_fallback import no_image_report

ROOT = Path(__file__).resolve().parents[1]
FIELDS = [
    "Main appeal",
    "Present medical history",
    "Oral Check",
    "Diagnosis",
    "Treatment plan",
    "Handle",
    "Doctor advices",
]

SYSTEM_PROMPT = """Generate the most likely dental outpatient record for the current CBCT in the translated-English style of the MMDental dataset. Output only one valid JSON object with exactly these keys: Main appeal, Present medical history, Oral Check, Diagnosis, Treatment plan, Handle, Doctor advices.

Use the field meanings below exactly:
- Main appeal: a short patient complaint or reason for attendance.
- Present medical history: a short history of the current dental problem. Never invent systemic disease, allergy, smoking, trauma, duration, or prior treatment unless directly supported.
- Oral Check: objective dental and CBCT findings. This is the most image-grounded and detailed field.
- Diagnosis: concise dental diagnoses supported by the findings.
- Treatment plan: proposed treatment, not treatment already completed.
- Handle: procedure or management performed at this visit, such as examination, local anesthesia, extraction, root-canal steps, irrigation, temporary sealing, medication, or explanation of the condition. Handle never means a person's name or clinician identity.
- Doctor advices: brief follow-up and postoperative advice.

Analyze all sagittal, coronal, and axial slices internally. Mention only findings that are reasonably visible, including FDI tooth numbers, missing teeth, implants, restorations, root fillings, impactions, periapical lesions, bone loss, and occlusal abnormalities. Do not invent a doctor name, patient identity, unsupported ICD code, medication dose, medical history, or exact symptom duration. When symptoms or history cannot be known from CBCT, use a short conservative dental presentation consistent with the principal visible abnormality. Keep each field concise and clinically coherent in plain outpatient-record English. All seven values must be non-empty strings. Do not output markdown, explanations, confidence scores, or extra keys."""


def parse_response(content):
    try:
        result = json.loads(content)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", content, flags=re.S)
        if not match:
            raise
        candidate = match.group(0)
        try:
            result = json.loads(candidate)
        except json.JSONDecodeError:
            result = json_repair.loads(candidate)
    return {
        field: str(result.get(field, "")).strip() or "No additional information available."
        for field in FIELDS
    }


def atomic_write_json(path, payload):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    temporary.replace(path)


def sanitize_prediction(prediction):
    history = prediction["Present medical history"]
    unsupported_history = [
        r"\s*No significant (?:systemic )?medical history (?:was )?reported\.?",
        r"\s*No history of trauma or prior treatment to the area (?:was )?reported\.?",
        r"\s*No history of systemic disease or trauma (?:was )?noted\.?",
    ]
    for pattern in unsupported_history:
        history = re.sub(pattern, "", history, flags=re.I)
    prediction["Present medical history"] = history.strip() or (
        "The patient presented for evaluation and treatment of the current dental condition."
    )

    advice = prediction["Doctor advices"]
    advice = re.sub(
        r"\s*Smoking cessation is strongly recommended to improve surgical outcomes\.?",
        "",
        advice,
        flags=re.I,
    )
    advice = re.sub(r"\s*Avoid smoking and", " Avoid", advice, flags=re.I)
    prediction["Doctor advices"] = advice.strip()
    return prediction


def infer(base_url, model, case_id, image_path):
    image = base64.b64encode(image_path.read_bytes()).decode("ascii")
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {
                "role": "user",
                "content": [
                    {
                        "type": "image_url",
                        "image_url": {"url": f"data:image/jpeg;base64,{image}"},
                    },
                    {
                        "type": "text",
                        "text": "Analyze this 12-slice dental CBCT contact sheet and return the seven-field JSON report only.",
                    },
                ],
            },
        ],
        "temperature": 0.0,
        "chat_template_kwargs": {"enable_thinking": False},
        "response_format": {"type": "json_object"},
    }
    api_key = os.environ.get("QWEN_API_KEY", "").strip()
    headers = auth_headers(api_key)

    def request():
        response = requests.post(
            f"{base_url.rstrip('/')}/chat/completions",
            json=payload,
            headers=headers,
            timeout=(15, 240),
        )
        response.raise_for_status()
        choice = response.json()["choices"][0]
        if choice.get("finish_reason") == "length":
            raise RuntimeError("Qwen response was truncated by the server output limit")
        return parse_response(choice["message"]["content"])

    return retry(request, f"Qwen VLM request for case {case_id}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--model", default="Qwen3.6-35B-A3B")
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--split", choices=["Train-Labeled", "Validation"], default="Validation")
    parser.add_argument("--output", type=Path, default=ROOT / "predictions_vlm_pure.json")
    args = parser.parse_args()

    case_ids = [path.name for path in case_directories(ROOT / args.split)]
    predictions = {}
    if args.output.is_file():
        predictions = json.loads(args.output.read_text(encoding="utf-8"))
    predictions = {case_id: predictions[case_id] for case_id in case_ids if case_id in predictions}
    pending = [case_id for case_id in case_ids if case_id not in predictions]
    lock = threading.Lock()

    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = {
            pool.submit(
                infer,
                args.base_url,
                args.model,
                case_id,
                ROOT / "contact_sheets" / args.split / f"{case_id}.jpg",
            ): case_id
            for case_id in pending
            if (ROOT / "contact_sheets" / args.split / f"{case_id}.jpg").is_file()
        }
        missing_images = [
            case_id
            for case_id in pending
            if not (ROOT / "contact_sheets" / args.split / f"{case_id}.jpg").is_file()
        ]
        for case_id in missing_images:
            predictions[case_id] = no_image_report()
        for index, future in enumerate(as_completed(futures), start=1):
            case_id = futures[future]
            prediction = sanitize_prediction(future.result())
            with lock:
                predictions[case_id] = prediction
                ordered = {key: predictions[key] for key in sorted(predictions, key=case_sort_key)}
                atomic_write_json(args.output, ordered)
            print(f"[{index}/{len(pending)}] case={case_id}", flush=True)

    predictions = {case_id: sanitize_prediction(value) for case_id, value in predictions.items()}
    predictions = {key: predictions[key] for key in sorted(predictions, key=case_sort_key)}
    atomic_write_json(args.output, predictions)
    zip_path = args.output.with_suffix(".zip")
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as bundle:
        bundle.write(args.output, "predictions.json")
    print(f"Finished {len(predictions)} cases: {zip_path}")


if __name__ == "__main__":
    main()
