import argparse
import json
import shutil
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from runtime_config import load_config
from case_utils import case_sort_key


ROOT = Path(__file__).resolve().parents[1]
CODE = ROOT / "code"
WORK = ROOT / "work"
ARTIFACTS = ROOT / "artifacts"
OUTPUT = ROOT / "output"
FINAL_OUTPUT = WORK / "final_output"
CONFIG = load_config()


def run(script, *arguments):
    command = [sys.executable, str(CODE / script), *map(str, arguments)]
    subprocess.run(command, cwd=ROOT, check=True)


def parallel(commands):
    with ThreadPoolExecutor(max_workers=len(commands)) as pool:
        futures = [pool.submit(run, *command) for command in commands]
        for future in futures:
            future.result()


def case_ids(split):
    return {
        path.name for path in (ROOT / "input" / split).iterdir() if path.is_dir()
    }


def require_cases(path, expected):
    actual = set(json.loads(Path(path).read_text(encoding="utf-8")))
    if actual != expected:
        missing = sorted(expected - actual, key=case_sort_key)
        extra = sorted(actual - expected, key=case_sort_key)
        raise RuntimeError(f"Invalid output {path}: missing={missing}, extra={extra}")


def require_mapping_cases(path, key, expected):
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    actual = set(payload[key])
    if actual != expected:
        missing = sorted(expected - actual, key=case_sort_key)
        extra = sorted(actual - expected, key=case_sort_key)
        raise RuntimeError(f"Invalid output {path}:{key}: missing={missing}, extra={extra}")


def clear(path):
    path.mkdir(parents=True, exist_ok=True)
    for child in path.iterdir():
        if child.is_dir() and not child.is_symlink():
            shutil.rmtree(child)
        else:
            child.unlink()


def publish_output(source_dir):
    OUTPUT.mkdir(parents=True, exist_ok=True)
    for name in ("predictions.json", "predictions.zip", "selection_audit.json"):
        source = source_dir / name
        if not source.is_file():
            continue
        temporary = OUTPUT / f".{name}.tmp"
        shutil.copy2(source, temporary)
        temporary.replace(OUTPUT / name)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--qwen-workers", type=int, default=4)
    parser.add_argument("--view-workers", type=int, default=6)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()

    generated = [
        ROOT / "diagnostic_sheets",
        ROOT / "dental_arch_views",
        ROOT / "quadrant_views",
        ROOT / "multiview_quadrant_views",
        ROOT / "contact_sheets",
        WORK,
        ARTIFACTS,
    ]
    if args.resume:
        for path in generated:
            path.mkdir(parents=True, exist_ok=True)
    else:
        for path in generated:
            clear(path)

    run("build_input_manifest.py")
    # Each generator skips complete current cases itself. Running them on resume
    # prevents views from a previous test split from hiding newly mounted cases.
    run("make_diagnostic_sheets.py", "--workers", args.view_workers)
    run("make_dental_arch_views.py", "--workers", args.view_workers)
    run("make_quadrant_views.py", "--workers", args.view_workers)
    run("make_multiview_quadrant_views.py", "--workers", args.view_workers)
    run("make_contact_sheets.py", "--workers", args.view_workers)
    # This archive encodes the complete current case set and must not be reused
    # after the mounted validation directory changes.
    run(
        "extract_volume_features.py",
        "--workers", args.view_workers,
        "--output", ARTIFACTS / "volume_features.npz",
    )
    run("build_visual_action_cache.py")

    common = ["--base-url", CONFIG["qwen_base_url"], "--model", CONFIG["qwen_model"]]
    parallel([
        (
            "infer_qwen_staged.py", *common, "--split", "Train-Labeled",
            "--workers", args.qwen_workers, "--report-mode", "broad",
            "--output", WORK / "qwen_broad_train.json",
            "--evidence-output", WORK / "qwen_broad_train_evidence.json",
        ),
        (
            "infer_qwen_staged.py", *common, "--split", "Validation",
            "--workers", args.qwen_workers, "--report-mode", "broad",
            "--output", WORK / "qwen_broad_validation.json",
            "--evidence-output", WORK / "qwen_broad_validation_evidence.json",
        ),
    ])

    require_cases(WORK / "qwen_broad_train.json", case_ids("Train-Labeled"))
    require_cases(WORK / "qwen_broad_validation.json", case_ids("Validation"))
    require_cases(WORK / "qwen_broad_train_evidence.json", case_ids("Train-Labeled"))
    require_cases(WORK / "qwen_broad_validation_evidence.json", case_ids("Validation"))

    parallel([
        (
            "infer_tooth_union.py", *common, "--split", "Train-Labeled",
            "--workers", args.qwen_workers,
            "--old-evidence", WORK / "qwen_broad_train_evidence.json",
            "--output", WORK / "tooth_union_train.json",
        ),
        (
            "infer_tooth_union.py", *common, "--split", "Validation",
            "--workers", args.qwen_workers,
            "--old-evidence", WORK / "qwen_broad_validation_evidence.json",
            "--output", WORK / "tooth_union_validation.json",
        ),
    ])
    require_mapping_cases(
        WORK / "tooth_union_train.json", "predictions", case_ids("Train-Labeled")
    )
    require_mapping_cases(
        WORK / "tooth_union_validation.json", "predictions", case_ids("Validation")
    )

    parallel([
        (
            "infer_qwen_staged.py", *common, "--split", "Validation",
            "--workers", args.qwen_workers, "--report-mode", "focus",
            "--output", WORK / "qwen_focus_validation.json",
            "--evidence-output", WORK / "qwen_broad_validation_evidence.json",
        ),
        (
            "infer_vlm_pure.py", *common, "--split", "Validation",
            "--workers", args.qwen_workers,
            "--output", WORK / "qwen_vlm_validation.json",
        ),
    ])

    validation = case_ids("Validation")
    require_cases(WORK / "qwen_focus_validation.json", validation)
    require_cases(WORK / "qwen_vlm_validation.json", validation)
    run("build_threeway_ensemble.py")
    run("build_retrieval_caches.py")
    run("build_rerank_caches.py")
    clear(FINAL_OUTPUT)
    run("refine_pipeline.py", "--output-dir", FINAL_OUTPUT)
    run("validate_output.py", FINAL_OUTPUT / "predictions.zip", "--root", ROOT)
    publish_output(FINAL_OUTPUT)


if __name__ == "__main__":
    main()
