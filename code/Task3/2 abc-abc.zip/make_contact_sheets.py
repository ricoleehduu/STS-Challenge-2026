#!/usr/bin/env python3
import argparse
import sys
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "vendor"))

import nibabel as nib
import numpy as np
from PIL import Image, ImageDraw, ImageFont

from case_utils import case_directories, find_volume


def normalize(array, low, high):
    array = np.nan_to_num(array.astype(np.float32), nan=low, posinf=high, neginf=low)
    return (np.clip((array - low) / max(high - low, 1.0), 0, 1) * 255).astype(np.uint8)


def make_sheet(source, destination):
    image = nib.load(str(source))
    shape = image.shape[:3]
    steps = tuple(max(1, int(np.ceil(size / 64))) for size in shape)
    sample = np.asanyarray(image.dataobj[:: steps[0], :: steps[1], :: steps[2]])
    low, high = np.percentile(sample[np.isfinite(sample)], [1, 99])

    positions = (0.22, 0.40, 0.58, 0.76)
    planes = []
    for axis, axis_name in enumerate(("Sagittal", "Coronal", "Axial")):
        for fraction in positions:
            index = min(shape[axis] - 1, int(round((shape[axis] - 1) * fraction)))
            slices = [slice(None)] * 3
            slices[axis] = index
            array = np.asanyarray(image.dataobj[tuple(slices)])
            array = np.rot90(normalize(array, low, high))
            tile = Image.fromarray(array).resize((256, 256), Image.Resampling.BILINEAR)
            tile = tile.convert("RGB")
            draw = ImageDraw.Draw(tile)
            label = f"{axis_name} {index}/{shape[axis]}"
            draw.rectangle((0, 0, 150, 22), fill=(0, 0, 0))
            draw.text((5, 4), label, fill=(255, 255, 255), font=ImageFont.load_default())
            planes.append(tile)

    sheet = Image.new("RGB", (4 * 256, 3 * 256), "black")
    for index, tile in enumerate(planes):
        sheet.paste(tile, ((index % 4) * 256, (index // 4) * 256))
    destination.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(destination, quality=92)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--workers", type=int, default=4)
    args = parser.parse_args()
    jobs = []
    for split in ("Train-Labeled", "Validation"):
        for case_dir in case_directories(ROOT / split):
            source = find_volume(case_dir)
            destination = ROOT / "contact_sheets" / split / f"{case_dir.name}.jpg"
            if source is not None and not destination.is_file():
                jobs.append((source, destination))
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        futures = {pool.submit(make_sheet, source, destination): destination for source, destination in jobs}
        for index, future in enumerate(as_completed(futures), start=1):
            destination = futures[future]
            future.result()
            print(f"[{index}/{len(jobs)}] {destination.relative_to(ROOT)}", flush=True)


if __name__ == "__main__":
    main()
