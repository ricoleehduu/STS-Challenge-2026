#!/usr/bin/env python3
import argparse
import sys
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "vendor"))

import nibabel as nib
import numpy as np
from scipy.ndimage import zoom

from case_utils import case_directories, find_volume


def resize_volume(array, target=(20, 20, 20)):
    factors = [target[index] / array.shape[index] for index in range(3)]
    return zoom(array, factors, order=1, prefilter=False)


def extract_feature(path):
    image = nib.load(str(path))
    source_shape = np.asarray(image.shape[:3], dtype=int)
    steps = tuple(max(1, int(np.ceil(size / 64))) for size in source_shape)
    array = np.asanyarray(image.dataobj[:: steps[0], :: steps[1], :: steps[2]])
    array = array.astype(np.float32, copy=False)
    finite = array[np.isfinite(array)]
    percentiles = np.percentile(finite, [0, 1, 5, 10, 25, 50, 75, 90, 95, 99, 100])
    low, high = percentiles[1], percentiles[-2]
    normalized = np.clip((array - low) / max(float(high - low), 1.0), 0.0, 1.0)
    histogram, _ = np.histogram(normalized, bins=64, range=(0.0, 1.0), density=True)
    coarse = resize_volume(normalized).ravel()
    projections = []
    for axis in range(3):
        for reducer in (np.mean, np.max):
            projection = reducer(normalized, axis=axis)
            factors = (32 / projection.shape[0], 32 / projection.shape[1])
            projections.append(zoom(projection, factors, order=1, prefilter=False).ravel())
    foreground = np.asarray(
        [(normalized > threshold).mean() for threshold in (0.1, 0.25, 0.5, 0.75, 0.9)],
        dtype=np.float32,
    )
    return np.concatenate(
        [
            source_shape.astype(np.float32) / 1000.0,
            np.asarray(image.header.get_zooms()[:3], dtype=np.float32),
            percentiles / 3000.0,
            histogram,
            foreground,
            coarse,
            *projections,
        ]
    ).astype(np.float32)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--output", type=Path, default=ROOT / "artifacts/volume_features.npz")
    args = parser.parse_args()
    jobs = []
    for split in ("Train-Labeled", "Validation"):
        for directory in case_directories(ROOT / split):
            path = find_volume(directory)
            if path is not None:
                jobs.append((split, directory.name, path))
    features = {}
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        futures = {
            pool.submit(extract_feature, path): (split, case_id)
            for split, case_id, path in jobs
        }
        for index, future in enumerate(as_completed(futures), start=1):
            split, case_id = futures[future]
            features[f"{split}/{case_id}"] = future.result()
            print(f"[{index}/{len(jobs)}] volume_feature={split}/{case_id}", flush=True)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(args.output, **features)
    print(f"wrote={args.output} cases={len(features)}")


if __name__ == "__main__":
    main()
