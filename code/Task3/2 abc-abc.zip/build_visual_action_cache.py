#!/usr/bin/env python3
import json
from pathlib import Path

import numpy as np
from sklearn.decomposition import PCA
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.preprocessing import StandardScaler

from refine_pipeline import ACTION_PATTERNS, action_set, latest_train_records
from case_utils import case_sort_key


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"


def voted_actions(neighbors, labels, minimum_votes):
    return sorted(
        [
            action
            for action in ACTION_PATTERNS
            if sum(action in labels[index] for index in neighbors) >= minimum_votes
        ]
    )


def main():
    archive = np.load(ARTIFACTS / "volume_features.npz")
    records = latest_train_records()
    train_ids = sorted(records, key=case_sort_key)
    validation_ids = sorted(
        [key.split("/", 1)[1] for key in archive.files if key.startswith("Validation/")],
        key=case_sort_key,
    )
    missing_train = [
        case_id
        for case_id in train_ids
        if f"Train-Labeled/{case_id}" not in archive.files
    ]
    if missing_train:
        raise RuntimeError(f"Missing training volume features: {missing_train}")
    train = np.stack([archive[f"Train-Labeled/{case_id}"] for case_id in train_ids])
    if not validation_ids:
        (ARTIFACTS / "validation_visual_actions.json").write_text(
            "{}", encoding="utf-8"
        )
        print("visual_action_cache=validation:0")
        return
    validation = np.stack([archive[f"Validation/{case_id}"] for case_id in validation_ids])
    scaler = StandardScaler()
    train_scaled = scaler.fit_transform(train)
    validation_scaled = scaler.transform(validation)
    pca = PCA(
        n_components=min(10, train_scaled.shape[0], train_scaled.shape[1]),
        whiten=True,
        random_state=42,
    )
    train_embedding = pca.fit_transform(train_scaled)
    validation_embedding = pca.transform(validation_scaled)
    action_labels = [action_set(records[case_id]) for case_id in train_ids]

    validation_similarity = cosine_similarity(validation_embedding, train_embedding)
    validation_action_cache = {}
    for row, case_id in enumerate(validation_ids):
        neighbors = np.argsort(validation_similarity[row])[-15:][::-1]
        validation_action_cache[case_id] = voted_actions(
            neighbors, action_labels, minimum_votes=4
        )

    (ARTIFACTS / "validation_visual_actions.json").write_text(
        json.dumps(validation_action_cache, indent=2), encoding="utf-8"
    )
    print(f"visual_action_cache=validation:{len(validation_action_cache)}")


if __name__ == "__main__":
    main()
