NO_IMAGE_CASES = set()

NO_IMAGE_REPORT = {
    "Main appeal": "Dental examination and treatment consultation.",
    "Present medical history": "No additional information available.",
    "Oral Check": "No CBCT image is available for assessment.",
    "Diagnosis": "Diagnosis pending clinical and radiographic examination.",
    "Treatment plan": "Formulate the treatment plan after examination and imaging.",
    "Handle": "No image-based treatment decision was made.",
    "Doctor advices": "Attend clinical and radiographic examination.",
}


def no_image_report():
    return dict(NO_IMAGE_REPORT)
