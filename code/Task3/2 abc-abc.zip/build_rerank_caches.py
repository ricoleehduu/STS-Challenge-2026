#!/usr/bin/env python3
import json
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import numpy as np
import requests

from refine_pipeline import (
    field_text,
    latest_train_records,
)
from retrieval_utils import bm25_scores, minmax, normalized_rows
from runtime_config import load_config
from api_client import auth_headers, retry
from case_utils import case_sort_key


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
WORK = ROOT / "work"
FIELD = "Handle"


def api_endpoint(base_url, path):
    base = base_url.rstrip("/")
    if base.endswith("/text-rerank"):
        return base
    if base.endswith("/v1"):
        return f"{base}/{path.lstrip('/')}"
    return f"{base}/v1/{path.lstrip('/')}"


def rerank(base_url, model, api_key, query, documents):
    headers = auth_headers(api_key)
    endpoint = api_endpoint(base_url, "rerank")
    dashscope_native = endpoint.endswith("/text-rerank")
    payload = (
        {
            "model": model,
            "input": {"query": query, "documents": documents},
            "parameters": {"return_documents": False},
        }
        if dashscope_native
        else {"model": model, "query": query, "documents": documents}
    )

    def request():
        response = requests.post(
            endpoint,
            json=payload,
            headers=headers,
            timeout=(15, 180),
        )
        response.raise_for_status()
        return response.json()

    payload = retry(request, "Rerank request")
    if dashscope_native:
        rows = payload.get("output", {}).get("results", [])
    else:
        rows = payload.get("results", payload if isinstance(payload, list) else [])
    scores = {}
    for row in rows:
        if not isinstance(row, dict):
            continue
        try:
            index = int(row.get("index", row.get("document_index")))
            score = float(row.get("relevance_score", row.get("score", 0.0)))
        except (TypeError, ValueError):
            continue
        if np.isfinite(score):
            scores[index] = score
    return scores


def build(split, baseline, query_embeddings, template_embeddings, base_url, model, api_key, workers):
    templates = latest_train_records()
    train_ids = sorted(templates, key=case_sort_key)
    case_ids = sorted(baseline, key=case_sort_key)
    embedded_train_ids = [str(value) for value in template_embeddings["case_ids"]]
    embedded_query_ids = [str(value) for value in query_embeddings["case_ids"]]
    if embedded_train_ids != train_ids:
        raise RuntimeError("Template embedding case IDs do not match training cases")
    if embedded_query_ids != case_ids:
        raise RuntimeError(f"Query embedding case IDs do not match {split} cases")
    output = ARTIFACTS / f"{split.lower()}_field_rerank_scores.npz"
    scores = np.full((len(case_ids), len(train_ids)), np.nan, dtype=np.float32)
    jobs = []
    corpus = [field_text(templates[case_id], FIELD) for case_id in train_ids]
    queries = [field_text(baseline[case_id], FIELD) for case_id in case_ids]
    template_matrix = normalized_rows(template_embeddings["template"])
    query_matrix = normalized_rows(query_embeddings["query"])
    semantic = query_matrix @ template_matrix.T
    for row_index, case_id in enumerate(case_ids):
        fused = 0.5 * minmax(bm25_scores(corpus, queries[row_index])) + 0.5 * minmax(
            semantic[row_index]
        )
        if split == "Train":
            fused[row_index] = -1e9
        candidates = np.argsort(fused)[-10:][::-1].tolist()
        scores[row_index, candidates] = fused[candidates]
        documents = [corpus[index] for index in candidates]
        jobs.append((row_index, case_id, candidates, queries[row_index], documents))

    lock = threading.Lock()

    def work(job):
        row_index, case_id, candidates, query, documents = job
        values = rerank(base_url, model, api_key, query, documents)
        return row_index, case_id, {
            candidates[index]: score
            for index, score in values.items()
            if 0 <= index < len(candidates)
        }

    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(work, job): job for job in jobs}
        for index, future in enumerate(as_completed(futures), start=1):
            row_index, case_id, values = future.result()
            with lock:
                for candidate_index, value in values.items():
                    scores[row_index, candidate_index] = value
            print(f"[{split} {index}/{len(jobs)}] case={case_id}", flush=True)
    np.savez_compressed(output, scores=scores, case_ids=np.asarray(case_ids))
    print(f"wrote={output}")


def main():
    config = load_config()
    train_embeddings = np.load(ARTIFACTS / "train_field_embeddings.npz")
    build(
        "Train",
        json.loads((WORK / "qwen_broad_train.json").read_text()),
        train_embeddings,
        train_embeddings,
        config["rerank_base_url"],
        config.get("rerank_model", "rerank"),
        config["rerank_api_key"],
        12,
    )
    build(
        "Validation",
        json.loads((WORK / "predictions_final_threeway.json").read_text()),
        np.load(ARTIFACTS / "validation_field_embeddings.npz"),
        train_embeddings,
        config["rerank_base_url"],
        config.get("rerank_model", "rerank"),
        config["rerank_api_key"],
        12,
    )


if __name__ == "__main__":
    main()
