#!/usr/bin/env python3
import argparse
import json
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import pandas as pd

from infer_qwen_staged import QUADRANT_INFO, chat, encode_image
from case_utils import case_sort_key


ROOT = Path(__file__).resolve().parents[1]
FIELDS = [
    "Main appeal",
    "Present medical history",
    "Oral Check",
    "Diagnosis",
    "Treatment plan",
    "Handle",
    "Doctor advices",
]
VALID_FDI = {f"{quadrant}{position}" for quadrant in range(1, 5) for position in range(1, 9)}
DIRECT_SYSTEM = """Analyze the complete dental CBCT and identify the permanent FDI teeth with definite focal abnormalities. Output one JSON object only.

Use all sagittal, coronal, axial, and dental-arch panels together. Check the four quadrants systematically and give equal attention to incisors, canines, premolars, and molars. Do not default to teeth 16/17/26/27/36/37/46/47. Establish tooth numbering from the midline and arch sequence. Select only abnormalities likely to be documented in the associated outpatient record, not every normal restoration or absent tooth visible in the scan.

Output keys:
- teeth: array of at most 8 objects with tooth, finding, confidence, and visual_basis
- quadrant_review: object with Q1, Q2, Q3, Q4 concise strings
- summary: concise string

Allowed FDI: 11-18, 21-28, 31-38, 41-48. Allowed findings: missing, impacted, unerupted, implant, crown, root_canal_filling, residual_root, caries, periapical_lesion, periodontal_bone_loss, root_resorption, fracture_suspected. Return an empty teeth array if no focal abnormality is defensible."""


def atomic_write(path, payload):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(path)


def quadrant_teeth(value):
    return {
        str(item.get("tooth"))
        for quadrant in value.values()
        for item in quadrant.get("teeth", [])
        if str(item.get("tooth")) in VALID_FDI
    }


def direct_teeth(value):
    return {
        str(item.get("tooth"))
        for item in value.get("teeth", [])
        if str(item.get("tooth")) in VALID_FDI
    }


def reference_teeth(rows):
    if isinstance(rows, pd.Series):
        text = " ".join(str(rows[field]) for field in FIELDS)
    else:
        text = " ".join(
            " ".join(str(value) for value in rows[field].tolist()) for field in FIELDS
        )
    return {tooth for tooth in VALID_FDI if re.search(rf"(?<!\d){tooth}(?!\d)", text)}


def set_f1(reference, prediction):
    if not reference and not prediction:
        return 1.0
    return 2 * len(reference & prediction) / (len(reference) + len(prediction))


def new_quadrant_request(base_url, model, split, case_id, quadrant):
    location, teeth = QUADRANT_INFO[quadrant]
    system = f"""You localize clinically abnormal permanent teeth in quadrant {quadrant} ({location}) from four aligned CBCT views of that same quadrant. Output one JSON object only.

Allowed FDI numbers: {', '.join(teeth)}. First establish the visible tooth sequence from the midline toward the posterior. Then report only teeth with a definite abnormality relevant to a dental visit. Do not report a tooth merely because it is present. Use adjacent teeth and arch position to verify numbering. If a posterior tooth is absent, distinguish true absence from being outside the field of view.

Output keys: quadrant, teeth, summary. teeth must contain at most 2 objects, ranked by clinical importance. Each object has tooth, findings, confidence, and localization_evidence describing its position from the midline and adjacent visible teeth. Allowed findings: missing, impacted, unerupted, implant, restoration, crown, root_canal_filling, residual_root, caries, periapical_lesion, periodontal_bone_loss, root_resorption, fracture_suspected. Do not label all visible teeth with the same finding. If no focal abnormality can be localized confidently, return an empty teeth array. Prefer omission over guessing."""
    image_path = ROOT / "multiview_quadrant_views" / split / case_id / f"{quadrant}.jpg"
    content = [
        {
            "type": "image_url",
            "image_url": {"url": f"data:image/jpeg;base64,{encode_image(image_path)}"},
        },
        {"type": "text", "text": f"Analyze {quadrant} and return the JSON now."},
    ]
    return chat(base_url, model, system, content)


def direct_content(split, case_id):
    paths = [
        ("SAGITTAL", ROOT / "diagnostic_sheets" / split / case_id / "sagittal.jpg"),
        ("CORONAL", ROOT / "diagnostic_sheets" / split / case_id / "coronal.jpg"),
        ("AXIAL", ROOT / "diagnostic_sheets" / split / case_id / "axial.jpg"),
        ("DENTAL ARCH", ROOT / "dental_arch_views" / split / f"{case_id}.jpg"),
    ]
    content = []
    for label, path in paths:
        content.extend([
            {"type": "text", "text": label},
            {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{encode_image(path)}"}},
        ])
    content.append({"type": "text", "text": "Return the structured tooth analysis now."})
    return content


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--split", choices=("Train-Labeled", "Validation"), required=True)
    parser.add_argument("--old-evidence", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    args = parser.parse_args()

    old = json.loads(args.old_evidence.read_text(encoding="utf-8"))
    case_ids = sorted(old, key=case_sort_key)
    evidence = {}
    if args.output.is_file():
        evidence = json.loads(args.output.read_text(encoding="utf-8")).get("evidence", {})
    evidence = {case_id: evidence[case_id] for case_id in case_ids if case_id in evidence}
    jobs = []
    for case_id in case_ids:
        if old[case_id].get("no_image"):
            evidence[case_id] = {"no_image": True}
            continue
        for quadrant in QUADRANT_INFO:
            if quadrant not in evidence.get(case_id, {}).get("new", {}):
                jobs.append((case_id, "new", quadrant))
        if "direct" not in evidence.get(case_id, {}):
            jobs.append((case_id, "direct", None))

    def infer(job):
        case_id, branch, quadrant = job
        if branch == "new":
            result = new_quadrant_request(args.base_url, args.model, args.split, case_id, quadrant)
        else:
            result = chat(args.base_url, args.model, DIRECT_SYSTEM, direct_content(args.split, case_id))
        return case_id, branch, quadrant, result

    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = {pool.submit(infer, job): job for job in jobs}
        for index, future in enumerate(as_completed(futures), 1):
            case_id, branch, quadrant, result = future.result()
            case = evidence.setdefault(case_id, {"new": {}})
            if branch == "new":
                case.setdefault("new", {})[quadrant] = result
            else:
                case["direct"] = result
            atomic_write(args.output, {"evidence": evidence})
            print(f"[tooth {index}/{len(jobs)}] case={case_id} branch={branch} quadrant={quadrant or '-'}", flush=True)

    predictions = {}
    rows = []
    records = None
    if args.split == "Train-Labeled":
        records = pd.read_csv(ROOT / "input" / "medical_records.csv", encoding="utf-8-sig").fillna("")
        records["Filename"] = records["Filename"].astype(str)
        records = records.set_index("Filename")
    for case_id in case_ids:
        if old[case_id].get("no_image"):
            predictions[case_id] = []
            continue
        if set(evidence[case_id].get("new", {})) != set(QUADRANT_INFO) or "direct" not in evidence[case_id]:
            raise RuntimeError(f"Incomplete tooth evidence for case {case_id}")
        old_set = quadrant_teeth(old[case_id]["quadrant_stages"])
        new_set = quadrant_teeth(evidence[case_id]["new"])
        direct_set = direct_teeth(evidence[case_id]["direct"])
        fused = old_set | new_set | direct_set
        predictions[case_id] = sorted(fused, key=int)
        if records is not None:
            reference = reference_teeth(records.loc[case_id])
            rows.append({
                "case_id": case_id,
                "old_f1": set_f1(reference, old_set),
                "new_f1": set_f1(reference, new_set),
                "direct_f1": set_f1(reference, direct_set),
                "fused_f1": set_f1(reference, fused),
            })
    payload = {
        "split": args.split,
        "case_count": len(case_ids),
        "api_request_count": len(jobs),
        "predictions": predictions,
        "evidence": evidence,
    }
    if rows:
        payload["metrics"] = {
            "old_macro_f1": sum(row["old_f1"] for row in rows) / len(rows),
            "new_macro_f1": sum(row["new_f1"] for row in rows) / len(rows),
            "direct_macro_f1": sum(row["direct_f1"] for row in rows) / len(rows),
            "fused_macro_f1": sum(row["fused_f1"] for row in rows) / len(rows),
        }
    atomic_write(args.output, payload)


if __name__ == "__main__":
    main()
