#!/usr/bin/env python3
import argparse
import base64
import json
import os
import re
import threading
import zipfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import requests
import json_repair

from api_client import auth_headers, retry
from case_utils import case_directories, find_volume, case_sort_key
from no_image_fallback import no_image_report

ROOT = Path(__file__).resolve().parents[1]
FIELDS = [
    "Main appeal",
    "Present medical history",
    "Oral Check",
    "Diagnosis",
    "Treatment plan",
    "Handle",
    "Doctor advices",
]
VALID_FDI = [
    f"{quadrant}{position}"
    for quadrant in range(1, 5)
    for position in range(1, 9)
]

TOOTH_SYSTEM = """You are the tooth-localization stage of a dental CBCT analysis pipeline. Analyze only objective visual evidence. Output one valid JSON object and no markdown.

The images include high-density sagittal, coronal, axial slices and a dental-arch projection. Yellow orientation markers identify patient right/left and superior/inferior. Use only permanent FDI numbers from this exact set: 11-18, 21-28, 31-38, 41-48.

Output keys:
- dentition_summary: short string
- teeth: array of objects with tooth, findings, confidence
- global_findings: array of high-confidence jaw or periodontal findings
- uncertain_findings: array

Allowed tooth findings: present, missing, impacted, unerupted, implant, restoration, crown, root_canal_filling, residual_root, caries, periapical_lesion, periodontal_bone_loss, root_resorption, fracture_suspected. Prefer omission over a false positive. Never infer symptoms, history, diagnosis codes, treatment, or clinician identity."""

QUADRANT_INFO = {
    "Q1": ("upper right", [f"1{i}" for i in range(1, 9)]),
    "Q2": ("upper left", [f"2{i}" for i in range(1, 9)]),
    "Q3": ("lower left", [f"3{i}" for i in range(1, 9)]),
    "Q4": ("lower right", [f"4{i}" for i in range(1, 9)]),
}

REASONING_SYSTEM = """You are the verification and clinical-reasoning stage of a dental CBCT pipeline. Cross-check the proposed tooth evidence against all supplied images. Output one valid JSON object and no markdown.

Use only permanent FDI numbers 11-18, 21-28, 31-38, 41-48. Remove weak or contradictory tooth findings. Do not introduce symptoms, patient history, medication, clinician names, or exact procedure details that cannot be seen.

Output keys:
- confirmed_teeth: array of objects with tooth, findings, confidence
- quadrant_summary: object with Q1, Q2, Q3, Q4
- disease_candidates: array of concise diagnoses with supporting_teeth and confidence
- treatment_actions: array of conservative likely actions supported by the findings
- report_focus: one short string identifying the principal record focus

Prefer a short high-precision result over listing every possible abnormality."""

REPORT_SYSTEM = """You write concise translated-English dental outpatient records in the MMDental dataset style from verified structured evidence. Output one valid JSON object with exactly these keys: Main appeal, Present medical history, Oral Check, Diagnosis, Treatment plan, Handle, Doctor advices.

Rules:
- Use only tooth numbers explicitly listed in allowed_fdi. Never add or change a tooth number.
- Oral Check is objective and image-grounded. Keep it to 1-3 short sentences.
- Main appeal and Present medical history must be conservative and consistent with report_focus. Do not invent duration, trauma, smoking, allergy, systemic disease, or prior treatment.
- Diagnosis may use these codes only when the matching diagnosis is high confidence: impacted tooth K01.100; missing tooth K00.002; dental caries K02.900; acute pulpitis K04.001; chronic pulpitis K04.002; chronic apical periodontitis K04.500; chronic periodontitis K05.300.
- Treatment plan is proposed treatment.
- Handle means management or procedure at this visit, never a clinician name. Use concise MMDental-like wording such as explaining the condition, imaging review, local treatment, extraction, root-canal steps, restoration, or implant planning as supported.
- Doctor advices should usually be a short follow-up or oral-hygiene instruction.
- All values must be non-empty strings. No markdown, explanations, confidence scores, arrays, or extra keys."""

FOCUS_SYSTEM = """You select the likely clinical focus of one dental outpatient record from verified CBCT evidence. Cross-check the images and output one valid JSON object with keys focus_teeth, principal_finding, likely_visit_type, confidence, rationale.

Choose at most 3 permanent FDI teeth from 11-18, 21-28, 31-38, 41-48. Select only teeth most likely to trigger this scan, complaint, or treatment visit. Prioritize a strongly asymmetric or severe finding: horizontal/deep impaction, periapical lesion, residual root, marked caries, failed endodontic treatment, a specific missing-tooth implant site, or focal bone loss. Do not select symmetric normal anatomy or multiple routine restorations merely because they are visible. If no tooth is a defensible focus, return an empty focus_teeth array. Never invent history or symptoms."""


def encode_image(path):
    return base64.b64encode(path.read_bytes()).decode("ascii")


def parse_json(content):
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", content, flags=re.S)
        if not match:
            raise
        candidate = match.group(0)
        try:
            return json.loads(candidate)
        except json.JSONDecodeError:
            return json_repair.loads(candidate)


def atomic_write_json(path, payload):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    temporary.replace(path)


def chat(base_url, model, system, content):
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": content},
        ],
        "temperature": 0.0,
        "chat_template_kwargs": {"enable_thinking": False},
        "response_format": {"type": "json_object"},
    }
    api_key = os.environ.get("QWEN_API_KEY", "").strip()
    headers = auth_headers(api_key)

    def request():
        response = requests.post(
            f"{base_url.rstrip('/')}/chat/completions",
            json=payload,
            headers=headers,
            timeout=(15, 120),
        )
        response.raise_for_status()
        choice = response.json()["choices"][0]
        if choice.get("finish_reason") == "length":
            raise RuntimeError("Qwen response was truncated by the server output limit")
        return parse_json(choice["message"]["content"])

    return retry(request, "Qwen staged request")


def image_content(split, case_id):
    paths = [
        ROOT / "diagnostic_sheets" / split / case_id / "sagittal.jpg",
        ROOT / "diagnostic_sheets" / split / case_id / "coronal.jpg",
        ROOT / "diagnostic_sheets" / split / case_id / "axial.jpg",
        ROOT / "dental_arch_views" / split / f"{case_id}.jpg",
    ]
    labels = ["SAGITTAL SERIES", "CORONAL SERIES", "AXIAL SERIES", "DENTAL-ARCH VIEWS"]
    content = [
        {
            "type": "text",
            "text": "Analyze the same dental CBCT represented by the four image groups below.",
        }
    ]
    for label, path in zip(labels, paths):
        if not path.is_file():
            raise FileNotFoundError(path)
        content.append({"type": "text", "text": label})
        content.append(
            {
                "type": "image_url",
                "image_url": {"url": f"data:image/jpeg;base64,{encode_image(path)}"},
            }
        )
    return content


def quadrant_content(split, case_id, quadrant):
    location, teeth = QUADRANT_INFO[quadrant]
    path = ROOT / "quadrant_views" / split / case_id / f"{quadrant}.jpg"
    system = f"""You are the tooth-level localization stage for quadrant {quadrant}, the permanent {location} quadrant. Analyze only objective visual evidence in the focused dental CBCT projection. Output one valid JSON object and no markdown.

Allowed tooth numbers are only: {', '.join(teeth)}. Never output a tooth number outside this list. Output keys: quadrant, teeth, summary. The teeth value is an array of high-confidence abnormal teeth with tooth, findings, and confidence. Allowed findings: missing, impacted, unerupted, implant, restoration, crown, root_canal_filling, residual_root, caries, periapical_lesion, periodontal_bone_loss, root_resorption, fracture_suspected. Pay special attention to the third molar and posterior teeth. Prefer omission over guessing. Do not infer symptoms, history, diagnosis codes, or treatment."""
    content = [
        {
            "type": "image_url",
            "image_url": {"url": f"data:image/jpeg;base64,{encode_image(path)}"},
        },
        {
            "type": "text",
            "text": f"Return the focused {quadrant} tooth-evidence JSON now.",
        },
    ]
    return system, content


def allowed_fdi(reasoning):
    text = json.dumps(reasoning.get("confirmed_teeth", []), ensure_ascii=False)
    return sorted(
        {number for number in VALID_FDI if re.search(rf"(?<!\d){number}(?!\d)", text)},
        key=int,
    )


def focus_fdi(focus):
    text = json.dumps(focus.get("focus_teeth", []), ensure_ascii=False)
    result = sorted(
        {number for number in VALID_FDI if re.search(rf"(?<!\d){number}(?!\d)", text)},
        key=int,
    )
    return result[:3]


def focused_reasoning(reasoning, allowed):
    allowed_set = set(allowed)
    confirmed = []
    for item in reasoning.get("confirmed_teeth", []):
        tooth = str(item.get("tooth", ""))
        if tooth in allowed_set:
            confirmed.append(item)
    diseases = []
    for item in reasoning.get("disease_candidates", []):
        supports = [
            str(tooth)
            for tooth in item.get("supporting_teeth", [])
            if str(tooth) in allowed_set
        ]
        if supports:
            reduced = dict(item)
            reduced["supporting_teeth"] = supports
            diseases.append(reduced)
    return {
        "confirmed_teeth": confirmed,
        "disease_candidates": diseases,
        "report_focus": reasoning.get("report_focus", ""),
    }


def normalize_report(report):
    result = {}
    for field in FIELDS:
        value = str(report.get(field, "")).strip()
        result[field] = value or "Further clinical evaluation and follow-up are recommended."
    history = result["Present medical history"]
    history = re.sub(
        r"\s*No significant (?:systemic )?medical history (?:was )?reported\.?",
        "",
        history,
        flags=re.I,
    ).strip()
    result["Present medical history"] = history or (
        "The patient presented for evaluation and treatment of the current dental condition."
    )
    return result


def infer_case(base_url, model, split, case_id, cached, report_mode):
    evidence = cached.get(case_id, {})
    images = image_content(split, case_id)
    if "quadrant_stages" not in evidence:
        evidence["quadrant_stages"] = {}
        for quadrant in QUADRANT_INFO:
            system, content = quadrant_content(split, case_id, quadrant)
            evidence["quadrant_stages"][quadrant] = chat(
                base_url, model, system, content
            )
    if "reasoning_stage" not in evidence:
        evidence["reasoning_stage"] = chat(
            base_url,
            model,
            REASONING_SYSTEM,
            images
            + [
                {
                    "type": "text",
                    "text": "Proposed quadrant-level tooth evidence:\n"
                    + json.dumps(evidence["quadrant_stages"], ensure_ascii=False),
                }
            ],
        )
    if report_mode == "focus" and "focus_stage" not in evidence:
        evidence["focus_stage"] = chat(
            base_url,
            model,
            FOCUS_SYSTEM,
            images
            + [
                {
                    "type": "text",
                    "text": "Verified evidence:\n"
                    + json.dumps(evidence["reasoning_stage"], ensure_ascii=False),
                }
            ],
        )
    if report_mode == "focus":
        allowed = focus_fdi(evidence["focus_stage"])
        report_input = {
            "allowed_fdi": allowed,
            "verified_evidence": focused_reasoning(evidence["reasoning_stage"], allowed),
            "selected_clinical_focus": evidence["focus_stage"],
        }
    else:
        allowed = allowed_fdi(evidence["reasoning_stage"])
        report_input = {
            "allowed_fdi": allowed,
            "verified_evidence": evidence["reasoning_stage"],
        }
    report = chat(
        base_url,
        model,
        REPORT_SYSTEM,
        "Generate the seven-field report from this evidence only:\n"
        + json.dumps(report_input, ensure_ascii=False),
    )
    return evidence, normalize_report(report)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--model", default="Qwen3.6-35B-A3B")
    parser.add_argument("--split", choices=["Train-Labeled", "Validation"], required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--limit", type=int)
    parser.add_argument("--report-mode", choices=["broad", "focus"], default="broad")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--evidence-output", type=Path)
    args = parser.parse_args()

    evidence_path = args.evidence_output or args.output.with_name(args.output.stem + "_evidence.json")
    case_ids = [path.name for path in case_directories(ROOT / args.split)]
    predictions = json.loads(args.output.read_text()) if args.output.is_file() else {}
    evidence = json.loads(evidence_path.read_text()) if evidence_path.is_file() else {}
    predictions = {case_id: predictions[case_id] for case_id in case_ids if case_id in predictions}
    evidence = {case_id: evidence[case_id] for case_id in case_ids if case_id in evidence}
    if args.limit:
        case_ids = case_ids[: args.limit]
    pending = [case_id for case_id in case_ids if case_id not in predictions]
    lock = threading.Lock()

    def work(case_id):
        if find_volume(ROOT / args.split / case_id) is None:
            return case_id, ({"no_image": True}, no_image_report())
        return case_id, infer_case(
            args.base_url, args.model, args.split, case_id, evidence, args.report_mode
        )

    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = {pool.submit(work, case_id): case_id for case_id in pending}
        for index, future in enumerate(as_completed(futures), start=1):
            try:
                case_id, (case_evidence, report) = future.result()
            except Exception as exc:
                print(
                    f"[{index}/{len(pending)}] case={futures[future]} ERROR={exc}",
                    flush=True,
                )
                continue
            with lock:
                evidence[case_id] = case_evidence
                predictions[case_id] = report
                evidence = {key: evidence[key] for key in sorted(evidence, key=case_sort_key)}
                predictions = {key: predictions[key] for key in sorted(predictions, key=case_sort_key)}
                atomic_write_json(evidence_path, evidence)
                atomic_write_json(args.output, predictions)
            print(f"[{index}/{len(pending)}] case={case_id}", flush=True)

    if args.split == "Validation":
        with zipfile.ZipFile(args.output.with_suffix(".zip"), "w", zipfile.ZIP_DEFLATED) as bundle:
            bundle.write(args.output, "predictions.json")


if __name__ == "__main__":
    main()
