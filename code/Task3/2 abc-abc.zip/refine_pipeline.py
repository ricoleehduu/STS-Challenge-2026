#!/usr/bin/env python3
import argparse
import html
import json
import re
import zipfile
from collections import Counter
from pathlib import Path

import pandas as pd
import numpy as np

from no_image_fallback import NO_IMAGE_CASES, no_image_report
from case_utils import case_directories, case_sort_key


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
WORK = ROOT / "work"
OUTPUTS = ROOT / "output"
FIELDS = [
    "Main appeal",
    "Present medical history",
    "Oral Check",
    "Diagnosis",
    "Treatment plan",
    "Handle",
    "Doctor advices",
]
CONSENSUS_PARTS = {
    "Main appeal": 1,
    "Present medical history": 2,
    "Oral Check": 2,
    "Diagnosis": 2,
    "Treatment plan": 3,
    "Doctor advices": 1,
}
CONSENSUS_FIELDS = {"Present medical history", "Treatment plan", "Doctor advices"}
VALID_FDI = [f"{q}{p}" for q in range(1, 5) for p in range(1, 9)]
ACTION_PATTERNS = {
    "extraction": r"\bextract(?:ion|ed|ing)?\b|\bremove(?:d|al)?\b",
    "root_canal": r"root canal|\brct\b|pulp extirpation",
    "restoration": r"restor|filling|resin|amalgam",
    "crown": r"\bcrown\b|full coverage",
    "implant": r"implant",
    "scaling": r"scaling|root planing|periodontal therapy",
    "orthodontic": r"orthodont|bracket|aligner",
    "surgery": r"surg(?:ery|ical)",
    "observation": r"observ|monitor|follow[- ]?up|review",
}
ACTION_TEXT = {
    "extraction": "extraction",
    "root_canal": "root canal treatment",
    "restoration": "restoration",
    "crown": "crown restoration",
    "implant": "implant treatment",
    "scaling": "periodontal scaling",
    "orthodontic": "orthodontic treatment",
    "surgery": "surgical treatment",
    "observation": "follow-up observation",
}
FIELD_WORD_CAPS = {"Oral Check": 80, "Treatment plan": 12, "Doctor advices": 40}
MEDOID_FIELDS = {"Main appeal", "Oral Check"}


def clean(value):
    if pd.isna(value):
        return ""
    return re.sub(r"\s+", " ", html.unescape(str(value))).strip()


def latest_train_records():
    frame = pd.read_csv(ROOT / "medical_records.csv", encoding="utf-8-sig")
    ids = [path.name for path in case_directories(ROOT / "Train-Labeled")]
    records = {}
    for case_id in ids:
        group = frame[frame["Filename"].astype(str) == case_id]
        report = {}
        for field in FIELDS:
            values = []
            for _, row in group.iterrows():
                value = clean(row[field])
                if field == "Main appeal" and not value:
                    value = clean(row["Subsequent"])
                if value:
                    values.append(value)
            report[field] = values[-1] if values else "No additional information available."
        records[case_id] = report
    return records


def anonymize(text):
    for tooth in VALID_FDI:
        text = re.sub(rf"(?<!\d){tooth}(?!\d)", " TOOTH ", text)
    text = re.sub(r"(?i)\b(?:K|LC)\d{2}(?:\.\d+)?\b", " CODE ", text)
    return re.sub(r"\s+", " ", text).strip().lower()


def field_text(report, field):
    if field in {"Main appeal", "Present medical history"}:
        return anonymize(report[field])
    clinical_fields = ["Oral Check", "Diagnosis", "Treatment plan", "Handle"]
    return " ".join(anonymize(report[item]) for item in clinical_fields)


def strip_template_entities(text):
    for tooth in VALID_FDI:
        text = re.sub(rf"(?<!\d){tooth}(?!\d)", "the affected tooth", text)
    text = re.sub(r"(?i)\b(?:K|LC)\d{2}(?:\.\d+)?\b", "", text)
    return re.sub(r"\s+", " ", text).strip(" ,;")


def token_f1(left, right):
    left_tokens = Counter(re.findall(r"[a-z0-9]+", left.lower()))
    right_tokens = Counter(re.findall(r"[a-z0-9]+", right.lower()))
    if not left_tokens and not right_tokens:
        return 1.0
    overlap = sum((left_tokens & right_tokens).values())
    return 2 * overlap / (sum(left_tokens.values()) + sum(right_tokens.values()))


def medoid_template_id(templates, field, excluded_id=None):
    case_ids = [case_id for case_id in sorted(templates, key=case_sort_key) if case_id != excluded_id]
    texts = {
        case_id: strip_template_entities(templates[case_id][field]) for case_id in case_ids
    }
    return max(
        case_ids,
        key=lambda candidate: np.mean(
            [
                token_f1(texts[candidate], texts[other])
                for other in case_ids
                if other != candidate
            ]
        ),
    )


def consensus_template(templates, field, parts, excluded_id=None):
    case_ids = [case_id for case_id in sorted(templates, key=case_sort_key) if case_id != excluded_id]
    values = {
        case_id: apply_word_cap(
            field, strip_template_entities(templates[case_id][field])
        )
        for case_id in case_ids
    }
    selected = []
    text = ""
    for _ in range(parts):
        best = None
        for case_id in case_ids:
            if case_id in selected:
                continue
            candidate = (text.rstrip(" .") + ". " + values[case_id]).strip(" .") if text else values[case_id]
            score = np.mean(
                [token_f1(candidate, templates[target_id][field]) for target_id in case_ids]
            )
            choice = (score, case_id, candidate)
            if best is None or choice[0] > best[0]:
                best = choice
        selected.append(best[1])
        text = best[2]
    return text, selected


def restore_diagnosis_entities(text, allowed_teeth):
    teeth = sorted(set(allowed_teeth), key=int)
    if teeth:
        text = text.rstrip(" .") + ". Relevant teeth: " + ", ".join(teeth) + "."
    return text


def apply_word_cap(field, text):
    cap = FIELD_WORD_CAPS.get(field)
    if not cap:
        return text
    words = text.split()
    return " ".join(words[:cap])


def tooth_set(report):
    text = " ".join(report.values())
    return {
        tooth
        for tooth in VALID_FDI
        if re.search(rf"(?<!\d){tooth}(?!\d)", text)
    }


def clean_generated_text(text):
    text = re.sub(r"\(\s*\)", "", str(text))
    text = re.sub(r"\\n|[\r\n]+", " ", text)
    text = re.sub(r"\s+([,.;:])", r"\1", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip(" ,;.")


def ordered_teeth(report):
    selected = []
    field_order = [
        "Diagnosis",
        "Oral Check",
        "Treatment plan",
        "Handle",
        "Main appeal",
        "Present medical history",
        "Doctor advices",
    ]
    for field in field_order:
        for tooth in re.findall(r"(?<!\d)([1-4][1-8])(?!\d)", report[field]):
            if tooth in VALID_FDI and tooth not in selected:
                selected.append(tooth)
    return selected


def lock_teeth(report, required_teeth):
    required = set(required_teeth)
    for field in FIELDS:
        for tooth in VALID_FDI:
            if tooth not in required:
                report[field] = re.sub(
                    rf"(?<!\d){tooth}(?!\d)", "the affected tooth", report[field]
                )
    missing = sorted(required - tooth_set(report), key=int)
    if missing:
        report["Oral Check"] = (
            report["Oral Check"].rstrip(" .")
            + ". Relevant teeth: "
            + ", ".join(missing)
            + "."
        )
    return report


def action_set(report):
    text = report["Treatment plan"] + " " + report["Handle"]
    return {
        name for name, pattern in ACTION_PATTERNS.items() if re.search(pattern, text, re.I)
    }


def make_consistent(report):
    report = {field: clean_generated_text(report[field]) for field in FIELDS}
    history = re.sub(
        r"^No additional information available\.\s*",
        "",
        report["Present medical history"],
        flags=re.I,
    )
    appeal = report["Main appeal"]
    conflicts = [
        (r"upper|maxillary", r"lower|mandibular"),
        (r"left", r"right"),
    ]
    if any(
        (re.search(left, appeal, re.I) and re.search(right, history, re.I))
        or (re.search(right, appeal, re.I) and re.search(left, history, re.I))
        for left, right in conflicts
    ):
        location = r"\b(?:upper|lower|left|right|maxillary|mandibular)\b\s*"
        appeal = re.sub(location, "", appeal, flags=re.I)
        history = re.sub(location, "", history, flags=re.I)
    report["Main appeal"] = clean_generated_text(appeal)
    report["Present medical history"] = clean_generated_text(history) or (
        "The patient presented for evaluation of the current dental condition"
    )

    if len(action_set(report)) >= 4:
        report["Treatment plan"] = (
            "Select treatment according to clinical findings: root canal treatment "
            "and crown restoration for retainable teeth; extraction for non-restorable "
            "or impacted teeth; implant restoration for confirmed missing sites"
        )
    report["Oral Check"] = re.sub(
        r"^the affected tooth\s+",
        "The affected tooth: ",
        report["Oral Check"],
        flags=re.I,
    )
    return {field: clean_generated_text(value) + "." for field, value in report.items()}


def lock_actions(text, allowed, append_missing):
    for name, pattern in ACTION_PATTERNS.items():
        if name not in allowed:
            text = re.sub(pattern, "treatment", text, flags=re.I)
    missing = [
        ACTION_TEXT[name]
        for name in ACTION_PATTERNS
        if name in allowed and not re.search(ACTION_PATTERNS[name], text, re.I)
    ]
    if missing and append_missing:
        text = text.rstrip(" .") + ". Planned actions: " + ", ".join(missing) + "."
    return re.sub(r"\s+", " ", text).strip()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, default=OUTPUTS)
    args = parser.parse_args()
    templates = latest_train_records()
    train_ids = sorted(templates, key=case_sort_key)
    baseline = json.loads(
        (WORK / "predictions_final_threeway.json").read_text()
    )
    tooth_union = json.loads(
        (WORK / "tooth_union_validation.json").read_text()
    )
    tooth_predictions = tooth_union["predictions"]
    no_image_cases = {
        case_id
        for case_id, value in tooth_union.get("evidence", {}).items()
        if value.get("no_image")
    }
    case_ids = sorted(baseline, key=case_sort_key)

    predictions = json.loads(json.dumps(baseline))
    visual_actions = json.loads(
        (ARTIFACTS / "validation_visual_actions.json").read_text()
    )
    choices = {}
    rerank_path = ARTIFACTS / "validation_field_rerank_scores.npz"
    if not rerank_path.is_file():
        raise RuntimeError(f"Missing rerank cache: {rerank_path}")
    rerank_cache = np.load(rerank_path)
    rerank_scores = rerank_cache["scores"]
    rerank_case_ids = [str(value) for value in rerank_cache["case_ids"]]
    if rerank_case_ids != case_ids:
        raise RuntimeError("Rerank cache case IDs do not match current validation cases")
    medoid_ids = {
        field: medoid_template_id(templates, field) for field in MEDOID_FIELDS
    }
    for row_index, case_id in enumerate(case_ids):
        if case_id in NO_IMAGE_CASES or case_id in no_image_cases:
            predictions[case_id] = no_image_report()
            choices[case_id] = {field: {"selection": "no_image_prior"} for field in FIELDS}
            continue
        required_teeth = set(tooth_predictions[case_id])
        diagnosis, diagnosis_ids = consensus_template(
            templates, "Diagnosis", CONSENSUS_PARTS["Diagnosis"]
        )
        predictions[case_id]["Diagnosis"] = restore_diagnosis_entities(
            diagnosis, required_teeth
        )
        required_actions = set(visual_actions.get(case_id, []))
        case_choices = {
            "Diagnosis": {
                "template_case_ids": diagnosis_ids,
                "selection": "train_consensus",
            }
        }
        for field in CONSENSUS_FIELDS:
            value, template_ids = consensus_template(
                templates, field, CONSENSUS_PARTS[field]
            )
            predictions[case_id][field] = value
            case_choices[field] = {
                "template_case_ids": template_ids,
                "selection": "train_consensus",
            }
        for field in MEDOID_FIELDS:
            template_id = medoid_ids[field]
            predictions[case_id][field] = apply_word_cap(
                field, strip_template_entities(templates[template_id][field])
            )
            case_choices[field] = {
                "template_case_id": template_id,
                "selection": "train_medoid",
            }
        row_rerank = rerank_scores[row_index]
        candidates = np.flatnonzero(np.isfinite(row_rerank))
        if not len(candidates):
            raise RuntimeError(f"No retrieval candidate is available for case {case_id}")
        template_index = int(candidates[np.argmax(row_rerank[candidates])])
        template_id = train_ids[template_index]
        predictions[case_id]["Handle"] = strip_template_entities(
            templates[template_id]["Handle"]
        )
        case_choices["Handle"] = {
            "template_case_id": template_id,
            "selection": "bm25_embedding_rerank",
        }
        predictions[case_id]["Treatment plan"] = lock_actions(
            predictions[case_id]["Treatment plan"], required_actions, True
        )
        predictions[case_id]["Handle"] = lock_actions(
            predictions[case_id]["Handle"], required_actions, False
        )
        predictions[case_id] = make_consistent(predictions[case_id])
        predictions[case_id] = lock_teeth(predictions[case_id], required_teeth)
        if tooth_set(predictions[case_id]) != required_teeth:
            raise RuntimeError(f"Failed to lock teeth for case {case_id}")
        choices[case_id] = case_choices

    output = args.output_dir / "predictions.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(predictions, ensure_ascii=False, indent=2), encoding="utf-8")
    (args.output_dir / "selection_audit.json").write_text(
        json.dumps(choices, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    with zipfile.ZipFile(output.with_suffix(".zip"), "w", zipfile.ZIP_DEFLATED) as bundle:
        bundle.write(output, "predictions.json")
    print(f"wrote={output}")


if __name__ == "__main__":
    main()
