#!/usr/bin/env python3
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from case_utils import case_sort_key

ROOT = Path(__file__).resolve().parents[1]
QUADRANTS = {
    "Q1": (0, 0, 296, 224),
    "Q2": (216, 0, 512, 224),
    "Q3": (216, 160, 512, 384),
    "Q4": (0, 160, 296, 384),
}


def make_quadrants(source, output_dir):
    sheet = Image.open(source).convert("RGB")
    panorama = sheet.crop((512, 0, 1024, 384))
    font = ImageFont.load_default()
    output_dir.mkdir(parents=True, exist_ok=True)
    for quadrant, box in QUADRANTS.items():
        crop = panorama.crop(box).resize((640, 480), Image.Resampling.BICUBIC)
        draw = ImageDraw.Draw(crop)
        draw.rectangle((0, 0, 250, 26), fill=(0, 0, 0))
        label = {
            "Q1": "Q1 upper right: teeth 11-18",
            "Q2": "Q2 upper left: teeth 21-28",
            "Q3": "Q3 lower left: teeth 31-38",
            "Q4": "Q4 lower right: teeth 41-48",
        }[quadrant]
        draw.text((5, 5), label, fill=(255, 255, 0), font=font)
        crop.save(output_dir / f"{quadrant}.jpg", quality=96, subsampling=0)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--splits", nargs="+", default=["Train-Labeled", "Validation"])
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    jobs = []
    for split in args.splits:
        for source in sorted(
            (ROOT / "dental_arch_views" / split).glob("*.jpg"), key=lambda path: case_sort_key(path.stem)
        ):
            output_dir = ROOT / "quadrant_views" / split / source.stem
            complete = all((output_dir / f"Q{q}.jpg").is_file() for q in range(1, 5))
            if args.force or not complete:
                jobs.append((source, output_dir))
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        futures = {
            pool.submit(make_quadrants, source, output_dir): output_dir
            for source, output_dir in jobs
        }
        for index, future in enumerate(as_completed(futures), start=1):
            future.result()
            print(f"[{index}/{len(jobs)}] {futures[future].relative_to(ROOT)}", flush=True)


if __name__ == "__main__":
    main()
