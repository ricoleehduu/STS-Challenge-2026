# Result status

## Complete GQ-TSR implementation

The complete `gq_tsr` code path is structurally and end-to-end tested. A tiny
synthetic CPU smoke run successfully executed volume caching, image-only
pretraining, two-fold warmup, guarded joint EMA training, bundle creation,
field retrieval, submission generation, and an independent validation rerun.
Synthetic metrics are intentionally not reported as method performance.

No fresh full-data GPU experiment was run as part of this source integration.
Formal results must be read from the outputs of `gq-tsr run-all` using the real
data and `configs/gq_tsr/default.yaml`.

## Legacy frozen-feature retrieval context

The earlier development run recorded the following local proxy values:

| Metric | Previous development run |
|---|---:|
| weighted proxy | **0.2643284852** |
| tooth notation F1 | 0.1802380952 |
| diagnosis F1 | 0.2547619048 |
| diagnosis-code F1 | 0.1426666667 |
| treatment-action F1 | 0.5642770563 |
| medication F1 | 0.7400000000 |
| BLEU-1 | 0.2251797350 |
| METEOR approximation | 0.4055828568 |
| ROUGE-L | 0.1936002826 |
| CIDEr approximation | 0.2049535087 |
| field completion | 1.0000000000 |

These values belong to the separate `sts_task3_v7` baseline. They are retained
as development context and are not presented as a fresh full GQ-TSR server run
or an official Codabench score. For baseline reproducibility, training and
validation feature caches must be kept in separate directories and created
with the same encoder. A new `sts-task3-v7 run-local` execution writes metrics to
`<output-dir>/validation_metrics.json` and its cache provenance to
`<output-dir>/cache_audit.json`.

Because the supplied validation labels drive global field-policy selection,
the resulting value is a development-set score rather than an unbiased blind
test estimate.
