from __future__ import annotations

import argparse
from pathlib import Path

import nibabel as nib
import numpy as np
import pandas as pd


FIELDS = (
    "Main appeal",
    "Present medical history",
    "Oral Check",
    "Diagnosis",
    "Treatment plan",
    "Handle",
    "Doctor advices",
)


def make_volume(seed: int, positive: bool) -> np.ndarray:
    rng = np.random.default_rng(seed)
    volume = rng.normal(0.05, 0.01, size=(24, 28, 20)).astype(np.float32)
    x, y, z = np.ogrid[:24, :28, :20]
    center = (12 + seed % 2, 14, 10)
    foreground = (
        ((x - center[0]) / 7) ** 2
        + ((y - center[1]) / 9) ** 2
        + ((z - center[2]) / 6) ** 2
        < 1
    )
    volume[foreground] += 0.55
    if positive:
        lesion = (x - 15) ** 2 + (y - 17) ** 2 + (z - 11) ** 2 < 8
        volume[lesion] += 0.35
    return volume


def record(case_id: str, index: int, positive: bool) -> dict[str, object]:
    tooth = "36" if positive else "46"
    return {
        "Filename": case_id,
        "Sex": "Female" if positive else "Male",
        "Age": 30 + index,
        "Main appeal": (
            "Molar pain for three days." if positive else "Food impaction in a molar."
        ),
        "Present medical history": (
            "Spontaneous pain and cold sensitivity."
            if positive
            else "Intermittent discomfort while chewing."
        ),
        "Oral Check": f"Tooth #{tooth} shows a deep carious lesion.",
        "Diagnosis": (
            f"K04.0 pulpitis of tooth #{tooth}."
            if positive
            else f"K02.9 dental caries of tooth #{tooth}."
        ),
        "Treatment plan": (
            "Root canal treatment and crown restoration."
            if positive
            else "Caries removal and dental restoration."
        ),
        "Handle": (
            "Local anesthesia with lidocaine and canal preparation."
            if positive
            else "Caries removal and resin filling."
        ),
        "Doctor advices": "Avoid hard food and return for follow-up.",
    }


def save_case(root: Path, case_id: str, seed: int, positive: bool) -> None:
    case_dir = root / case_id
    case_dir.mkdir(parents=True, exist_ok=True)
    destination = case_dir / f"{case_id}.nii.gz"
    if destination.exists():
        raise FileExistsError(f"Refusing to overwrite {destination}")
    nib.save(nib.Nifti1Image(make_volume(seed, positive), np.eye(4)), destination)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Create a tiny labeled/unlabeled/validation dataset for GQ-TSR smoke tests"
    )
    parser.add_argument("--output", default="tmp/synthetic_gq_tsr")
    parser.add_argument("--labeled-cases", type=int, default=6)
    parser.add_argument("--unlabeled-cases", type=int, default=2)
    parser.add_argument("--validation-cases", type=int, default=2)
    args = parser.parse_args()
    if args.labeled_cases < 2:
        parser.error("--labeled-cases must be at least 2")
    if args.unlabeled_cases < 1 or args.validation_cases < 1:
        parser.error("unlabeled and validation case counts must be positive")

    root = Path(args.output)
    if root.exists() and any(root.iterdir()):
        raise FileExistsError(f"Output directory is not empty: {root}")
    labeled_dir = root / "Train-Labeled"
    unlabeled_dir = root / "Train-Unlabeled"
    validation_dir = root / "Validation"
    evaluation_dir = root / "evaluation"

    labeled_rows: list[dict[str, object]] = []
    for index in range(args.labeled_cases):
        case_id = str(101 + index)
        positive = index % 2 == 0
        save_case(labeled_dir, case_id, index, positive)
        labeled_rows.append(record(case_id, index, positive))
    labeled_dir.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(labeled_rows).to_csv(
        labeled_dir / "Train-Labeled.csv", index=False, encoding="utf-8-sig"
    )

    for index in range(args.unlabeled_cases):
        case_id = str(201 + index)
        save_case(unlabeled_dir, case_id, 100 + index, index % 2 == 0)

    validation_rows: list[dict[str, object]] = []
    for index in range(args.validation_cases):
        case_id = str(301 + index)
        positive = index % 2 == 0
        save_case(validation_dir, case_id, 200 + index, positive)
        validation_rows.append(record(case_id, 100 + index, positive))
    evaluation_dir.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(validation_rows).to_csv(
        evaluation_dir / "validation_ground_truth.csv", index=False, encoding="utf-8-sig"
    )

    print(root.resolve())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
