from __future__ import annotations

import sys
from pathlib import Path


PROJECT = Path(__file__).resolve().parents[1]
SOURCE = PROJECT / "src"
if str(SOURCE) not in sys.path:
    sys.path.insert(0, str(SOURCE))

from sts_task3_v7.cli import main  # noqa: E402


if __name__ == "__main__":
    raise SystemExit(main())
