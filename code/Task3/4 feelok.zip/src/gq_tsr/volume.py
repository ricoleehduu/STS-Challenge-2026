from __future__ import annotations

from pathlib import Path
from time import perf_counter

import nibabel as nib
import numpy as np
import torch
import torch.nn.functional as F

from .io import CaseItem, write_json


def _bounds(volume: np.ndarray, margin: int) -> tuple[slice, slice, slice]:
    stride = tuple(max(1, size // 192) for size in volume.shape)
    coarse = volume[::stride[0], ::stride[1], ::stride[2]]
    foreground = coarse > max(0.03, float(np.percentile(coarse, 20)))
    if not foreground.any():
        return (slice(None), slice(None), slice(None))
    lo, hi = [], []
    for axis in range(3):
        occupied = foreground.any(axis=tuple(i for i in range(3) if i != axis))
        values = np.flatnonzero(occupied)
        lo.append(max(0, int(values[0]) * stride[axis] - margin))
        hi.append(min(volume.shape[axis], (int(values[-1]) + 1) * stride[axis] + margin))
    if any(end - start < 8 for start, end in zip(lo, hi)):
        return (slice(None), slice(None), slice(None))
    return tuple(slice(start, end) for start, end in zip(lo, hi))  # type: ignore[return-value]


def load_volume(path: str | Path, config: dict) -> torch.Tensor:
    image = nib.as_closest_canonical(nib.load(str(path)))
    volume = np.asarray(image.dataobj, dtype=np.float32)
    if volume.ndim == 4 and volume.shape[-1] == 1:
        volume = volume[..., 0]
    if volume.ndim != 3:
        raise ValueError(f"Expected 3-D NIfTI, got {volume.shape} at {path}")
    volume = np.ascontiguousarray(volume)
    stride = tuple(max(1, size // 160) for size in volume.shape)
    sample = volume[::stride[0], ::stride[1], ::stride[2]]
    sample = sample[np.isfinite(sample)]
    if not sample.size:
        raise ValueError(f"No finite voxels in {path}")
    lo, hi = np.percentile(sample, [float(config.get("percentile_low", 0.5)), float(config.get("percentile_high", 99.5))])
    if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
        lo, hi = float(np.nanmin(sample)), float(np.nanmax(sample))
    np.nan_to_num(volume, copy=False, nan=float(lo), posinf=float(hi), neginf=float(lo))
    if hi <= lo:
        volume.fill(0)
    else:
        np.clip(volume, lo, hi, out=volume)
        volume = (volume - lo) / (hi - lo)
    volume = volume[_bounds(volume, int(config.get("foreground_margin", 8)))]
    target = tuple(int(v) for v in config["shape"])
    tensor = torch.from_numpy(np.ascontiguousarray(volume))[None, None]
    tensor = F.interpolate(tensor, size=target, mode="trilinear", align_corners=False)
    return tensor[0].clamp_(0, 1).float()


class VolumeStore:
    def __init__(self, cache_root: str | Path | None, config: dict) -> None:
        self.root = Path(cache_root) if cache_root else None
        self.config = config
        self.memory: dict[tuple[str, str], torch.Tensor] = {}

    def path(self, item: CaseItem) -> Path | None:
        return self.root / item.split / f"{item.case_id}.npy" if self.root else None

    def load(self, item: CaseItem) -> torch.Tensor:
        key = (item.split, item.case_id)
        if bool(self.config.get("preload", False)) and key in self.memory:
            return self.memory[key].clone()
        path = self.path(item)
        if path and path.exists():
            value = torch.from_numpy(np.asarray(np.load(path), dtype=np.float32))
        else:
            value = load_volume(item.image_path, self.config)
        if value.ndim != 4 or value.shape[0] != 1:
            raise ValueError(f"Expected cached [1,D,H,W], got {tuple(value.shape)} for {item.case_id}")
        if bool(self.config.get("preload", False)):
            self.memory[key] = value.clone()
        return value

    def preload(self, items: list[CaseItem]) -> dict:
        started = perf_counter()
        for item in items:
            self.load(item)
        total = sum(v.numel() * v.element_size() for v in self.memory.values())
        return {"cases": len(self.memory), "megabytes": total / 1024**2, "seconds": perf_counter() - started}


def cache_volumes(items: list[CaseItem], output_dir: str | Path, config: dict, overwrite: bool = False) -> dict:
    root = Path(output_dir)
    dtype = np.float16 if str(config.get("cache_dtype", "float16")) == "float16" else np.float32
    manifest, started = [], perf_counter()
    for index, item in enumerate(items, 1):
        destination = root / item.split / f"{item.case_id}.npy"
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists() and not overwrite:
            status = "reused"
        else:
            array = load_volume(item.image_path, config).numpy().astype(dtype)
            np.save(destination, array)
            status = "written"
        manifest.append({"case_id": item.case_id, "split": item.split, "path": str(destination.resolve()), "status": status})
        print(f"[cache-volume] {index}/{len(items)} {item.split}/{item.case_id}: {status}", flush=True)
    payload = {"cases": len(items), "seconds": perf_counter() - started, "shape": list(config["shape"]), "dtype": str(dtype), "items": manifest, "targets_read": 0}
    write_json(payload, root / "manifest.json")
    return payload
