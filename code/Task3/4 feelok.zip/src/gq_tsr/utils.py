from __future__ import annotations

import math
import random
from pathlib import Path
from typing import Iterator

import numpy as np
import torch
from torch.utils.data import DataLoader


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = True


def resolve_device(value: str) -> torch.device:
    device = torch.device(value)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but torch.cuda.is_available() is false")
    return device


def move_to_device(value, device: torch.device):
    if torch.is_tensor(value):
        return value.to(device, non_blocking=True)
    if isinstance(value, dict):
        return {key: move_to_device(item, device) for key, item in value.items()}
    if isinstance(value, (list, tuple)) and value and not isinstance(value[0], str):
        return type(value)(move_to_device(item, device) for item in value)
    return value


def infinite(loader: DataLoader) -> Iterator[dict]:
    while True:
        yield from loader


def cosine_learning_rate(step: int, total: int, warmup: int, maximum: float, minimum: float) -> float:
    if step <= warmup:
        return maximum * step / max(1, warmup)
    progress = min(max((step - warmup) / max(1, total - warmup), 0.0), 1.0)
    return minimum + 0.5 * (maximum - minimum) * (1.0 + math.cos(math.pi * progress))


def set_optimizer_learning_rates(optimizer: torch.optim.Optimizer, learning_rates: list[float]) -> None:
    if len(optimizer.param_groups) != len(learning_rates):
        raise ValueError("Learning-rate list does not match optimizer groups")
    for group, value in zip(optimizer.param_groups, learning_rates):
        group["lr"] = float(value)


def cpu_state_dict(model: torch.nn.Module) -> dict[str, torch.Tensor]:
    return {name: value.detach().cpu().clone() for name, value in model.state_dict().items()}


def safe_torch_load(path: str | Path, map_location: str | torch.device = "cpu"):
    try:
        return torch.load(path, map_location=map_location, weights_only=False)
    except TypeError:
        return torch.load(path, map_location=map_location)


def autocast_context(device: torch.device, enabled: bool):
    return torch.autocast(device_type=device.type, dtype=torch.float16, enabled=bool(enabled and device.type == "cuda"))
