from __future__ import annotations

import argparse

from .pipeline import (
    audit_data, cache_task_volumes, evaluate_files, predict_task, pretrain_task,
    print_result, run_complete, train_task, validate_task,
)


def _data_arguments(parser: argparse.ArgumentParser, validation_csv: bool = True) -> None:
    parser.add_argument("--labeled-dir", required=True)
    parser.add_argument("--labeled-csv", required=True)
    parser.add_argument("--unlabeled-dir", required=True)
    parser.add_argument("--validation-dir", required=True)
    parser.add_argument("--validation-csv", required=validation_csv)
    parser.add_argument("--config", dest="config_path")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="gq-tsr",
        description="Complete Guarded Query Teacher-Student Retrieval for STS Task 3",
    )
    commands = parser.add_subparsers(dest="command", required=True)

    audit = commands.add_parser("audit-data", help="Run the structural no-unlabeled-label firewall")
    _data_arguments(audit, False)
    audit.add_argument("--output")

    cache = commands.add_parser("cache-volumes", help="Cache normalized image volumes only")
    cache.add_argument("--labeled-dir", required=True)
    cache.add_argument("--unlabeled-dir", required=True)
    cache.add_argument("--validation-dir", required=True)
    cache.add_argument("--output-dir", required=True)
    cache.add_argument("--config", dest="config_path")
    cache.add_argument("--overwrite", action="store_true")

    pretrain = commands.add_parser("pretrain", help="Image-only masked-volume encoder pretraining")
    pretrain.add_argument("--labeled-dir", required=True)
    pretrain.add_argument("--unlabeled-dir", required=True)
    pretrain.add_argument("--volume-cache")
    pretrain.add_argument("--output-dir", required=True)
    pretrain.add_argument("--config", dest="config_path")
    pretrain.add_argument("--device", default="cuda")
    pretrain.add_argument("--resume", action="store_true")

    train = commands.add_parser("train", help="5-fold warmup plus full 3D EMA Teacher joint training")
    _data_arguments(train, False)
    train.add_argument("--volume-cache")
    train.add_argument("--pretrained-encoder")
    train.add_argument("--output-dir", required=True)
    train.add_argument("--device", default="cuda")
    train.add_argument("--resume", action="store_true")

    run_all = commands.add_parser(
        "run-all",
        help="Audit, cache, pretrain, train the guarded EMA model, and validate",
    )
    _data_arguments(run_all, True)
    run_all.add_argument("--output-dir", required=True)
    run_all.add_argument("--device", default="cuda")
    run_all.add_argument("--resume", action="store_true")
    run_all.add_argument("--overwrite-cache", action="store_true")
    run_all.add_argument(
        "--skip-pretrain",
        action="store_true",
        help="Train from random initialization (an ablation, not the full default method)",
    )

    validate = commands.add_parser("validate", help="Predict and score a labeled validation set")
    validate.add_argument("--bundle", required=True)
    validate.add_argument("--validation-dir", required=True)
    validate.add_argument("--validation-csv", required=True)
    validate.add_argument("--volume-cache")
    validate.add_argument("--output-dir", required=True)
    validate.add_argument("--device", default="cuda")
    validate.add_argument("--hubness-penalty", type=float)
    validate.add_argument("--entity-rerank-weight", type=float)
    validate.add_argument("--calibrated-entity-hard-weight", type=float)
    validate.add_argument("--entity-constraint-top-k", type=int)
    validate.add_argument(
        "--hard-entity-constraints", action=argparse.BooleanOptionalAction, default=None,
        help="Enable/disable configured hard entity constraints during retrieval",
    )
    validate.add_argument(
        "--cross-fold-candidate-aggregation", action=argparse.BooleanOptionalAction, default=None,
    )

    predict = commands.add_parser("predict", help="Predict seven Task3 fields and build submission.zip")
    predict.add_argument("--bundle", required=True)
    predict.add_argument("--query-dir", required=True)
    predict.add_argument("--volume-cache")
    predict.add_argument("--output-dir", required=True)
    predict.add_argument("--device", default="cuda")
    predict.add_argument("--hubness-penalty", type=float)
    predict.add_argument("--entity-rerank-weight", type=float)
    predict.add_argument("--calibrated-entity-hard-weight", type=float)
    predict.add_argument("--entity-constraint-top-k", type=int)
    predict.add_argument(
        "--hard-entity-constraints", action=argparse.BooleanOptionalAction, default=None,
        help="Enable/disable configured hard entity constraints during retrieval",
    )
    predict.add_argument(
        "--cross-fold-candidate-aggregation", action=argparse.BooleanOptionalAction, default=None,
    )

    evaluate = commands.add_parser("evaluate", help="Score an existing predictions.json")
    evaluate.add_argument("--predictions-json", required=True)
    evaluate.add_argument("--ground-truth-csv", required=True)
    evaluate.add_argument("--bundle")
    evaluate.add_argument("--output")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    values = vars(args)
    command = values.pop("command")
    if command == "audit-data":
        result = audit_data(**values)
    elif command == "cache-volumes":
        result = cache_task_volumes(**values)
    elif command == "pretrain":
        result = pretrain_task(**values)
    elif command == "train":
        result = train_task(**values)
    elif command == "run-all":
        result = run_complete(**values)
    elif command == "validate":
        result = validate_task(**values)
    elif command == "predict":
        result = predict_task(**values)
    elif command == "evaluate":
        result = evaluate_files(**values)
    else:
        raise AssertionError(command)
    print_result(result)
    return 0
