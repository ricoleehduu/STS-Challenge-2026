from __future__ import annotations

import json
import zipfile
from pathlib import Path

from .constants import FIELDS
from .io import write_json
from .records import clean_text


def validate_predictions(predictions: object, expected_case_ids: list[str] | None = None) -> list[str]:
    if not isinstance(predictions, dict):
        return ["predictions.json root must be an object"]
    errors: list[str] = []
    for case_id, record in predictions.items():
        if not isinstance(record, dict):
            errors.append(f"{case_id}: expected an object")
            continue
        if set(record) != set(FIELDS):
            errors.append(f"{case_id}: fields differ from required seven fields")
        for field in FIELDS:
            if not isinstance(record.get(field), str) or not clean_text(record.get(field)):
                errors.append(f"{case_id}/{field}: must be a non-empty string")
    if expected_case_ids is not None and set(map(str, expected_case_ids)) != set(map(str, predictions)):
        errors.append("Prediction case IDs do not exactly match query IDs")
    return errors


def write_submission(predictions: dict[str, dict[str, str]], output_zip: str | Path, expected_case_ids: list[str]) -> tuple[Path, Path]:
    if errors := validate_predictions(predictions, expected_case_ids):
        raise ValueError("Invalid predictions:\n- " + "\n- ".join(errors))
    output_zip = Path(output_zip)
    output_zip.parent.mkdir(parents=True, exist_ok=True)
    predictions_path = output_zip.with_name("predictions.json")
    write_json(predictions, predictions_path)
    with zipfile.ZipFile(output_zip, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.write(predictions_path, "predictions.json")
    with zipfile.ZipFile(output_zip) as archive:
        parsed = json.loads(archive.read("predictions.json").decode("utf-8"))
    if errors := validate_predictions(parsed, expected_case_ids):
        raise RuntimeError(f"ZIP self-check failed: {errors}")
    return predictions_path, output_zip
