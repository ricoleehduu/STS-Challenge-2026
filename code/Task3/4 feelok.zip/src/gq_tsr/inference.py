from __future__ import annotations

import csv
from collections import Counter
from copy import deepcopy
from pathlib import Path

import torch

from .calibration import (
    family_is_reliable, family_label_reliability, family_presence_probability,
    family_presence_threshold, family_thresholds,
)
from .datasets import VolumeDataset
from .constants import ENTITY_NAMES, FIELDS
from .entities import EntityVocabulary
from .io import CaseItem, write_json
from .metrics import evaluate_predictions
from .model import build_model
from .retrieval import ensemble_fold_outputs, ensemble_text_predictions, retrieve_text
from .records import clean_text
from .submission import write_submission
from .training import predict_outputs
from .utils import resolve_device, safe_torch_load, seed_everything
from .volume import VolumeStore


def load_bundle(path: str | Path) -> dict:
    bundle = safe_torch_load(path)
    required = {"config", "vocabulary", "folds", "labeled_records", "labeled_items"}
    if missing := required - set(bundle):
        raise ValueError(f"Invalid model bundle; missing {sorted(missing)}")
    return bundle


def _case_items(bundle: dict) -> list[CaseItem]:
    return [CaseItem(**row) for row in bundle["labeled_items"]]


def predict_with_bundle(
    bundle_path: str | Path,
    query_items: list[CaseItem],
    volume_cache: str | Path | None,
    output_dir: str | Path,
    device_name: str,
    references: dict[str, dict[str, str]] | None = None,
    retrieval_overrides: dict[str, object] | None = None,
) -> tuple[dict[str, dict[str, str]], dict | None]:
    bundle = load_bundle(bundle_path)
    config = deepcopy(bundle["config"])
    config["entity_calibration"] = deepcopy(bundle.get("entity_calibration", {"enabled": False, "families": {}}))
    allowed_overrides = {
        "hubness_penalty", "entity_rerank_weight", "calibrated_entity_hard_weight",
        "entity_constraint_top_k", "cross_fold_candidate_aggregation",
        "enable_hard_entity_constraints",
    }
    for name, value in (retrieval_overrides or {}).items():
        if name not in allowed_overrides:
            raise ValueError(f"Unsupported retrieval override: {name}")
        if name in {"cross_fold_candidate_aggregation", "enable_hard_entity_constraints"}:
            config["retrieval"][name] = bool(value)
            continue
        if float(value) < 0:
            raise ValueError(f"Retrieval override {name} must be >= 0")
        if name == "calibrated_entity_hard_weight" and float(value) > 1:
            raise ValueError("calibrated_entity_hard_weight must be <= 1")
        config["retrieval"][name] = int(value) if name == "entity_constraint_top_k" else float(value)
    seed_everything(int(config["seed"]))
    device = resolve_device(device_name)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    write_json(config["retrieval"], output_dir / "retrieval_config.json")
    write_json(config["entity_calibration"], output_dir / "entity_calibration.json")
    vocabulary = EntityVocabulary.from_dict(bundle["vocabulary"])
    dataset = VolumeDataset(query_items, VolumeStore(volume_cache, config["volume"]))
    labeled_items = _case_items(bundle)
    reference_ids = [item.case_id for item in labeled_items]
    reference_records = bundle["labeled_records"]
    fold_predictions, fold_provenance, fold_outputs = [], [], []
    for fold_index, fold in enumerate(bundle["folds"]):
        model = build_model(config["model"], vocabulary).to(device)
        model.load_state_dict(fold["inference_state"])
        output = predict_outputs(model, dataset, config, device)
        fold_outputs.append(output)
        reference_fields, _ = fold["text_space"].transform([reference_records[case_id] for case_id in reference_ids])
        prediction, provenance = retrieve_text(
            output["case_ids"], output["field_embeddings"], output["entity_probabilities"],
            reference_ids, reference_records, reference_fields, vocabulary, config,
            output["count_probabilities"],
        )
        fold_predictions.append(prediction)
        fold_provenance.append(provenance)
        print(f"[predict] completed fold {fold_index + 1}/{len(bundle['folds'])}", flush=True)
        del model
        if device.type == "cuda":
            torch.cuda.empty_cache()
    predictions, provenance = ensemble_text_predictions(fold_predictions, fold_provenance, config)
    ensembled = ensemble_fold_outputs(fold_outputs)
    entity_predictions, entity_audit = _entity_head_predictions(
        ensembled, vocabulary, config["entity_calibration"], config["model"]["max_counts"]
    )
    write_json(predictions, output_dir / "predictions.json")
    write_json(provenance, output_dir / "prediction_provenance.json")
    write_json(entity_predictions, output_dir / "entity_head_predictions.json")
    write_json(entity_audit, output_dir / "entity_head_audit.json")
    diversity = prediction_diversity_audit(predictions, provenance, config, len(bundle["folds"]))
    write_json(diversity, output_dir / "prediction_diversity_audit.json")
    if diversity["warnings"]:
        print("[prediction-diversity] " + " | ".join(diversity["warnings"]), flush=True)
    write_submission(predictions, output_dir / "submission.zip", [item.case_id for item in query_items])
    metrics = None
    if references:
        metrics = evaluate_predictions(predictions, references, config["evaluation"]["weights"])
        metrics["prediction_diversity"] = diversity
        write_json(metrics, output_dir / "validation_metrics.json")
        _write_case_metrics(metrics.get("case_results", {}), output_dir / "validation_case_metrics.csv")
        _write_mean_metrics(metrics.get("metrics_mean", {}), output_dir / "validation_metrics.csv")
    return predictions, metrics


def _entity_head_predictions(
    output: dict, vocabulary: EntityVocabulary, calibration: dict, max_counts: dict,
) -> tuple[dict[str, dict[str, list[str]]], dict]:
    predictions = {case_id: {} for case_id in output["case_ids"]}
    audit = {"cases": len(output["case_ids"]), "families": {}}
    for name in ENTITY_NAMES:
        labels = list(getattr(vocabulary, name))
        values = output["entity_probabilities"][name]
        thresholds = family_thresholds(calibration, name, len(labels))
        label_reliable = family_label_reliability(calibration, name, len(labels))
        reliable = family_is_reliable(calibration, name)
        presence_threshold = family_presence_threshold(calibration, name)
        counts = output["count_probabilities"][name]
        limit = int(max_counts.get(name, len(labels)))
        nonempty = 0
        total = 0
        presence_values: list[float] = []
        for row, case_id in enumerate(output["case_ids"]):
            presence = family_presence_probability(
                calibration, name, values[row], counts[row]
            )
            presence_values.append(presence)
            # An unreliable OOF calibration must never create a hard clinical
            # entity claim. Soft entity probabilities remain available in the
            # saved model outputs and in soft retrieval.
            present = reliable and presence >= presence_threshold
            ranked = sorted(
                (
                    index for index, score in enumerate(values[row])
                    if present and label_reliable[index] and float(score) >= thresholds[index]
                ),
                key=lambda index: float(values[row, index]), reverse=True,
            )[:limit]
            selected = [labels[index] for index in ranked]
            predictions[case_id][name] = selected
            nonempty += int(bool(selected))
            total += len(selected)
        audit["families"][name] = {
            "label_thresholds": thresholds.tolist(),
            "presence_threshold": presence_threshold,
            "calibration_reliable": reliable,
            "predicted_nonempty_cases": nonempty,
            "predicted_nonempty_fraction": nonempty / max(len(output["case_ids"]), 1),
            "mean_predicted_count": total / max(len(output["case_ids"]), 1),
            "mean_presence_probability": sum(presence_values) / max(len(presence_values), 1),
        }
    return predictions, audit


def prediction_diversity_audit(
    predictions: dict[str, dict[str, str]], provenance: dict,
    config: dict | None = None, number_of_folds: int = 5,
) -> dict:
    case_ids = list(predictions)
    full_records = {
        tuple(clean_text(predictions[case_id].get(field)) for field in FIELDS) for case_id in case_ids
    }
    fields: dict[str, dict] = {}
    warnings: list[str] = []
    retrieval = (config or {}).get("retrieval", {})
    maximum_reference_fraction = float(retrieval.get("maximum_reference_fraction_warning", 0.40))
    minimum_majority_fraction = float(retrieval.get("minimum_fold_majority_fraction_warning", 0.20))
    majority_votes = number_of_folds // 2 + 1
    for field in FIELDS:
        texts = [clean_text(predictions[case_id].get(field)) for case_id in case_ids]
        references = [
            str(provenance.get(case_id, {}).get(field, {}).get("reference_case_id", ""))
            for case_id in case_ids
        ]
        counts = Counter(references)
        top_reference, top_count = counts.most_common(1)[0] if counts else ("", 0)
        unique_ratio = len(set(texts)) / max(1, len(texts))
        votes = [
            int(provenance.get(case_id, {}).get(field, {}).get("fold_votes", 0))
            for case_id in case_ids
        ]
        candidate_support = [
            int(provenance.get(case_id, {}).get(field, {}).get("candidate_fold_support", value))
            for case_id, value in zip(case_ids, votes)
        ]
        majority_count = sum(value >= majority_votes for value in votes)
        majority_fraction = majority_count / max(1, len(votes))
        candidate_majority_count = sum(value >= majority_votes for value in candidate_support)
        candidate_majority_fraction = candidate_majority_count / max(1, len(candidate_support))
        top_reference_fraction = top_count / max(1, len(references))
        fields[field] = {
            "unique_texts": len(set(texts)), "unique_ratio": unique_ratio,
            "top_reference_case_id": top_reference, "top_reference_count": top_count,
            "top_reference_fraction": top_reference_fraction,
            "mean_fold_votes": sum(votes) / max(1, len(votes)),
            "majority_vote_threshold": majority_votes,
            "fold_majority_count": majority_count,
            "fold_majority_fraction": majority_fraction,
            "mean_candidate_fold_support": sum(candidate_support) / max(1, len(candidate_support)),
            "candidate_fold_majority_count": candidate_majority_count,
            "candidate_fold_majority_fraction": candidate_majority_fraction,
        }
        if len(case_ids) >= 10 and unique_ratio < 0.10:
            warnings.append(f"{field} unique_ratio={unique_ratio:.3f} indicates retrieval collapse")
        if len(case_ids) >= 10 and top_reference_fraction > maximum_reference_fraction:
            warnings.append(
                f"{field} top_reference_fraction={top_reference_fraction:.3f} indicates reference hubness"
            )
        if len(case_ids) >= 10 and majority_fraction < minimum_majority_fraction:
            warnings.append(
                f"{field} fold_majority_fraction={majority_fraction:.3f} indicates fold instability"
            )
        if (
            bool(retrieval.get("cross_fold_candidate_aggregation", False))
            and len(case_ids) >= 10 and candidate_majority_fraction < minimum_majority_fraction
        ):
            warnings.append(
                f"{field} candidate_fold_majority_fraction={candidate_majority_fraction:.3f} "
                "indicates no stable top-k consensus"
            )
    full_ratio = len(full_records) / max(1, len(case_ids))
    if len(case_ids) >= 10 and full_ratio < 0.10:
        warnings.append(f"full_record_unique_ratio={full_ratio:.3f} indicates output collapse")
    return {
        "cases": len(case_ids), "unique_full_records": len(full_records),
        "full_record_unique_ratio": full_ratio, "fields": fields, "warnings": warnings,
    }


def _write_case_metrics(rows: dict[str, dict[str, float]], path: Path) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    names = sorted({name for row in rows.values() for name in row})
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["case_id", *names])
        writer.writeheader()
        for case_id, row in rows.items():
            writer.writerow({"case_id": case_id, **row})


def _write_mean_metrics(metrics: dict[str, float], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["metric", "value"])
        writer.writerows(sorted(metrics.items()))
