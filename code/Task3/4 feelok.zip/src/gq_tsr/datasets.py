from __future__ import annotations

import numpy as np
import torch
from torch.utils.data import Dataset

from .constants import ENTITY_NAMES
from .entities import EntityVocabulary
from .io import CaseItem
from .text_space import TextTargetSpace
from .volume import VolumeStore


class VolumeDataset(Dataset):
    def __init__(
        self,
        items: list[CaseItem],
        store: VolumeStore,
        records: dict[str, dict[str, str]] | None = None,
        vocabulary: EntityVocabulary | None = None,
        text_space: TextTargetSpace | None = None,
    ) -> None:
        self.items, self.store, self.records = items, store, records
        self.vocabulary, self.text_space = vocabulary, text_space
        self.targets: dict[str, dict] = {}
        if records is not None:
            if vocabulary is None or text_space is None:
                raise ValueError("Labeled dataset requires vocabulary and text space")
            ordered = [records[item.case_id] for item in items]
            fields, record = text_space.transform(ordered)
            for row, item in enumerate(items):
                encoded = vocabulary.encode(records[item.case_id])
                self.targets[item.case_id] = {
                    "entity_targets": {name: torch.from_numpy(encoded[name]) for name in ENTITY_NAMES},
                    "count_targets": {name: torch.tensor(min(int(encoded[name].sum()), 99), dtype=torch.long) for name in ENTITY_NAMES},
                    "field_targets": torch.from_numpy(fields[row]),
                    "record_target": torch.from_numpy(record[row]),
                }

    def __len__(self) -> int:
        return len(self.items)

    def __getitem__(self, index: int) -> dict:
        item = self.items[index]
        output = {"case_id": item.case_id, "volume": self.store.load(item)}
        output.update(self.targets.get(item.case_id, {}))
        return output


def entity_matrix(records: list[dict[str, str]], vocabulary: EntityVocabulary) -> tuple[dict[str, np.ndarray], np.ndarray]:
    encoded = [vocabulary.encode(record) for record in records]
    by_name = {name: np.stack([row[name] for row in encoded]) for name in ENTITY_NAMES}
    return by_name, np.concatenate([by_name[name] for name in ENTITY_NAMES], axis=1)
