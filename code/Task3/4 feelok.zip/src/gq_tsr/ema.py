from __future__ import annotations

import copy

import torch
from torch import nn


def create_teacher(student: nn.Module) -> nn.Module:
    teacher = copy.deepcopy(student)
    teacher.requires_grad_(False)
    teacher.eval()
    return teacher


@torch.no_grad()
def update_teacher(
    teacher: nn.Module,
    student: nn.Module,
    step: int,
    alpha_start: float,
    alpha_end: float,
    total_steps: int,
    bias_correction: bool = True,
) -> float:
    progress = min(max(step / max(total_steps, 1), 0.0), 1.0)
    scheduled = alpha_start + (alpha_end - alpha_start) * progress
    alpha = min(scheduled, 1.0 - 1.0 / float(step + 1)) if bias_correction else scheduled
    teacher_parameters = dict(teacher.named_parameters())
    for name, value in student.named_parameters():
        teacher_parameters[name].mul_(alpha).add_(value.detach(), alpha=1.0 - alpha)
    teacher_buffers = dict(teacher.named_buffers())
    for name, value in student.named_buffers():
        teacher_buffers[name].copy_(value.detach())
    teacher.eval()
    return float(alpha)


@torch.no_grad()
def model_distance(teacher: nn.Module, student: nn.Module) -> dict[str, float]:
    squared, student_squared = 0.0, 0.0
    maximum = 0.0
    teacher_parameters = dict(teacher.named_parameters())
    for name, value in student.named_parameters():
        difference = value.detach().float() - teacher_parameters[name].detach().float()
        squared += float(difference.square().sum().item())
        student_squared += float(value.detach().float().square().sum().item())
        maximum = max(maximum, float(difference.abs().max().item()))
    return {
        "ema_relative_l2": (squared / max(student_squared, 1e-12)) ** 0.5,
        "ema_max_abs": maximum,
    }
