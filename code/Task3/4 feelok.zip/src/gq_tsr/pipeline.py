from __future__ import annotations

import json
from pathlib import Path

from .config import load_config
from .data import load_strict_task_data
from .inference import predict_with_bundle
from .io import build_case_items, read_json, write_json
from .metrics import evaluate_predictions
from .pretraining import pretrain_encoder
from .records import load_records
from .training import train_teacher_student
from .volume import cache_volumes


def audit_data(
    labeled_dir: str, labeled_csv: str, unlabeled_dir: str,
    validation_dir: str, validation_csv: str | None, config_path: str | None,
    output: str | None = None,
) -> dict:
    config = load_config(config_path)
    data = load_strict_task_data(labeled_dir, labeled_csv, unlabeled_dir, validation_dir, validation_csv, config)
    if output:
        write_json(data.audit, output)
    return data.audit


def cache_task_volumes(
    labeled_dir: str, unlabeled_dir: str, validation_dir: str,
    output_dir: str, config_path: str | None, overwrite: bool,
) -> dict:
    config = load_config(config_path)
    items = (
        build_case_items(labeled_dir, "labeled")
        + build_case_items(unlabeled_dir, "unlabeled")
        + build_case_items(validation_dir, "validation")
    )
    return cache_volumes(items, output_dir, config["volume"], overwrite)


def pretrain_task(
    labeled_dir: str, unlabeled_dir: str, volume_cache: str | None,
    output_dir: str, config_path: str | None, device: str, resume: bool,
) -> dict:
    config = load_config(config_path)
    labeled = build_case_items(labeled_dir, "labeled")
    unlabeled = build_case_items(unlabeled_dir, "unlabeled")
    overlap = {item.case_id for item in labeled} & {item.case_id for item in unlabeled}
    if overlap:
        raise ValueError(f"Labeled/unlabeled overlap: {sorted(overlap)[:10]}")
    counts = {"labeled": len(labeled), "unlabeled": len(unlabeled)}
    if bool(config["data"].get("strict_counts", True)):
        expected = {"labeled": int(config["data"]["expected_labeled_cases"]), "unlabeled": int(config["data"]["expected_unlabeled_cases"])}
        if counts != expected:
            raise ValueError(f"Unexpected pretraining counts: actual={counts}, expected={expected}")
    return pretrain_encoder(labeled + unlabeled, volume_cache, output_dir, config, device, resume)


def train_task(
    labeled_dir: str, labeled_csv: str, unlabeled_dir: str,
    validation_dir: str, validation_csv: str | None, volume_cache: str | None,
    pretrained_encoder: str | None, output_dir: str, config_path: str | None,
    device: str, resume: bool,
) -> dict:
    config = load_config(config_path)
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    data = load_strict_task_data(labeled_dir, labeled_csv, unlabeled_dir, validation_dir, validation_csv, config)
    write_json(data.audit, output / "data_firewall_audit.json")
    bundle = train_teacher_student(
        data.labeled_items, data.unlabeled_items, data.labeled_records, volume_cache,
        output, config, device, pretrained_encoder, resume,
    )
    metrics = None
    if data.validation_records:
        _, metrics = predict_with_bundle(
            output / "model_bundle.pt", data.validation_items, volume_cache,
            output / "validation", device, data.validation_records,
        )
    return {"bundle": str((output / "model_bundle.pt").resolve()), "data_audit": data.audit, "validation_metrics": metrics}


def run_complete(
    labeled_dir: str,
    labeled_csv: str,
    unlabeled_dir: str,
    validation_dir: str,
    validation_csv: str | None,
    output_dir: str,
    config_path: str | None,
    device: str,
    resume: bool,
    overwrite_cache: bool,
    skip_pretrain: bool,
) -> dict:
    """Run the complete GQ-TSR data-to-validation workflow.

    The validation labels are passed to ``train_task`` only for the final
    external evaluation.  Fold selection, text spaces, calibration, and
    pseudo-labels are fitted exclusively from the labeled training split.
    """
    root = Path(output_dir)
    root.mkdir(parents=True, exist_ok=True)
    volume_cache = root / "volume_cache"
    pretrain_dir = root / "pretrain"
    train_dir = root / "train"

    audit = audit_data(
        labeled_dir, labeled_csv, unlabeled_dir, validation_dir,
        validation_csv, config_path, str(root / "data_firewall_audit.json"),
    )
    cache_report = cache_task_volumes(
        labeled_dir, unlabeled_dir, validation_dir, str(volume_cache),
        config_path, overwrite_cache,
    )

    pretrain_report: dict | None = None
    pretrained_encoder: str | None = None
    if not skip_pretrain:
        pretrain_report = pretrain_task(
            labeled_dir, unlabeled_dir, str(volume_cache), str(pretrain_dir),
            config_path, device, resume,
        )
        pretrained_encoder = str(pretrain_dir / "encoder_pretrained.pt")

    train_report = train_task(
        labeled_dir, labeled_csv, unlabeled_dir, validation_dir,
        validation_csv, str(volume_cache), pretrained_encoder,
        str(train_dir), config_path, device, resume,
    )
    summary = {
        "workflow": "complete_gq_tsr",
        "output_dir": str(root.resolve()),
        "data_audit": audit,
        "volume_cache": cache_report,
        "pretraining": pretrain_report,
        "training": train_report,
    }
    write_json(summary, root / "run_all_summary.json")
    return summary


def validate_task(
    bundle: str, validation_dir: str, validation_csv: str,
    volume_cache: str | None, output_dir: str, device: str,
    hubness_penalty: float | None = None, entity_rerank_weight: float | None = None,
    calibrated_entity_hard_weight: float | None = None,
    entity_constraint_top_k: int | None = None,
    hard_entity_constraints: bool | None = None,
    cross_fold_candidate_aggregation: bool | None = None,
) -> dict:
    records = load_records(validation_csv)
    items = build_case_items(validation_dir, "validation")
    if {item.case_id for item in items} != set(records):
        raise ValueError("Validation image IDs and ground-truth IDs do not match")
    overrides = {
        name: value for name, value in {
            "hubness_penalty": hubness_penalty,
            "entity_rerank_weight": entity_rerank_weight,
            "calibrated_entity_hard_weight": calibrated_entity_hard_weight,
            "entity_constraint_top_k": entity_constraint_top_k,
            "enable_hard_entity_constraints": hard_entity_constraints,
            "cross_fold_candidate_aggregation": cross_fold_candidate_aggregation,
        }.items() if value is not None
    }
    _, metrics = predict_with_bundle(
        bundle, items, volume_cache, output_dir, device, records, overrides
    )
    assert metrics is not None
    return metrics


def predict_task(
    bundle: str, query_dir: str, volume_cache: str | None, output_dir: str, device: str,
    hubness_penalty: float | None = None, entity_rerank_weight: float | None = None,
    calibrated_entity_hard_weight: float | None = None,
    entity_constraint_top_k: int | None = None,
    hard_entity_constraints: bool | None = None,
    cross_fold_candidate_aggregation: bool | None = None,
) -> dict:
    items = build_case_items(query_dir, "query")
    overrides = {
        name: value for name, value in {
            "hubness_penalty": hubness_penalty,
            "entity_rerank_weight": entity_rerank_weight,
            "calibrated_entity_hard_weight": calibrated_entity_hard_weight,
            "entity_constraint_top_k": entity_constraint_top_k,
            "enable_hard_entity_constraints": hard_entity_constraints,
            "cross_fold_candidate_aggregation": cross_fold_candidate_aggregation,
        }.items() if value is not None
    }
    predictions, _ = predict_with_bundle(
        bundle, items, volume_cache, output_dir, device,
        retrieval_overrides=overrides,
    )
    return {"cases": len(predictions), "output_dir": str(Path(output_dir).resolve())}


def evaluate_files(predictions_json: str, ground_truth_csv: str, bundle: str | None, output: str | None) -> dict:
    predictions = read_json(predictions_json)
    references = load_records(ground_truth_csv)
    if bundle:
        from .inference import load_bundle
        weights = load_bundle(bundle)["config"]["evaluation"]["weights"]
    else:
        weights = load_config()["evaluation"]["weights"]
    metrics = evaluate_predictions(predictions, references, weights)  # type: ignore[arg-type]
    if output:
        write_json(metrics, output)
    return metrics


def print_result(value: dict) -> None:
    print(json.dumps(value, ensure_ascii=False, indent=2, default=str))
