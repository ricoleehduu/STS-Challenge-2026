FIELDS = (
    "Main appeal",
    "Present medical history",
    "Oral Check",
    "Diagnosis",
    "Treatment plan",
    "Handle",
    "Doctor advices",
)

ENTITY_NAMES = ("teeth", "diagnoses", "diagnosis_codes", "treatments", "medications")
NON_TOOTH_ENTITIES = ENTITY_NAMES[1:]
FDI_ADULT_TEETH = tuple(f"{quadrant}{position}" for quadrant in range(1, 5) for position in range(1, 9))

ID_ALIASES = ("Filename", "filename", "case_id", "Case ID", "id", "ID")
FIELD_ALIASES = {
    "Main appeal": ("Main appeal", "main appeal", "chief complaint", "Chief complaint"),
    "Present medical history": ("Present medical history", "present medical history", "present history"),
    "Oral Check": ("Oral Check", "oral check", "oral examination", "Oral examination"),
    "Diagnosis": ("Diagnosis", "diagnosis"),
    "Treatment plan": ("Treatment plan", "treatment plan"),
    "Handle": ("Handle", "handle", "treatment performed", "procedure"),
    "Doctor advices": ("Doctor advices", "doctor advices", "doctor advice", "advice"),
}
OPTIONAL_INPUT_FIELDS = ("Sex", "Age", "Past medical history", "Subsequent")

EMPTY_FALLBACKS = {
    "Main appeal": "Dental consultation.",
    "Present medical history": "Dental symptoms require clinical correlation.",
    "Oral Check": "Dental examination findings require clinical correlation.",
    "Diagnosis": "Dental condition requiring professional assessment.",
    "Treatment plan": "Further dental evaluation and appropriate treatment are recommended.",
    "Handle": "Clinical management according to examination findings.",
    "Doctor advices": "Maintain oral hygiene and return for dental follow-up.",
}
