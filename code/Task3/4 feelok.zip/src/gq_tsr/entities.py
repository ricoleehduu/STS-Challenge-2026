from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass
from typing import Iterable

import numpy as np

from .constants import ENTITY_NAMES, FDI_ADULT_TEETH, FIELDS
from .records import clean_text

DIAGNOSIS_PATTERNS = {
    "caries": (r"\bcar(?:y|ies|ious)\b", r"dental decay", r"龋"),
    "pulpitis": (r"\bpulpitis\b", r"牙髓炎"),
    "pulp necrosis": (r"pulp(?:al)? necrosis", r"牙髓坏死"),
    "apical periodontitis": (r"(?:peri)?apical periodontitis", r"根尖周炎"),
    "periodontitis": (r"\bperiodontitis\b", r"牙周炎", r"periodontal disease"),
    "gingivitis": (r"\bgingivitis\b", r"牙龈炎"),
    "impacted tooth": (r"impact(?:ed|ion)", r"impressed teeth", r"阻生"),
    "missing tooth": (r"missing teeth?", r"tooth loss", r"缺失牙", r"牙缺失"),
    "retained root": (r"retained root", r"residual root", r"残根"),
    "periapical lesion": (r"periapical lesion", r"periapical radioluc", r"根尖.*(?:病变|低密度)"),
    "dental abscess": (r"(?:dental|periapical|periodontal) abscess", r"脓肿"),
    "tooth fracture": (r"(?:tooth|root) fracture", r"牙折", r"根折"),
    "malocclusion": (r"malocclusion", r"uneven teeth", r"错颌", r"错合"),
    "pericoronitis": (r"pericoronitis", r"冠周炎"),
    "temporomandibular disorder": (r"temporomandibular", r"\bTMD\b", r"颞下颌关节"),
}

TREATMENT_PATTERNS = {
    "root canal treatment": (r"root canal", r"\bRCT\b", r"endodontic", r"根管治疗"),
    "restoration": (r"restoration", r"filling", r"充填", r"修复"),
    "extraction": (r"extract(?:ion|ed)?", r"removal", r"exodont", r"拔除", r"拔牙"),
    "periodontal treatment": (r"periodontal treatment", r"scaling", r"root planing", r"洁治"),
    "orthodontic treatment": (r"orthodont", r"window traction", r"正畸", r"牵引"),
    "implant treatment": (r"implant", r"种植"),
    "crown restoration": (r"crown restoration", r"冠修复", r"牙冠修复"),
    "surgical treatment": (r"surg(?:ery|ical)", r"手术"),
    "medication": (r"medication", r"prescri", r"用药", r"口服"),
    "observation": (r"observation", r"monitor", r"观察"),
    "follow-up": (r"follow[ -]?up", r"review", r"复诊", r"随访"),
    "oral hygiene instruction": (r"oral hygiene", r"刷牙", r"口腔卫生"),
}

MEDICATION_PATTERNS = {
    "amoxicillin": (r"amoxicillin", r"阿莫西林"),
    "metronidazole": (r"metronidazole", r"甲硝唑"),
    "ibuprofen": (r"ibuprofen", r"布洛芬"),
    "acetaminophen": (r"acetaminophen", r"paracetamol", r"对乙酰氨基酚"),
    "chlorhexidine": (r"chlorhexidine", r"氯己定"),
    "cephalosporin": (r"cephalospor", r"头孢"),
    "clindamycin": (r"clindamycin", r"克林霉素"),
    "articaine": (r"articaine", r"阿替卡因"),
    "lidocaine": (r"lidocaine", r"利多卡因"),
}


def _match(text: str, patterns: dict[str, tuple[str, ...]]) -> set[str]:
    return {label for label, values in patterns.items() if any(re.search(value, text, re.I) for value in values)}


def extract_teeth(text: str) -> set[str]:
    found: set[str] = set()
    for pattern in (
        r"(?:tooth|teeth|#|\*|牙位|牙|齿)\s*[*#:]?\s*([1-4][1-8])\b",
        r"\b([1-4][1-8])\s*(?:tooth|teeth|牙|齿)\b",
        r"(?:^|[;,.])\s*([1-4][1-8])(?=\s|[;,.])",
    ):
        found.update(value for value in re.findall(pattern, clean_text(text), re.I) if value in FDI_ADULT_TEETH)
    return found


def extract_entities(record: dict[str, str]) -> dict[str, set[str]]:
    diagnostic = " ".join(clean_text(record.get(f)) for f in ("Main appeal", "Oral Check", "Diagnosis"))
    treatment = " ".join(clean_text(record.get(f)) for f in ("Treatment plan", "Handle", "Doctor advices"))
    tooth = " ".join(clean_text(record.get(f)) for f in ("Main appeal", "Oral Check", "Diagnosis", "Treatment plan"))
    all_text = " ".join(clean_text(record.get(f)) for f in FIELDS)
    return {
        "teeth": extract_teeth(tooth),
        "diagnoses": _match(diagnostic, DIAGNOSIS_PATTERNS),
        "diagnosis_codes": {v.upper() for v in re.findall(r"\b([A-Z]\d{2}(?:\.\d{1,4})?)\b", diagnostic, re.I)},
        "treatments": _match(treatment, TREATMENT_PATTERNS),
        "medications": _match(all_text, MEDICATION_PATTERNS),
    }


@dataclass
class EntityVocabulary:
    teeth: list[str]
    diagnoses: list[str]
    diagnosis_codes: list[str]
    treatments: list[str]
    medications: list[str]

    @classmethod
    def fit(cls, records: Iterable[dict[str, str]]) -> "EntityVocabulary":
        counters = {name: Counter() for name in ENTITY_NAMES[1:]}
        for record in records:
            values = extract_entities(record)
            for name in counters:
                counters[name].update(values[name])
        return cls(
            teeth=list(FDI_ADULT_TEETH),
            diagnoses=[v for v, _ in counters["diagnoses"].most_common(64)],
            diagnosis_codes=[v for v, _ in counters["diagnosis_codes"].most_common(64)],
            treatments=[v for v, _ in counters["treatments"].most_common(48)],
            medications=[v for v, _ in counters["medications"].most_common(32)],
        )

    def to_dict(self) -> dict[str, list[str]]:
        return {name: list(getattr(self, name)) for name in ENTITY_NAMES}

    @classmethod
    def from_dict(cls, value: dict[str, list[str]]) -> "EntityVocabulary":
        return cls(**{name: list(value.get(name, [])) for name in ENTITY_NAMES})

    def encode(self, record: dict[str, str]) -> dict[str, np.ndarray]:
        values = extract_entities(record)
        return {name: np.asarray([float(label in values[name]) for label in getattr(self, name)], np.float32) for name in ENTITY_NAMES}

    def decode(self, probabilities: dict[str, np.ndarray], thresholds: dict[str, float], max_counts: dict[str, int]) -> dict[str, list[str]]:
        output: dict[str, list[str]] = {}
        for name in ENTITY_NAMES:
            labels = getattr(self, name)
            scores = np.asarray(probabilities.get(name, []), np.float32)
            threshold = float(thresholds.get(name, 0.35))
            ranked = sorted((i for i in range(len(scores)) if scores[i] >= threshold), key=lambda i: float(scores[i]), reverse=True)
            count_scores = np.asarray(probabilities.get(f"{name}__count", []), np.float32)
            limit = int(max_counts.get(name, len(labels)))
            if count_scores.size and float(count_scores.max()) >= 0.35:
                limit = min(limit, int(count_scores.argmax()))
            output[name] = [labels[i] for i in ranked[:limit]]
        return output


def entity_vector(vocabulary: EntityVocabulary, record: dict[str, str]) -> np.ndarray:
    encoded = vocabulary.encode(record)
    return np.concatenate([encoded[name] for name in ENTITY_NAMES]).astype(np.float32)
