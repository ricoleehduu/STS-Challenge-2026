from __future__ import annotations

import hashlib
import json
from copy import deepcopy
from pathlib import Path

import yaml


def _merge(base: dict, update: dict) -> dict:
    result = deepcopy(base)
    for key, value in update.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = _merge(result[key], value)
        else:
            result[key] = deepcopy(value)
    return result


def load_config(path: str | Path | None = None) -> dict:
    # Keep the effective default inside the Python package so an installed
    # wheel does not depend on the source checkout (or any reference project).
    default_path = Path(__file__).resolve().parent / "configs" / "default.yaml"
    with default_path.open("r", encoding="utf-8") as handle:
        base = yaml.safe_load(handle) or {}
    config = base
    if path is not None:
        with Path(path).open("r", encoding="utf-8") as handle:
            update = yaml.safe_load(handle) or {}
        if not isinstance(update, dict):
            raise ValueError("Configuration root must be a mapping")
        config = _merge(base, update)
    validate_config(config)
    return config


def validate_config(config: dict) -> None:
    """Fail before loading data when a run cannot execute its intended stages."""
    training = config["training"]
    warmup_steps = int(training["warmup_steps"])
    joint_steps = int(training["joint_steps"])
    warmup_min = int(training["warmup_min_steps_before_selection"])
    joint_min = int(training["joint_min_steps_before_selection"])
    online_start = int(training["online_teacher_start_step"])
    eval_every = int(training["eval_every_steps"])
    accumulation = int(training["accumulation_steps"])

    errors: list[str] = []
    if warmup_min < 1 or warmup_steps < warmup_min:
        errors.append(
            "training.warmup_steps must be >= warmup_min_steps_before_selection >= 1 "
            f"(got {warmup_steps}, {warmup_min})"
        )
    joint_enabled = bool(training.get("enable_joint", True))
    if joint_enabled and not (joint_steps > joint_min >= online_start >= 1):
        errors.append(
            "joint schedule must satisfy joint_steps > joint_min_steps_before_selection "
            ">= online_teacher_start_step >= 1 "
            f"(got {joint_steps}, {joint_min}, {online_start})"
        )
    if not joint_enabled and joint_steps < 0:
        errors.append("training.joint_steps must be >= 0 when joint training is disabled")
    if eval_every < 1:
        errors.append("training.eval_every_steps must be >= 1")
    if accumulation < 1:
        errors.append("training.accumulation_steps must be >= 1")
    if int(training["folds"]) < 2:
        errors.append("training.folds must be >= 2")
    if float(training.get("amp_initial_scale", 1.0)) <= 0:
        errors.append("training.amp_initial_scale must be > 0")
    if int(training.get("field_contrast_queue_size", 0)) < 0:
        errors.append("training.field_contrast_queue_size must be >= 0")
    for name in (
        "encoder_learning_rate", "head_learning_rate",
        "joint_encoder_learning_rate", "joint_head_learning_rate",
    ):
        if float(training[name]) <= 0:
            errors.append(f"training.{name} must be > 0")
    selection = training["checkpoint_selection"]
    if not 0.0 <= float(selection["diversity_floor"]) <= 1.0:
        errors.append("training.checkpoint_selection.diversity_floor must be in [0, 1]")
    if float(selection["joint_loss_relative_limit"]) < 1.0:
        errors.append("training.checkpoint_selection.joint_loss_relative_limit must be >= 1")
    if int(selection["joint_required_consecutive_evaluations"]) < 1:
        errors.append("joint_required_consecutive_evaluations must be >= 1")
    pseudo = config["pseudo_labels"]
    if float(pseudo["maximum_negative_to_positive_ratio"]) < 0:
        errors.append("pseudo_labels.maximum_negative_to_positive_ratio must be >= 0")
    valid_families = {"teeth", "diagnoses", "diagnosis_codes", "treatments", "medications"}
    unknown_families = set(pseudo["enabled_families"]) - valid_families
    if unknown_families:
        errors.append(f"pseudo_labels.enabled_families contains unknown values: {sorted(unknown_families)}")
    for name in ("offline_weight", "online_weight"):
        if float(pseudo[name]) < 0:
            errors.append(f"pseudo_labels.{name} must be >= 0")
    calibration = config.get("entity_calibration", {})
    lower = float(calibration.get("minimum_threshold", 0.10))
    upper = float(calibration.get("maximum_threshold", 0.90))
    if not 0.0 < lower < upper < 1.0:
        errors.append("entity_calibration thresholds must satisfy 0 < minimum < maximum < 1")
    if int(calibration.get("threshold_steps", 33)) < 2:
        errors.append("entity_calibration.threshold_steps must be >= 2")
    if int(calibration.get("minimum_positive_cases", 3)) < 1:
        errors.append("entity_calibration.minimum_positive_cases must be >= 1")
    if int(calibration.get("minimum_positive_labels_per_class", 1)) < 1:
        errors.append("entity_calibration.minimum_positive_labels_per_class must be >= 1")
    if not 0.0 <= float(calibration.get("minimum_f1_for_reliable", 0.10)) <= 1.0:
        errors.append("entity_calibration.minimum_f1_for_reliable must be in [0, 1]")
    for name in ("minimum_precision_for_reliable", "minimum_specificity_for_reliable"):
        if not 0.0 <= float(calibration.get(name, 0.0)) <= 1.0:
            errors.append(f"entity_calibration.{name} must be in [0, 1]")
    if float(calibration.get("maximum_predicted_to_observed_ratio", 1.0)) < 1.0:
        errors.append("entity_calibration.maximum_predicted_to_observed_ratio must be >= 1")
    if not 0.0 <= float(calibration.get("presence_entity_weight", 1.0)) <= 1.0:
        errors.append("entity_calibration.presence_entity_weight must be in [0, 1]")
    retrieval = config["retrieval"]
    if not 0.0 <= float(retrieval.get("calibrated_entity_hard_weight", 0.0)) <= 1.0:
        errors.append("retrieval.calibrated_entity_hard_weight must be in [0, 1]")
    unknown_constraints = set(retrieval.get("hard_entity_constraints", [])) - valid_families
    if unknown_constraints:
        errors.append(f"retrieval.hard_entity_constraints contains unknown values: {sorted(unknown_constraints)}")
    if int(retrieval.get("entity_constraint_top_k", 1)) < 1:
        errors.append("retrieval.entity_constraint_top_k must be >= 1")
    if int(retrieval.get("candidate_vote_top_k", 1)) < 1:
        errors.append("retrieval.candidate_vote_top_k must be >= 1")
    if int(retrieval.get("minimum_candidate_fold_support", 1)) < 1:
        errors.append("retrieval.minimum_candidate_fold_support must be >= 1")
    if int(config["model"]["field_dim"]) != int(config["text"]["field_dim"]):
        errors.append("model.field_dim and text.field_dim must match")
    if int(config["model"]["record_dim"]) != int(config["text"]["record_dim"]):
        errors.append("model.record_dim and text.record_dim must match")
    if errors:
        raise ValueError("Invalid configuration:\n- " + "\n- ".join(errors))


def config_fingerprint(config: dict) -> str:
    serialized = json.dumps(config, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(serialized.encode("utf-8")).hexdigest()


def write_resolved_config(config: dict, output_dir: str | Path) -> tuple[Path, str]:
    """Persist the fully merged configuration used by a run."""
    root = Path(output_dir)
    root.mkdir(parents=True, exist_ok=True)
    output = root / "resolved_config.yaml"
    with output.open("w", encoding="utf-8", newline="\n") as handle:
        yaml.safe_dump(config, handle, allow_unicode=True, sort_keys=False)
    fingerprint = config_fingerprint(config)
    (root / "config_fingerprint.txt").write_text(fingerprint + "\n", encoding="utf-8")
    return output, fingerprint
