from __future__ import annotations

import math
from pathlib import Path

import pandas as pd

from .constants import FIELD_ALIASES, FIELDS, ID_ALIASES, OPTIONAL_INPUT_FIELDS
from .io import canonical_case_id


def _read_csv(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(path)
    last_error: Exception | None = None
    for encoding in ("utf-8-sig", "utf-8", "gb18030"):
        try:
            return pd.read_csv(path, encoding=encoding, dtype=object)
        except UnicodeDecodeError as exc:
            last_error = exc
    assert last_error is not None
    raise last_error


def clean_text(value: object) -> str:
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return ""
    text = " ".join(str(value).replace("\r", " ").replace("\n", " ").split())
    return "" if text.casefold() in {"nan", "none", "null", "n/a", "na"} else text


def _resolve(columns: list[str], aliases: tuple[str, ...]) -> str | None:
    lookup = {column.strip().casefold(): column for column in columns}
    return next((lookup[a.strip().casefold()] for a in aliases if a.strip().casefold() in lookup), None)


def load_records(path: str | Path, merge: str = "most_complete") -> dict[str, dict[str, str]]:
    frame = _read_csv(path)
    columns = [str(column) for column in frame.columns]
    id_column = _resolve(columns, ID_ALIASES)
    if id_column is None:
        raise ValueError(f"No case ID column found; expected one of {ID_ALIASES}")
    field_columns = {field: _resolve(columns, aliases) for field, aliases in FIELD_ALIASES.items()}
    missing = [field for field, column in field_columns.items() if column is None]
    if missing:
        raise ValueError(f"CSV misses Task3 fields: {missing}")
    optional = {field: _resolve(columns, (field, field.lower())) for field in OPTIONAL_INPUT_FIELDS}
    grouped: dict[str, list[dict[str, str]]] = {}
    for _, source in frame.iterrows():
        raw_id = clean_text(source.get(id_column))
        if not raw_id:
            continue
        row = {"case_id": canonical_case_id(raw_id)}
        row.update({field: clean_text(source.get(field_columns[field])) for field in FIELDS})
        row.update({field: clean_text(source.get(column)) if column else "" for field, column in optional.items()})
        grouped.setdefault(row["case_id"], []).append(row)
    result: dict[str, dict[str, str]] = {}
    for case_id, rows in grouped.items():
        if merge == "first":
            selected = rows[0]
        elif merge == "last":
            selected = rows[-1]
        elif merge == "most_complete":
            selected = max(rows, key=lambda r: (sum(bool(r[f]) for f in FIELDS), sum(len(r[f]) for f in FIELDS)))
        else:
            raise ValueError(f"Unsupported record merge: {merge}")
        result[case_id] = dict(selected)
    return result


def serialize_record(record: dict[str, str]) -> str:
    return " ".join(f"[{field.upper().replace(' ', '_')}] {clean_text(record.get(field))}" for field in FIELDS)
