from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from sklearn.decomposition import TruncatedSVD
from sklearn.feature_extraction.text import TfidfVectorizer

from .constants import FIELDS
from .records import clean_text, serialize_record


def normalized(values: np.ndarray) -> np.ndarray:
    values = np.nan_to_num(values, copy=False, nan=0.0, posinf=0.0, neginf=0.0)
    return (values / np.maximum(np.linalg.norm(values, axis=-1, keepdims=True), 1e-8)).astype(np.float32)


@dataclass
class Projection:
    vectorizer: TfidfVectorizer
    svd: TruncatedSVD | None
    output_dim: int

    def transform(self, texts: list[str]) -> np.ndarray:
        matrix = self.vectorizer.transform([text or "[EMPTY]" for text in texts])
        values = self.svd.transform(matrix) if self.svd is not None else matrix.toarray()
        if values.shape[1] < self.output_dim:
            values = np.pad(values, ((0, 0), (0, self.output_dim - values.shape[1])))
        return normalized(values[:, :self.output_dim])


@dataclass
class TextTargetSpace:
    fields: list[Projection]
    record: Projection

    @staticmethod
    def _fit(texts: list[str], dim: int, config: dict, seed: int) -> Projection:
        vectorizer = TfidfVectorizer(
            analyzer="char_wb",
            ngram_range=(int(config["ngram_min"]), int(config["ngram_max"])),
            max_features=int(config["max_features"]),
            lowercase=True,
            sublinear_tf=True,
        )
        matrix = vectorizer.fit_transform([text or "[EMPTY]" for text in texts])
        rank = min(dim, max(0, matrix.shape[0] - 1), max(0, matrix.shape[1] - 1))
        svd = TruncatedSVD(n_components=rank, random_state=seed).fit(matrix) if rank >= 2 else None
        return Projection(vectorizer, svd, dim)

    @classmethod
    def fit(cls, records: list[dict[str, str]], config: dict, seed: int) -> "TextTargetSpace":
        fields = [cls._fit([clean_text(r.get(field)) for r in records], int(config["field_dim"]), config, seed + i) for i, field in enumerate(FIELDS)]
        return cls(fields, cls._fit([serialize_record(r) for r in records], int(config["record_dim"]), config, seed + 100))

    def transform(self, records: list[dict[str, str]]) -> tuple[np.ndarray, np.ndarray]:
        fields = np.stack([projection.transform([clean_text(r.get(field)) for r in records]) for field, projection in zip(FIELDS, self.fields)], axis=1)
        return fields.astype(np.float32), self.record.transform([serialize_record(r) for r in records]).astype(np.float32)
