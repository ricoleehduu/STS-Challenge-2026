from __future__ import annotations

import math
import re
from collections import Counter

import numpy as np

from .constants import ENTITY_NAMES, FIELDS
from .entities import extract_entities
from .records import clean_text


def tokenize(text: str) -> list[str]:
    return re.findall(r"[a-z0-9#]+|[\u4e00-\u9fff]", clean_text(text).casefold())


def _ngrams(tokens: list[str], size: int) -> Counter[tuple[str, ...]]:
    return Counter(tuple(tokens[index:index + size]) for index in range(max(0, len(tokens) - size + 1)))


def bleu(prediction: str, reference: str, size: int) -> float:
    predicted, expected = _ngrams(tokenize(prediction), size), _ngrams(tokenize(reference), size)
    if not predicted:
        return 0.0
    overlap = sum(min(count, expected[gram]) for gram, count in predicted.items())
    pred_len, ref_len = len(tokenize(prediction)), len(tokenize(reference))
    brevity = 1.0 if pred_len >= ref_len else math.exp(1.0 - ref_len / max(1, pred_len))
    return brevity * overlap / sum(predicted.values())


def rouge_l(prediction: str, reference: str) -> float:
    first, second = tokenize(prediction), tokenize(reference)
    if not first or not second:
        return 0.0
    previous = [0] * (len(second) + 1)
    for token in first:
        current = [0]
        for index, other in enumerate(second, 1):
            current.append(previous[index - 1] + 1 if token == other else max(previous[index], current[-1]))
        previous = current
    precision, recall = previous[-1] / len(first), previous[-1] / len(second)
    return 2 * precision * recall / max(precision + recall, 1e-8)


def meteor(prediction: str, reference: str) -> float:
    predicted, expected = Counter(tokenize(prediction)), Counter(tokenize(reference))
    matches = sum(min(count, expected[token]) for token, count in predicted.items())
    if not matches:
        return 0.0
    precision = matches / max(1, sum(predicted.values()))
    recall = matches / max(1, sum(expected.values()))
    return 10 * precision * recall / max(recall + 9 * precision, 1e-8)


def cider(prediction: str, reference: str) -> float:
    scores: list[float] = []
    for size in range(1, 5):
        first, second = _ngrams(tokenize(prediction), size), _ngrams(tokenize(reference), size)
        keys = set(first) | set(second)
        dot = sum(first[key] * second[key] for key in keys)
        norms = math.sqrt(sum(first[key] ** 2 for key in keys) * sum(second[key] ** 2 for key in keys))
        scores.append(dot / max(norms, 1e-8))
    return float(np.mean(scores))


def set_prf(predicted: set[str], expected: set[str]) -> dict[str, float]:
    true_positive = len(predicted & expected)
    precision = true_positive / len(predicted) if predicted else float(not expected)
    recall = true_positive / len(expected) if expected else float(not predicted)
    return {"precision": precision, "recall": recall, "f1": 2 * precision * recall / max(precision + recall, 1e-8)}


def evaluate_case(prediction: dict[str, str], reference: dict[str, str], weights: dict) -> dict[str, float]:
    predicted_text = " ".join(clean_text(prediction.get(field)) for field in FIELDS)
    reference_text = " ".join(clean_text(reference.get(field)) for field in FIELDS)
    result = {f"bleu_{size}": bleu(predicted_text, reference_text, size) for size in range(1, 5)}
    result.update({"meteor": meteor(predicted_text, reference_text), "rouge_l": rouge_l(predicted_text, reference_text), "cider": cider(predicted_text, reference_text)})
    predicted_entities, expected_entities = extract_entities(prediction), extract_entities(reference)
    for name in ENTITY_NAMES:
        result.update({f"{name}_{metric}": value for metric, value in set_prf(predicted_entities[name], expected_entities[name]).items()})
    predicted_diagnosis = clean_text(prediction.get("Diagnosis")).casefold()
    reference_diagnosis = clean_text(reference.get("Diagnosis")).casefold()
    result["diagnosis_exact_match"] = float(bool(reference_diagnosis) and predicted_diagnosis == reference_diagnosis)
    result["diagnosis_partial_match"] = rouge_l(predicted_diagnosis, reference_diagnosis)
    result["field_completion_rate"] = sum(bool(clean_text(prediction.get(field))) for field in FIELDS) / len(FIELDS)
    text_score = np.mean([result[f"bleu_{size}"] for size in range(1, 5)] + [result["meteor"], result["rouge_l"], result["cider"]])
    diagnosis_score = np.mean([result["diagnoses_f1"], result["diagnosis_partial_match"], result["diagnosis_exact_match"]])
    result["weighted_proxy"] = float(
        weights["text"] * text_score + weights["teeth"] * result["teeth_f1"]
        + weights["diagnoses"] * diagnosis_score + weights["diagnosis_codes"] * result["diagnosis_codes_f1"]
        + weights["treatments"] * result["treatments_f1"] + weights["medications"] * result["medications_f1"]
        + weights["completion"] * result["field_completion_rate"]
    )
    return result


def evaluate_predictions(predictions: dict[str, dict[str, str]], references: dict[str, dict[str, str]], weights: dict) -> dict:
    common = sorted(set(predictions) & set(references))
    cases = {case_id: evaluate_case(predictions[case_id], references[case_id], weights) for case_id in common}
    names = sorted({name for row in cases.values() for name in row})
    mean = {name: float(np.mean([row[name] for row in cases.values()])) if cases else 0.0 for name in names}
    entity_prevalence: dict[str, dict[str, float | int]] = {}
    for name in ENTITY_NAMES:
        eligible = [case_id for case_id in common if extract_entities(references[case_id])[name]]
        mean[f"{name}_f1_nonempty_reference"] = (
            float(np.mean([cases[case_id][f"{name}_f1"] for case_id in eligible])) if eligible else 0.0
        )
        entity_prevalence[name] = {
            "nonempty_reference_cases": len(eligible),
            "fraction": len(eligible) / max(1, len(common)),
        }
    fields: dict[str, dict[str, float]] = {}
    for field in FIELDS:
        fields[field] = {
            **{f"bleu_{size}": float(np.mean([bleu(predictions[case][field], references[case][field], size) for case in common])) if common else 0.0 for size in range(1, 5)},
            "meteor": float(np.mean([meteor(predictions[case][field], references[case][field]) for case in common])) if common else 0.0,
            "rouge_l": float(np.mean([rouge_l(predictions[case][field], references[case][field]) for case in common])) if common else 0.0,
            "cider": float(np.mean([cider(predictions[case][field], references[case][field]) for case in common])) if common else 0.0,
            "completion": float(np.mean([bool(clean_text(predictions[case][field])) for case in common])) if common else 0.0,
            "unique_ratio": len({clean_text(predictions[case][field]) for case in common}) / max(1, len(common)),
        }
    return {
        "num_reference_cases": len(references), "num_evaluated": len(common),
        "num_missing_predictions": len(set(references) - set(predictions)),
        "metrics_mean": mean, "field_metrics": fields,
        "entity_reference_prevalence": entity_prevalence, "case_results": cases,
    }
