from __future__ import annotations

import numpy as np

from .constants import ENTITY_NAMES


def _binary_metrics(probabilities: np.ndarray, targets: np.ndarray, threshold: float) -> dict[str, float]:
    predicted = np.asarray(probabilities) >= float(threshold)
    expected = np.asarray(targets) >= 0.5
    true_positive = int((predicted & expected).sum())
    false_positive = int((predicted & ~expected).sum())
    false_negative = int((~predicted & expected).sum())
    true_negative = int((~predicted & ~expected).sum())
    precision = true_positive / max(true_positive + false_positive, 1)
    recall = true_positive / max(true_positive + false_negative, 1)
    specificity = true_negative / max(true_negative + false_positive, 1)
    f1 = 2.0 * precision * recall / max(precision + recall, 1e-12)
    total = max(int(expected.size), 1)
    observed_fraction = (true_positive + false_negative) / total
    predicted_fraction = (true_positive + false_positive) / total
    prevalence_ratio = predicted_fraction / max(observed_fraction, 1e-12)
    return {
        "f1": float(f1), "precision": float(precision), "recall": float(recall),
        "specificity": float(specificity),
        "observed_positive_fraction": float(observed_fraction),
        "predicted_positive_fraction": float(predicted_fraction),
        "predicted_to_observed_ratio": float(prevalence_ratio),
        "true_positive": true_positive, "true_negative": true_negative,
        "false_positive": false_positive, "false_negative": false_negative,
    }


def _passes_reliability(metrics: dict[str, float], settings: dict) -> bool:
    return (
        metrics["f1"] >= float(settings["minimum_f1_for_reliable"])
        and metrics["precision"] >= float(settings["minimum_precision_for_reliable"])
        and metrics["specificity"] >= float(settings["minimum_specificity_for_reliable"])
        and metrics["predicted_to_observed_ratio"]
        <= float(settings["maximum_predicted_to_observed_ratio"])
    )


def _select_threshold(
    probabilities: np.ndarray, targets: np.ndarray, grid: np.ndarray, settings: dict,
) -> tuple[float, dict[str, float], bool]:
    scored = [
        (float(threshold), _binary_metrics(probabilities, targets, float(threshold)))
        for threshold in grid
    ]
    eligible = [item for item in scored if _passes_reliability(item[1], settings)]
    pool = eligible or scored
    # With equal F1, prefer precision and then a higher threshold. This keeps
    # rare-family hard decisions conservative.
    threshold, metrics = max(
        pool, key=lambda item: (item[1]["f1"], item[1]["precision"], item[0])
    )
    return threshold, metrics, bool(eligible)


def _presence_probability(
    entity_probability: np.ndarray, count_probability: np.ndarray | None,
    entity_weight: float,
) -> np.ndarray:
    values = np.asarray(entity_probability, np.float32)
    entity_presence = values.max(axis=-1) if values.shape[-1] else np.zeros(values.shape[0], np.float32)
    if count_probability is None:
        return entity_presence.astype(np.float32)
    counts = np.asarray(count_probability, np.float32)
    if counts.ndim != 2 or counts.shape[0] != values.shape[0] or counts.shape[1] < 1:
        raise ValueError("Count calibration probabilities must have shape [cases, count_classes]")
    count_presence = 1.0 - counts[:, 0]
    return (entity_weight * entity_presence + (1.0 - entity_weight) * count_presence).astype(np.float32)


def fit_entity_calibration(
    probabilities: dict[str, np.ndarray],
    targets: dict[str, np.ndarray],
    config: dict,
    count_probabilities: dict[str, np.ndarray] | None = None,
) -> dict:
    """Fit leakage-free label and presence thresholds from OOF labeled predictions.

    A family is reliable only when both flattened label prediction and case-level
    presence prediction pass F1, precision, specificity and prevalence guards.
    Validation/test labels are never accepted by this API.
    """
    raw = config.get("entity_calibration", {})
    enabled = bool(raw.get("enabled", True))
    minimum = float(raw.get("minimum_threshold", 0.10))
    maximum = float(raw.get("maximum_threshold", 0.90))
    steps = int(raw.get("threshold_steps", 33))
    grid = np.linspace(minimum, maximum, steps, dtype=np.float32)
    minimum_cases = int(raw.get("minimum_positive_cases", 3))
    minimum_per_class = int(raw.get("minimum_positive_labels_per_class", 1))
    settings = {
        "minimum_f1_for_reliable": float(raw.get("minimum_f1_for_reliable", 0.10)),
        "minimum_precision_for_reliable": float(raw.get("minimum_precision_for_reliable", 0.0)),
        "minimum_specificity_for_reliable": float(raw.get("minimum_specificity_for_reliable", 0.0)),
        "maximum_predicted_to_observed_ratio": float(
            raw.get("maximum_predicted_to_observed_ratio", 1000.0)
        ),
    }
    entity_weight = float(raw.get("presence_entity_weight", 1.0))
    families: dict[str, dict] = {}
    case_count = 0
    for name in ENTITY_NAMES:
        values = np.asarray(probabilities[name], np.float32)
        expected = np.asarray(targets[name], np.float32)
        if values.shape != expected.shape:
            raise ValueError(
                f"Entity calibration shape mismatch for {name}: {values.shape} != {expected.shape}"
            )
        if values.ndim != 2:
            raise ValueError(f"Entity calibration arrays for {name} must be two-dimensional")
        case_count = max(case_count, int(values.shape[0]))
        positive_cases = int((expected >= 0.5).any(axis=1).sum())
        positive_labels = int((expected >= 0.5).sum())
        if not enabled or values.size == 0 or positive_labels == 0:
            families[name] = {
                "threshold": 0.5, "label_thresholds": [0.5] * int(values.shape[1]),
                "label_reliable": [False] * int(values.shape[1]),
                "presence_threshold": 0.5,
                "f1": 0.0, "precision": 0.0, "recall": 0.0, "specificity": 0.0,
                "positive_cases": positive_cases, "positive_labels": positive_labels,
                "reliable": False,
                "reason": "calibration_disabled" if not enabled else "no_positive_oof_labels",
            }
            continue

        threshold, best, label_gate = _select_threshold(values, expected, grid, settings)
        count_values = None if count_probabilities is None else count_probabilities.get(name)
        presence_values = _presence_probability(values, count_values, entity_weight)
        presence_targets = (expected >= 0.5).any(axis=1).astype(np.float32)
        presence_threshold, presence_metrics, presence_gate = _select_threshold(
            presence_values, presence_targets, grid, settings
        )

        label_thresholds: list[float] = []
        label_reliable: list[bool] = []
        for column in range(values.shape[1]):
            positives = int((expected[:, column] >= 0.5).sum())
            if positives < minimum_per_class:
                label_thresholds.append(0.5)
                label_reliable.append(False)
                continue
            current_threshold, _, current_reliable = _select_threshold(
                values[:, column], expected[:, column], grid, settings
            )
            label_thresholds.append(float(current_threshold))
            label_reliable.append(bool(current_reliable))

        reliable = (
            positive_cases >= minimum_cases and label_gate and presence_gate
            and any(label_reliable)
        )
        failed: list[str] = []
        if positive_cases < minimum_cases:
            failed.append("insufficient_positive_cases")
        if not label_gate:
            failed.append("label_quality_guard")
        if not presence_gate:
            failed.append("presence_quality_guard")
        if not any(label_reliable):
            failed.append("no_reliable_label")
        families[name] = {
            "threshold": float(threshold), **best,
            "label_thresholds": label_thresholds, "label_reliable": label_reliable,
            "presence_threshold": float(presence_threshold),
            "presence_f1": float(presence_metrics["f1"]),
            "presence_precision": float(presence_metrics["precision"]),
            "presence_recall": float(presence_metrics["recall"]),
            "presence_specificity": float(presence_metrics["specificity"]),
            "presence_predicted_nonempty_fraction": float(
                presence_metrics["predicted_positive_fraction"]
            ),
            "presence_observed_nonempty_fraction": float(
                presence_metrics["observed_positive_fraction"]
            ),
            "presence_predicted_to_observed_ratio": float(
                presence_metrics["predicted_to_observed_ratio"]
            ),
            "presence_uses_count_head": count_values is not None,
            "presence_entity_weight": entity_weight,
            "positive_cases": positive_cases, "positive_labels": positive_labels,
            "reliable": bool(reliable),
            "reason": "reliable" if reliable else "+".join(failed),
        }
    return {
        "enabled": enabled,
        "source": "out_of_fold_labeled_only",
        "cases": case_count,
        "families": families,
        "settings": {
            "minimum_threshold": minimum, "maximum_threshold": maximum,
            "threshold_steps": steps, "minimum_positive_cases": minimum_cases,
            "minimum_positive_labels_per_class": minimum_per_class,
            "presence_entity_weight": entity_weight,
            **settings,
        },
    }


def family_threshold(calibration: dict | None, name: str, default: float = 0.5) -> float:
    family = (calibration or {}).get("families", {}).get(name, {})
    return float(family.get("threshold", default))


def family_thresholds(
    calibration: dict | None, name: str, size: int, default: float = 0.5,
) -> np.ndarray:
    family = (calibration or {}).get("families", {}).get(name, {})
    values = family.get("label_thresholds")
    if isinstance(values, list) and len(values) == size:
        return np.asarray(values, np.float32)
    return np.full(size, family_threshold(calibration, name, default), np.float32)


def family_label_reliability(calibration: dict | None, name: str, size: int) -> np.ndarray:
    family = (calibration or {}).get("families", {}).get(name, {})
    values = family.get("label_reliable")
    if isinstance(values, list) and len(values) == size:
        return np.asarray(values, bool)
    return np.full(size, bool(family.get("reliable", False)), bool)


def family_presence_probability(
    calibration: dict | None, name: str, entity_probability: np.ndarray,
    count_probability: np.ndarray | None = None,
) -> float:
    family = (calibration or {}).get("families", {}).get(name, {})
    weight = float(family.get("presence_entity_weight", 1.0))
    entity = np.asarray(entity_probability, np.float32).reshape(1, -1)
    count = None if count_probability is None else np.asarray(count_probability, np.float32).reshape(1, -1)
    return float(_presence_probability(entity, count, weight)[0])


def family_presence_threshold(calibration: dict | None, name: str, default: float = 0.5) -> float:
    family = (calibration or {}).get("families", {}).get(name, {})
    return float(family.get("presence_threshold", family.get("threshold", default)))


def family_is_reliable(calibration: dict | None, name: str) -> bool:
    return bool((calibration or {}).get("families", {}).get(name, {}).get("reliable", False))
