from __future__ import annotations

from pathlib import Path
from time import perf_counter

import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader

from .augment import block_mask, weak_augment
from .config import config_fingerprint, write_resolved_config
from .datasets import VolumeDataset
from .io import CaseItem, write_json
from .model import MaskedVolumeAutoencoder, parameter_report
from .monitoring import RunLogger
from .utils import (
    autocast_context, cosine_learning_rate, infinite, move_to_device, resolve_device,
    safe_torch_load, seed_everything,
)
from .volume import VolumeStore


def _reconstruction_loss(reconstructed: torch.Tensor, target: torch.Tensor, masked: torch.Tensor, foreground_weight: float) -> torch.Tensor:
    region = (masked - target).abs() > 1e-6
    weights = torch.ones_like(target) + foreground_weight * (target > 0.10).to(target.dtype)
    selected = region.to(target.dtype)
    if not bool(region.any()):
        selected = torch.ones_like(target)
    return ((reconstructed - target).abs() * weights * selected).sum() / (weights * selected).sum().clamp_min(1.0)


def pretrain_encoder(
    items: list[CaseItem],
    volume_cache: str | Path | None,
    output_dir: str | Path,
    config: dict,
    device_name: str,
    resume: bool = False,
) -> dict:
    seed_everything(int(config["seed"]))
    device = resolve_device(device_name)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    fingerprint = config_fingerprint(config)
    existing_fingerprint = output_dir / "config_fingerprint.txt"
    if existing_fingerprint.exists():
        previous = existing_fingerprint.read_text(encoding="utf-8").strip()
        if previous != fingerprint:
            raise ValueError("Pretraining configuration does not match the existing run directory; use a new output directory")
    elif (output_dir / "pretrain_latest.pt").exists() or (output_dir / "encoder_pretrained.pt").exists():
        raise ValueError("Legacy pretraining checkpoints have no config fingerprint; use a new output directory")
    resolved_path, _ = write_resolved_config(config, output_dir)
    print(f"[config] resolved={resolved_path.resolve()} sha256={fingerprint}", flush=True)
    dataset = VolumeDataset(items, VolumeStore(volume_cache, config["volume"]))
    loader = DataLoader(
        dataset, batch_size=int(config["pretrain"]["batch_size"]), shuffle=True,
        num_workers=int(config["training"]["num_workers"]), pin_memory=bool(config["training"]["pin_memory"]),
        persistent_workers=int(config["training"]["num_workers"]) > 0,
    )
    stream = infinite(loader)
    model = MaskedVolumeAutoencoder(config["model"]).to(device)
    settings = config["pretrain"]
    optimizer = torch.optim.AdamW(model.parameters(), lr=float(settings["learning_rate"]), weight_decay=float(settings["weight_decay"]))
    scaler = torch.cuda.amp.GradScaler(
        enabled=bool(settings["amp"] and device.type == "cuda"),
        init_scale=float(settings.get("amp_initial_scale", 4096.0)),
    )
    start_step = 0
    latest = output_dir / "pretrain_latest.pt"
    if resume and latest.exists():
        payload = safe_torch_load(latest)
        if payload.get("config_fingerprint") != fingerprint:
            raise ValueError(
                f"Refusing incompatible pretraining checkpoint {latest}; use a new output directory"
            )
        model.load_state_dict(payload["model"])
        optimizer.load_state_dict(payload["optimizer"])
        scaler.load_state_dict(payload["scaler"])
        start_step = int(payload["step"])
    report = {**parameter_report(model), "cases": len(dataset), "target_fields_read": 0, "start_step": start_step}
    write_json(report, output_dir / "pretrain_model_audit.json")
    logger = RunLogger(output_dir, bool(config["logging"]["tensorboard"]))
    total_steps = int(settings["steps"])
    accumulation = int(settings["accumulation_steps"])
    started = perf_counter()
    for step in range(start_step + 1, total_steps + 1):
        model.train()
        optimizer.zero_grad(set_to_none=True)
        sums = {"reconstruction": 0.0, "pretrain_consistency": 0.0, "pretrain_total": 0.0}
        learning_rate = cosine_learning_rate(
            step, total_steps, int(settings["warmup_steps"]),
            float(settings["learning_rate"]), float(settings["minimum_learning_rate"]),
        )
        optimizer.param_groups[0]["lr"] = learning_rate
        for _ in range(accumulation):
            batch = move_to_device(next(stream), device)
            target = batch["volume"]
            first = block_mask(weak_augment(target, config["augmentation"]), float(settings["mask_ratio"]), settings["block_size"])
            second = block_mask(weak_augment(target, config["augmentation"]), float(settings["mask_ratio"]), settings["block_size"])
            with autocast_context(device, bool(settings["amp"])):
                reconstructed, first_embedding = model(first)
                with torch.no_grad():
                    _, second_embedding = model(second)
                reconstruction = _reconstruction_loss(reconstructed, target, first, float(settings["foreground_weight"]))
                consistency = F.mse_loss(first_embedding, second_embedding.detach())
                loss = reconstruction + float(settings["consistency_weight"]) * consistency
            scaler.scale(loss / accumulation).backward()
            sums["reconstruction"] += float(reconstruction.detach()) / accumulation
            sums["pretrain_consistency"] += float(consistency.detach()) / accumulation
            sums["pretrain_total"] += float(loss.detach()) / accumulation
        scaler.unscale_(optimizer)
        gradient_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), float(settings["gradient_clip"]))
        previous_scale = float(scaler.get_scale())
        scaler.step(optimizer)
        scaler.update()
        amp_scale = float(scaler.get_scale())
        optimizer_step_skipped = amp_scale < previous_scale
        if step % int(settings["log_every_steps"]) == 0 or step == 1:
            logger.step(step, "pretrain", None, {
                **sums, "learning_rate": learning_rate, "gradient_norm": float(gradient_norm),
                "gradient_norm_finite": bool(torch.isfinite(gradient_norm)),
                "amp_scale": amp_scale, "optimizer_step_skipped": optimizer_step_skipped,
            }, device)
            print(f"[pretrain] step={step}/{total_steps} loss={sums['pretrain_total']:.5f} lr={learning_rate:.3e}", flush=True)
        if step % int(settings["save_every_steps"]) == 0 or step == total_steps:
            checkpoint = {
                "step": step, "model": model.state_dict(), "optimizer": optimizer.state_dict(),
                "scaler": scaler.state_dict(), "config": config,
                "config_fingerprint": fingerprint,
            }
            torch.save(checkpoint, latest)
            torch.save({
                "step": step, "encoder": model.encoder.state_dict(), "config": config,
                "config_fingerprint": fingerprint, "audit": report,
            }, output_dir / "encoder_pretrained.pt")
    logger.close()
    result = {
        **report, "completed_steps": total_steps, "seconds": perf_counter() - started,
        "encoder_checkpoint": str((output_dir / "encoder_pretrained.pt").resolve()),
        "config_fingerprint": fingerprint, "resolved_config": str(resolved_path.resolve()),
    }
    write_json(result, output_dir / "pretrain_summary.json")
    return result
