from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import torch
from torch import nn
import torch.nn.functional as F

from .constants import ENTITY_NAMES, FDI_ADULT_TEETH, FIELDS
from .entities import EntityVocabulary


def _groups(channels: int) -> int:
    for value in (16, 8, 4, 2, 1):
        if channels % value == 0:
            return value
    return 1


class BasicBlock3D(nn.Module):
    expansion = 1

    def __init__(self, in_channels: int, out_channels: int, stride: int = 1) -> None:
        super().__init__()
        self.conv1 = nn.Conv3d(in_channels, out_channels, 3, stride=stride, padding=1, bias=False)
        self.norm1 = nn.GroupNorm(_groups(out_channels), out_channels)
        self.conv2 = nn.Conv3d(out_channels, out_channels, 3, padding=1, bias=False)
        self.norm2 = nn.GroupNorm(_groups(out_channels), out_channels)
        self.act = nn.GELU()
        self.skip = (
            nn.Identity()
            if stride == 1 and in_channels == out_channels
            else nn.Sequential(
                nn.Conv3d(in_channels, out_channels, 1, stride=stride, bias=False),
                nn.GroupNorm(_groups(out_channels), out_channels),
            )
        )

    def forward(self, value: torch.Tensor) -> torch.Tensor:
        residual = self.skip(value)
        value = self.act(self.norm1(self.conv1(value)))
        value = self.norm2(self.conv2(value))
        return self.act(value + residual)


class ResNet3DEncoder(nn.Module):
    """Trainable full-volume 3D encoder used identically by Student and Teacher."""

    def __init__(self, in_channels: int, base_channels: int, blocks: Iterable[int]) -> None:
        super().__init__()
        depths = list(blocks)
        if len(depths) != 4:
            raise ValueError("model.encoder_blocks must contain four stage depths")
        self.stem = nn.Sequential(
            nn.Conv3d(in_channels, base_channels, 7, stride=2, padding=3, bias=False),
            nn.GroupNorm(_groups(base_channels), base_channels),
            nn.GELU(),
            nn.MaxPool3d(3, stride=2, padding=1),
        )
        widths = [base_channels, base_channels * 2, base_channels * 4, base_channels * 8]
        self.layer1 = self._stage(base_channels, widths[0], depths[0], 1)
        self.layer2 = self._stage(widths[0], widths[1], depths[1], 2)
        self.layer3 = self._stage(widths[1], widths[2], depths[2], 2)
        self.layer4 = self._stage(widths[2], widths[3], depths[3], 2)
        self.pyramid_channels = (widths[1], widths[2], widths[3])
        self.output_channels = widths[3]
        self.apply(self._init_weights)

    @staticmethod
    def _stage(in_channels: int, out_channels: int, depth: int, stride: int) -> nn.Sequential:
        layers = [BasicBlock3D(in_channels, out_channels, stride)]
        layers.extend(BasicBlock3D(out_channels, out_channels) for _ in range(1, depth))
        return nn.Sequential(*layers)

    @staticmethod
    def _init_weights(module: nn.Module) -> None:
        if isinstance(module, nn.Conv3d):
            nn.init.kaiming_normal_(module.weight, mode="fan_out", nonlinearity="relu")
        elif isinstance(module, (nn.GroupNorm, nn.LayerNorm)):
            nn.init.ones_(module.weight)
            nn.init.zeros_(module.bias)

    def forward(self, value: torch.Tensor) -> list[torch.Tensor]:
        value = self.stem(value)
        value = self.layer1(value)
        level2 = self.layer2(value)
        level3 = self.layer3(level2)
        level4 = self.layer4(level3)
        return [level2, level3, level4]


class PyramidTokenizer(nn.Module):
    def __init__(self, channels: Iterable[int], hidden_dim: int, grids: list[list[int]]) -> None:
        super().__init__()
        channels = list(channels)
        if len(channels) != len(grids):
            raise ValueError("pyramid_grids must match the three encoder pyramid levels")
        self.grids = [tuple(int(x) for x in grid) for grid in grids]
        self.projections = nn.ModuleList(nn.Conv3d(c, hidden_dim, 1) for c in channels)
        self.level_embeddings = nn.Parameter(torch.empty(len(channels), hidden_dim))
        self.coordinate_mlp = nn.Sequential(nn.Linear(3, hidden_dim), nn.GELU(), nn.Linear(hidden_dim, hidden_dim))
        nn.init.normal_(self.level_embeddings, std=0.02)

    @staticmethod
    def _coordinates(grid: tuple[int, int, int], device: torch.device, dtype: torch.dtype) -> torch.Tensor:
        axes = [torch.linspace(-1.0, 1.0, steps=size, device=device, dtype=dtype) for size in grid]
        coordinates = torch.stack(torch.meshgrid(*axes, indexing="ij"), dim=-1)
        return coordinates.reshape(-1, 3)

    def forward(self, pyramid: list[torch.Tensor]) -> torch.Tensor:
        tokens: list[torch.Tensor] = []
        for level, (feature, projection, grid) in enumerate(zip(pyramid, self.projections, self.grids)):
            value = F.adaptive_avg_pool3d(projection(feature), grid).flatten(2).transpose(1, 2)
            coordinates = self.coordinate_mlp(self._coordinates(grid, value.device, value.dtype))
            value = value + coordinates.unsqueeze(0) + self.level_embeddings[level].to(value.dtype)
            tokens.append(value)
        return torch.cat(tokens, dim=1)


@dataclass(frozen=True)
class QuerySlices:
    record: slice
    teeth: slice
    entities: dict[str, slice]
    fields: slice


class Homogeneous3DQueryModel(nn.Module):
    """Complete 3D query model; an exact copy is maintained as the EMA Teacher."""

    def __init__(self, config: dict, vocabulary: EntityVocabulary) -> None:
        super().__init__()
        self.config = dict(config)
        self.vocabulary = vocabulary
        hidden = int(config["hidden_dim"])
        self.encoder = ResNet3DEncoder(
            int(config["in_channels"]), int(config["base_channels"]), config["encoder_blocks"]
        )
        self.tokenizer = PyramidTokenizer(self.encoder.pyramid_channels, hidden, config["pyramid_grids"])
        local = config.get("local_crops", {})
        self.local_crops_enabled = bool(local.get("enabled", False))
        self.local_crop_size = tuple(int(value) for value in local.get("size", (64, 112, 112)))
        self.max_local_crops = int(local.get("max_crops", 4))
        self.local_projection = nn.Linear(self.encoder.output_channels, hidden)
        self.local_position = nn.Parameter(torch.empty(max(1, self.max_local_crops), hidden))
        nn.init.normal_(self.local_position, std=0.02)
        visual_layer = nn.TransformerEncoderLayer(
            hidden, int(config["num_heads"]), int(config["ffn_dim"]), float(config["dropout"]),
            activation="gelu", batch_first=True, norm_first=True,
        )
        self.visual_transformer = nn.TransformerEncoder(visual_layer, int(config["visual_layers"]), norm=nn.LayerNorm(hidden))
        decoder_layer = nn.TransformerDecoderLayer(
            hidden, int(config["num_heads"]), int(config["ffn_dim"]), float(config["dropout"]),
            activation="gelu", batch_first=True, norm_first=True,
        )
        self.query_transformer = nn.TransformerDecoder(decoder_layer, int(config["query_layers"]), norm=nn.LayerNorm(hidden))

        cursor = 0
        record = slice(cursor, cursor + 1)
        cursor += 1
        teeth = slice(cursor, cursor + len(FDI_ADULT_TEETH))
        cursor += len(FDI_ADULT_TEETH)
        entities: dict[str, slice] = {}
        for name in ENTITY_NAMES[1:]:
            entities[name] = slice(cursor, cursor + 1)
            cursor += 1
        fields = slice(cursor, cursor + len(FIELDS))
        cursor += len(FIELDS)
        self.slices = QuerySlices(record, teeth, entities, fields)
        self.queries = nn.Parameter(torch.empty(cursor, hidden))
        nn.init.normal_(self.queries, std=0.02)

        self.entity_heads = nn.ModuleDict({"teeth": nn.Linear(hidden, 1)})
        for name in ENTITY_NAMES[1:]:
            self.entity_heads[name] = nn.Linear(hidden, len(getattr(vocabulary, name)))
        self.count_heads = nn.ModuleDict(
            {name: nn.Linear(hidden, int(config["max_counts"][name]) + 1) for name in ENTITY_NAMES}
        )
        self.field_heads = nn.ModuleList(nn.Linear(hidden, int(config["field_dim"])) for _ in FIELDS)
        self.record_head = nn.Linear(hidden, int(config["record_dim"]))

    def _extract_overlapping_crops(self, volume: torch.Tensor) -> tuple[torch.Tensor, int]:
        spatial = volume.shape[-3:]
        sizes = tuple(min(size, available) for size, available in zip(self.local_crop_size, spatial))
        starts = [[0] if size >= available else [0, available - size] for size, available in zip(sizes, spatial)]
        candidates = [
            (starts[0][0], starts[1][0], starts[2][0]),
            (starts[0][0], starts[1][-1], starts[2][-1]),
            (starts[0][-1], starts[1][0], starts[2][-1]),
            (starts[0][-1], starts[1][-1], starts[2][0]),
            (starts[0][0], starts[1][0], starts[2][-1]),
            (starts[0][-1], starts[1][-1], starts[2][-1]),
        ]
        unique: list[tuple[int, int, int]] = []
        for candidate in candidates:
            if candidate not in unique:
                unique.append(candidate)
        unique = unique[:max(1, self.max_local_crops)]
        crops = [
            volume[:, :, d:d + sizes[0], h:h + sizes[1], w:w + sizes[2]]
            for d, h, w in unique
        ]
        stacked = torch.stack(crops, dim=1)
        return stacked.flatten(0, 1), len(unique)

    def _visual_tokens(self, volume: torch.Tensor) -> torch.Tensor:
        global_tokens = self.tokenizer(self.encoder(volume))
        if not self.local_crops_enabled or self.max_local_crops <= 0:
            return global_tokens
        crops, count = self._extract_overlapping_crops(volume)
        local_feature = self.encoder(crops)[-1].mean(dim=(2, 3, 4))
        local_tokens = self.local_projection(local_feature).reshape(volume.shape[0], count, -1)
        local_tokens = local_tokens + self.local_position[:count].to(local_tokens.dtype)
        return torch.cat([global_tokens, local_tokens], dim=1)

    def forward(self, volume: torch.Tensor) -> dict[str, torch.Tensor | dict[str, torch.Tensor]]:
        memory = self.visual_transformer(self._visual_tokens(volume))
        queries = self.queries.unsqueeze(0).expand(volume.shape[0], -1, -1)
        decoded = self.query_transformer(queries, memory)
        tooth_tokens = decoded[:, self.slices.teeth]
        entity_logits: dict[str, torch.Tensor] = {
            "teeth": self.entity_heads["teeth"](tooth_tokens).squeeze(-1)
        }
        count_logits: dict[str, torch.Tensor] = {
            "teeth": self.count_heads["teeth"](tooth_tokens.mean(dim=1))
        }
        for name in ENTITY_NAMES[1:]:
            token = decoded[:, self.slices.entities[name]].squeeze(1)
            entity_logits[name] = self.entity_heads[name](token)
            count_logits[name] = self.count_heads[name](token)
        field_tokens = decoded[:, self.slices.fields]
        field_embeddings = torch.stack(
            [head(field_tokens[:, index]) for index, head in enumerate(self.field_heads)], dim=1
        )
        record_token = decoded[:, self.slices.record].squeeze(1)
        return {
            "entity_logits": entity_logits,
            "count_logits": count_logits,
            "field_embeddings": F.normalize(field_embeddings, dim=-1),
            "record_embedding": F.normalize(self.record_head(record_token), dim=-1),
            "visual_embedding": F.normalize(memory.mean(dim=1), dim=-1),
        }

    def encoder_parameters(self) -> Iterable[nn.Parameter]:
        return self.encoder.parameters()

    def head_parameters(self) -> Iterable[nn.Parameter]:
        encoder_ids = {id(value) for value in self.encoder.parameters()}
        return (value for value in self.parameters() if id(value) not in encoder_ids)


class MaskedVolumeAutoencoder(nn.Module):
    """Stage-0 image-only pretraining head; only its encoder is transferred."""

    def __init__(self, model_config: dict) -> None:
        super().__init__()
        base = int(model_config["base_channels"])
        self.encoder = ResNet3DEncoder(
            int(model_config["in_channels"]), base, model_config["encoder_blocks"]
        )
        widths = [base * 8, base * 4, base * 2, base, max(base // 2, 8)]
        layers: list[nn.Module] = []
        for in_channels, out_channels in zip(widths[:-1], widths[1:]):
            layers.extend(
                [nn.ConvTranspose3d(in_channels, out_channels, 4, stride=2, padding=1),
                 nn.GroupNorm(_groups(out_channels), out_channels), nn.GELU()]
            )
        layers.append(nn.ConvTranspose3d(widths[-1], 1, 4, stride=2, padding=1))
        self.decoder = nn.Sequential(*layers)
        self.projection = nn.Sequential(
            nn.Linear(base * 8, int(model_config["record_dim"])),
            nn.LayerNorm(int(model_config["record_dim"])),
        )

    def forward(self, volume: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        bottleneck = self.encoder(volume)[-1]
        reconstructed = self.decoder(bottleneck)
        if reconstructed.shape[-3:] != volume.shape[-3:]:
            reconstructed = F.interpolate(reconstructed, size=volume.shape[-3:], mode="trilinear", align_corners=False)
        embedding = F.normalize(self.projection(bottleneck.mean(dim=(2, 3, 4))), dim=-1)
        return reconstructed, embedding


def build_model(config: dict, vocabulary: EntityVocabulary) -> Homogeneous3DQueryModel:
    return Homogeneous3DQueryModel(config, vocabulary)


def parameter_report(model: nn.Module) -> dict[str, int | float]:
    total = sum(value.numel() for value in model.parameters())
    trainable = sum(value.numel() for value in model.parameters() if value.requires_grad)
    return {"parameters": total, "trainable_parameters": trainable, "parameters_million": total / 1_000_000.0}
