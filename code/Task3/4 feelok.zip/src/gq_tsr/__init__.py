"""Complete Guarded Query Teacher-Student Retrieval (GQ-TSR) for Task 3."""

__version__ = "1.0.0"
