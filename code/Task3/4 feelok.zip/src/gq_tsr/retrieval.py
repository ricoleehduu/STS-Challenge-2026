from __future__ import annotations

import numpy as np

from .calibration import (
    family_is_reliable, family_label_reliability, family_presence_probability,
    family_presence_threshold, family_thresholds,
)
from .constants import EMPTY_FALLBACKS, ENTITY_NAMES, FIELDS
from .entities import EntityVocabulary
from .records import clean_text


FIELD_ENTITY_WEIGHTS = {
    "Main appeal": {"teeth": 0.35, "diagnoses": 0.25},
    "Present medical history": {"diagnoses": 0.40},
    "Oral Check": {"teeth": 0.55, "diagnoses": 0.30, "diagnosis_codes": 0.15},
    "Diagnosis": {"teeth": 0.25, "diagnoses": 0.50, "diagnosis_codes": 0.45},
    "Treatment plan": {"diagnoses": 0.25, "diagnosis_codes": 0.20, "treatments": 0.55},
    "Handle": {"diagnoses": 0.15, "treatments": 0.60, "medications": 0.15},
    "Doctor advices": {"treatments": 0.45, "medications": 0.25},
}


def _normalize(value: np.ndarray) -> np.ndarray:
    return value / np.maximum(np.linalg.norm(value, axis=-1, keepdims=True), 1e-8)


def _soft_f1(probability: np.ndarray, target: np.ndarray) -> np.ndarray:
    if probability.shape[1] == 0:
        return np.zeros((len(probability), len(target)), np.float32)
    intersection = probability @ target.T
    denominator = probability.sum(1, keepdims=True) + target.sum(1)[None]
    return (2 * intersection / np.maximum(denominator, 1e-8)).astype(np.float32)


def _hard_f1(
    probability: np.ndarray, target: np.ndarray, threshold: float | np.ndarray,
) -> np.ndarray:
    predicted = (probability >= np.asarray(threshold, np.float32)).astype(np.float32)
    return _soft_f1(predicted, target)


def _entity_similarity(
    probability: np.ndarray, target: np.ndarray, name: str, config: dict,
) -> np.ndarray:
    soft = _soft_f1(probability, target)
    calibration = config.get("entity_calibration")
    hard_weight = float(config["retrieval"].get("calibrated_entity_hard_weight", 0.0))
    if hard_weight <= 0 or not family_is_reliable(calibration, name):
        return soft
    hard = _hard_f1(
        probability, target, family_thresholds(calibration, name, probability.shape[1])
    )
    return ((1.0 - hard_weight) * soft + hard_weight * hard).astype(np.float32)


def _correct_reference_hubness(score: np.ndarray, config: dict) -> np.ndarray:
    """One-sided CSLS correction; the omitted query term is rank-constant."""
    penalty = float(config["retrieval"].get("hubness_penalty", 0.0))
    if penalty <= 0 or score.shape[0] < 2:
        return score
    top_k = min(max(1, int(config["retrieval"].get("hubness_top_k", 5))), score.shape[0])
    reference_density = np.partition(score, score.shape[0] - top_k, axis=0)[-top_k:].mean(axis=0)
    return score - penalty * reference_density[None, :]


def retrieve_text(
    query_ids: list[str],
    query_fields: np.ndarray,
    query_entities: dict[str, np.ndarray],
    reference_ids: list[str],
    reference_records: dict[str, dict[str, str]],
    reference_fields: np.ndarray,
    vocabulary: EntityVocabulary,
    config: dict,
    query_count_probabilities: dict[str, np.ndarray] | None = None,
) -> tuple[dict[str, dict[str, str]], dict]:
    records = [reference_records[case_id] for case_id in reference_ids]
    encoded = [vocabulary.encode(record) for record in records]
    targets = {name: np.stack([row[name] for row in encoded]) for name in ENTITY_NAMES}
    # Hard constraints must be supported by the text that will actually be
    # copied, not merely by an entity mentioned elsewhere in the same record.
    field_targets = {
        field: {
            name: np.stack([
                vocabulary.encode({field: record.get(field, "")})[name]
                for record in records
            ])
            for name in ENTITY_NAMES
        }
        for field in FIELDS
    }
    entity_scores = {
        name: _entity_similarity(query_entities[name], targets[name], name, config)
        for name in ENTITY_NAMES
    }
    predictions = {case_id: {} for case_id in query_ids}
    provenance = {case_id: {} for case_id in query_ids}
    top_k = min(max(1, int(config["retrieval"]["top_k"])), len(reference_ids))
    candidate_top_k = min(
        max(top_k, int(config["retrieval"].get("candidate_vote_top_k", top_k))),
        len(reference_ids),
    )
    constraint_top_k = min(
        max(candidate_top_k, int(config["retrieval"].get("entity_constraint_top_k", candidate_top_k))),
        len(reference_ids),
    )
    configured_constraints = set(config["retrieval"].get("hard_entity_constraints", []))
    constraints_enabled = bool(config["retrieval"].get(
        "enable_hard_entity_constraints", bool(configured_constraints)
    ))
    constrained_families = configured_constraints if constraints_enabled else set()
    calibration = config.get("entity_calibration")
    rerank = float(config["retrieval"]["entity_rerank_weight"])
    for field_index, field in enumerate(FIELDS):
        semantic = _normalize(query_fields[:, field_index]) @ _normalize(reference_fields[:, field_index]).T
        semantic = _correct_reference_hubness(semantic, config)
        weights = FIELD_ENTITY_WEIGHTS[field]
        clinical = sum(weight * entity_scores[name] for name, weight in weights.items()) / max(sum(weights.values()), 1e-8)
        score = semantic + rerank * clinical
        for row, case_id in enumerate(query_ids):
            ordered = np.argsort(-score[row])
            valid = [
                int(index) for index in ordered[:top_k]
                if clean_text(records[int(index)].get(field))
            ]
            applied_constraints: list[str] = []
            missed_constraints: list[str] = []
            for name in constrained_families & set(weights):
                if not family_is_reliable(calibration, name):
                    continue
                count_probability = None
                if query_count_probabilities is not None:
                    count_probability = query_count_probabilities[name][row]
                presence_probability = family_presence_probability(
                    calibration, name, query_entities[name][row], count_probability
                )
                if presence_probability < family_presence_threshold(calibration, name):
                    continue
                query_positive = (
                    query_entities[name][row]
                    >= family_thresholds(calibration, name, query_entities[name].shape[1])
                )
                query_positive &= family_label_reliability(
                    calibration, name, query_entities[name].shape[1]
                )
                if not bool(query_positive.any()):
                    continue
                matching = [
                    int(index) for index in ordered[:constraint_top_k]
                    if clean_text(records[int(index)].get(field))
                    and bool(field_targets[field][name][int(index), query_positive].any())
                ]
                if matching:
                    valid = matching
                    applied_constraints.append(name)
                else:
                    missed_constraints.append(name)
            if not valid:
                valid = [int(ordered[0])]
            candidate_pool = valid[:candidate_top_k]
            index = max(
                candidate_pool,
                key=lambda i: float(score[row, i]) + min(len(clean_text(records[i].get(field))), 600) * 1e-6,
            )
            predictions[case_id][field] = clean_text(records[index].get(field)) or EMPTY_FALLBACKS[field]
            provenance[case_id][field] = {
                "reference_case_id": reference_ids[index], "score": float(score[row, index]),
                "entity_constraints_applied": applied_constraints,
                "entity_constraints_missed": missed_constraints,
                "candidates": [
                    {
                        "reference_case_id": reference_ids[candidate],
                        "score": float(score[row, candidate]),
                        "rank": rank,
                        "text": clean_text(records[candidate].get(field)) or EMPTY_FALLBACKS[field],
                    }
                    for rank, candidate in enumerate(candidate_pool)
                ],
            }
    return predictions, provenance


def ensemble_fold_outputs(outputs: list[dict]) -> dict:
    if not outputs:
        raise ValueError("At least one fold output is required")
    case_ids = outputs[0]["case_ids"]
    if any(value["case_ids"] != case_ids for value in outputs):
        raise ValueError("Fold prediction case order mismatch")
    return {
        "case_ids": case_ids,
        "field_embeddings": np.mean([value["field_embeddings"] for value in outputs], axis=0),
        "record_embedding": np.mean([value["record_embedding"] for value in outputs], axis=0),
        "entity_probabilities": {
            name: np.mean([value["entity_probabilities"][name] for value in outputs], axis=0) for name in ENTITY_NAMES
        },
        "count_probabilities": {
            name: np.mean([value["count_probabilities"][name] for value in outputs], axis=0) for name in ENTITY_NAMES
        },
    }


def ensemble_text_predictions(
    fold_predictions: list[dict[str, dict[str, str]]],
    fold_provenance: list[dict],
    config: dict | None = None,
) -> tuple[dict[str, dict[str, str]], dict]:
    if not fold_predictions:
        raise ValueError("At least one fold prediction is required")
    case_ids = list(fold_predictions[0])
    final = {case_id: {} for case_id in case_ids}
    provenance = {case_id: {} for case_id in case_ids}
    retrieval = (config or {}).get("retrieval", {})
    aggregate_candidates = bool(retrieval.get("cross_fold_candidate_aggregation", False))
    minimum_support = int(retrieval.get("minimum_candidate_fold_support", 2))
    for case_id in case_ids:
        for field in FIELDS:
            candidates: dict[str, list[tuple[int, float]]] = {}
            for fold, (prediction, details) in enumerate(zip(fold_predictions, fold_provenance)):
                text = prediction[case_id][field]
                score = float(details[case_id][field]["score"])
                candidates.setdefault(text, []).append((fold, score))
            selected_text, votes = max(candidates.items(), key=lambda item: (
                len(item[1]), max(value[1] for value in item[1]), len(item[0])
            ))
            candidate_support = len(votes)
            aggregation_mode = "exact_top1_vote"
            selected_reference = None
            candidate_groups: dict[str, list[dict]] = {}
            if aggregate_candidates:
                for fold, details in enumerate(fold_provenance):
                    seen: set[str] = set()
                    for candidate in details[case_id][field].get("candidates", []):
                        text = str(candidate.get("text", ""))
                        if not text or text in seen:
                            continue
                        seen.add(text)
                        candidate_groups.setdefault(text, []).append({**candidate, "fold": fold})
                eligible = {
                    text: values for text, values in candidate_groups.items()
                    if len({int(value["fold"]) for value in values}) >= minimum_support
                }
                if eligible:
                    selected_text, selected_values = max(eligible.items(), key=lambda item: (
                        len({int(value["fold"]) for value in item[1]}),
                        sum(1.0 / (1.0 + int(value.get("rank", 0))) for value in item[1]),
                        len(candidates.get(item[0], [])),
                        max(float(value.get("score", 0.0)) for value in item[1]),
                        len(item[0]),
                    ))
                    votes = candidates.get(selected_text, [])
                    candidate_support = len({int(value["fold"]) for value in selected_values})
                    selected_reference = max(
                        selected_values,
                        key=lambda value: (-int(value.get("rank", 0)), float(value.get("score", 0.0))),
                    )
                    aggregation_mode = "cross_fold_topk_consensus"
            if selected_reference is not None:
                best_fold = int(selected_reference["fold"])
                best_score = float(selected_reference.get("score", 0.0))
                reference_case_id = str(selected_reference.get("reference_case_id", ""))
            elif votes:
                best_fold, best_score = max(votes, key=lambda value: value[1])
                reference_case_id = fold_provenance[best_fold][case_id][field]["reference_case_id"]
            else:
                # A top-k consensus may select a text that was never top-1.
                best_fold, best_score, reference_case_id = 0, 0.0, ""
            final[case_id][field] = selected_text
            provenance[case_id][field] = {
                "fold_votes": len(votes), "candidate_fold_support": candidate_support,
                "selected_fold": best_fold, "score": best_score,
                "reference_case_id": reference_case_id,
                "aggregation_mode": aggregation_mode,
            }
    return final, provenance
