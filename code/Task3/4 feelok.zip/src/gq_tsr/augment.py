from __future__ import annotations

import random

import torch
import torch.nn.functional as F


def _flips(volume: torch.Tensor, probability: float) -> torch.Tensor:
    for axis in (2, 3, 4):
        if random.random() < probability:
            volume = torch.flip(volume, (axis,))
    return volume


def _intensity(volume: torch.Tensor, scale: float, shift: float) -> torch.Tensor:
    factor = 1.0 + (torch.rand((len(volume), 1, 1, 1, 1), device=volume.device) * 2 - 1) * scale
    offset = (torch.rand((len(volume), 1, 1, 1, 1), device=volume.device) * 2 - 1) * shift
    return volume * factor + offset


def weak_augment(volume: torch.Tensor, config: dict) -> torch.Tensor:
    value = _flips(volume, float(config["flip_probability"]))
    value = _intensity(value, float(config["weak_intensity_scale"]), float(config["weak_intensity_shift"]))
    value = value + torch.randn_like(value) * float(config["weak_noise_std"])
    return value.clamp(0, 1)


def strong_augment(volume: torch.Tensor, config: dict) -> torch.Tensor:
    value = _flips(volume, float(config["flip_probability"]))
    value = _intensity(value, float(config["strong_intensity_scale"]), float(config["strong_intensity_shift"]))
    gamma = 1.0 + random.uniform(-float(config["strong_gamma"]), float(config["strong_gamma"]))
    value = value.clamp(1e-4, 1).pow(gamma)
    value = value + torch.randn_like(value) * float(config["strong_noise_std"])
    if random.random() < float(config["strong_blur_probability"]):
        value = F.avg_pool3d(value, 3, stride=1, padding=1)
    if random.random() < float(config["strong_cutout_probability"]):
        low, high = (float(v) for v in config["strong_cutout_fraction"])
        for row in range(len(value)):
            sizes = [max(1, int(size * random.uniform(low, high))) for size in value.shape[2:]]
            starts = [random.randint(0, max(0, size - block)) for size, block in zip(value.shape[2:], sizes)]
            value[row, :, starts[0]:starts[0]+sizes[0], starts[1]:starts[1]+sizes[1], starts[2]:starts[2]+sizes[2]] = 0
    return value.clamp(0, 1)


def block_mask(volume: torch.Tensor, ratio: float, block_size: list[int]) -> torch.Tensor:
    masked = volume.clone()
    voxels, target = int(volume[0].numel()), int(volume[0].numel() * ratio)
    block_voxels = max(1, int(block_size[0]) * int(block_size[1]) * int(block_size[2]))
    blocks = max(1, target // block_voxels)
    for row in range(len(masked)):
        for _ in range(blocks):
            starts = [random.randint(0, max(0, size - int(block))) for size, block in zip(masked.shape[2:], block_size)]
            masked[row, :, starts[0]:starts[0]+block_size[0], starts[1]:starts[1]+block_size[1], starts[2]:starts[2]+block_size[2]] = 0
    return masked
