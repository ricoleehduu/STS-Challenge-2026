from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .constants import FIELDS
from .io import CaseItem, build_case_items
from .records import load_records


@dataclass(frozen=True)
class StrictTaskData:
    labeled_records: dict[str, dict[str, str]]
    validation_records: dict[str, dict[str, str]]
    labeled_items: list[CaseItem]
    unlabeled_items: list[CaseItem]
    validation_items: list[CaseItem]
    audit: dict


def _require_exact_join(items: list[CaseItem], records: dict[str, dict[str, str]], role: str) -> None:
    image_ids, record_ids = {item.case_id for item in items}, set(records)
    if image_ids != record_ids:
        raise ValueError(f"{role} image/CSV mismatch: missing_records={sorted(image_ids-record_ids)[:10]}, missing_images={sorted(record_ids-image_ids)[:10]}")


def load_strict_task_data(
    labeled_dir: str | Path,
    labeled_csv: str | Path,
    unlabeled_dir: str | Path,
    validation_dir: str | Path,
    validation_csv: str | Path | None,
    config: dict,
) -> StrictTaskData:
    """Load Task3 with a structural firewall: there is no unlabeled CSV argument."""
    merge = str(config["data"].get("record_merge", "most_complete"))
    labeled_records = load_records(labeled_csv, merge)
    validation_records = load_records(validation_csv, merge) if validation_csv else {}
    labeled_items = build_case_items(labeled_dir, "labeled")
    unlabeled_items = build_case_items(unlabeled_dir, "unlabeled")
    validation_items = build_case_items(validation_dir, "validation")
    _require_exact_join(labeled_items, labeled_records, "labeled")
    if validation_records:
        _require_exact_join(validation_items, validation_records, "validation")
    sets = {"labeled": {i.case_id for i in labeled_items}, "unlabeled": {i.case_id for i in unlabeled_items}, "validation": {i.case_id for i in validation_items}}
    overlaps = {
        "labeled_unlabeled": sorted(sets["labeled"] & sets["unlabeled"]),
        "labeled_validation": sorted(sets["labeled"] & sets["validation"]),
        "unlabeled_validation": sorted(sets["unlabeled"] & sets["validation"]),
    }
    if any(overlaps.values()):
        raise ValueError(f"Split overlap detected: {overlaps}")
    counts = {"labeled": len(labeled_items), "unlabeled": len(unlabeled_items), "validation": len(validation_items)}
    expected = {name: int(config["data"][f"expected_{name}_cases"]) for name in counts}
    if bool(config["data"].get("strict_counts", True)) and counts != expected:
        raise ValueError(f"Unexpected counts: actual={counts}, expected={expected}")
    audit = {
        "counts": counts,
        "expected_counts": expected,
        "split_overlap": overlaps,
        "labeled_csv": str(Path(labeled_csv).resolve()),
        "validation_csv": str(Path(validation_csv).resolve()) if validation_csv else None,
        "unlabeled_csv_accessed": False,
        "unlabeled_target_fields_loaded": 0,
        "unlabeled_source": "CBCT paths only",
        "validation_labels_available": bool(validation_records),
        "validation_empty_fields": {f: sum(not r.get(f, "").strip() for r in validation_records.values()) for f in FIELDS},
        "passed": True,
    }
    return StrictTaskData(labeled_records, validation_records, labeled_items, unlabeled_items, validation_items, audit)
