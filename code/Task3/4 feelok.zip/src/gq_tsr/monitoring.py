from __future__ import annotations

import csv
from pathlib import Path
from time import perf_counter

import torch

from .io import append_jsonl


_METRIC_NAMES = [
    "loss_total", "loss_supervised", "loss_entity", "loss_count",
    "loss_field_alignment", "loss_record_alignment", "loss_image_text_contrast",
    "loss_field_text_contrast", "weighted_proxy", "field_unique_ratio",
    "teeth_f1", "diagnoses_f1", "diagnosis_codes_f1",
    "treatments_f1",
    "head_mean_count_accuracy",
    *[f"head_{name}_f1_nonempty_reference" for name in (
        "teeth", "diagnoses", "diagnosis_codes", "treatments", "medications"
    )],
    *[f"head_{name}_count_accuracy" for name in (
        "teeth", "diagnoses", "diagnosis_codes", "treatments", "medications"
    )],
]
EVALUATION_FIELDS = [
    "stage", "fold", "step", "source", "improved", "improved_over_warm",
    "student_loss", "teacher_loss", "selected_loss", "best_loss",
    "student_selection_score", "teacher_selection_score", "selected_selection_score",
    "best_selection_score", "selected_weighted_proxy", "best_weighted_proxy",
    "selected_field_unique_ratio", "best_field_unique_ratio",
    "selection_qualified", "selection_pending_count", "selection_reason",
    *[f"{prefix}_{name}" for prefix in ("student", "teacher") for name in _METRIC_NAMES],
]


class RunLogger:
    def __init__(self, output_dir: str | Path, enabled_tensorboard: bool = True) -> None:
        self.root = Path(output_dir)
        self.root.mkdir(parents=True, exist_ok=True)
        self.started = perf_counter()
        self.step_path = self.root / "logs" / "steps.jsonl"
        self.eval_path = self.root / "logs" / "evaluations.csv"
        self.eval_jsonl_path = self.root / "logs" / "evaluations.jsonl"
        if self.eval_path.exists():
            with self.eval_path.open("r", encoding="utf-8-sig", newline="") as handle:
                header = next(csv.reader(handle), [])
            if header != EVALUATION_FIELDS:
                self.eval_path = self.root / "logs" / "evaluations_v3.csv"
                print(
                    "[logging] Existing evaluations.csv uses a legacy schema; "
                    f"new evaluations will be written to {self.eval_path}",
                    flush=True,
                )
        self.writer = None
        if enabled_tensorboard:
            try:
                from torch.utils.tensorboard import SummaryWriter
                self.writer = SummaryWriter(self.root / "tensorboard")
            except Exception as exc:  # TensorBoard is observational, not a training dependency.
                print(f"[logging] TensorBoard disabled: {exc}", flush=True)

    @staticmethod
    def hardware(device: torch.device) -> dict[str, float | str]:
        result: dict[str, float | str] = {"device": str(device)}
        if device.type == "cuda":
            result.update({
                "gpu_name": torch.cuda.get_device_name(device),
                "gpu_memory_allocated_mb": torch.cuda.memory_allocated(device) / 1024**2,
                "gpu_memory_reserved_mb": torch.cuda.memory_reserved(device) / 1024**2,
                "gpu_max_memory_allocated_mb": torch.cuda.max_memory_allocated(device) / 1024**2,
            })
        return result

    def step(self, step: int, stage: str, fold: int | None, values: dict, device: torch.device) -> None:
        row = {"step": int(step), "stage": stage, "fold": fold, "elapsed_seconds": perf_counter() - self.started}
        row.update({key: float(value.item()) if torch.is_tensor(value) else value for key, value in values.items()})
        row.update(self.hardware(device))
        append_jsonl(row, self.step_path)
        if self.writer:
            prefix = f"{stage}/fold_{fold}" if fold is not None else stage
            for key, value in values.items():
                if isinstance(value, (int, float)) or (torch.is_tensor(value) and value.numel() == 1):
                    self.writer.add_scalar(f"{prefix}/{key}", float(value), int(step))

    def evaluation(self, row: dict) -> None:
        self.eval_path.parent.mkdir(parents=True, exist_ok=True)
        exists = self.eval_path.exists()
        with self.eval_path.open("a", encoding="utf-8-sig", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=EVALUATION_FIELDS, extrasaction="ignore")
            if not exists:
                writer.writeheader()
            writer.writerow(row)
        append_jsonl(row, self.eval_jsonl_path)

    def close(self) -> None:
        if self.writer:
            self.writer.flush()
            self.writer.close()
