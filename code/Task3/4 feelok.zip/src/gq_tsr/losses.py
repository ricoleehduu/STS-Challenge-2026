from __future__ import annotations

import torch
import torch.nn.functional as F

from .constants import ENTITY_NAMES


def _zero(output: dict) -> torch.Tensor:
    return output["record_embedding"].sum() * 0.0


def supervised_loss(
    output: dict,
    batch: dict,
    pos_weights: dict[str, torch.Tensor],
    config: dict,
    negative_record_targets: torch.Tensor | None = None,
    negative_field_targets: torch.Tensor | None = None,
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    family_weights = config["family_weights"]
    weights = config["loss_weights"]
    entity = _zero(output)
    count = _zero(output)
    for name in ENTITY_NAMES:
        logits = output["entity_logits"][name]
        if logits.shape[-1]:
            target = batch["entity_targets"][name].to(logits.dtype)
            value = F.binary_cross_entropy_with_logits(logits, target, pos_weight=pos_weights[name])
            entity = entity + float(family_weights[name]) * value
        count_target = batch["count_targets"][name].clamp_max(output["count_logits"][name].shape[-1] - 1)
        count = count + float(family_weights[name]) * F.cross_entropy(output["count_logits"][name], count_target)
    field_alignment = (1.0 - F.cosine_similarity(output["field_embeddings"], batch["field_targets"], dim=-1)).mean()
    record_alignment = (1.0 - F.cosine_similarity(output["record_embedding"], batch["record_target"], dim=-1)).mean()
    temperature = float(config.get("contrast_temperature", 0.10))
    if output["record_embedding"].shape[0] > 1:
        logits = output["record_embedding"] @ batch["record_target"].T / temperature
        contrast = F.cross_entropy(logits, torch.arange(logits.shape[0], device=logits.device))
    elif negative_record_targets is not None and len(negative_record_targets):
        negative_record_targets = negative_record_targets.to(output["record_embedding"].dtype)
        positive = (output["record_embedding"] * batch["record_target"]).sum(dim=-1, keepdim=True)
        negative = output["record_embedding"] @ negative_record_targets.T
        logits = torch.cat([positive, negative], dim=1) / temperature
        contrast = F.cross_entropy(logits, torch.zeros(logits.shape[0], dtype=torch.long, device=logits.device))
    else:
        contrast = _zero(output)
    field_contrast = _zero(output)
    for field_index in range(output["field_embeddings"].shape[1]):
        predicted = output["field_embeddings"][:, field_index]
        target = batch["field_targets"][:, field_index]
        if predicted.shape[0] > 1:
            logits = predicted @ target.T / temperature
            field_contrast = field_contrast + F.cross_entropy(
                logits, torch.arange(logits.shape[0], device=logits.device)
            )
        elif negative_field_targets is not None and len(negative_field_targets):
            negative = negative_field_targets[:, field_index].to(predicted.dtype)
            positive_logit = (predicted * target).sum(dim=-1, keepdim=True)
            negative_logits = predicted @ negative.T
            logits = torch.cat([positive_logit, negative_logits], dim=1) / temperature
            field_contrast = field_contrast + F.cross_entropy(
                logits, torch.zeros(logits.shape[0], dtype=torch.long, device=logits.device)
            )
    field_contrast = field_contrast / max(1, output["field_embeddings"].shape[1])
    total = (
        float(weights["entity"]) * entity
        + float(weights["count"]) * count
        + float(weights["field_alignment"]) * field_alignment
        + float(weights["record_alignment"]) * record_alignment
        + float(weights["image_text_contrast"]) * contrast
        + float(weights.get("field_text_contrast", 0.0)) * field_contrast
    )
    return total, {
        "supervised": total.detach(), "entity": entity.detach(), "count": count.detach(),
        "field_alignment": field_alignment.detach(), "record_alignment": record_alignment.detach(),
        "image_text_contrast": contrast.detach(), "field_text_contrast": field_contrast.detach(),
    }


def _masked_bce(logits: torch.Tensor, targets: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    if not bool(mask.any()):
        return logits.sum() * 0.0
    values = F.binary_cross_entropy_with_logits(logits, targets, reduction="none")
    positive = mask & (targets >= 0.5)
    negative = mask & ~positive
    parts = []
    if bool(positive.any()):
        parts.append(values[positive].mean())
    if bool(negative.any()):
        parts.append(values[negative].mean())
    return torch.stack(parts).mean()


def gate_pseudo_mask(
    probabilities: torch.Tensor,
    targets: torch.Tensor,
    raw_mask: torch.Tensor,
    minimum_positives: int,
    maximum_negative_to_positive_ratio: float,
) -> torch.Tensor:
    """Keep only rows with positive evidence and cap confident negatives."""
    gated = torch.zeros_like(raw_mask, dtype=torch.bool)
    for row in range(raw_mask.shape[0]):
        positive = raw_mask[row] & (targets[row] >= 0.5)
        positive_count = int(positive.sum().item())
        if positive_count < int(minimum_positives):
            continue
        gated[row] |= positive
        negative_indices = torch.where(raw_mask[row] & (targets[row] < 0.5))[0]
        maximum_negatives = int(maximum_negative_to_positive_ratio * positive_count)
        if maximum_negatives <= 0 or not len(negative_indices):
            continue
        if len(negative_indices) > maximum_negatives:
            # Lower probability means a more confident negative.
            ranking = torch.argsort(probabilities[row, negative_indices])[:maximum_negatives]
            negative_indices = negative_indices[ranking]
        gated[row, negative_indices] = True
    return gated


def teacher_consistency_loss(
    student: dict,
    teacher: dict,
    config: dict,
    use_pseudo_entities: bool,
) -> tuple[torch.Tensor, dict[str, torch.Tensor], dict[str, float]]:
    pseudo = config["pseudo_labels"]
    weights = config["training"]["loss_weights"]
    family_weights = config["training"]["family_weights"]
    entity = _zero(student)
    count = _zero(student)
    selected, candidates = 0, 0
    raw_selected = 0
    selected_positive, selected_negative = 0, 0
    count_selected, count_candidates = 0, 0
    enabled_families = set(pseudo.get("enabled_families", ENTITY_NAMES))
    online_hard_enabled = bool(pseudo.get("enable_online_hard_pseudo", True))
    minimum_positives = int(pseudo.get("minimum_online_positives_per_batch", 1))
    negative_ratio = float(pseudo.get("maximum_negative_to_positive_ratio", 3.0))
    for name in ENTITY_NAMES:
        teacher_probability = torch.sigmoid(teacher["entity_logits"][name]).detach()
        family_enabled = name in enabled_families
        eligible_rows = torch.zeros(teacher_probability.shape[0], dtype=torch.bool, device=teacher_probability.device)
        if teacher_probability.shape[-1] and use_pseudo_entities and online_hard_enabled and family_enabled:
            raw_mask = (teacher_probability >= float(pseudo["positive_threshold"])) | (
                teacher_probability <= float(pseudo["negative_threshold"])
            )
            targets = (teacher_probability >= float(pseudo["positive_threshold"])).to(teacher_probability.dtype)
            mask = gate_pseudo_mask(
                teacher_probability, targets, raw_mask, minimum_positives, negative_ratio
            )
            entity = entity + float(family_weights[name]) * _masked_bce(
                student["entity_logits"][name], targets, mask
            )
            raw_selected += int(raw_mask.sum().item())
            selected += int(mask.sum().item())
            candidates += mask.numel()
            selected_positive += int((mask & (targets >= 0.5)).sum().item())
            selected_negative += int((mask & (targets < 0.5)).sum().item())
            eligible_rows = (mask & (targets >= 0.5)).any(dim=-1)
        if use_pseudo_entities and online_hard_enabled and family_enabled:
            teacher_count = torch.softmax(teacher["count_logits"][name], dim=-1).detach()
            confidence, target = teacher_count.max(dim=-1)
            mask = (confidence >= float(pseudo["count_confidence"])) & eligible_rows
            count_candidates += mask.numel()
            count_selected += int(mask.sum().item())
            if bool(mask.any()):
                count = count + float(family_weights[name]) * F.cross_entropy(
                    student["count_logits"][name][mask], target[mask]
                )
    embedding = F.mse_loss(student["field_embeddings"], teacher["field_embeddings"].detach())
    record = F.mse_loss(student["record_embedding"], teacher["record_embedding"].detach())
    total = (
        float(weights["pseudo_entity"]) * entity
        + float(weights["pseudo_count"]) * count
        + float(weights["embedding_consistency"]) * embedding
        + float(weights["record_consistency"]) * record
    )
    return total, {
        "unsupervised": total.detach(), "pseudo_entity": entity.detach(), "pseudo_count": count.detach(),
        "embedding_consistency": embedding.detach(), "record_consistency": record.detach(),
    }, {
        "pseudo_selected": float(selected), "pseudo_candidates": float(candidates),
        "pseudo_raw_selected": float(raw_selected),
        "pseudo_rejected_by_balance": float(raw_selected - selected),
        "pseudo_positive": float(selected_positive), "pseudo_negative": float(selected_negative),
        "pseudo_coverage": selected / max(candidates, 1),
        "pseudo_count_selected": float(count_selected),
        "pseudo_count_candidates": float(count_candidates),
        "pseudo_count_coverage": count_selected / max(count_candidates, 1),
        "online_hard_pseudo_enabled": float(online_hard_enabled),
    }


def fixed_pseudo_loss(student: dict, targets: dict, config: dict) -> tuple[torch.Tensor, dict[str, float]]:
    total = _zero(student)
    selected, candidates = 0, 0
    for name in ENTITY_NAMES:
        if name not in targets:
            continue
        logits = student["entity_logits"][name]
        target = targets[name]["target"].to(logits.device, logits.dtype)
        mask = targets[name]["mask"].to(logits.device)
        total = total + float(config["family_weights"][name]) * _masked_bce(logits, target, mask)
        selected += int(mask.sum().item())
        candidates += mask.numel()
    return total, {
        "offline_pseudo_selected": float(selected),
        "offline_pseudo_candidates": float(candidates),
        "offline_pseudo_coverage": selected / max(candidates, 1),
    }


def anti_collapse_loss(*embeddings: torch.Tensor) -> torch.Tensor:
    values = torch.cat([value for value in embeddings if value.numel()], dim=0)
    if values.shape[0] < 2:
        return values.sum() * 0.0
    standard_deviation = torch.sqrt(values.float().var(dim=0, unbiased=False) + 1e-4)
    return torch.relu(0.20 - standard_deviation).mean().to(values.dtype)


def field_anti_collapse_loss(*embeddings: torch.Tensor) -> torch.Tensor:
    """Penalize collapse across cases separately for each semantic field."""
    values = torch.cat([value for value in embeddings if value.numel()], dim=0)
    if values.shape[0] < 2:
        return values.sum() * 0.0
    standard_deviation = torch.sqrt(values.float().var(dim=0, unbiased=False) + 1e-4)
    return torch.relu(0.20 - standard_deviation).mean().to(values.dtype)
