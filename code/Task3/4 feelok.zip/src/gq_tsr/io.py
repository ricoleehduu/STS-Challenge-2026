from __future__ import annotations

import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path


def canonical_case_id(value: object) -> str:
    text = str(value).strip().replace("\\", "/").split("/")[-1]
    text = re.sub(r"\.nii(?:\.gz)?$", "", text, flags=re.IGNORECASE)
    if re.fullmatch(r"[+-]?\d+\.0+", text):
        text = text.split(".", 1)[0]
    if not text:
        raise ValueError(f"Empty case ID derived from {value!r}")
    return text


def _natural_key(text: str) -> tuple:
    return tuple(int(part) if part.isdigit() else part.casefold() for part in re.split(r"(\d+)", text))


def discover_nifti(root: str | Path) -> dict[str, Path]:
    root = Path(root)
    if not root.exists():
        raise FileNotFoundError(root)
    found: dict[str, Path] = {}
    for path in sorted(root.rglob("*")):
        if not path.is_file() or not path.name.casefold().endswith((".nii", ".nii.gz")):
            continue
        case_id = canonical_case_id(path.name)
        if case_id in found:
            raise ValueError(f"Duplicate NIfTI for case {case_id}: {found[case_id]} and {path}")
        found[case_id] = path
    if not found:
        raise FileNotFoundError(f"No NIfTI files found under {root}")
    return dict(sorted(found.items(), key=lambda pair: _natural_key(pair[0])))


@dataclass(frozen=True)
class CaseItem:
    case_id: str
    image_path: str
    split: str

    def to_dict(self) -> dict:
        return asdict(self)


def build_case_items(image_root: str | Path, split: str) -> list[CaseItem]:
    return [CaseItem(case_id, str(path), split) for case_id, path in discover_nifti(image_root).items()]


def write_json(value: object, path: str | Path) -> Path:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
    return output


def read_json(path: str | Path) -> object:
    with Path(path).open("r", encoding="utf-8") as handle:
        return json.load(handle)


def append_jsonl(row: dict, path: str | Path) -> None:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(row, ensure_ascii=False) + "\n")
