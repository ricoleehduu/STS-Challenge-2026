from __future__ import annotations

import gc
from copy import deepcopy
from pathlib import Path
from time import perf_counter

import numpy as np
import torch
from torch.utils.data import DataLoader

from .augment import strong_augment, weak_augment
from .calibration import fit_entity_calibration
from .config import config_fingerprint, write_resolved_config
from .constants import ENTITY_NAMES
from .datasets import VolumeDataset, entity_matrix
from .ema import create_teacher, model_distance, update_teacher
from .entities import EntityVocabulary
from .io import CaseItem, write_json
from .losses import (
    anti_collapse_loss, field_anti_collapse_loss, fixed_pseudo_loss,
    supervised_loss, teacher_consistency_loss,
)
from .metrics import evaluate_predictions
from .model import build_model, parameter_report
from .monitoring import RunLogger
from .retrieval import retrieve_text
from .text_space import TextTargetSpace
from .utils import (
    autocast_context, cosine_learning_rate, cpu_state_dict, infinite, move_to_device,
    resolve_device, safe_torch_load, seed_everything, set_optimizer_learning_rates,
)
from .volume import VolumeStore


class LabeledTargetQueue:
    """Fold-local labeled text targets; never receives an unlabeled target."""

    def __init__(self, maximum: int) -> None:
        self.maximum = max(0, int(maximum))
        self.order: list[str] = []
        self.values: dict[str, torch.Tensor] = {}

    def negatives(self, current_case_ids: list[str], device: torch.device) -> torch.Tensor | None:
        available = [self.values[case_id] for case_id in self.order if case_id not in set(current_case_ids)]
        return torch.stack(available).to(device) if available else None

    def add(self, case_ids: list[str], targets: torch.Tensor) -> None:
        if self.maximum <= 0:
            return
        for case_id, target in zip(case_ids, targets.detach().cpu()):
            if case_id in self.order:
                self.order.remove(case_id)
            self.order.append(case_id)
            self.values[case_id] = target.clone()
        while len(self.order) > self.maximum:
            self.values.pop(self.order.pop(0), None)


def make_multilabel_folds(matrix: np.ndarray, folds: int, seed: int) -> list[tuple[np.ndarray, np.ndarray]]:
    if folds < 2 or folds > len(matrix):
        raise ValueError(f"Invalid folds={folds} for {len(matrix)} labeled cases")
    rng = np.random.default_rng(seed)
    frequency = matrix.sum(axis=0)
    rarity = (matrix / np.maximum(frequency, 1)).sum(axis=1)
    order = np.argsort(-(rarity + rng.uniform(0, 1e-6, size=len(matrix))))
    fold_labels = np.zeros((folds, matrix.shape[1]), np.float64)
    fold_members: list[list[int]] = [[] for _ in range(folds)]
    maximum_size = int(np.ceil(len(matrix) / folds))
    desired = frequency / folds
    for index in order:
        candidates = [fold for fold in range(folds) if len(fold_members[fold]) < maximum_size]
        scores = []
        for fold in candidates:
            label_cost = ((fold_labels[fold] + matrix[index]) / np.maximum(desired, 1.0)).sum()
            size_cost = len(fold_members[fold]) / max(1, len(matrix) / folds)
            scores.append(label_cost + 0.25 * size_cost)
        selected = candidates[int(np.argmin(scores))]
        fold_members[selected].append(int(index))
        fold_labels[selected] += matrix[index]
    all_indices = np.arange(len(matrix))
    return [(np.setdiff1d(all_indices, np.asarray(val, dtype=int)), np.asarray(sorted(val), dtype=int)) for val in fold_members]


def _loader(dataset: VolumeDataset, batch_size: int, config: dict, shuffle: bool) -> DataLoader:
    workers = int(config["training"]["num_workers"])
    return DataLoader(
        dataset, batch_size=batch_size, shuffle=shuffle, num_workers=workers,
        pin_memory=bool(config["training"]["pin_memory"]), persistent_workers=workers > 0,
    )


def _positive_weights(dataset: VolumeDataset, vocabulary: EntityVocabulary, config: dict, device: torch.device) -> dict[str, torch.Tensor]:
    records = [dataset.records[item.case_id] for item in dataset.items]  # type: ignore[index]
    values, _ = entity_matrix(records, vocabulary)
    result: dict[str, torch.Tensor] = {}
    for name in ENTITY_NAMES:
        positive = values[name].sum(axis=0)
        negative = len(records) - positive
        weight = np.clip(negative / np.maximum(positive, 1.0), 1.0, float(config["training"]["pos_weight_max"]))
        result[name] = torch.from_numpy(weight.astype(np.float32)).to(device)
    return result


def _load_pretrained_encoder(model: torch.nn.Module, path: str | Path | None) -> dict:
    if not path:
        return {"loaded": False, "path": None}
    payload = safe_torch_load(path)
    state = payload.get("encoder", payload)
    missing, unexpected = model.encoder.load_state_dict(state, strict=False)
    if missing or unexpected:
        raise ValueError(f"Pretrained encoder mismatch: missing={missing}, unexpected={unexpected}")
    return {"loaded": True, "path": str(Path(path).resolve()), "pretrain_step": payload.get("step")}


def _load_resume_checkpoint(path: Path, expected_fingerprint: str) -> dict:
    payload = safe_torch_load(path)
    observed = payload.get("config_fingerprint")
    if observed != expected_fingerprint:
        raise ValueError(
            f"Refusing incompatible checkpoint {path}: config fingerprint={observed!r}, "
            f"current={expected_fingerprint!r}. Use a new output directory."
        )
    return payload


def _stage_maximum_learning_rates(config: dict, stage: str) -> list[float]:
    settings = config["training"]
    if stage == "joint":
        return [
            float(settings["joint_encoder_learning_rate"]),
            float(settings["joint_head_learning_rate"]),
        ]
    if stage == "warm":
        return [float(settings["encoder_learning_rate"]), float(settings["head_learning_rate"])]
    raise ValueError(f"Unknown training stage: {stage}")


def _optimizer(student, config: dict, stage: str) -> torch.optim.Optimizer:
    settings = config["training"]
    learning_rates = _stage_maximum_learning_rates(config, stage)
    return torch.optim.AdamW(
        [
            {"params": list(student.encoder_parameters()), "lr": learning_rates[0]},
            {"params": list(student.head_parameters()), "lr": learning_rates[1]},
        ],
        weight_decay=float(settings["weight_decay"]),
    )


@torch.no_grad()
def evaluate_supervised(model, loader: DataLoader, pos_weights: dict, config: dict, device: torch.device) -> dict[str, float]:
    model.eval()
    values: dict[str, list[float]] = {}
    for batch in loader:
        batch = move_to_device(batch, device)
        with autocast_context(device, bool(config["training"]["amp"])):
            loss, parts = supervised_loss(model(batch["volume"]), batch, pos_weights, config["training"])
        for name, value in {"total": loss.detach(), **parts}.items():
            values.setdefault(name, []).append(float(value))
    return {name: float(np.mean(items)) for name, items in values.items()} if values else {"total": float("inf")}


@torch.no_grad()
def predict_outputs(model, dataset: VolumeDataset, config: dict, device: torch.device) -> dict:
    model.eval()
    case_ids: list[str] = []
    fields: list[np.ndarray] = []
    records: list[np.ndarray] = []
    entity = {name: [] for name in ENTITY_NAMES}
    counts = {name: [] for name in ENTITY_NAMES}
    for batch in _loader(dataset, 1, config, False):
        case_ids.extend(list(batch["case_id"]))
        volume = batch["volume"].to(device, non_blocking=True)
        with autocast_context(device, bool(config["training"]["amp"])):
            output = model(volume)
        fields.append(output["field_embeddings"].float().cpu().numpy())
        records.append(output["record_embedding"].float().cpu().numpy())
        for name in ENTITY_NAMES:
            entity[name].append(torch.sigmoid(output["entity_logits"][name]).float().cpu().numpy())
            counts[name].append(torch.softmax(output["count_logits"][name], -1).float().cpu().numpy())
    return {
        "case_ids": case_ids,
        "field_embeddings": np.concatenate(fields, axis=0),
        "record_embedding": np.concatenate(records, axis=0),
        "entity_probabilities": {name: np.concatenate(entity[name], axis=0) for name in ENTITY_NAMES},
        "count_probabilities": {name: np.concatenate(counts[name], axis=0) for name in ENTITY_NAMES},
    }


def _direct_head_metrics(output: dict, dataset: VolumeDataset) -> dict[str, float]:
    result: dict[str, float] = {}
    count_accuracies: list[float] = []
    for name in ENTITY_NAMES:
        targets = np.stack([
            dataset.targets[case_id]["entity_targets"][name].numpy()
            for case_id in output["case_ids"]
        ])
        predicted = output["entity_probabilities"][name] >= 0.5
        f1_values: list[float] = []
        for row in range(len(targets)):
            expected = targets[row] >= 0.5
            if not bool(expected.any()):
                continue
            intersection = int((predicted[row] & expected).sum())
            denominator = int(predicted[row].sum()) + int(expected.sum())
            f1_values.append(2 * intersection / max(denominator, 1))
        result[f"head_{name}_f1_nonempty_reference"] = float(np.mean(f1_values)) if f1_values else 0.0
        count_targets = np.asarray([
            int(dataset.targets[case_id]["count_targets"][name])
            for case_id in output["case_ids"]
        ])
        count_predictions = output["count_probabilities"][name].argmax(axis=-1)
        accuracy = float(np.mean(count_predictions == count_targets))
        result[f"head_{name}_count_accuracy"] = accuracy
        count_accuracies.append(accuracy)
    result["head_mean_count_accuracy"] = float(np.mean(count_accuracies))
    return result


@torch.no_grad()
def evaluate_fold_model(
    model, validation_dataset: VolumeDataset, validation_loader: DataLoader,
    train_dataset: VolumeDataset, vocabulary: EntityVocabulary, text_space: TextTargetSpace,
    pos_weights: dict, config: dict, device: torch.device,
) -> dict[str, float]:
    """Evaluate both differentiable objectives and the downstream retrieval task."""
    losses = evaluate_supervised(model, validation_loader, pos_weights, config, device)
    output = predict_outputs(model, validation_dataset, config, device)
    head_metrics = _direct_head_metrics(output, validation_dataset)
    reference_ids = [item.case_id for item in train_dataset.items]
    reference_records = train_dataset.records
    validation_records = validation_dataset.records
    if reference_records is None or validation_records is None:
        raise ValueError("Fold retrieval evaluation requires labeled train and validation records")
    reference_fields, _ = text_space.transform([reference_records[case_id] for case_id in reference_ids])
    selection_config = deepcopy(config)
    selection_config["retrieval"].update(
        config["training"].get("checkpoint_retrieval", {})
    )
    predictions, _ = retrieve_text(
        output["case_ids"], output["field_embeddings"], output["entity_probabilities"],
        reference_ids, reference_records, reference_fields, vocabulary, selection_config,
        output["count_probabilities"],
    )
    metrics = evaluate_predictions(predictions, validation_records, config["evaluation"]["weights"])
    weighted_proxy = float(metrics["metrics_mean"].get("weighted_proxy", 0.0))
    field_unique_ratio = float(np.mean([
        values.get("unique_ratio", 0.0) for values in metrics["field_metrics"].values()
    ]))
    return {
        **{f"loss_{name}": value for name, value in losses.items()},
        "weighted_proxy": weighted_proxy,
        "field_unique_ratio": field_unique_ratio,
        # Retained as a stable logging field. v3 checkpoint decisions use
        # explicit stage-specific guards instead of a mixed-unit linear score.
        "selection_score": weighted_proxy,
        "teeth_f1": float(metrics["metrics_mean"].get("teeth_f1", 0.0)),
        "diagnoses_f1": float(metrics["metrics_mean"].get("diagnoses_f1", 0.0)),
        "diagnosis_codes_f1": float(metrics["metrics_mean"].get("diagnosis_codes_f1", 0.0)),
        "treatments_f1": float(metrics["metrics_mean"].get("treatments_f1", 0.0)),
        **head_metrics,
    }


def _selected_model(
    student, teacher, student_metrics: dict, teacher_metrics: dict,
    stage: str, diversity_floor: float,
) -> tuple[str, object, dict]:
    def rank(metrics: dict) -> tuple:
        diverse = metrics["field_unique_ratio"] >= diversity_floor
        if stage == "warm":
            return diverse, -metrics["loss_total"], metrics["weighted_proxy"]
        if stage == "joint":
            return diverse, metrics["weighted_proxy"], -metrics["loss_total"]
        raise ValueError(f"Unknown selection stage: {stage}")

    if rank(teacher_metrics) >= rank(student_metrics):
        return "teacher", teacher, teacher_metrics
    return "student", student, student_metrics


def warm_candidate_improved(candidate: dict, best: dict, selection: dict) -> tuple[bool, str]:
    diversity_floor = float(selection["diversity_floor"])
    if candidate["field_unique_ratio"] < diversity_floor:
        minimum = float(selection["warm_loss_minimum_improvement"])
        if not best.get("diversity_qualified", False) and candidate["loss_total"] < best["loss"] - minimum:
            return True, "fallback_before_diversity_floor"
        return False, "below_diversity_floor"
    if not best.get("diversity_qualified", False):
        return True, "first_diversity_qualified"
    minimum = float(selection["warm_loss_minimum_improvement"])
    if candidate["loss_total"] < best["loss"] - minimum:
        return True, "lower_supervised_loss"
    return False, "no_warm_loss_improvement"


def joint_candidate_qualification(candidate: dict, best: dict, warm: dict, selection: dict) -> tuple[bool, str]:
    if candidate["field_unique_ratio"] < float(selection["diversity_floor"]):
        return False, "below_diversity_floor"
    loss_limit = float(warm["best_loss"]) * float(selection["joint_loss_relative_limit"])
    if candidate["loss_total"] > loss_limit:
        return False, "validation_loss_guard"
    required_proxy = float(best["weighted_proxy"]) + float(selection["joint_proxy_minimum_improvement"])
    if candidate["weighted_proxy"] < required_proxy:
        return False, "insufficient_proxy_improvement"
    return True, "qualified"


def select_joint_candidate(
    student_model, teacher_model, student_metrics: dict, teacher_metrics: dict,
    best: dict, warm: dict, selection: dict,
) -> tuple[str, object, dict, bool, str]:
    student_qualified, student_reason = joint_candidate_qualification(
        student_metrics, best, warm, selection
    )
    teacher_qualified, teacher_reason = joint_candidate_qualification(
        teacher_metrics, best, warm, selection
    )
    if student_qualified != teacher_qualified:
        if teacher_qualified:
            return "teacher", teacher_model, teacher_metrics, True, teacher_reason
        return "student", student_model, student_metrics, True, student_reason
    source, model, metrics = _selected_model(
        student_model, teacher_model, student_metrics, teacher_metrics,
        "joint", float(selection["diversity_floor"]),
    )
    qualified, reason = (teacher_qualified, teacher_reason) if source == "teacher" else (student_qualified, student_reason)
    return source, model, metrics, qualified, reason


def _scaler_step(scaler, optimizer) -> tuple[float, bool]:
    previous_scale = float(scaler.get_scale())
    scaler.step(optimizer)
    scaler.update()
    current_scale = float(scaler.get_scale())
    return current_scale, current_scale < previous_scale


def _evaluation_row(
    stage: str, fold: int, step: int, source: str, improved: bool,
    improved_over_warm: bool, student: dict, teacher: dict,
    selected: dict, best: dict, selection_qualified: bool = False,
    selection_pending_count: int = 0, selection_reason: str = "",
) -> dict:
    row = {
        "stage": stage, "fold": fold, "step": step, "source": source,
        "improved": improved, "improved_over_warm": improved_over_warm,
        "student_loss": student["loss_total"], "teacher_loss": teacher["loss_total"],
        "selected_loss": selected["loss_total"], "best_loss": best["loss"],
        "student_selection_score": student["selection_score"],
        "teacher_selection_score": teacher["selection_score"],
        "selected_selection_score": selected["selection_score"],
        "best_selection_score": best["score"],
        "selected_weighted_proxy": selected["weighted_proxy"],
        "best_weighted_proxy": best["weighted_proxy"],
        "selected_field_unique_ratio": selected["field_unique_ratio"],
        "best_field_unique_ratio": best["field_unique_ratio"],
        "selection_qualified": selection_qualified,
        "selection_pending_count": selection_pending_count,
        "selection_reason": selection_reason,
    }
    for prefix, metrics in (("student", student), ("teacher", teacher)):
        for name, value in metrics.items():
            row[f"{prefix}_{name}"] = value
    return row


def _stage_learning_rates(step: int, total_steps: int, config: dict, stage: str) -> list[float]:
    settings = config["training"]
    maximum = _stage_maximum_learning_rates(config, stage)
    warmup_key = "joint_lr_warmup_steps" if stage == "joint" else "lr_warmup_steps"
    return [
        cosine_learning_rate(step, total_steps, int(settings[warmup_key]), maximum[0], float(settings["minimum_learning_rate"])),
        cosine_learning_rate(step, total_steps, int(settings[warmup_key]), maximum[1], float(settings["minimum_learning_rate"])),
    ]


def _run_warm_fold(
    fold: int, train_dataset: VolumeDataset, validation_dataset: VolumeDataset,
    vocabulary: EntityVocabulary, text_space: TextTargetSpace, config: dict,
    device: torch.device, logger: RunLogger, output_dir: Path, pretrained_encoder: str | Path | None,
) -> dict:
    settings = config["training"]
    student = build_model(config["model"], vocabulary).to(device)
    pretrain_audit = _load_pretrained_encoder(student, pretrained_encoder)
    teacher = create_teacher(student)
    optimizer = _optimizer(student, config, "warm")
    scaler = torch.cuda.amp.GradScaler(
        enabled=bool(settings["amp"] and device.type == "cuda"),
        init_scale=float(settings.get("amp_initial_scale", 4096.0)),
    )
    train_stream = infinite(_loader(train_dataset, int(settings["batch_size_labeled"]), config, True))
    validation_loader = _loader(validation_dataset, int(settings["batch_size_labeled"]), config, False)
    pos_weights = _positive_weights(train_dataset, vocabulary, config, device)
    record_queue = LabeledTargetQueue(int(settings.get("contrast_queue_size", 64)))
    field_queue = LabeledTargetQueue(int(settings.get("field_contrast_queue_size", 64)))
    total_steps, accumulation = int(settings["warmup_steps"]), int(settings["accumulation_steps"])
    best = {
        "score": float("-inf"), "loss": float("inf"), "weighted_proxy": 0.0,
        "field_unique_ratio": 0.0, "diversity_qualified": False,
        "step": 0, "source": "student", "state": cpu_state_dict(student),
    }
    stale = 0
    successful_updates = 0
    for step in range(1, total_steps + 1):
        student.train()
        optimizer.zero_grad(set_to_none=True)
        sums: dict[str, float] = {}
        learning_rates = _stage_learning_rates(step, total_steps, config, "warm")
        set_optimizer_learning_rates(optimizer, learning_rates)
        for _ in range(accumulation):
            batch = move_to_device(next(train_stream), device)
            batch["volume"] = strong_augment(batch["volume"], config["augmentation"])
            case_ids = list(batch["case_id"])
            record_negatives = record_queue.negatives(case_ids, device)
            field_negatives = field_queue.negatives(case_ids, device)
            with autocast_context(device, bool(settings["amp"])):
                loss, parts = supervised_loss(
                    student(batch["volume"]), batch, pos_weights, settings,
                    record_negatives, field_negatives,
                )
            scaler.scale(loss / accumulation).backward()
            record_queue.add(case_ids, batch["record_target"])
            field_queue.add(case_ids, batch["field_targets"])
            for name, value in parts.items():
                sums[name] = sums.get(name, 0.0) + float(value) / accumulation
        scaler.unscale_(optimizer)
        gradient_norm = torch.nn.utils.clip_grad_norm_(student.parameters(), float(settings["gradient_clip"]))
        amp_scale, optimizer_step_skipped = _scaler_step(scaler, optimizer)
        if not optimizer_step_skipped:
            successful_updates += 1
            alpha = update_teacher(
                teacher, student, successful_updates, float(settings["ema_alpha_start"]),
                float(settings["ema_alpha_end"]), total_steps, bool(settings["ema_bias_correction"]),
            )
        else:
            alpha = 1.0
        if step % int(settings["log_every_steps"]) == 0 or step == 1:
            logger.step(step, "warm", fold, {
                **sums, "encoder_lr": learning_rates[0], "head_lr": learning_rates[1],
                "gradient_norm": float(gradient_norm), "ema_alpha": alpha,
                "gradient_norm_finite": bool(torch.isfinite(gradient_norm)),
                "amp_scale": amp_scale, "optimizer_step_skipped": optimizer_step_skipped,
                "successful_optimizer_steps": successful_updates,
            }, device)
        evaluate = (step % int(settings["eval_every_steps"]) == 0 or step == total_steps) and step >= int(settings["warmup_min_steps_before_selection"])
        if evaluate:
            student_metrics = evaluate_fold_model(
                student, validation_dataset, validation_loader, train_dataset,
                vocabulary, text_space, pos_weights, config, device,
            )
            teacher_metrics = evaluate_fold_model(
                teacher, validation_dataset, validation_loader, train_dataset,
                vocabulary, text_space, pos_weights, config, device,
            )
            selection = settings["checkpoint_selection"]
            source, selected, selected_metrics = _selected_model(
                student, teacher, student_metrics, teacher_metrics,
                "warm", float(selection["diversity_floor"]),
            )
            improved, selection_reason = warm_candidate_improved(selected_metrics, best, selection)
            if improved:
                best = {
                    "score": selected_metrics["weighted_proxy"], "loss": selected_metrics["loss_total"],
                    "weighted_proxy": selected_metrics["weighted_proxy"],
                    "field_unique_ratio": selected_metrics["field_unique_ratio"],
                    "diversity_qualified": selected_metrics["field_unique_ratio"] >= float(selection["diversity_floor"]),
                    "step": step, "source": source, "state": cpu_state_dict(selected),
                }
                stale = 0
            else:
                stale += 1
            logger.evaluation(_evaluation_row(
                "warm", fold, step, source, improved, False,
                student_metrics, teacher_metrics, selected_metrics, best,
                selected_metrics["field_unique_ratio"] >= float(selection["diversity_floor"]),
                0, selection_reason,
            ))
            print(
                f"[warm/fold={fold}] step={step}/{total_steps} "
                f"loss={selected_metrics['loss_total']:.5f} proxy={selected_metrics['weighted_proxy']:.5f} "
                f"unique={selected_metrics['field_unique_ratio']:.3f} best_loss={best['loss']:.5f} "
                f"source={source} reason={selection_reason}",
                flush=True,
            )
            patience = int(settings.get("warm_early_stopping_evaluations", settings["early_stopping_evaluations"]))
            if patience > 0 and stale >= patience:
                break
    payload = {
        "fold": fold, "inference_state": best["state"], "text_space": text_space,
        "best_loss": best["loss"], "best_score": best["score"],
        "best_weighted_proxy": best["weighted_proxy"],
        "best_field_unique_ratio": best["field_unique_ratio"],
        "best_step": best["step"], "best_source": best["source"],
        "pretrain": pretrain_audit, "config_fingerprint": config_fingerprint(config),
    }
    torch.save(payload, output_dir / "checkpoints" / f"warm_fold_{fold}.pt")
    del student, teacher, optimizer, scaler
    gc.collect()
    if device.type == "cuda":
        torch.cuda.empty_cache()
    return payload


def build_offline_pseudo(predictions: list[dict], config: dict) -> tuple[dict[str, dict], dict]:
    settings = config["pseudo_labels"]
    offline_hard_enabled = bool(settings.get("enable_offline_hard_pseudo", True))
    enabled_families = set(settings.get("enabled_families", ENTITY_NAMES))
    minimum_positives = int(settings.get("minimum_offline_positives_per_family", 1))
    negative_ratio = float(settings.get("maximum_negative_to_positive_ratio", 3.0))
    case_ids = predictions[0]["case_ids"]
    result: dict[str, dict] = {case_id: {} for case_id in case_ids}
    selected, candidates = 0, 0
    family_audit: dict[str, dict[str, float | int]] = {}
    for name in ENTITY_NAMES:
        values = np.stack([fold["entity_probabilities"][name] for fold in predictions], axis=0)
        positive_votes = (values >= float(settings["offline_positive_threshold"])).sum(axis=0)
        negative_votes = (values <= float(settings["offline_negative_threshold"])).sum(axis=0)
        raw_positive = positive_votes >= int(settings["fold_agreement"])
        raw_negative = negative_votes >= int(settings["fold_agreement"])
        raw_mask = raw_positive | raw_negative
        raw_positive_count = int(raw_positive.sum())
        retained_negative = np.zeros_like(raw_negative, dtype=bool)
        reason = "retained"
        if not offline_hard_enabled:
            reason = "offline_hard_pseudo_disabled"
        elif name not in enabled_families:
            reason = "family_disabled"
        elif raw_positive_count < minimum_positives:
            reason = "insufficient_positive_pseudo_labels"
        else:
            maximum_negatives = int(negative_ratio * raw_positive_count)
            negative_indices = np.flatnonzero(raw_negative)
            if maximum_negatives > 0 and len(negative_indices):
                mean_probability = values.mean(axis=0).reshape(-1)
                ranked = negative_indices[np.argsort(mean_probability[negative_indices])]
                retained_negative.reshape(-1)[ranked[:maximum_negatives]] = True
        mask = raw_positive | retained_negative if reason == "retained" else np.zeros_like(raw_mask, dtype=bool)
        target = raw_positive.astype(np.float32)
        family_selected = int(mask.sum())
        family_candidates = int(mask.size)
        family_positive = int((mask & (target >= 0.5)).sum())
        family_negative = family_selected - family_positive
        selected += family_selected
        candidates += family_candidates
        family_audit[name] = {
            "selected": family_selected, "candidates": family_candidates,
            "coverage": family_selected / max(family_candidates, 1),
            "positive": family_positive, "negative": family_negative,
            "positive_fraction_of_selected": family_positive / max(family_selected, 1),
            "raw_selected": int(raw_mask.sum()), "raw_positive": raw_positive_count,
            "raw_negative": int(raw_negative.sum()),
            "rejected_by_balance": int(raw_mask.sum()) - family_selected,
            "gate_reason": reason,
        }
        for row, case_id in enumerate(case_ids):
            result[case_id][name] = {"target": torch.from_numpy(target[row]), "mask": torch.from_numpy(mask[row])}
    cases_with_any = sum(
        any(bool(value["mask"].any()) for value in result[case_id].values()) for case_id in case_ids
    )
    return result, {
        "selected": selected, "candidates": candidates,
        "coverage": selected / max(candidates, 1), "models": len(predictions),
        "cases": len(case_ids), "cases_with_any_pseudo_entity": cases_with_any,
        "families": family_audit,
        "gating": {
            "enable_offline_hard_pseudo": offline_hard_enabled,
            "enabled_families": sorted(enabled_families),
            "minimum_offline_positives_per_family": minimum_positives,
            "maximum_negative_to_positive_ratio": negative_ratio,
        },
    }


@torch.no_grad()
def _fit_oof_calibration(
    folds: list[dict], splits: list[tuple[np.ndarray, np.ndarray]],
    labeled_items: list[CaseItem], labeled_records: dict[str, dict[str, str]],
    store: VolumeStore, vocabulary: EntityVocabulary, config: dict, device: torch.device,
) -> dict:
    probabilities: dict[str, list[np.ndarray]] = {name: [] for name in ENTITY_NAMES}
    count_probabilities: dict[str, list[np.ndarray]] = {name: [] for name in ENTITY_NAMES}
    targets: dict[str, list[np.ndarray]] = {name: [] for name in ENTITY_NAMES}
    for fold, (_, validation_indices) in zip(folds, splits):
        validation_items = [labeled_items[int(index)] for index in validation_indices]
        dataset = VolumeDataset(
            validation_items, store, labeled_records, vocabulary, fold["text_space"]
        )
        model = build_model(config["model"], vocabulary).to(device)
        model.load_state_dict(fold["inference_state"])
        output = predict_outputs(model, dataset, config, device)
        for name in ENTITY_NAMES:
            probabilities[name].append(output["entity_probabilities"][name])
            count_probabilities[name].append(output["count_probabilities"][name])
            targets[name].append(np.stack([
                vocabulary.encode(labeled_records[case_id])[name]
                for case_id in output["case_ids"]
            ]))
        del model
        if device.type == "cuda":
            torch.cuda.empty_cache()
    return fit_entity_calibration(
        {name: np.concatenate(values, axis=0) for name, values in probabilities.items()},
        {name: np.concatenate(values, axis=0) for name, values in targets.items()},
        config,
        {name: np.concatenate(values, axis=0) for name, values in count_probabilities.items()},
    )


def _batch_fixed_pseudo(case_ids: list[str], pseudo: dict[str, dict]) -> dict:
    return {
        name: {
            "target": torch.stack([pseudo[case_id][name]["target"] for case_id in case_ids]),
            "mask": torch.stack([pseudo[case_id][name]["mask"] for case_id in case_ids]),
        }
        for name in ENTITY_NAMES
    }


def _run_joint_fold(
    fold: int, warm: dict, train_dataset: VolumeDataset, validation_dataset: VolumeDataset,
    unlabeled_dataset: VolumeDataset, vocabulary: EntityVocabulary, fixed_pseudo: dict,
    config: dict, device: torch.device, logger: RunLogger, output_dir: Path,
) -> dict:
    settings, pseudo_settings = config["training"], config["pseudo_labels"]
    student = build_model(config["model"], vocabulary).to(device)
    student.load_state_dict(warm["inference_state"])
    teacher = create_teacher(student)
    optimizer = _optimizer(student, config, "joint")
    scaler = torch.cuda.amp.GradScaler(
        enabled=bool(settings["amp"] and device.type == "cuda"),
        init_scale=float(settings.get("amp_initial_scale", 4096.0)),
    )
    labeled_stream = infinite(_loader(train_dataset, int(settings["batch_size_labeled"]), config, True))
    unlabeled_stream = infinite(_loader(unlabeled_dataset, int(settings["batch_size_unlabeled"]), config, True))
    validation_loader = _loader(validation_dataset, int(settings["batch_size_labeled"]), config, False)
    pos_weights = _positive_weights(train_dataset, vocabulary, config, device)
    record_queue = LabeledTargetQueue(int(settings.get("contrast_queue_size", 64)))
    field_queue = LabeledTargetQueue(int(settings.get("field_contrast_queue_size", 64)))
    total_steps, accumulation = int(settings["joint_steps"]), int(settings["accumulation_steps"])
    best = {
        "score": float(warm["best_score"]), "loss": float(warm["best_loss"]),
        "weighted_proxy": float(warm["best_weighted_proxy"]),
        "field_unique_ratio": float(warm["best_field_unique_ratio"]),
        "step": 0, "source": "warm_fallback", "state": warm["inference_state"],
        "improved_over_warm": False,
    }
    stale = 0
    pending: dict | None = None
    pending_count = 0
    successful_updates = 0
    for step in range(1, total_steps + 1):
        student.train()
        teacher.eval()
        optimizer.zero_grad(set_to_none=True)
        sums: dict[str, float] = {}
        coverage: dict[str, float] = {}
        learning_rates = _stage_learning_rates(step, total_steps, config, "joint")
        set_optimizer_learning_rates(optimizer, learning_rates)
        ramp = min(1.0, step / max(1, int(settings["unsupervised_ramp_steps"]))) * float(settings["unsupervised_max_weight"])
        for _ in range(accumulation):
            labeled = move_to_device(next(labeled_stream), device)
            unlabeled = move_to_device(next(unlabeled_stream), device)
            labeled["volume"] = strong_augment(labeled["volume"], config["augmentation"])
            weak = weak_augment(unlabeled["volume"], config["augmentation"])
            strong = strong_augment(unlabeled["volume"], config["augmentation"])
            labeled_case_ids = list(labeled["case_id"])
            record_negatives = record_queue.negatives(labeled_case_ids, device)
            field_negatives = field_queue.negatives(labeled_case_ids, device)
            with torch.no_grad(), autocast_context(device, bool(settings["amp"])):
                teacher_output = teacher(weak)
            with autocast_context(device, bool(settings["amp"])):
                labeled_output = student(labeled["volume"])
                student_output = student(strong)
                supervised, supervised_parts = supervised_loss(
                    labeled_output, labeled, pos_weights, settings,
                    record_negatives, field_negatives,
                )
                online, online_parts, online_coverage = teacher_consistency_loss(
                    student_output, teacher_output, config, step >= int(settings["online_teacher_start_step"])
                )
                fixed_targets = _batch_fixed_pseudo(list(unlabeled["case_id"]), fixed_pseudo)
                offline, offline_coverage = fixed_pseudo_loss(student_output, fixed_targets, settings)
                record_collapse = anti_collapse_loss(
                    labeled_output["record_embedding"], student_output["record_embedding"]
                )
                field_collapse = field_anti_collapse_loss(
                    labeled_output["field_embeddings"], student_output["field_embeddings"]
                )
                collapse = 0.5 * (record_collapse + field_collapse)
                loss = supervised + ramp * (
                    float(pseudo_settings["online_weight"]) * online
                    + float(pseudo_settings["offline_weight"]) * offline
                    + float(settings["loss_weights"]["anti_collapse"]) * collapse
                )
            scaler.scale(loss / accumulation).backward()
            record_queue.add(labeled_case_ids, labeled["record_target"])
            field_queue.add(labeled_case_ids, labeled["field_targets"])
            parts = {
                **supervised_parts, **online_parts, "offline_pseudo": offline.detach(),
                "record_anti_collapse": record_collapse.detach(),
                "field_anti_collapse": field_collapse.detach(),
                "anti_collapse": collapse.detach(), "total": loss.detach(),
            }
            for name, value in parts.items():
                sums[name] = sums.get(name, 0.0) + float(value) / accumulation
            coverage = {**online_coverage, **offline_coverage}
        scaler.unscale_(optimizer)
        gradient_norm = torch.nn.utils.clip_grad_norm_(student.parameters(), float(settings["gradient_clip"]))
        amp_scale, optimizer_step_skipped = _scaler_step(scaler, optimizer)
        if not optimizer_step_skipped:
            successful_updates += 1
            alpha = update_teacher(
                teacher, student, successful_updates, float(settings["ema_alpha_start"]),
                float(settings["ema_alpha_end"]), total_steps, bool(settings["ema_bias_correction"]),
            )
        else:
            alpha = 1.0
        if step % int(settings["log_every_steps"]) == 0 or step == 1:
            distance = model_distance(teacher, student)
            logger.step(step, "joint", fold, {
                **sums, **coverage, **distance, "unsupervised_weight": ramp,
                "encoder_lr": learning_rates[0], "head_lr": learning_rates[1],
                "gradient_norm": float(gradient_norm), "ema_alpha": alpha,
                "gradient_norm_finite": bool(torch.isfinite(gradient_norm)),
                "amp_scale": amp_scale, "optimizer_step_skipped": optimizer_step_skipped,
                "successful_optimizer_steps": successful_updates,
            }, device)
        evaluate = (step % int(settings["eval_every_steps"]) == 0 or step == total_steps) and step >= int(settings["joint_min_steps_before_selection"])
        if evaluate:
            student_metrics = evaluate_fold_model(
                student, validation_dataset, validation_loader, train_dataset,
                vocabulary, warm["text_space"], pos_weights, config, device,
            )
            teacher_metrics = evaluate_fold_model(
                teacher, validation_dataset, validation_loader, train_dataset,
                vocabulary, warm["text_space"], pos_weights, config, device,
            )
            selection = settings["checkpoint_selection"]
            source, selected, selected_metrics, qualified, selection_reason = select_joint_candidate(
                student, teacher, student_metrics, teacher_metrics, best, warm, selection
            )
            improved = False
            if qualified:
                pending_count += 1
                candidate = {
                    "score": selected_metrics["weighted_proxy"], "loss": selected_metrics["loss_total"],
                    "weighted_proxy": selected_metrics["weighted_proxy"],
                    "field_unique_ratio": selected_metrics["field_unique_ratio"],
                    "step": step, "source": source, "state": cpu_state_dict(selected),
                    "improved_over_warm": True,
                }
                if pending is None or candidate["weighted_proxy"] > pending["weighted_proxy"]:
                    pending = candidate
                required = int(selection["joint_required_consecutive_evaluations"])
                selection_reason = f"qualified_pending_{pending_count}_of_{required}"
                if pending_count >= required:
                    assert pending is not None
                    best = pending
                    pending = None
                    pending_count = 0
                    improved = True
                    stale = 0
                    selection_reason = f"promoted_after_{required}_qualified_evaluations"
            else:
                pending = None
                pending_count = 0
                stale += 1
            logger.evaluation(_evaluation_row(
                "joint", fold, step, source, improved, best["improved_over_warm"],
                student_metrics, teacher_metrics, selected_metrics, best,
                qualified, pending_count, selection_reason,
            ))
            print(
                f"[joint/fold={fold}] step={step}/{total_steps} "
                f"loss={selected_metrics['loss_total']:.5f} proxy={selected_metrics['weighted_proxy']:.5f} "
                f"unique={selected_metrics['field_unique_ratio']:.3f} best_proxy={best['weighted_proxy']:.5f} "
                f"source={source} reason={selection_reason}",
                flush=True,
            )
            patience = int(settings.get("joint_early_stopping_evaluations", settings["early_stopping_evaluations"]))
            if patience > 0 and stale >= patience:
                break
    payload = {
        "fold": fold, "inference_state": best["state"], "text_space": warm["text_space"],
        "best_loss": best["loss"], "best_score": best["score"],
        "best_weighted_proxy": best["weighted_proxy"],
        "best_field_unique_ratio": best["field_unique_ratio"],
        "best_step": best["step"], "best_source": best["source"],
        "improved_over_warm": best["improved_over_warm"], "warm_best_loss": warm["best_loss"],
        "config_fingerprint": config_fingerprint(config),
    }
    torch.save(payload, output_dir / "checkpoints" / f"joint_fold_{fold}.pt")
    del student, teacher, optimizer, scaler
    gc.collect()
    if device.type == "cuda":
        torch.cuda.empty_cache()
    return payload


def train_teacher_student(
    labeled_items: list[CaseItem], unlabeled_items: list[CaseItem],
    labeled_records: dict[str, dict[str, str]], volume_cache: str | Path | None,
    output_dir: str | Path, config: dict, device_name: str,
    pretrained_encoder: str | Path | None = None, resume: bool = False,
) -> dict:
    seed_everything(int(config["seed"]))
    device = resolve_device(device_name)
    output_dir = Path(output_dir)
    (output_dir / "checkpoints").mkdir(parents=True, exist_ok=True)
    fingerprint = config_fingerprint(config)
    existing_fingerprint = output_dir / "config_fingerprint.txt"
    if existing_fingerprint.exists():
        previous = existing_fingerprint.read_text(encoding="utf-8").strip()
        if previous != fingerprint:
            raise ValueError(
                "Configuration mismatch: the current config does not match the run directory. "
                f"existing={previous}, current={fingerprint}. Use a new --output-dir."
            )
    elif any((output_dir / "checkpoints").glob("*.pt")) or (output_dir / "model_bundle.pt").exists():
        raise ValueError(
            "The output directory contains legacy checkpoints without a config fingerprint. "
            "Use a new --output-dir to avoid mixing experiment versions."
        )
    resolved_path, _ = write_resolved_config(config, output_dir)
    print(f"[config] resolved={resolved_path.resolve()} sha256={fingerprint}", flush=True)
    print(
        "[config] "
        f"experiment={config['training'].get('experiment_name', 'unnamed')} "
        f"joint_enabled={bool(config['training'].get('enable_joint', True))} "
        f"warm={config['training']['warmup_steps']} joint={config['training']['joint_steps']} "
        f"eval_every={config['training']['eval_every_steps']} "
        f"online_start={config['training']['online_teacher_start_step']} "
        f"joint_selection_start={config['training']['joint_min_steps_before_selection']} "
        f"joint_lr=({config['training']['joint_encoder_learning_rate']},"
        f"{config['training']['joint_head_learning_rate']})",
        flush=True,
    )
    logger = RunLogger(output_dir, bool(config["logging"]["tensorboard"]))
    ordered_records = [labeled_records[item.case_id] for item in labeled_items]
    vocabulary = EntityVocabulary.fit(ordered_records)
    _, matrix = entity_matrix(ordered_records, vocabulary)
    splits = make_multilabel_folds(matrix, int(config["training"]["folds"]), int(config["seed"]))
    store = VolumeStore(volume_cache, config["volume"])
    pretrained_encoder = pretrained_encoder or config["training"].get("pretrained_encoder")
    warm_folds: list[dict] = []
    fold_membership: list[dict] = []
    started = perf_counter()
    for fold, (train_indices, validation_indices) in enumerate(splits):
        train_items = [labeled_items[int(index)] for index in train_indices]
        validation_items = [labeled_items[int(index)] for index in validation_indices]
        fold_records = [labeled_records[item.case_id] for item in train_items]
        text_space = TextTargetSpace.fit(fold_records, config["text"], int(config["seed"]) + fold)
        train_dataset = VolumeDataset(train_items, store, labeled_records, vocabulary, text_space)
        validation_dataset = VolumeDataset(validation_items, store, labeled_records, vocabulary, text_space)
        checkpoint = output_dir / "checkpoints" / f"warm_fold_{fold}.pt"
        warm = _load_resume_checkpoint(checkpoint, fingerprint) if resume and checkpoint.exists() else _run_warm_fold(
            fold, train_dataset, validation_dataset, vocabulary, text_space, config, device, logger, output_dir, pretrained_encoder
        )
        warm_folds.append(warm)
        fold_membership.append({"fold": fold, "train_ids": [item.case_id for item in train_items], "validation_ids": [item.case_id for item in validation_items]})

    joint_enabled = bool(config["training"].get("enable_joint", True))
    offline_enabled = bool(config["pseudo_labels"].get("enable_offline_hard_pseudo", True))
    unlabeled_dataset = VolumeDataset(unlabeled_items, store)
    warm_predictions: list[dict] = []
    if joint_enabled and offline_enabled:
        for warm in warm_folds:
            model = build_model(config["model"], vocabulary).to(device)
            model.load_state_dict(warm["inference_state"])
            warm_predictions.append(predict_outputs(model, unlabeled_dataset, config, device))
            del model
            if device.type == "cuda":
                torch.cuda.empty_cache()
    else:
        warm_predictions.append({
            "case_ids": [item.case_id for item in unlabeled_items],
            "entity_probabilities": {
                name: np.zeros((len(unlabeled_items), len(getattr(vocabulary, name))), np.float32)
                for name in ENTITY_NAMES
            },
        })
    offline_pseudo, offline_audit = build_offline_pseudo(warm_predictions, config)
    offline_audit["joint_stage_enabled"] = joint_enabled
    write_json(offline_audit, output_dir / "offline_pseudo_audit.json")

    final_folds: list[dict] = []
    for fold, ((train_indices, validation_indices), warm) in enumerate(zip(splits, warm_folds)):
        train_items = [labeled_items[int(index)] for index in train_indices]
        validation_items = [labeled_items[int(index)] for index in validation_indices]
        train_dataset = VolumeDataset(train_items, store, labeled_records, vocabulary, warm["text_space"])
        validation_dataset = VolumeDataset(validation_items, store, labeled_records, vocabulary, warm["text_space"])
        if joint_enabled:
            checkpoint = output_dir / "checkpoints" / f"joint_fold_{fold}.pt"
            final = _load_resume_checkpoint(checkpoint, fingerprint) if resume and checkpoint.exists() else _run_joint_fold(
                fold, warm, train_dataset, validation_dataset, unlabeled_dataset, vocabulary,
                offline_pseudo, config, device, logger, output_dir,
            )
        else:
            final = dict(warm)
            final.update({
                "best_source": f"warm_only:{warm['best_source']}",
                "improved_over_warm": False, "warm_best_loss": warm["best_loss"],
            })
        final["train_ids"] = fold_membership[fold]["train_ids"]
        final["validation_ids"] = fold_membership[fold]["validation_ids"]
        final_folds.append(final)
    entity_calibration = _fit_oof_calibration(
        final_folds, splits, labeled_items, labeled_records, store,
        vocabulary, config, device,
    )
    write_json(entity_calibration, output_dir / "entity_calibration.json")
    audit_model = build_model(config["model"], vocabulary)
    model_audit = {
        **parameter_report(audit_model), "teacher_architecture": type(audit_model).__name__,
        "student_architecture": type(audit_model).__name__, "teacher_student_parameter_ratio": 1.0,
        "encoder_trainable": True, "unlabeled_csv_api_available": False,
        "unlabeled_target_fields_read": 0, "offline_pseudo": offline_audit,
        "experiment_name": config["training"].get("experiment_name", "unnamed"),
        "joint_stage_enabled": joint_enabled,
    }
    del audit_model
    bundle = {
        "format_version": 4,
        "architecture": "GQ-TSR-Full3D-Homogeneous-EMA-Teacher",
        "config": config, "vocabulary": vocabulary.to_dict(), "folds": final_folds,
        "labeled_records": labeled_records, "labeled_items": [item.to_dict() for item in labeled_items],
        "model_audit": model_audit, "fold_membership": fold_membership,
        "entity_calibration": entity_calibration,
        "config_fingerprint": fingerprint,
    }
    bundle_path = output_dir / "model_bundle.pt"
    torch.save(bundle, bundle_path)
    summary = {
        **model_audit, "folds": len(final_folds), "seconds": perf_counter() - started,
        "bundle": str(bundle_path.resolve()),
        "config_fingerprint": fingerprint, "resolved_config": str(resolved_path.resolve()),
        "semi_supervised_folds_improved": sum(bool(fold["improved_over_warm"]) for fold in final_folds),
        "effective_schedule": {
            name: config["training"][name] for name in (
                "warmup_steps", "joint_steps", "eval_every_steps",
                "warmup_min_steps_before_selection", "joint_min_steps_before_selection",
                "online_teacher_start_step", "unsupervised_ramp_steps",
                "encoder_learning_rate", "head_learning_rate",
                "joint_encoder_learning_rate", "joint_head_learning_rate",
                "unsupervised_max_weight",
            )
        },
        "selection_policy": config["training"]["checkpoint_selection"],
        "pseudo_label_policy": {
            name: config["pseudo_labels"][name] for name in (
                "enable_online_hard_pseudo", "enable_offline_hard_pseudo",
                "enabled_families", "minimum_offline_positives_per_family",
                "minimum_online_positives_per_batch",
                "maximum_negative_to_positive_ratio", "offline_weight", "online_weight",
            )
        },
        "entity_calibration": entity_calibration,
        "fold_results": [{
            "fold": fold["fold"], "best_step": fold["best_step"],
            "best_source": fold["best_source"], "best_loss": fold["best_loss"],
            "best_score": fold["best_score"],
            "best_weighted_proxy": fold["best_weighted_proxy"],
            "best_field_unique_ratio": fold["best_field_unique_ratio"],
            "improved_over_warm": fold["improved_over_warm"],
        } for fold in final_folds],
    }
    write_json(summary, output_dir / "training_summary.json")
    write_json(fold_membership, output_dir / "folds.json")
    logger.close()
    return bundle
