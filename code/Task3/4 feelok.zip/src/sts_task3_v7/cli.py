from __future__ import annotations

import argparse
import json

from .pipeline import (
    audit_cache,
    cache_simulation,
    evaluate,
    extract_validation_cache,
    predict,
    refit_for_official,
    run_local,
)
from .submission import validate_submission_zip


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="STS 2026 Task 3 validation-guided retrieval")
    commands = parser.add_subparsers(dest="command", required=True)

    audit = commands.add_parser("audit-cache", help="Verify cache coverage and encoder compatibility")
    audit.add_argument("--simulation-root", required=True)
    audit.add_argument("--config", default=None)
    audit.add_argument("--training-cache-root", action="append", required=True)
    audit.add_argument("--validation-cache-root", action="append", required=True)

    cache = commands.add_parser(
        "cache", help="Encode all splits into a generic diagnostic cache"
    )
    cache.add_argument("--simulation-root", required=True)
    cache.add_argument("--output-dir", required=True)
    cache.add_argument("--config", default=None)
    cache.add_argument("--device", default=None)
    cache.add_argument("--overwrite", action="store_true")

    validation_cache = commands.add_parser(
        "extract-validation-cache",
        help="Extract simulated Validation IDs from an existing original-unlabeled cache",
    )
    validation_cache.add_argument("--simulation-root", required=True)
    validation_cache.add_argument("--training-cache-root", required=True)
    validation_cache.add_argument("--source-cache-root", required=True)
    validation_cache.add_argument("--output-dir", required=True)
    validation_cache.add_argument("--config", default=None)
    validation_cache.add_argument("--overwrite", action="store_true")

    local = commands.add_parser("run-local", help="Fit, tune, evaluate, and package on local validation")
    local.add_argument("--simulation-root", required=True)
    local.add_argument("--output-dir", required=True)
    local.add_argument("--config", default=None)
    local.add_argument("--training-cache-root", action="append", required=True)
    local.add_argument("--validation-cache-root", action="append", required=True)
    local.add_argument("--external-predictions", action="append", default=[])

    prediction = commands.add_parser("predict", help="Predict an image-only split with a frozen V7 bundle")
    prediction.add_argument("--bundle", required=True)
    prediction.add_argument("--query-dir", required=True)
    prediction.add_argument("--output-dir", required=True)
    prediction.add_argument("--cache-root", action="append", required=True)
    prediction.add_argument("--external-predictions", action="append", default=[])

    scoring = commands.add_parser("evaluate", help="Evaluate predictions against a labeled CSV")
    scoring.add_argument("--predictions", required=True)
    scoring.add_argument("--ground-truth-csv", required=True)
    scoring.add_argument("--output", required=True)
    scoring.add_argument("--config", default=None)

    validation = commands.add_parser("validate-submission", help="Validate the Task 3 ZIP layout")
    validation.add_argument("--zip", required=True)
    validation.add_argument("--query-dir", default=None)

    refit = commands.add_parser(
        "refit-official",
        help="Refit the frozen local policy on all 250 record-bearing cases for official prediction",
    )
    refit.add_argument("--bundle", required=True)
    refit.add_argument("--simulation-root", required=True)
    refit.add_argument("--output", required=True)
    refit.add_argument("--training-cache-root", action="append", required=True)
    refit.add_argument("--validation-cache-root", action="append", required=True)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "audit-cache":
        result = audit_cache(
            args.simulation_root,
            args.config,
            args.training_cache_root,
            args.validation_cache_root,
        )
    elif args.command == "cache":
        result = cache_simulation(
            args.simulation_root, args.output_dir, args.config, args.device, args.overwrite
        )
    elif args.command == "extract-validation-cache":
        result = extract_validation_cache(
            args.simulation_root,
            args.training_cache_root,
            args.source_cache_root,
            args.output_dir,
            args.config,
            args.overwrite,
        )
    elif args.command == "run-local":
        result = run_local(
            args.simulation_root,
            args.output_dir,
            args.config,
            args.training_cache_root,
            args.validation_cache_root,
            args.external_predictions,
        )
    elif args.command == "predict":
        result = predict(
            args.bundle,
            args.query_dir,
            args.output_dir,
            args.cache_root,
            args.external_predictions,
        )
    elif args.command == "evaluate":
        result = evaluate(args.predictions, args.ground_truth_csv, args.output, args.config)
    elif args.command == "validate-submission":
        expected = None
        if args.query_dir:
            from .io import discover_nifti

            expected = sorted(discover_nifti(args.query_dir))
        errors = validate_submission_zip(args.zip, expected)
        result = {"valid": not errors, "errors": errors}
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if not errors else 2
    elif args.command == "refit-official":
        result = refit_for_official(
            args.bundle,
            args.simulation_root,
            args.output,
            args.training_cache_root,
            args.validation_cache_root,
        )
    else:
        raise AssertionError(args.command)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0
