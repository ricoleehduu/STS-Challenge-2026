from __future__ import annotations

import math
from pathlib import Path

import pandas as pd

from .constants import FIELD_ALIASES, FIELDS, ID_ALIASES, OPTIONAL_INPUT_FIELDS
from .io import canonical_case_id


def _read_csv(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(path)
    last_error: Exception | None = None
    for encoding in ("utf-8-sig", "utf-8", "gb18030"):
        try:
            return pd.read_csv(path, encoding=encoding, dtype=object)
        except UnicodeDecodeError as exc:
            last_error = exc
    assert last_error is not None
    raise last_error


def _column_lookup(columns: list[str]) -> dict[str, str]:
    return {str(column).strip().casefold(): str(column) for column in columns}


def _resolve_column(columns: list[str], aliases: tuple[str, ...]) -> str | None:
    lookup = _column_lookup(columns)
    for alias in aliases:
        resolved = lookup.get(alias.strip().casefold())
        if resolved is not None:
            return resolved
    return None


def clean_text(value: object) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and math.isnan(value):
        return ""
    text = " ".join(str(value).replace("\r", " ").replace("\n", " ").split())
    return "" if text.casefold() in {"nan", "none", "null", "n/a", "na"} else text


def _normalized_rows(frame: pd.DataFrame) -> list[dict[str, str]]:
    columns = [str(column) for column in frame.columns]
    id_column = _resolve_column(columns, ID_ALIASES)
    if id_column is None:
        raise ValueError(f"No case ID column found. Expected one of {ID_ALIASES}; got {columns}")
    field_columns = {
        field: _resolve_column(columns, aliases) for field, aliases in FIELD_ALIASES.items()
    }
    optional_columns = {
        field: _resolve_column(columns, (field, field.lower())) for field in OPTIONAL_INPUT_FIELDS
    }
    rows: list[dict[str, str]] = []
    for _, source in frame.iterrows():
        raw_id = source.get(id_column)
        if not clean_text(raw_id):
            continue
        record = {"case_id": canonical_case_id(raw_id)}
        for field in FIELDS:
            column = field_columns[field]
            record[field] = clean_text(source.get(column)) if column else ""
        for field, column in optional_columns.items():
            record[field] = clean_text(source.get(column)) if column else ""
        rows.append(record)
    return rows


def load_records(path: str | Path, merge: str = "most_complete") -> dict[str, dict[str, str]]:
    rows = _normalized_rows(_read_csv(path))
    grouped: dict[str, list[dict[str, str]]] = {}
    for row in rows:
        grouped.setdefault(row["case_id"], []).append(row)
    result: dict[str, dict[str, str]] = {}
    for case_id, candidates in grouped.items():
        if merge == "first":
            selected = candidates[0]
        elif merge == "last":
            selected = candidates[-1]
        elif merge == "most_complete":
            selected = max(
                candidates,
                key=lambda item: (
                    sum(bool(item.get(field)) for field in FIELDS),
                    sum(len(item.get(field, "")) for field in FIELDS),
                ),
            )
        else:
            raise ValueError(f"Unsupported record_merge={merge!r}")
        result[case_id] = dict(selected)
    return result


def serialize_record(record: dict[str, str]) -> str:
    parts = [f"[{field.upper().replace(' ', '_')}] {clean_text(record.get(field, ''))}" for field in FIELDS]
    return " ".join(parts)


def record_completeness(record: dict[str, str]) -> float:
    return sum(bool(clean_text(record.get(field))) for field in FIELDS) / len(FIELDS)
