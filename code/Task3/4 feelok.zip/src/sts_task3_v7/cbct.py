from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from time import perf_counter

import nibabel as nib
import numpy as np
import torch
import torch.nn.functional as F


@dataclass
class SliceBatch:
    images: torch.Tensor
    plane_ids: torch.Tensor
    positions: torch.Tensor


def load_canonical_volume(path: str | Path, low: float = 0.5, high: float = 99.5) -> np.ndarray:
    image = nib.as_closest_canonical(nib.load(str(path)))
    volume = np.asarray(image.dataobj, dtype=np.float32)
    if volume.ndim == 4 and volume.shape[-1] == 1:
        volume = volume[..., 0]
    if volume.ndim != 3:
        raise ValueError(f"Expected 3D NIfTI, got shape={volume.shape} at {path}")
    # Follow the memory-conscious nnU-Net pattern: clip and normalize in
    # place. A 640x640x400 CBCT already occupies about 625 MiB as float32,
    # therefore full-size masks and repeated normalized copies are wasteful.
    if not volume.flags.writeable or not volume.flags.c_contiguous:
        volume = np.ascontiguousarray(volume, dtype=np.float32)
    sample_stride = tuple(max(1, size // 160) for size in volume.shape)
    sample = volume[:: sample_stride[0], :: sample_stride[1], :: sample_stride[2]]
    sample = sample[np.isfinite(sample)]
    if sample.size == 0:
        raise ValueError(f"NIfTI contains no finite voxels: {path}")
    lo, hi = np.percentile(sample, [low, high]).astype(np.float32)
    if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
        lo, hi = float(np.nanmin(sample)), float(np.nanmax(sample))
    if hi <= lo:
        return np.zeros_like(volume, dtype=np.float32)
    np.nan_to_num(volume, copy=False, nan=float(lo), posinf=float(hi), neginf=float(lo))
    np.clip(volume, lo, hi, out=volume)
    volume -= lo
    volume /= hi - lo
    return volume


def crop_foreground(volume: np.ndarray, margin: int = 8) -> np.ndarray:
    stride = tuple(max(1, size // 192) for size in volume.shape)
    coarse = volume[:: stride[0], :: stride[1], :: stride[2]]
    threshold = max(0.03, float(np.percentile(coarse, 20)))
    foreground = coarse > threshold
    if not foreground.any():
        return volume

    # rank1/nnU-Net crops with a foreground bounding box. Axis projections
    # yield the same box without allocating an N_foreground x 3 coordinate
    # matrix as np.argwhere does.
    bounds: list[tuple[int, int]] = []
    for axis in range(3):
        reduce_axes = tuple(value for value in range(3) if value != axis)
        occupied = np.any(foreground, axis=reduce_axes)
        indices = np.flatnonzero(occupied)
        bounds.append((int(indices[0]), int(indices[-1]) + 1))
    stride_array = np.asarray(stride, dtype=np.int64)
    lo = np.asarray([bound[0] for bound in bounds], dtype=np.int64) * stride_array
    hi = np.asarray([bound[1] for bound in bounds], dtype=np.int64) * stride_array
    lo = np.maximum(0, lo - margin)
    hi = np.minimum(np.asarray(volume.shape), hi + margin)
    if np.any(hi - lo < 8):
        return volume
    return volume[lo[0] : hi[0], lo[1] : hi[1], lo[2] : hi[2]]


def _slice_at(volume: np.ndarray, axis: int, index: int) -> np.ndarray:
    selector = [slice(None), slice(None), slice(None)]
    selector[axis] = int(index)
    return volume[tuple(selector)]


def _information_score(image: np.ndarray) -> float:
    if image.size == 0:
        return 0.0
    down = image[:: max(1, image.shape[0] // 96), :: max(1, image.shape[1] // 96)]
    gx = np.abs(np.diff(down, axis=0)).mean() if down.shape[0] > 1 else 0.0
    gy = np.abs(np.diff(down, axis=1)).mean() if down.shape[1] > 1 else 0.0
    foreground = float((down > 0.08).mean())
    return float(down.std() + gx + gy + 0.15 * foreground)


def select_indices(
    volume: np.ndarray,
    axis: int,
    count: int,
    mode: str = "hybrid",
    candidate_multiplier: int = 4,
) -> np.ndarray:
    size = volume.shape[axis]
    if count <= 0:
        raise ValueError("slices_per_plane must be positive")
    if size <= count:
        return np.rint(np.linspace(0, size - 1, count)).astype(np.int64)
    uniform = np.rint(np.linspace(0, size - 1, count)).astype(np.int64)
    if mode == "uniform":
        return uniform
    if mode != "hybrid":
        raise ValueError(f"Unsupported sampling mode: {mode}")
    keep_uniform = max(2, count // 2)
    base = np.rint(np.linspace(0, size - 1, keep_uniform)).astype(np.int64)
    candidates = np.unique(
        np.rint(np.linspace(0, size - 1, max(count, count * candidate_multiplier))).astype(np.int64)
    )
    ranked = sorted(candidates, key=lambda idx: _information_score(_slice_at(volume, axis, int(idx))), reverse=True)
    selected = set(int(value) for value in base)
    min_distance = max(1, size // (count * 3))
    for index in ranked:
        if len(selected) >= count:
            break
        if all(abs(int(index) - other) >= min_distance for other in selected):
            selected.add(int(index))
    for index in uniform:
        if len(selected) >= count:
            break
        selected.add(int(index))
    values = sorted(selected)
    if len(values) < count:
        for index in range(size):
            if index not in selected:
                values.append(index)
                selected.add(index)
            if len(values) == count:
                break
    return np.asarray(sorted(values[:count]), dtype=np.int64)


def _neighbor_stack(volume: np.ndarray, axis: int, index: int, stride: int) -> np.ndarray:
    size = volume.shape[axis]
    indices = [max(0, min(size - 1, index + offset * stride)) for offset in (-1, 0, 1)]
    return np.stack([_slice_at(volume, axis, value) for value in indices], axis=0)


def _plane_neighbor_stacks(
    volume: np.ndarray,
    axis: int,
    indices: np.ndarray,
    neighbor_stride: int,
) -> np.ndarray:
    """Build one anatomical plane in one allocation for batch resizing."""
    slice_shape = _slice_at(volume, axis, 0).shape
    stacks = np.empty((len(indices), 3, *slice_shape), dtype=np.float32)
    axis_size = volume.shape[axis]
    for row, index in enumerate(indices):
        neighbors = [
            max(0, min(axis_size - 1, int(index) + offset * neighbor_stride))
            for offset in (-1, 0, 1)
        ]
        for channel, neighbor in enumerate(neighbors):
            stacks[row, channel] = _slice_at(volume, axis, neighbor)
    return stacks


def volume_to_slices(path: str | Path, preprocess: dict) -> SliceBatch:
    max_threads = int(preprocess.get("cpu_threads", 8))
    if max_threads > 0 and torch.get_num_threads() > max_threads:
        # rank2 explicitly caps PyTorch CPU threads at eight. This avoids
        # severe OpenMP scheduling overhead on high-core-count servers.
        torch.set_num_threads(max_threads)

    report_timing = bool(preprocess.get("report_timing", True))
    case_name = Path(path).name
    total_start = perf_counter()
    stage_start = total_start
    if report_timing:
        print(f"[CBCT {case_name}] loading and normalizing...", flush=True)
    volume = load_canonical_volume(
        path,
        low=float(preprocess.get("percentile_low", 0.5)),
        high=float(preprocess.get("percentile_high", 99.5)),
    )
    if report_timing:
        print(
            f"[CBCT {case_name}] loaded shape={tuple(volume.shape)} in {perf_counter() - stage_start:.2f}s; "
            "cropping foreground...",
            flush=True,
        )
    stage_start = perf_counter()
    volume = crop_foreground(volume, margin=int(preprocess.get("foreground_margin", 8)))
    if report_timing:
        print(
            f"[CBCT {case_name}] cropped shape={tuple(volume.shape)} in {perf_counter() - stage_start:.2f}s; "
            "selecting and resizing slices...",
            flush=True,
        )
    count = int(preprocess.get("slices_per_plane", 16))
    size = int(preprocess.get("image_size", 224))
    mode = str(preprocess.get("sampling", "hybrid"))
    multiplier = int(preprocess.get("candidate_multiplier", 4))
    neighbor_stride = int(preprocess.get("neighbor_stride", 1))
    images: list[torch.Tensor] = []
    plane_ids: list[int] = []
    positions: list[float] = []
    for axis in range(3):
        plane_start = perf_counter()
        indices = select_indices(volume, axis, count, mode=mode, candidate_multiplier=multiplier)
        denominator = max(1, volume.shape[axis] - 1)
        # Resize a complete anatomical plane in one call. This reduces 48
        # separate F.interpolate calls to three while preserving output order.
        plane = _plane_neighbor_stacks(volume, axis, indices, neighbor_stride)
        tensor = torch.from_numpy(plane)
        tensor = F.interpolate(tensor, size=(size, size), mode="bilinear", align_corners=False)
        images.append(tensor)
        plane_ids.extend([axis] * len(indices))
        positions.extend(float(index) / denominator for index in indices)
        if report_timing:
            print(
                f"[CBCT {case_name}] plane={axis} slices={len(indices)} finished "
                f"in {perf_counter() - plane_start:.2f}s",
                flush=True,
            )
    result = SliceBatch(
        images=torch.cat(images, dim=0).float(),
        plane_ids=torch.tensor(plane_ids, dtype=torch.long),
        positions=torch.tensor(positions, dtype=torch.float32),
    )
    if report_timing:
        print(
            f"[CBCT {case_name}] preprocessing completed in {perf_counter() - total_start:.2f}s",
            flush=True,
        )
    return result
