from __future__ import annotations

import json
import zipfile
from pathlib import Path

from .constants import FIELDS
from .io import write_json
from .records import clean_text


def validate_predictions(
    predictions: object,
    expected_case_ids: list[str] | None = None,
    require_nonempty: bool = True,
) -> list[str]:
    errors: list[str] = []
    if not isinstance(predictions, dict):
        return ["Root JSON value must be an object keyed by case ID"]
    for raw_case_id, record in predictions.items():
        case_id = str(raw_case_id)
        if not case_id.strip():
            errors.append("Empty case ID")
        if not isinstance(record, dict):
            errors.append(f"{case_id}: prediction must be an object")
            continue
        missing = [field for field in FIELDS if field not in record]
        extra = [field for field in record if field not in FIELDS]
        if missing:
            errors.append(f"{case_id}: missing fields {missing}")
        if extra:
            errors.append(f"{case_id}: unexpected fields {extra}")
        for field in FIELDS:
            if field in record and not isinstance(record[field], str):
                errors.append(f"{case_id}/{field}: value must be a string")
            elif require_nonempty and field in record and not clean_text(record[field]):
                errors.append(f"{case_id}/{field}: value is empty")
    if expected_case_ids is not None:
        actual = {str(case_id) for case_id in predictions}
        expected = {str(case_id) for case_id in expected_case_ids}
        missing_cases = sorted(expected - actual)
        extra_cases = sorted(actual - expected)
        if missing_cases:
            errors.append(f"Missing case IDs: {missing_cases}")
        if extra_cases:
            errors.append(f"Unexpected case IDs: {extra_cases}")
    return errors


def write_submission(
    predictions: dict[str, dict[str, str]],
    output_zip: str | Path,
    expected_case_ids: list[str] | None = None,
) -> tuple[Path, Path]:
    errors = validate_predictions(predictions, expected_case_ids=expected_case_ids)
    if errors:
        raise ValueError("Invalid predictions:\n- " + "\n- ".join(errors))
    output_zip = Path(output_zip)
    output_zip.parent.mkdir(parents=True, exist_ok=True)
    predictions_path = output_zip.with_name("predictions.json")
    write_json(predictions, predictions_path)
    with zipfile.ZipFile(output_zip, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.write(predictions_path, arcname="predictions.json")
    with zipfile.ZipFile(output_zip, "r") as archive:
        names = archive.namelist()
        if names != ["predictions.json"]:
            raise RuntimeError(f"Submission ZIP must contain exactly predictions.json; got {names}")
        parsed = json.loads(archive.read("predictions.json").decode("utf-8"))
        errors = validate_predictions(parsed, expected_case_ids=expected_case_ids)
        if errors:
            raise RuntimeError("ZIP verification failed:\n- " + "\n- ".join(errors))
    return predictions_path, output_zip


def validate_submission_zip(path: str | Path, expected_case_ids: list[str] | None = None) -> list[str]:
    path = Path(path)
    if not path.exists():
        return [f"File does not exist: {path}"]
    try:
        with zipfile.ZipFile(path, "r") as archive:
            if archive.namelist() != ["predictions.json"]:
                return [f"ZIP must contain exactly predictions.json at root; got {archive.namelist()}"]
            predictions = json.loads(archive.read("predictions.json").decode("utf-8"))
    except (zipfile.BadZipFile, UnicodeDecodeError, json.JSONDecodeError) as exc:
        return [f"Cannot read valid predictions ZIP: {exc}"]
    return validate_predictions(predictions, expected_case_ids=expected_case_ids)
