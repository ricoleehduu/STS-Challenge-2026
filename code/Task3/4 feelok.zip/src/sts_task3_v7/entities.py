from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass
from typing import Iterable

import numpy as np

from .constants import ENTITY_NAMES, FIELDS
from .records import clean_text


FDI_TEETH = tuple(
    [f"{q}{p}" for q in range(1, 5) for p in range(1, 9)]
    + [f"{q}{p}" for q in range(5, 9) for p in range(1, 6)]
)

DIAGNOSIS_PATTERNS = {
    "caries": (r"\bcar(?:y|ies|ious)\b", r"dental decay", r"龋"),
    "pulpitis": (r"\bpulpitis\b", r"牙髓炎"),
    "pulp necrosis": (r"pulp(?:al)? necrosis", r"牙髓坏死"),
    "apical periodontitis": (r"(?:peri)?apical periodontitis", r"根尖周炎"),
    "periodontitis": (r"\bperiodontitis\b", r"牙周炎", r"periodontal disease"),
    "gingivitis": (r"\bgingivitis\b", r"牙龈炎"),
    "impacted tooth": (r"impact(?:ed|ion)", r"impressed teeth", r"阻生"),
    "missing tooth": (r"missing teeth?", r"teeth are missing", r"tooth loss", r"缺失牙", r"牙缺失"),
    "retained deciduous tooth": (r"retained deciduous", r"残留乳牙", r"滞留乳牙"),
    "residual crown": (r"residual crown", r"残冠"),
    "retained root": (r"retained root", r"residual root", r"残根"),
    "periapical lesion": (r"periapical lesion", r"periapical radioluc", r"根尖.*(?:病变|低密度)"),
    "dental abscess": (r"(?:dental|periapical|periodontal) abscess", r"脓肿"),
    "tooth fracture": (r"(?:tooth|root) fracture", r"牙折", r"根折"),
    "malocclusion": (r"malocclusion", r"uneven teeth", r"错颌", r"错合"),
    "pericoronitis": (r"pericoronitis", r"冠周炎"),
    "dentinal hypersensitivity": (r"hypersensitiv", r"牙本质敏感"),
    "temporomandibular disorder": (r"temporomandibular", r"\bTMD\b", r"颞下颌关节"),
}

TREATMENT_PATTERNS = {
    "root canal treatment": (r"root canal", r"\bRCT\b", r"endodontic", r"根管治疗"),
    "restoration": (r"restoration", r"filling", r"充填", r"修复"),
    "extraction": (r"extract(?:ion|ed)?", r"removal", r"exodont", r"拔除", r"拔牙"),
    "periodontal treatment": (r"periodontal treatment", r"scaling", r"root planing", r"洁治"),
    "orthodontic treatment": (r"orthodont", r"window traction", r"正畸", r"牵引"),
    "implant treatment": (r"implant", r"种植"),
    "crown restoration": (r"crown restoration", r"冠修复", r"牙冠修复"),
    "surgical treatment": (r"surg(?:ery|ical)", r"手术"),
    "medication": (r"medication", r"prescri", r"用药", r"口服"),
    "observation": (r"observation", r"monitor", r"观察"),
    "follow-up": (r"follow[ -]?up", r"review", r"复诊", r"随访"),
    "oral hygiene instruction": (r"oral hygiene", r"刷牙", r"口腔卫生"),
}

MEDICATION_PATTERNS = {
    "amoxicillin": (r"amoxicillin", r"阿莫西林"),
    "metronidazole": (r"metronidazole", r"甲硝唑"),
    "ibuprofen": (r"ibuprofen", r"布洛芬"),
    "acetaminophen": (r"acetaminophen", r"paracetamol", r"对乙酰氨基酚"),
    "chlorhexidine": (r"chlorhexidine", r"氯己定"),
    "cephalosporin": (r"cephalospor", r"头孢"),
    "clindamycin": (r"clindamycin", r"克林霉素"),
    "articaine": (r"articaine", r"阿替卡因"),
    "lidocaine": (r"lidocaine", r"利多卡因"),
}


def _match(text: str, mapping: dict[str, tuple[str, ...]]) -> set[str]:
    return {
        label
        for label, patterns in mapping.items()
        if any(re.search(pattern, text, flags=re.IGNORECASE) for pattern in patterns)
    }


def extract_diagnosis_codes(text: str) -> set[str]:
    return {value.upper() for value in re.findall(r"\b([A-Z]\d{2}(?:\.\d{1,4})?)\b", clean_text(text), flags=re.I)}


def extract_teeth(text: str) -> set[str]:
    text = clean_text(text)
    found: set[str] = set()
    patterns = (
        r"(?:tooth|teeth|#|牙位|牙|齿)\s*[*#:]?\s*([1-8][1-8])\b",
        r"[*#]\s*([1-8][1-8])\b",
        r"\b([1-8][1-8])\s*(?:tooth|teeth|牙|齿)\b",
        r"(?:^|[;,.])\s*([1-8][1-8])(?=\s|[;,.])",
    )
    for pattern in patterns:
        for value in re.findall(pattern, text, flags=re.I):
            if value in FDI_TEETH:
                found.add(value)
    return found


def extract_entities(record: dict[str, str]) -> dict[str, set[str]]:
    diagnostic_text = " ".join(clean_text(record.get(field, "")) for field in ("Main appeal", "Oral Check", "Diagnosis"))
    treatment_text = " ".join(clean_text(record.get(field, "")) for field in ("Treatment plan", "Handle", "Doctor advices"))
    tooth_text = " ".join(clean_text(record.get(field, "")) for field in ("Main appeal", "Oral Check", "Diagnosis", "Treatment plan"))
    all_text = " ".join(clean_text(record.get(field, "")) for field in FIELDS)
    return {
        "teeth": extract_teeth(tooth_text),
        "diagnoses": _match(diagnostic_text, DIAGNOSIS_PATTERNS),
        "diagnosis_codes": extract_diagnosis_codes(clean_text(record.get("Diagnosis", ""))),
        "treatments": _match(treatment_text, TREATMENT_PATTERNS),
        "medications": _match(all_text, MEDICATION_PATTERNS),
    }


@dataclass
class EntityVocabulary:
    teeth: list[str]
    diagnoses: list[str]
    diagnosis_codes: list[str]
    treatments: list[str]
    medications: list[str]

    @classmethod
    def fit(
        cls,
        records: Iterable[dict[str, str]],
        max_diagnoses: int = 64,
        max_diagnosis_codes: int = 64,
        max_treatments: int = 48,
        max_medications: int = 32,
    ) -> "EntityVocabulary":
        counters = {name: Counter() for name in ENTITY_NAMES if name != "teeth"}
        for record in records:
            entities = extract_entities(record)
            for name in counters:
                counters[name].update(entities[name])
        return cls(
            teeth=list(FDI_TEETH),
            diagnoses=[name for name, _ in counters["diagnoses"].most_common(max_diagnoses)],
            diagnosis_codes=[name for name, _ in counters["diagnosis_codes"].most_common(max_diagnosis_codes)],
            treatments=[name for name, _ in counters["treatments"].most_common(max_treatments)],
            medications=[name for name, _ in counters["medications"].most_common(max_medications)],
        )

    def to_dict(self) -> dict[str, list[str]]:
        return {name: list(getattr(self, name)) for name in ENTITY_NAMES}

    @classmethod
    def from_dict(cls, value: dict[str, list[str]]) -> "EntityVocabulary":
        return cls(**{name: list(value.get(name, [])) for name in ENTITY_NAMES})

    def encode(self, record: dict[str, str]) -> dict[str, np.ndarray]:
        entities = extract_entities(record)
        return {
            name: np.asarray([float(label in entities[name]) for label in getattr(self, name)], dtype=np.float32)
            for name in ENTITY_NAMES
        }

    def decode(
        self,
        probabilities: dict[str, np.ndarray],
        thresholds: dict[str, float],
        max_entities: dict[str, int] | None = None,
        label_thresholds: dict[str, dict[str, float]] | None = None,
        use_cardinality: bool = False,
        cardinality_confidence: float = 0.35,
    ) -> dict[str, list[str]]:
        return self.decode_with_details(
            probabilities,
            thresholds,
            max_entities,
            label_thresholds,
            use_cardinality,
            cardinality_confidence,
        )[0]

    def decode_with_details(
        self,
        probabilities: dict[str, np.ndarray],
        thresholds: dict[str, float],
        max_entities: dict[str, int] | None = None,
        label_thresholds: dict[str, dict[str, float]] | None = None,
        use_cardinality: bool = False,
        cardinality_confidence: float = 0.35,
    ) -> tuple[dict[str, list[str]], dict]:
        max_entities = max_entities or {}
        label_thresholds = label_thresholds or {}
        output: dict[str, list[str]] = {}
        details: dict[str, dict] = {}
        for name in ENTITY_NAMES:
            labels = getattr(self, name)
            scores = np.asarray(probabilities.get(name, []), dtype=np.float32)
            threshold = float(thresholds.get(name, 0.5))
            count_values = np.asarray(probabilities.get(f"{name}__count", []), dtype=np.float32)
            # ``max_entities`` is a soft prior in V5.  Labels with very high
            # confidence are allowed to exceed it, avoiding the recall loss
            # observed with an earlier hard-cardinality decoder.
            soft_limit = max(0, int(max_entities.get(name, len(labels))))
            predicted_count, count_confidence = soft_limit, 0.0
            if count_values.size:
                predicted_count = int(np.argmax(count_values))
                count_confidence = float(count_values[predicted_count])
            dynamic_limit = soft_limit
            if use_cardinality and count_values.size and count_confidence >= float(cardinality_confidence):
                dynamic_limit = min(soft_limit, predicted_count)
            ranked = sorted(
                (
                    (index, float(score))
                    for index, score in enumerate(scores)
                    if float(score) >= float(label_thresholds.get(name, {}).get(labels[index], threshold))
                ),
                key=lambda pair: pair[1],
                reverse=True,
            )
            if not use_cardinality and ranked:
                strong_floor = max(0.80, threshold + 0.20)
                strong_count = sum(score >= strong_floor for _, score in ranked)
                dynamic_limit = max(dynamic_limit, strong_count)
            ranked = ranked[:dynamic_limit]
            if not ranked and labels and scores.size and float(scores.max()) >= threshold * 0.90 and dynamic_limit > 0:
                ranked = [(int(scores.argmax()), float(scores.max()))]
            output[name] = [labels[index] for index, _ in ranked]
            details[name] = {
                "family_threshold": threshold,
                "soft_limit": soft_limit,
                "predicted_count": predicted_count,
                "count_confidence": count_confidence,
                "applied_limit": dynamic_limit,
                "selected": [{"label": labels[index], "probability": score} for index, score in ranked],
            }
        return output, details

    def decode_ensemble(
        self,
        member_probabilities: list[dict[str, np.ndarray]],
        thresholds: dict[str, float],
        max_entities: dict[str, int] | None = None,
        vote_fraction: float = 0.50,
        label_thresholds: dict[str, dict[str, float]] | None = None,
        use_cardinality: bool = False,
        cardinality_confidence: float = 0.35,
    ) -> dict[str, list[str]]:
        """Vote after per-model calibration instead of averaging away confidence."""
        return self.decode_ensemble_with_details(
            member_probabilities,
            thresholds,
            max_entities,
            vote_fraction,
            label_thresholds,
            use_cardinality,
            cardinality_confidence,
        )[0]

    def decode_ensemble_with_details(
        self,
        member_probabilities: list[dict[str, np.ndarray]],
        thresholds: dict[str, float],
        max_entities: dict[str, int] | None = None,
        vote_fraction: float = 0.50,
        label_thresholds: dict[str, dict[str, float]] | None = None,
        use_cardinality: bool = False,
        cardinality_confidence: float = 0.35,
    ) -> tuple[dict[str, list[str]], dict]:
        if not member_probabilities:
            return {name: [] for name in ENTITY_NAMES}, {}
        max_entities = max_entities or {}
        label_thresholds = label_thresholds or {}
        output: dict[str, list[str]] = {}
        details: dict[str, dict] = {}
        for name in ENTITY_NAMES:
            labels = getattr(self, name)
            values = np.stack([np.asarray(member.get(name, []), dtype=np.float32) for member in member_probabilities])
            if not labels or not values.size:
                output[name] = []
                details[name] = {"selected": [], "member_disagreement": 0.0}
                continue
            threshold = float(thresholds.get(name, 0.5))
            thresholds_by_label = np.asarray(
                [float(label_thresholds.get(name, {}).get(label, threshold)) for label in labels], dtype=np.float32
            )
            votes = (values >= thresholds_by_label[None, :]).mean(axis=0)
            confidence = values.mean(axis=0)
            ranked = [
                int(index) for index in np.argsort(-(votes + 0.05 * confidence))
                if float(votes[index]) >= float(vote_fraction)
            ]
            soft_limit = max(0, int(max_entities.get(name, len(labels))))
            count_members = [np.asarray(member.get(f"{name}__count", []), dtype=np.float32) for member in member_probabilities]
            count_members = [value for value in count_members if value.size]
            predicted_count, count_confidence = soft_limit, 0.0
            if count_members:
                count_values = np.mean(np.stack(count_members), axis=0)
                predicted_count = int(np.argmax(count_values))
                count_confidence = float(count_values[predicted_count])
            limit = soft_limit
            if use_cardinality and count_members and count_confidence >= float(cardinality_confidence):
                limit = min(soft_limit, predicted_count)
            elif ranked:
                strong_floor = max(0.80, threshold + 0.20)
                strong_count = sum(
                    float(votes[index]) >= max(0.80, float(vote_fraction))
                    and float(confidence[index]) >= strong_floor
                    for index in ranked
                )
                limit = max(limit, strong_count)
            selected = ranked[:limit]
            output[name] = [labels[index] for index in selected]
            details[name] = {
                "family_threshold": threshold,
                "soft_limit": soft_limit,
                "predicted_count": predicted_count,
                "count_confidence": count_confidence,
                "applied_limit": limit,
                "member_disagreement": float(values.std(axis=0).mean()),
                "selected": [
                    {"label": labels[index], "probability": float(confidence[index]), "vote_fraction": float(votes[index])}
                    for index in selected
                ],
            }
        return output, details

    def combined_vector(self, record: dict[str, str]) -> np.ndarray:
        encoded = self.encode(record)
        values = [encoded[name] for name in ENTITY_NAMES]
        return np.concatenate(values).astype(np.float32) if values else np.zeros(0, dtype=np.float32)
