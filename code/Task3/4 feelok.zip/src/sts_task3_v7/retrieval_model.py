from __future__ import annotations

from collections import Counter
from dataclasses import dataclass

import numpy as np
from sklearn.decomposition import PCA, TruncatedSVD
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler, normalize

from .constants import EMPTY_FALLBACKS, FIELD_GROUPS, FIELDS
from .feature_store import FeatureStore, descriptor_matrix
from .records import clean_text


def _l2(values: np.ndarray) -> np.ndarray:
    values = np.asarray(values, dtype=np.float32)
    return values / np.maximum(np.linalg.norm(values, axis=1, keepdims=True), 1e-8)


def _record_text(record: dict[str, str], fields: tuple[str, ...] = FIELDS) -> str:
    return " ".join(f"[{field}] {clean_text(record.get(field, ''))}" for field in fields)


def _group_for_field(field: str) -> str:
    for group, fields in FIELD_GROUPS.items():
        if field in fields:
            return group
    raise KeyError(field)


def _target_key(field: str, target_kind: str) -> str:
    if target_kind == "field":
        return f"field::{field}"
    if target_kind == "group":
        return f"group::{_group_for_field(field)}"
    if target_kind == "record":
        return "record"
    raise ValueError(target_kind)


def _target_text(record: dict[str, str], key: str) -> str:
    if key == "record":
        return _record_text(record)
    kind, value = key.split("::", 1)
    if kind == "field":
        return clean_text(record.get(value, ""))
    if kind == "group":
        return _record_text(record, FIELD_GROUPS[value])
    raise ValueError(key)


@dataclass
class DescriptorSpace:
    scaler: StandardScaler
    pca: PCA
    raw_train: np.ndarray
    pca_train: np.ndarray

    @classmethod
    def fit(cls, matrix: np.ndarray, pca_dim: int, whiten: bool, seed: int) -> "DescriptorSpace":
        raw = _l2(matrix)
        scaler = StandardScaler().fit(matrix)
        scaled = scaler.transform(matrix)
        components = max(1, min(int(pca_dim), len(matrix) - 1, matrix.shape[1]))
        pca = PCA(n_components=components, whiten=bool(whiten), random_state=seed).fit(scaled)
        reduced = _l2(pca.transform(scaled))
        return cls(scaler, pca, raw, reduced)

    def transform(self, matrix: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        return _l2(matrix), _l2(self.pca.transform(self.scaler.transform(matrix)))


@dataclass
class TextSpace:
    vectorizer: TfidfVectorizer
    svd: TruncatedSVD | None
    train_targets: np.ndarray

    @classmethod
    def fit(cls, texts: list[str], config: dict, seed: int) -> "TextSpace":
        safe = [text if clean_text(text) else "[EMPTY]" for text in texts]
        vectorizer = TfidfVectorizer(
            analyzer="char_wb",
            ngram_range=(int(config.get("ngram_min", 2)), int(config.get("ngram_max", 5))),
            min_df=1,
            max_features=int(config.get("max_features", 10000)),
            sublinear_tf=True,
            lowercase=True,
        )
        matrix = vectorizer.fit_transform(safe)
        components = min(int(config.get("svd_dim", 48)), len(texts) - 1, matrix.shape[1] - 1)
        if components >= 2:
            svd = TruncatedSVD(n_components=components, random_state=seed).fit(matrix)
            targets = svd.transform(matrix)
        else:
            svd = None
            targets = matrix.toarray()
        return cls(vectorizer, svd, normalize(targets, norm="l2").astype(np.float32))


@dataclass
class SemanticMap:
    ridge: Ridge

    @classmethod
    def fit(cls, x: np.ndarray, y: np.ndarray, alpha: float) -> "SemanticMap":
        ridge = Ridge(alpha=float(alpha), solver="lsqr")
        ridge.fit(x, y)
        return cls(ridge)

    def predict(self, x: np.ndarray) -> np.ndarray:
        return _l2(np.asarray(self.ridge.predict(x), dtype=np.float32))


def _select_text(
    records: list[dict[str, str]],
    indices: np.ndarray,
    scores: np.ndarray,
    field: str,
    strategy: str,
    temperature: float,
) -> str:
    if not len(indices):
        return EMPTY_FALLBACKS[field]
    values = [clean_text(records[int(index)].get(field, "")) for index in indices]
    if strategy == "nearest":
        return values[0] or EMPTY_FALLBACKS[field]
    if strategy == "longest":
        ranked = sorted(
            zip(values, scores),
            key=lambda pair: (bool(pair[0]), len(pair[0]), float(pair[1])),
            reverse=True,
        )
        return ranked[0][0] or EMPTY_FALLBACKS[field]
    if strategy == "vote":
        shifted = scores - float(np.max(scores))
        weights = np.exp(shifted / max(float(temperature), 1e-4))
        votes: dict[str, float] = {}
        originals: dict[str, str] = {}
        for rank, (value, weight) in enumerate(zip(values, weights)):
            if not value:
                continue
            key = " ".join(value.casefold().split())
            votes[key] = votes.get(key, 0.0) + float(weight) / (1.0 + 0.05 * rank)
            originals.setdefault(key, value)
        return originals[max(votes, key=votes.get)] if votes else EMPTY_FALLBACKS[field]
    raise ValueError(strategy)


class ValidationGuidedRetriever:
    """Field-specific global/local descriptor retrieval with supervised text alignment."""

    def __init__(self, config: dict) -> None:
        self.config = config
        self.case_ids: list[str] = []
        self.records: list[dict[str, str]] = []
        self.source_by_case: dict[str, str] = {}
        self.descriptor_spaces: dict[str, DescriptorSpace] = {}
        self.text_spaces: dict[str, TextSpace] = {}
        self.semantic_maps: dict[tuple[str, str, str, float], SemanticMap] = {}
        self.scope_indices: dict[str, np.ndarray] = {}

    def fit(
        self,
        records: dict[str, dict[str, str]],
        source_by_case: dict[str, str],
        store: FeatureStore,
    ) -> "ValidationGuidedRetriever":
        self.case_ids = sorted(records, key=lambda value: (len(value), value))
        self.records = [dict(records[case_id]) for case_id in self.case_ids]
        self.source_by_case = dict(source_by_case)
        sources = np.asarray([source_by_case[case_id] for case_id in self.case_ids])
        self.scope_indices = {
            "combined": np.arange(len(self.case_ids), dtype=np.int64),
            "primary": np.flatnonzero(sources == "primary"),
            "weak": np.flatnonzero(sources == "weak"),
        }
        descriptor_config = self.config["descriptors"]
        seed = int(self.config.get("seed", 20260722))
        for offset, name in enumerate(descriptor_config["names"]):
            matrix = descriptor_matrix(
                store, self.case_ids, name, int(descriptor_config.get("pyramid_bins", 4))
            )
            self.descriptor_spaces[name] = DescriptorSpace.fit(
                matrix,
                int(descriptor_config.get("pca_dim", 64)),
                bool(descriptor_config.get("pca_whiten", True)),
                seed + offset,
            )
        target_keys = ["record"]
        target_keys.extend(f"field::{field}" for field in FIELDS)
        target_keys.extend(f"group::{group}" for group in FIELD_GROUPS)
        semantic_config = self.config["semantic"]
        for offset, key in enumerate(target_keys):
            texts = [_target_text(record, key) for record in self.records]
            self.text_spaces[key] = TextSpace.fit(texts, semantic_config, seed + 100 + offset)
        for key, text_space in self.text_spaces.items():
            for descriptor_name, descriptor in self.descriptor_spaces.items():
                for fit_scope in semantic_config.get("fit_scopes", ["combined"]):
                    indices = self.scope_indices[str(fit_scope)]
                    for alpha in semantic_config.get("ridge_alphas", [10.0]):
                        self.semantic_maps[(key, descriptor_name, str(fit_scope), float(alpha))] = SemanticMap.fit(
                            descriptor.pca_train[indices], text_space.train_targets[indices], float(alpha)
                        )
        return self

    def _static_candidates(self, field: str, reference_scope: str) -> dict[str, str]:
        indices = self.scope_indices[reference_scope]
        values = [clean_text(self.records[int(index)].get(field, "")) for index in indices]
        nonempty = [value for value in values if value]
        if not nonempty:
            return {
                f"static.mode.ref={reference_scope}": EMPTY_FALLBACKS[field],
                f"static.longest.ref={reference_scope}": EMPTY_FALLBACKS[field],
                f"static.medoid.ref={reference_scope}": EMPTY_FALLBACKS[field],
            }
        normalized = [" ".join(value.casefold().split()) for value in nonempty]
        mode_key = Counter(normalized).most_common(1)[0][0]
        mode = nonempty[normalized.index(mode_key)]
        longest = max(nonempty, key=len)
        key = _target_key(field, "field")
        targets = self.text_spaces[key].train_targets[indices]
        centroid = _l2(targets.mean(axis=0, keepdims=True))[0]
        medoid_index = int(indices[int(np.argmax(targets @ centroid))])
        medoid = clean_text(self.records[medoid_index].get(field, "")) or EMPTY_FALLBACKS[field]
        return {
            f"static.mode.ref={reference_scope}": mode,
            f"static.longest.ref={reference_scope}": longest,
            f"static.medoid.ref={reference_scope}": medoid,
        }

    def generate_candidates(
        self,
        query_case_ids: list[str],
        store: FeatureStore,
    ) -> dict[str, dict[str, dict[str, str]]]:
        descriptor_config = self.config["descriptors"]
        query_views: dict[str, tuple[np.ndarray, np.ndarray]] = {}
        for name, space in self.descriptor_spaces.items():
            matrix = descriptor_matrix(
                store, query_case_ids, name, int(descriptor_config.get("pyramid_bins", 4))
            )
            query_views[name] = space.transform(matrix)
        result: dict[str, dict[str, dict[str, str]]] = {field: {} for field in FIELDS}
        retrieval = self.config["retrieval"]
        reference_scopes = [str(value) for value in retrieval.get("reference_scopes", ["combined"])]
        top_values = [int(value) for value in retrieval.get("top_k", [1, 3, 5])]
        strategies = [str(value) for value in retrieval.get("strategies", ["nearest"])]
        semantic_weights = [float(value) for value in retrieval.get("semantic_weights", [0.0, 1.0])]
        temperature = float(retrieval.get("temperature", 0.10))
        alphas = [float(value) for value in self.config["semantic"].get("ridge_alphas", [10.0])]
        fit_scopes = [str(value) for value in self.config["semantic"].get("fit_scopes", ["combined"])]
        for field in FIELDS:
            for reference_scope in reference_scopes:
                for candidate_name, value in self._static_candidates(field, reference_scope).items():
                    result[field][candidate_name] = {case_id: value for case_id in query_case_ids}
            for descriptor_name, descriptor in self.descriptor_spaces.items():
                query_raw, query_pca = query_views[descriptor_name]
                all_visual_scores = {
                    "raw": query_raw @ descriptor.raw_train.T,
                    "pca": query_pca @ descriptor.pca_train.T,
                }
                visual_scores_by_space = {
                    name: all_visual_scores[name]
                    for name in retrieval.get("visual_spaces", ["raw"])
                }
                for target_kind in ("field", "group", "record"):
                    target_key = _target_key(field, target_kind)
                    text_targets = self.text_spaces[target_key].train_targets
                    for fit_scope in fit_scopes:
                        for alpha in alphas:
                            semantic_query = self.semantic_maps[
                                (target_key, descriptor_name, fit_scope, alpha)
                            ].predict(query_pca)
                            semantic_scores = semantic_query @ text_targets.T
                            for visual_space, visual_scores in visual_scores_by_space.items():
                                for semantic_weight in semantic_weights:
                                    if semantic_weight == 0.0 and (
                                        target_kind != "field" or fit_scope != fit_scopes[0] or alpha != alphas[0]
                                    ):
                                        continue
                                    scores_all = (
                                        (1.0 - semantic_weight) * visual_scores
                                        + semantic_weight * semantic_scores
                                    )
                                    for reference_scope in reference_scopes:
                                        reference_indices = self.scope_indices[reference_scope]
                                        scoped_scores = scores_all[:, reference_indices]
                                        for top_k in top_values:
                                            count = max(1, min(top_k, len(reference_indices)))
                                            order = np.argsort(-scoped_scores, axis=1)[:, :count]
                                            chosen_indices = reference_indices[order]
                                            chosen_scores = np.take_along_axis(scoped_scores, order, axis=1)
                                            for strategy in strategies:
                                                name = (
                                                    f"retrieval.desc={descriptor_name}.{visual_space}"
                                                    f".target={target_kind}.fit={fit_scope}.alpha={alpha:g}"
                                                    f".sw={semantic_weight:g}.ref={reference_scope}"
                                                    f".k={count}.strategy={strategy}"
                                                )
                                                predictions: dict[str, str] = {}
                                                for row, case_id in enumerate(query_case_ids):
                                                    predictions[case_id] = _select_text(
                                                        self.records,
                                                        chosen_indices[row],
                                                        chosen_scores[row],
                                                        field,
                                                        strategy,
                                                        temperature,
                                                    )
                                                result[field][name] = predictions
        return result
