from __future__ import annotations

import json
from pathlib import Path
from time import perf_counter
from typing import Iterable

import numpy as np
import torch
from tqdm import tqdm

from .cbct import volume_to_slices
from .encoder import build_slice_encoder, encode_slices
from .io import CaseItem


def cache_path(cache_dir: str | Path, split: str, case_id: str) -> Path:
    return Path(cache_dir) / split / f"{case_id}.npz"


def cache_case(
    item: CaseItem,
    cache_dir: str | Path,
    encoder: torch.nn.Module,
    device: torch.device,
    preprocess_config: dict,
    encoder_config: dict,
    overwrite: bool = False,
) -> Path:
    output = cache_path(cache_dir, item.split, item.case_id)
    if output.exists() and not overwrite:
        return output
    slices = volume_to_slices(item.image_path, preprocess_config)
    features = encode_slices(
        encoder,
        slices.images,
        device=device,
        batch_size=int(encoder_config.get("batch_size", 48)),
        amp=bool(encoder_config.get("amp", True)),
    )
    output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        output,
        features=features.numpy().astype(np.float16),
        plane_ids=slices.plane_ids.numpy().astype(np.int8),
        positions=slices.positions.numpy().astype(np.float32),
        case_id=np.asarray(item.case_id),
    )
    return output


def cache_all(
    items: Iterable[CaseItem],
    cache_dir: str | Path,
    preprocess_config: dict,
    encoder_config: dict,
    device: str | torch.device | None = None,
    overwrite: bool = False,
    encoder_state: dict[str, torch.Tensor] | None = None,
) -> dict:
    items = list(items)
    if not items:
        raise ValueError("No cases provided for feature caching")
    selected_device = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))
    encoder, output_dim = build_slice_encoder(encoder_config, load_checkpoint=encoder_state is None)
    if encoder_state is not None:
        encoder.load_state_dict(encoder_state, strict=True)
    encoder.to(selected_device)
    total_started = perf_counter()
    encoded_count = 0
    reused_count = 0
    encoded_durations: list[float] = []
    progress = tqdm(items, desc="Caching CBCT slice features")
    for item in progress:
        progress.set_postfix_str(f"case={item.case_id}", refresh=True)
        started = perf_counter()
        output_path = cache_path(cache_dir, item.split, item.case_id)
        reused = bool(output_path.exists() and not overwrite)
        cache_case(
            item,
            cache_dir=cache_dir,
            encoder=encoder,
            device=selected_device,
            preprocess_config=preprocess_config,
            encoder_config=encoder_config,
            overwrite=overwrite,
        )
        duration = perf_counter() - started
        if reused:
            reused_count += 1
        else:
            encoded_count += 1
            encoded_durations.append(duration)
        status = "reused" if reused else f"last={duration:.1f}s"
        progress.set_postfix_str(f"case={item.case_id}, {status}", refresh=False)
    cache_dir = Path(cache_dir)
    cache_dir.mkdir(parents=True, exist_ok=True)
    torch.save({"state_dict": encoder.cpu().state_dict(), "output_dim": output_dim}, cache_dir / "encoder.pt")
    manifest = {
        "num_cases": len(items),
        "num_encoded": encoded_count,
        "num_reused": reused_count,
        "output_dim": output_dim,
        "backbone": encoder_config.get("backbone", "resnet18"),
        "preprocess": preprocess_config,
        "splits": sorted({item.split for item in items}),
        "timing": {
            "total_seconds": float(perf_counter() - total_started),
            "mean_encoded_case_seconds": float(np.mean(encoded_durations)) if encoded_durations else 0.0,
            "max_encoded_case_seconds": float(max(encoded_durations, default=0.0)),
        },
    }
    with (cache_dir / "manifest.json").open("w", encoding="utf-8") as handle:
        json.dump(manifest, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
    return manifest


def load_cached_case(path: str | Path) -> dict[str, torch.Tensor | str]:
    with np.load(path, allow_pickle=False) as data:
        return {
            "case_id": str(data["case_id"].item()),
            "features": torch.from_numpy(data["features"].astype(np.float32)),
            "plane_ids": torch.from_numpy(data["plane_ids"].astype(np.int64)),
            "positions": torch.from_numpy(data["positions"].astype(np.float32)),
        }
