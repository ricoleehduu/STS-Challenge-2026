"""STS 2026 Task 3: validation-guided multimodal retrieval."""

__version__ = "7.0.0"
