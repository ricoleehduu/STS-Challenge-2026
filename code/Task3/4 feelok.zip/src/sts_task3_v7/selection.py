from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .constants import EMPTY_FALLBACKS, FIELDS
from .metrics import evaluate_case
from .records import clean_text


def _sanitize(value: object, field: str, max_chars: int) -> str:
    text = clean_text(value) or EMPTY_FALLBACKS[field]
    if len(text) <= max_chars:
        return text
    shortened = text[:max_chars].rsplit(" ", 1)[0].rstrip(" ,;:")
    return shortened + ("" if shortened.endswith((".", "!", "?")) else ".")


def assemble_predictions(
    candidates: dict[str, dict[str, dict[str, str]]],
    policy: dict[str, str],
    case_ids: list[str],
    max_chars: int = 600,
) -> dict[str, dict[str, str]]:
    output: dict[str, dict[str, str]] = {}
    for case_id in case_ids:
        record: dict[str, str] = {}
        for field in FIELDS:
            source = policy[field]
            try:
                value = candidates[field][source][case_id]
            except KeyError as exc:
                raise KeyError(f"Policy source {source!r} is unavailable for {case_id}/{field}") from exc
            record[field] = _sanitize(value, field, max_chars)
        output[case_id] = record
    return output


def add_external_predictions(
    candidates: dict[str, dict[str, dict[str, str]]],
    name: str,
    predictions: dict[str, dict[str, str]],
    case_ids: list[str],
) -> None:
    missing = sorted(set(case_ids) - set(predictions))
    if missing:
        raise ValueError(f"External prediction source {name!r} misses cases {missing[:10]}")
    source = f"external::{name}"
    for field in FIELDS:
        candidates[field][source] = {
            case_id: clean_text(predictions[case_id].get(field, "")) for case_id in case_ids
        }


@dataclass
class SelectionResult:
    policy: dict[str, str]
    predictions: dict[str, dict[str, str]]
    evaluation: dict
    report: dict


def _proxy(evaluation: dict) -> float:
    return float(evaluation.get("metrics_mean", {}).get("weighted_proxy", 0.0))


class _EvaluationCache:
    def __init__(self, references: dict[str, dict[str, str]], weights: dict | None) -> None:
        self.references = references
        self.weights = weights
        self.case_cache: dict[tuple[str, tuple[str, ...]], dict[str, float]] = {}

    def evaluate(self, predictions: dict[str, dict[str, str]]) -> dict:
        cases: dict[str, dict[str, float]] = {}
        for case_id, reference in self.references.items():
            record = predictions.get(case_id)
            if record is None:
                continue
            signature = tuple(record.get(field, "") for field in FIELDS)
            key = (case_id, signature)
            metrics = self.case_cache.get(key)
            if metrics is None:
                metrics = evaluate_case(record, reference, self.weights)
                self.case_cache[key] = metrics
            cases[case_id] = metrics
        names = sorted({name for values in cases.values() for name in values})
        mean = {
            name: float(np.mean([values[name] for values in cases.values()])) if cases else 0.0
            for name in names
        }
        return {
            "num_cases": len(self.references),
            "num_evaluated": len(cases),
            "num_missing_predictions": len(set(self.references) - set(predictions)),
            "metrics_mean": mean,
            "case_results": cases,
        }


def _deduplicated_sources(
    field_candidates: dict[str, dict[str, str]], case_ids: list[str]
) -> tuple[list[str], int]:
    unique: dict[tuple[str, ...], str] = {}
    for source in sorted(field_candidates):
        signature = tuple(clean_text(field_candidates[source].get(case_id, "")) for case_id in case_ids)
        unique.setdefault(signature, source)
    return list(unique.values()), len(field_candidates) - len(unique)


def select_policy(
    candidates: dict[str, dict[str, dict[str, str]]],
    references: dict[str, dict[str, str]],
    config: dict,
) -> SelectionResult:
    case_ids = sorted(references, key=lambda value: (len(value), value))
    weights = config.get("evaluation", {}).get("weights")
    evaluator = _EvaluationCache(references, weights)
    max_chars = int(config.get("retrieval", {}).get("max_field_chars", 600))
    selection_config = config.get("selection", {})
    common = set(candidates[FIELDS[0]])
    for field in FIELDS[1:]:
        common &= set(candidates[field])
    if not common:
        raise ValueError("Candidate generator produced no source common to all seven fields")
    uniform_rows = []
    uniform_signatures: set[tuple[str, ...]] = set()
    uniform_duplicates = 0
    best_policy: dict[str, str] | None = None
    best_predictions: dict[str, dict[str, str]] | None = None
    best_evaluation: dict | None = None
    for source in sorted(common):
        policy = {field: source for field in FIELDS}
        predictions = assemble_predictions(candidates, policy, case_ids, max_chars)
        signature = tuple(
            predictions[case_id][field] for case_id in case_ids for field in FIELDS
        )
        if signature in uniform_signatures:
            uniform_duplicates += 1
            continue
        uniform_signatures.add(signature)
        evaluation = evaluator.evaluate(predictions)
        score = _proxy(evaluation)
        uniform_rows.append({"source": source, "weighted_proxy": score})
        if best_evaluation is None or score > _proxy(best_evaluation):
            best_policy, best_predictions, best_evaluation = policy, predictions, evaluation
    assert best_policy is not None and best_predictions is not None and best_evaluation is not None
    seed_rows = []
    for seed_index, configured in enumerate(selection_config.get("seed_policies", [])):
        if not isinstance(configured, dict) or set(configured) != set(FIELDS):
            raise ValueError(f"selection.seed_policies[{seed_index}] must map exactly the seven fields")
        policy = {field: str(configured[field]) for field in FIELDS}
        unavailable = [field for field in FIELDS if policy[field] not in candidates[field]]
        if unavailable:
            raise ValueError(
                f"selection.seed_policies[{seed_index}] uses unavailable sources for {unavailable}"
            )
        predictions = assemble_predictions(candidates, policy, case_ids, max_chars)
        evaluation = evaluator.evaluate(predictions)
        seed_rows.append({
            "seed_index": seed_index,
            "weighted_proxy": _proxy(evaluation),
            "policy": policy,
        })
        if _proxy(evaluation) > _proxy(best_evaluation):
            best_policy, best_predictions, best_evaluation = policy, predictions, evaluation
    max_candidates = max(1, int(selection_config.get("max_candidates_per_field", 48)))
    shortlist: dict[str, list[dict]] = {}
    deduplication: dict[str, dict[str, int]] = {}
    for field in FIELDS:
        rows = []
        sources, removed = _deduplicated_sources(candidates[field], case_ids)
        deduplication[field] = {
            "before": len(candidates[field]),
            "after": len(sources),
            "removed": removed,
        }
        for source in sources:
            policy = dict(best_policy)
            policy[field] = source
            predictions = assemble_predictions(candidates, policy, case_ids, max_chars)
            evaluation = evaluator.evaluate(predictions)
            rows.append({"source": source, "weighted_proxy": _proxy(evaluation)})
        rows.sort(key=lambda row: (-row["weighted_proxy"], row["source"]))
        selected = rows[:max_candidates]
        if best_policy[field] not in {row["source"] for row in selected}:
            selected.append({"source": best_policy[field], "weighted_proxy": _proxy(best_evaluation)})
        shortlist[field] = selected
    trace = [{"stage": "best_uniform", "weighted_proxy": _proxy(best_evaluation), "policy": dict(best_policy)}]
    minimum_gain = float(selection_config.get("minimum_gain", 1e-10))
    for pass_index in range(max(1, int(selection_config.get("coordinate_passes", 3)))):
        changed = False
        for field in FIELDS:
            field_best_source = best_policy[field]
            field_best_predictions = best_predictions
            field_best_evaluation = best_evaluation
            for row in shortlist[field]:
                policy = dict(best_policy)
                policy[field] = row["source"]
                predictions = assemble_predictions(candidates, policy, case_ids, max_chars)
                evaluation = evaluator.evaluate(predictions)
                if _proxy(evaluation) > _proxy(field_best_evaluation) + minimum_gain:
                    field_best_source = row["source"]
                    field_best_predictions = predictions
                    field_best_evaluation = evaluation
            if field_best_source != best_policy[field]:
                best_policy[field] = field_best_source
                best_predictions = field_best_predictions
                best_evaluation = field_best_evaluation
                changed = True
                trace.append({
                    "stage": "coordinate_update",
                    "pass": pass_index + 1,
                    "field": field,
                    "source": field_best_source,
                    "weighted_proxy": _proxy(best_evaluation),
                })
        if not changed:
            break
    report = {
        "selection_uses_validation_labels": True,
        "selection_scope": "global field policy; no case-level oracle and no ground-truth text is copied",
        "num_candidates_by_field": {field: len(candidates[field]) for field in FIELDS},
        "candidate_deduplication": deduplication,
        "cached_case_metric_entries": len(evaluator.case_cache),
        "uniform_leaderboard": sorted(
            uniform_rows, key=lambda row: (-row["weighted_proxy"], row["source"])
        )[:50],
        "configured_seed_policies": seed_rows,
        "uniform_candidate_deduplication": {
            "before": len(common),
            "after": len(uniform_signatures),
            "removed": uniform_duplicates,
        },
        "shortlist": shortlist,
        "trace": trace,
        "selected_policy": dict(best_policy),
        "selected_weighted_proxy": _proxy(best_evaluation),
    }
    return SelectionResult(best_policy, best_predictions, best_evaluation, report)
