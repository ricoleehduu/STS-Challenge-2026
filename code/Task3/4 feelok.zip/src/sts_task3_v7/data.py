from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

from .io import canonical_case_id
from .records import load_records


@dataclass(frozen=True)
class TaskData:
    primary_records: dict[str, dict[str, str]]
    weak_records: dict[str, dict[str, str]]
    validation_records: dict[str, dict[str, str]]
    validation_case_ids: list[str]
    manifest: dict

    @property
    def train_records(self) -> dict[str, dict[str, str]]:
        overlap = set(self.primary_records) & set(self.weak_records)
        if overlap:
            raise ValueError(f"Primary and weak records overlap: {sorted(overlap)[:10]}")
        return {**self.primary_records, **self.weak_records}

    @property
    def source_by_case(self) -> dict[str, str]:
        return {
            **{case_id: "primary" for case_id in self.primary_records},
            **{case_id: "weak" for case_id in self.weak_records},
        }


def _validation_ids(manifest: dict) -> list[str]:
    values = manifest.get("splits", {}).get("simulated_validation", {}).get("case_ids", [])
    return [canonical_case_id(value) for value in values]


def load_simulation(simulation_root: str | Path, expose_validation_labels: bool = True) -> TaskData:
    root = Path(simulation_root)
    manifest_path = root / "split_manifest.json"
    with manifest_path.open("r", encoding="utf-8") as handle:
        manifest = json.load(handle)
    primary = load_records(root / "dataset_view" / "Train-Labeled" / "Train-Labeled.csv")
    weak = load_records(root / "simulated_unlabeled_records.csv")
    validation = (
        load_records(root / "evaluation" / "simulated_validation_ground_truth.csv")
        if expose_validation_labels
        else {}
    )
    validation_ids = _validation_ids(manifest)
    if len(primary) != 50:
        raise ValueError(f"Expected 50 primary records, got {len(primary)}")
    if len(weak) != 150:
        raise ValueError(f"Expected 150 weak records, got {len(weak)}")
    if len(validation_ids) != 50:
        raise ValueError(f"Expected 50 simulated validation IDs, got {len(validation_ids)}")
    if validation and set(validation) != set(validation_ids):
        raise ValueError("Validation ground-truth IDs do not match split_manifest.json")
    if set(primary) & set(validation_ids) or set(weak) & set(validation_ids):
        raise ValueError("Validation cases leak into supervised training records")
    return TaskData(primary, weak, validation, validation_ids, manifest)
