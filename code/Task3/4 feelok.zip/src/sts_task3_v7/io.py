from __future__ import annotations

import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable


def canonical_case_id(value: object) -> str:
    text = str(value).strip().replace("\\", "/").split("/")[-1]
    text = re.sub(r"\.nii(?:\.gz)?$", "", text, flags=re.IGNORECASE)
    if re.fullmatch(r"[+-]?\d+\.0+", text):
        text = text.split(".", 1)[0]
    if not text:
        raise ValueError(f"Empty case ID derived from {value!r}")
    return text


def discover_nifti(root: str | Path) -> dict[str, Path]:
    root = Path(root)
    if not root.exists():
        return {}
    found: dict[str, Path] = {}
    paths = sorted(p for p in root.rglob("*") if p.is_file() and p.name.lower().endswith((".nii", ".nii.gz")))
    for path in paths:
        case_id = canonical_case_id(path.name)
        if case_id in found:
            preferred = path.parent.name == case_id
            existing_preferred = found[case_id].parent.name == case_id
            if preferred and not existing_preferred:
                found[case_id] = path
            elif preferred == existing_preferred:
                raise ValueError(f"Duplicate NIfTI for case {case_id}: {found[case_id]} and {path}")
        else:
            found[case_id] = path
    return found


@dataclass(frozen=True)
class CaseItem:
    case_id: str
    image_path: str
    split: str
    record: dict[str, str] | None = None

    def to_dict(self) -> dict:
        return asdict(self)


def build_case_items(
    image_root: str | Path,
    split: str,
    records: dict[str, dict[str, str]] | None = None,
    strict_join: bool = True,
) -> list[CaseItem]:
    images = discover_nifti(image_root)
    if not images:
        raise FileNotFoundError(f"No .nii or .nii.gz files found under {image_root}")
    records = records or {}
    if strict_join and records:
        missing_records = sorted(set(images) - set(records))
        missing_images = sorted(set(records) - set(images))
        if missing_records or missing_images:
            raise ValueError(
                f"Image/CSV mismatch for {split}: missing_records={missing_records[:10]}, "
                f"missing_images={missing_images[:10]}"
            )
    return [
        CaseItem(case_id=case_id, image_path=str(images[case_id]), split=split, record=records.get(case_id))
        for case_id in sorted(images, key=_natural_key)
    ]


def _natural_key(text: str) -> tuple:
    return tuple(int(part) if part.isdigit() else part.lower() for part in re.split(r"(\d+)", text))


def write_json(data: object, path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        json.dump(data, handle, ensure_ascii=False, indent=2)
        handle.write("\n")


def read_json(path: str | Path) -> object:
    with Path(path).open("r", encoding="utf-8") as handle:
        return json.load(handle)


def write_jsonl(rows: Iterable[dict], path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
