from __future__ import annotations

import json
import pickle
import shutil
import zipfile
from pathlib import Path
from typing import Any

import yaml

from .cache import cache_all
from .config import load_config
from .data import load_simulation
from .feature_store import FeatureStore, sha256_file
from .io import build_case_items, discover_nifti, write_json
from .metrics import evaluate_predictions
from .records import load_records
from .retrieval_model import ValidationGuidedRetriever
from .selection import add_external_predictions, assemble_predictions, select_policy
from .submission import write_submission


BUNDLE_FORMAT = "sts_task3_v7_validation_guided_retrieval_v1"


def _read_predictions(path: str | Path) -> dict[str, dict[str, str]]:
    path = Path(path)
    if path.suffix.casefold() == ".zip":
        with zipfile.ZipFile(path, "r") as archive:
            if archive.namelist() != ["predictions.json"]:
                raise ValueError(f"{path} must contain exactly predictions.json")
            value = json.loads(archive.read("predictions.json").decode("utf-8"))
    else:
        value = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise ValueError(f"Prediction root in {path} must be an object")
    return {str(case_id): dict(record) for case_id, record in value.items()}


def _prediction_source_name(path: Path) -> str:
    return path.parent.name if path.stem.casefold() == "predictions" else path.stem


def _cache_roots(
    config: dict,
    overrides: list[str | Path] | None,
    role: str | None = None,
) -> list[Path]:
    key = f"{role}_roots" if role else "roots"
    values = overrides if overrides else config.get("cache", {}).get(key, [])
    roots = [Path(value) for value in values]
    if not roots:
        option = f"--{role.replace('_', '-')}-cache-root" if role else "--cache-root"
        raise ValueError(f"No {role or 'feature'} cache roots configured; pass {option} or set cache.{key}")
    return roots


def _store(
    config: dict,
    overrides: list[str | Path] | None,
    *,
    role: str | None = None,
    allowed_splits: set[str] | None = None,
) -> FeatureStore:
    settings = config["cache"]
    return FeatureStore(
        _cache_roots(config, overrides, role),
        require_same_encoder=bool(settings.get("require_same_encoder", True)),
        verify_duplicate_features=bool(settings.get("verify_duplicate_features", True)),
        allowed_splits=allowed_splits,
    )


def _one_encoder_hash(store: FeatureStore, role: str) -> str:
    missing = [str(root) for root in store.roots if str(root) not in store.encoder_hashes]
    if missing:
        raise FileNotFoundError(f"{role} cache roots miss encoder.pt: {missing}")
    hashes = set(store.encoder_hashes.values())
    if len(hashes) != 1:
        raise ValueError(f"{role} caches must resolve to exactly one encoder hash: {store.encoder_hashes}")
    return next(iter(hashes))


def _validate_validation_provenance(store: FeatureStore) -> None:
    for root in store.roots:
        manifest = store.manifests.get(str(root))
        if manifest is None:
            raise FileNotFoundError(f"Validation cache has no manifest.json: {root}")
        if manifest.get("cache_role") != "validation":
            raise ValueError(
                f"Validation cache {root} was not created by extract-validation-cache "
                "(manifest cache_role must be 'validation')"
            )
        if manifest.get("creation_method") != "extract_cached_features":
            raise ValueError(
                f"Validation cache {root} must be an ID-filtered extraction from the "
                "original unlabeled cache"
            )
        if manifest.get("splits") != ["validation"]:
            raise ValueError(f"Validation cache {root} must contain only the validation split")
        declared_ids = {str(case_id) for case_id in manifest.get("case_ids", [])}
        actual_paths = {path.stem: path for path in (root / "validation").glob("*.npz")}
        if not declared_ids or declared_ids != set(actual_paths):
            raise ValueError(f"Validation cache {root} files do not match its manifest case_ids")
        declared_hashes = manifest.get("feature_sha256")
        if not isinstance(declared_hashes, dict) or set(declared_hashes) != declared_ids:
            raise ValueError(f"Validation cache {root} has incomplete feature SHA256 provenance")
        for case_id, path in actual_paths.items():
            if sha256_file(path) != declared_hashes[case_id]:
                raise ValueError(f"Validation feature SHA256 mismatch: {path}")
        actual_hash = store.encoder_hashes.get(str(root))
        if manifest.get("source_encoder_sha256") != actual_hash:
            raise ValueError(
                f"Validation cache {root} provenance encoder hash does not match encoder.pt"
            )


def _audit_role_stores(
    training_store: FeatureStore,
    validation_store: FeatureStore,
    training_case_ids: set[str],
    validation_case_ids: set[str],
) -> dict:
    training = training_store.require(training_case_ids).to_dict()
    validation = validation_store.require(validation_case_ids).to_dict()
    _validate_validation_provenance(validation_store)
    training_hash = _one_encoder_hash(training_store, "training")
    validation_hash = _one_encoder_hash(validation_store, "validation")
    if training_hash != validation_hash:
        raise ValueError(
            "Training and validation caches use different encoders: "
            f"training={training_hash}, validation={validation_hash}"
        )
    return {
        "training": training,
        "validation": validation,
        "encoder_sha256": training_hash,
        "encoder_compatible": True,
        "passed": True,
    }


class _CaseRoutedStore:
    """Route known case IDs to role-specific stores without cross-role fallback."""

    def __init__(self, routes: dict[str, FeatureStore]) -> None:
        self.routes = routes

    def load(self, case_id: str) -> dict:
        case_id = str(case_id)
        if case_id not in self.routes:
            raise KeyError(f"No role-specific cached feature for case {case_id}")
        return self.routes[case_id].load(case_id)


def _save_bundle(payload: dict[str, Any], path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("wb") as handle:
        pickle.dump(payload, handle, protocol=pickle.HIGHEST_PROTOCOL)
    return path


def load_bundle(path: str | Path) -> dict[str, Any]:
    with Path(path).open("rb") as handle:
        payload = pickle.load(handle)
    if not isinstance(payload, dict) or payload.get("format") != BUNDLE_FORMAT:
        raise ValueError(f"Unsupported V7 bundle: {path}")
    return payload


def audit_cache(
    simulation_root: str | Path,
    config_path: str | Path | None,
    training_cache_roots: list[str | Path] | None,
    validation_cache_roots: list[str | Path] | None,
) -> dict:
    config = load_config(config_path)
    data = load_simulation(simulation_root, expose_validation_labels=False)
    training_store = _store(
        config,
        training_cache_roots,
        role="training",
        allowed_splits={"labeled", "unlabeled"},
    )
    validation_store = _store(
        config,
        validation_cache_roots,
        role="validation",
        allowed_splits={"validation"},
    )
    return _audit_role_stores(
        training_store,
        validation_store,
        set(data.train_records),
        set(data.validation_case_ids),
    )


def run_local(
    simulation_root: str | Path,
    output_dir: str | Path,
    config_path: str | Path | None = None,
    training_cache_roots: list[str | Path] | None = None,
    validation_cache_roots: list[str | Path] | None = None,
    external_predictions: list[str | Path] | None = None,
) -> dict:
    config = load_config(config_path)
    data = load_simulation(simulation_root, expose_validation_labels=True)
    training_store = _store(
        config,
        training_cache_roots,
        role="training",
        allowed_splits={"labeled", "unlabeled"},
    )
    validation_store = _store(
        config,
        validation_cache_roots,
        role="validation",
        allowed_splits={"validation"},
    )
    cache_audit = _audit_role_stores(
        training_store,
        validation_store,
        set(data.train_records),
        set(data.validation_case_ids),
    )
    model = ValidationGuidedRetriever(config).fit(
        data.train_records, data.source_by_case, training_store
    )
    candidates = model.generate_candidates(data.validation_case_ids, validation_store)
    external_sources = []
    for path in external_predictions or []:
        path = Path(path)
        name = _prediction_source_name(path)
        add_external_predictions(candidates, name, _read_predictions(path), data.validation_case_ids)
        external_sources.append({"name": name, "path": str(path.resolve())})
    selected = select_policy(candidates, data.validation_records, config)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    predictions_path, zip_path = write_submission(
        selected.predictions,
        output_dir / "predictions.zip",
        expected_case_ids=data.validation_case_ids,
    )
    write_json(cache_audit, output_dir / "cache_audit.json")
    write_json(selected.evaluation, output_dir / "validation_metrics.json")
    write_json(selected.report, output_dir / "selection_report.json")
    with (output_dir / "resolved_config.yaml").open("w", encoding="utf-8", newline="\n") as handle:
        yaml.safe_dump(config, handle, allow_unicode=True, sort_keys=False)
    bundle = {
        "format": BUNDLE_FORMAT,
        "method": "field_specific_supervised_text_alignment_and_validation_guided_retrieval",
        "config": config,
        "model": model,
        "policy": selected.policy,
        "encoder_sha256": cache_audit["encoder_sha256"],
        "external_sources": external_sources,
        "training_case_ids": list(model.case_ids),
        "validation_labels_embedded": False,
    }
    bundle_path = _save_bundle(bundle, output_dir / "task3_v7_bundle.pkl")
    report = {
        "method": bundle["method"],
        "objective": "maximize the supplied simulated validation weighted proxy",
        "num_primary_supervised": len(data.primary_records),
        "num_weak_supervised": len(data.weak_records),
        "num_validation": len(data.validation_case_ids),
        "cache_audit": cache_audit,
        "selected_policy": selected.policy,
        "validation_metrics_mean": selected.evaluation["metrics_mean"],
        "predictions": str(predictions_path.resolve()),
        "submission_zip": str(zip_path.resolve()),
        "bundle": str(bundle_path.resolve()),
        "external_sources": external_sources,
        "warning": "Validation labels select a global per-field policy. This is a development-set score, not an unbiased blind-test estimate.",
    }
    write_json(report, output_dir / "run_report.json")
    return report


def predict(
    bundle_path: str | Path,
    query_dir: str | Path,
    output_dir: str | Path,
    cache_roots: list[str | Path],
    external_predictions: list[str | Path] | None = None,
) -> dict:
    bundle = load_bundle(bundle_path)
    config = bundle["config"]
    store = _store(config, cache_roots, allowed_splits={"validation"})
    expected_hash = bundle.get("encoder_sha256")
    actual_hashes = set(store.encoder_hashes.values())
    if expected_hash and actual_hashes and actual_hashes != {expected_hash}:
        raise ValueError(f"Query cache encoder mismatch: expected {expected_hash}, got {sorted(actual_hashes)}")
    images = discover_nifti(query_dir)
    if not images:
        raise FileNotFoundError(f"No query NIfTI found under {query_dir}")
    case_ids = sorted(images, key=lambda value: (len(value), value))
    cache_audit = store.require(case_ids).to_dict()
    model: ValidationGuidedRetriever = bundle["model"]
    candidates = model.generate_candidates(case_ids, store)
    for path in external_predictions or []:
        path = Path(path)
        add_external_predictions(candidates, _prediction_source_name(path), _read_predictions(path), case_ids)
    predictions = assemble_predictions(
        candidates,
        bundle["policy"],
        case_ids,
        int(config.get("retrieval", {}).get("max_field_chars", 600)),
    )
    output_dir = Path(output_dir)
    predictions_path, zip_path = write_submission(
        predictions, output_dir / "predictions.zip", expected_case_ids=case_ids
    )
    report = {
        "bundle": str(Path(bundle_path).resolve()),
        "num_cases": len(case_ids),
        "cache_audit": cache_audit,
        "policy": bundle["policy"],
        "predictions": str(predictions_path.resolve()),
        "submission_zip": str(zip_path.resolve()),
    }
    write_json(report, output_dir / "prediction_report.json")
    return report


def evaluate(
    predictions_path: str | Path,
    ground_truth_csv: str | Path,
    output_path: str | Path,
    config_path: str | Path | None = None,
) -> dict:
    config = load_config(config_path)
    predictions = _read_predictions(predictions_path)
    references = load_records(ground_truth_csv)
    result = evaluate_predictions(predictions, references, config["evaluation"]["weights"])
    write_json(result, output_path)
    return result


def cache_simulation(
    simulation_root: str | Path,
    output_dir: str | Path,
    config_path: str | Path | None = None,
    device: str | None = None,
    overwrite: bool = False,
) -> dict:
    config = load_config(config_path)
    root = Path(simulation_root) / "dataset_view"
    primary_records = load_records(root / "Train-Labeled" / "Train-Labeled.csv")
    items = build_case_items(root / "Train-Labeled", "labeled", primary_records, strict_join=True)
    items.extend(build_case_items(root / "Train-Unlabeled", "unlabeled", None, strict_join=False))
    items.extend(build_case_items(root / "Validation", "validation", None, strict_join=False))
    return cache_all(
        items,
        output_dir,
        config["preprocess"],
        config["encoder"],
        device=device,
        overwrite=overwrite,
    )


def extract_validation_cache(
    simulation_root: str | Path,
    training_cache_root: str | Path,
    source_cache_root: str | Path,
    output_dir: str | Path,
    config_path: str | Path | None = None,
    overwrite: bool = False,
) -> dict:
    """Extract simulated Validation IDs from an existing original-unlabeled cache."""

    config = load_config(config_path)
    simulation_root = Path(simulation_root).resolve()
    training_cache_root = Path(training_cache_root).resolve()
    source_cache_root = Path(source_cache_root).resolve()
    output_dir = Path(output_dir).resolve()
    if output_dir in {training_cache_root, source_cache_root}:
        raise ValueError("Validation output must be separate from both source cache roots")
    data = load_simulation(simulation_root, expose_validation_labels=False)
    expected_ids = set(data.validation_case_ids)
    training_store = FeatureStore(
        [training_cache_root],
        require_same_encoder=True,
        verify_duplicate_features=True,
        allowed_splits={"labeled", "unlabeled"},
    )
    source_store = FeatureStore(
        [source_cache_root],
        require_same_encoder=True,
        verify_duplicate_features=True,
        allowed_splits={"unlabeled"},
    )
    training_store.require(set(data.train_records))
    source_store.require(expected_ids)
    training_hash = _one_encoder_hash(training_store, "training")
    source_hash = _one_encoder_hash(source_store, "Validation source")
    if training_hash != source_hash:
        raise ValueError(
            "Training and Validation-source caches use different encoders: "
            f"training={training_hash}, source={source_hash}"
        )
    expected_backbone = str(config["encoder"].get("backbone", "resnet18"))
    for role, store, root in (
        ("training", training_store, training_cache_root),
        ("Validation source", source_store, source_cache_root),
    ):
        manifest = store.manifests.get(str(root))
        if manifest is None:
            raise FileNotFoundError(f"{role} cache has no manifest.json: {root}")
        if manifest.get("preprocess") != config["preprocess"]:
            raise ValueError(f"{role} cache preprocessing differs from the V7 config")
        if str(manifest.get("backbone")) != expected_backbone:
            raise ValueError(
                f"{role} cache backbone is {manifest.get('backbone')!r}, "
                f"expected {expected_backbone!r}"
            )

    ordered_ids = sorted(expected_ids, key=lambda value: (len(value), value))
    source_file_hashes = {
        case_id: sha256_file(source_store.paths[case_id]) for case_id in ordered_ids
    }
    validation_dir = output_dir / "validation"
    existing_features = list(validation_dir.glob("*.npz"))
    if existing_features:
        existing_ids = {path.stem for path in existing_features}
        if existing_ids != expected_ids:
            raise ValueError(
                f"Validation output contains a different ID set: "
                f"missing={sorted(expected_ids - existing_ids)[:10]}, "
                f"unexpected={sorted(existing_ids - expected_ids)[:10]}. "
                "Use a new empty output directory."
            )
        if not overwrite:
            existing_manifest_path = output_dir / "manifest.json"
            existing_manifest = (
                json.loads(existing_manifest_path.read_text(encoding="utf-8"))
                if existing_manifest_path.is_file()
                else {}
            )
            exact_files = all(
                sha256_file(validation_dir / f"{case_id}.npz") == source_file_hashes[case_id]
                for case_id in ordered_ids
            )
            cached_encoder = output_dir / "encoder.pt"
            if (
                existing_manifest.get("creation_method") == "extract_cached_features"
                and existing_manifest.get("source_encoder_sha256") == source_hash
                and exact_files
                and cached_encoder.is_file()
                and sha256_file(cached_encoder) == training_hash
            ):
                return existing_manifest
            raise ValueError(
                f"Output {output_dir} contains unverified features; choose a new directory "
                "or pass --overwrite to replace exactly these 50 files"
            )

    validation_dir.mkdir(parents=True, exist_ok=True)
    for case_id in ordered_ids:
        shutil.copy2(source_store.paths[case_id], validation_dir / f"{case_id}.npz")
    shutil.copy2(training_cache_root / "encoder.pt", output_dir / "encoder.pt")
    copied_hashes = {
        case_id: sha256_file(validation_dir / f"{case_id}.npz") for case_id in ordered_ids
    }
    if copied_hashes != source_file_hashes:
        raise OSError("Validation feature copy verification failed")
    source_manifest = source_store.manifests[str(source_cache_root)]
    manifest = {
        "num_cases": len(ordered_ids),
        "num_copied": len(ordered_ids),
        "num_reencoded": 0,
        "output_dim": source_manifest.get("output_dim"),
        "backbone": source_manifest.get("backbone"),
        "preprocess": source_manifest.get("preprocess"),
        "splits": ["validation"],
        "cache_role": "validation",
        "creation_method": "extract_cached_features",
        "source_split": "unlabeled",
        "source_feature_cache": str(source_cache_root),
        "training_feature_cache": str(training_cache_root),
        "source_encoder_sha256": source_hash,
        "encoder_sha256": sha256_file(output_dir / "encoder.pt"),
        "case_ids": ordered_ids,
        "feature_sha256": copied_hashes,
    }
    write_json(manifest, output_dir / "manifest.json")
    return manifest


def refit_for_official(
    bundle_path: str | Path,
    simulation_root: str | Path,
    output_path: str | Path,
    training_cache_roots: list[str | Path],
    validation_cache_roots: list[str | Path],
) -> dict:
    bundle = load_bundle(bundle_path)
    if any(str(source).startswith("external::") for source in bundle["policy"].values()):
        raise ValueError("Cannot refit a policy that depends on external prediction candidates")
    data = load_simulation(simulation_root, expose_validation_labels=True)
    records = {**data.train_records, **data.validation_records}
    sources = {**data.source_by_case, **{case_id: "weak" for case_id in data.validation_records}}
    training_store = _store(
        bundle["config"],
        training_cache_roots,
        role="training",
        allowed_splits={"labeled", "unlabeled"},
    )
    validation_store = _store(
        bundle["config"],
        validation_cache_roots,
        role="validation",
        allowed_splits={"validation"},
    )
    audit = _audit_role_stores(
        training_store,
        validation_store,
        set(data.train_records),
        set(data.validation_case_ids),
    )
    routes = {
        **{case_id: training_store for case_id in data.train_records},
        **{case_id: validation_store for case_id in data.validation_case_ids},
    }
    model = ValidationGuidedRetriever(bundle["config"]).fit(
        records, sources, _CaseRoutedStore(routes)
    )
    refit = {
        **bundle,
        "model": model,
        "encoder_sha256": audit["encoder_sha256"],
        "training_case_ids": list(model.case_ids),
        "refit_includes_local_validation": True,
        "validation_labels_embedded": False,
    }
    saved = _save_bundle(refit, output_path)
    return {"bundle": str(saved.resolve()), "num_supervised": len(records), "cache_audit": audit}
