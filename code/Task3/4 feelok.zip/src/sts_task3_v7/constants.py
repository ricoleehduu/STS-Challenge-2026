FIELDS = (
    "Main appeal",
    "Present medical history",
    "Oral Check",
    "Diagnosis",
    "Treatment plan",
    "Handle",
    "Doctor advices",
)

# Field groups are used only to select intact prototype fields from the
# reference bank.  V5 never rewrites whole clinical fields with templates.
FIELD_GROUPS = {
    "symptom": ("Main appeal", "Present medical history"),
    "diagnosis": ("Oral Check", "Diagnosis"),
    "treatment": ("Treatment plan", "Handle"),
    "advice": ("Doctor advices",),
}

ENTITY_NAMES = ("teeth", "diagnoses", "diagnosis_codes", "treatments", "medications")

OPTIONAL_INPUT_FIELDS = (
    "Sex",
    "Age",
    "Past medical history",
    "Subsequent",
)

ID_ALIASES = ("Filename", "filename", "case_id", "Case ID", "id", "ID")

FIELD_ALIASES = {
    "Main appeal": ("Main appeal", "main appeal", "chief complaint", "Chief complaint"),
    "Present medical history": (
        "Present medical history",
        "present medical history",
        "present history",
    ),
    "Oral Check": ("Oral Check", "oral check", "oral examination", "Oral examination"),
    "Diagnosis": ("Diagnosis", "diagnosis"),
    "Treatment plan": ("Treatment plan", "treatment plan"),
    "Handle": ("Handle", "handle", "treatment performed", "procedure"),
    "Doctor advices": ("Doctor advices", "doctor advices", "doctor advice", "advice"),
}

EMPTY_FALLBACKS = {
    "Main appeal": "Dental consultation.",
    "Present medical history": "Dental symptoms require clinical correlation.",
    "Oral Check": "Dental examination findings require clinical correlation.",
    "Diagnosis": "Dental condition requiring professional assessment.",
    "Treatment plan": "Further dental evaluation and appropriate treatment are recommended.",
    "Handle": "Clinical management according to examination findings.",
    "Doctor advices": "Maintain oral hygiene and return for dental follow-up.",
}
