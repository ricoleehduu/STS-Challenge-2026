from __future__ import annotations

from copy import deepcopy
from pathlib import Path

import yaml


DEFAULT_CONFIG = {
    "seed": 20260722,
    "cache": {
        "roots": [],
        "require_same_encoder": True,
        "verify_duplicate_features": True,
    },
    "preprocess": {
        "slices_per_plane": 16,
        "image_size": 224,
        "sampling": "hybrid",
        "candidate_multiplier": 4,
        "cpu_threads": 8,
        "report_timing": True,
        "foreground_margin": 8,
        "percentile_low": 0.5,
        "percentile_high": 99.5,
        "neighbor_stride": 1,
    },
    "encoder": {
        "backbone": "resnet18",
        "pretrained": True,
        "checkpoint": None,
        "batch_size": 48,
        "num_workers": 0,
        "amp": True,
    },
    "descriptors": {
        "names": ["global", "plane", "pyramid4"],
        "pyramid_bins": 4,
        "pca_dim": 64,
        "pca_whiten": True,
    },
    "semantic": {
        "svd_dim": 48,
        "max_features": 10000,
        "ngram_min": 2,
        "ngram_max": 5,
        "ridge_alphas": [10.0],
        "fit_scopes": ["combined"],
    },
    "retrieval": {
        "reference_scopes": ["combined", "weak"],
        "top_k": [1, 3, 5],
        "strategies": ["nearest", "vote", "longest"],
        "semantic_weights": [0.0, 0.5, 1.0],
        "visual_spaces": ["raw"],
        "temperature": 0.10,
        "max_field_chars": 600,
    },
    "selection": {
        "max_candidates_per_field": 48,
        "coordinate_passes": 3,
        "minimum_gain": 1e-10,
        "seed_policies": [],
    },
    "evaluation": {
        "weights": {
            "text": 0.35,
            "teeth": 0.15,
            "diagnoses": 0.20,
            "diagnosis_codes": 0.10,
            "treatments": 0.12,
            "medications": 0.03,
            "completion": 0.05,
        }
    },
}


def _merge(base: dict, update: dict) -> dict:
    result = deepcopy(base)
    for key, value in update.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = _merge(result[key], value)
        else:
            result[key] = deepcopy(value)
    return result


def load_config(path: str | Path | None) -> dict:
    if path is None:
        return deepcopy(DEFAULT_CONFIG)
    with Path(path).open("r", encoding="utf-8") as handle:
        loaded = yaml.safe_load(handle) or {}
    if not isinstance(loaded, dict):
        raise ValueError("V7 config root must be a mapping")
    return _merge(DEFAULT_CONFIG, loaded)
