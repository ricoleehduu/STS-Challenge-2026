from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path

import numpy as np


def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _load_npz(path: Path) -> dict[str, np.ndarray | str]:
    with np.load(path, allow_pickle=False) as payload:
        required = {"features", "plane_ids", "positions", "case_id"}
        missing = required - set(payload.files)
        if missing:
            raise ValueError(f"Cache file {path} misses keys {sorted(missing)}")
        return {
            "features": payload["features"].astype(np.float32),
            "plane_ids": payload["plane_ids"].astype(np.int64),
            "positions": payload["positions"].astype(np.float32),
            "case_id": str(payload["case_id"].item()),
        }


@dataclass
class CacheAudit:
    roots: list[str]
    allowed_splits: list[str] | None
    encoder_sha256: dict[str, str]
    manifests: dict[str, dict]
    num_unique_cases: int
    duplicate_case_ids: list[str]
    missing_case_ids: list[str]
    required_case_count: int

    def to_dict(self) -> dict:
        return {
            "roots": self.roots,
            "allowed_splits": self.allowed_splits,
            "encoder_sha256": self.encoder_sha256,
            "manifests": self.manifests,
            "num_unique_cases": self.num_unique_cases,
            "duplicate_case_ids": self.duplicate_case_ids,
            "missing_case_ids": self.missing_case_ids,
            "required_case_count": self.required_case_count,
            "passed": not self.missing_case_ids and len(set(self.encoder_sha256.values())) <= 1,
        }


class FeatureStore:
    """Read one or more compatible feature caches without copying them."""

    def __init__(
        self,
        roots: list[str | Path],
        require_same_encoder: bool = True,
        verify_duplicate_features: bool = True,
        allowed_splits: set[str] | list[str] | tuple[str, ...] | None = None,
    ) -> None:
        if not roots:
            raise ValueError("At least one feature-cache root is required")
        self.roots = [Path(root).resolve() for root in roots]
        self.allowed_splits = (
            frozenset(str(split) for split in allowed_splits) if allowed_splits is not None else None
        )
        if self.allowed_splits is not None and not self.allowed_splits:
            raise ValueError("allowed_splits must contain at least one split")
        self.paths: dict[str, Path] = {}
        self.duplicates: dict[str, list[Path]] = {}
        self.encoder_hashes: dict[str, str] = {}
        self.manifests: dict[str, dict] = {}
        for root in self.roots:
            if not root.exists():
                raise FileNotFoundError(root)
            encoder = root / "encoder.pt"
            if encoder.exists():
                self.encoder_hashes[str(root)] = sha256_file(encoder)
            manifest = root / "manifest.json"
            if manifest.exists():
                self.manifests[str(root)] = json.loads(manifest.read_text(encoding="utf-8"))
            for path in sorted(root.rglob("*.npz")):
                relative_parts = path.relative_to(root).parts
                split = relative_parts[0] if len(relative_parts) >= 2 else ""
                if self.allowed_splits is not None and split not in self.allowed_splits:
                    continue
                case_id = path.stem
                if case_id in self.paths:
                    self.duplicates.setdefault(case_id, [self.paths[case_id]]).append(path)
                else:
                    self.paths[case_id] = path
        hashes = set(self.encoder_hashes.values())
        if require_same_encoder and len(hashes) > 1:
            raise ValueError(f"Feature caches use different encoders: {self.encoder_hashes}")
        if verify_duplicate_features:
            self._verify_duplicates()

    def _verify_duplicates(self) -> None:
        for case_id, paths in self.duplicates.items():
            first = _load_npz(paths[0])
            for path in paths[1:]:
                other = _load_npz(path)
                for key in ("features", "plane_ids", "positions"):
                    if first[key].shape != other[key].shape or not np.array_equal(first[key], other[key]):
                        raise ValueError(f"Conflicting duplicate cache for case {case_id}: {paths[0]} vs {path}")

    def require(self, case_ids: list[str] | set[str]) -> CacheAudit:
        required = {str(case_id) for case_id in case_ids}
        missing = sorted(required - set(self.paths))
        audit = CacheAudit(
            roots=[str(root) for root in self.roots],
            allowed_splits=sorted(self.allowed_splits) if self.allowed_splits is not None else None,
            encoder_sha256=dict(self.encoder_hashes),
            manifests=dict(self.manifests),
            num_unique_cases=len(self.paths),
            duplicate_case_ids=sorted(self.duplicates),
            missing_case_ids=missing,
            required_case_count=len(required),
        )
        if missing:
            raise FileNotFoundError(f"Feature caches miss {len(missing)} required cases: {missing[:20]}")
        return audit

    def load(self, case_id: str) -> dict[str, np.ndarray | str]:
        case_id = str(case_id)
        if case_id not in self.paths:
            raise KeyError(f"No cached feature for case {case_id}")
        payload = _load_npz(self.paths[case_id])
        if payload["case_id"] != case_id:
            raise ValueError(f"Cache filename/content mismatch at {self.paths[case_id]}")
        return payload


def _safe_mean(values: np.ndarray, width: int) -> np.ndarray:
    return values.mean(axis=0) if len(values) else np.zeros(width, dtype=np.float32)


def build_descriptor(payload: dict[str, np.ndarray | str], name: str, pyramid_bins: int = 4) -> np.ndarray:
    features = np.asarray(payload["features"], dtype=np.float32)
    plane_ids = np.asarray(payload["plane_ids"], dtype=np.int64)
    positions = np.asarray(payload["positions"], dtype=np.float32)
    if features.ndim != 2 or len(features) != len(plane_ids) or len(features) != len(positions):
        raise ValueError("Malformed cached feature tensors")
    width = int(features.shape[1])
    global_mean = _safe_mean(features, width)
    if name == "global":
        return global_mean.astype(np.float32)
    plane_means = [_safe_mean(features[plane_ids == plane], width) for plane in range(3)]
    if name == "plane":
        return np.concatenate(plane_means).astype(np.float32)
    if name == "plane_stats":
        blocks: list[np.ndarray] = [global_mean]
        for plane in range(3):
            values = features[plane_ids == plane]
            blocks.append(_safe_mean(values, width))
            blocks.append(values.std(axis=0) if len(values) else np.zeros(width, dtype=np.float32))
        return np.concatenate(blocks).astype(np.float32)
    if name == "pyramid4":
        bins = max(1, int(pyramid_bins))
        blocks = [global_mean]
        for plane in range(3):
            indices = np.flatnonzero(plane_ids == plane)
            indices = indices[np.argsort(positions[indices])]
            for chunk in np.array_split(indices, bins):
                blocks.append(_safe_mean(features[chunk], width))
        return np.concatenate(blocks).astype(np.float32)
    raise ValueError(f"Unsupported descriptor {name!r}")


def descriptor_matrix(
    store: FeatureStore,
    case_ids: list[str],
    name: str,
    pyramid_bins: int = 4,
) -> np.ndarray:
    return np.stack([build_descriptor(store.load(case_id), name, pyramid_bins) for case_id in case_ids])
