from __future__ import annotations

from pathlib import Path

import torch
from torch import nn


class TinySliceEncoder(nn.Module):
    """Small dependency-free fallback used for tests and offline debugging."""

    output_dim = 128

    def __init__(self) -> None:
        super().__init__()
        channels = (3, 24, 48, 96, 128)
        blocks: list[nn.Module] = []
        for in_channels, out_channels in zip(channels[:-1], channels[1:]):
            blocks.extend(
                [
                    nn.Conv2d(in_channels, out_channels, 3, stride=2, padding=1, bias=False),
                    nn.BatchNorm2d(out_channels),
                    nn.SiLU(inplace=True),
                ]
            )
        self.features = nn.Sequential(*blocks, nn.AdaptiveAvgPool2d(1))

    def forward(self, images: torch.Tensor) -> torch.Tensor:
        return self.features(images).flatten(1)


class NormalizedEncoder(nn.Module):
    """Apply ImageNet normalization inside the saved encoder bundle."""

    def __init__(self, encoder: nn.Module) -> None:
        super().__init__()
        self.encoder = encoder
        self.register_buffer("mean", torch.tensor((0.485, 0.456, 0.406)).view(1, 3, 1, 1))
        self.register_buffer("std", torch.tensor((0.229, 0.224, 0.225)).view(1, 3, 1, 1))

    def forward(self, images: torch.Tensor) -> torch.Tensor:
        return self.encoder((images - self.mean) / self.std)


def _torchvision_encoder(name: str, pretrained: bool) -> tuple[nn.Module, int]:
    try:
        from torchvision import models
    except Exception as exc:
        raise RuntimeError(
            "torchvision is required for the default pretrained encoder. "
            "Install requirements.txt or use encoder.backbone=tiny for a smoke test."
        ) from exc
    if name == "resnet18":
        weights = models.ResNet18_Weights.DEFAULT if pretrained else None
        model = models.resnet18(weights=weights)
        output_dim = int(model.fc.in_features)
        model.fc = nn.Identity()
        return NormalizedEncoder(model), output_dim
    if name == "resnet50":
        weights = models.ResNet50_Weights.DEFAULT if pretrained else None
        model = models.resnet50(weights=weights)
        output_dim = int(model.fc.in_features)
        model.fc = nn.Identity()
        return NormalizedEncoder(model), output_dim
    if name == "convnext_tiny":
        weights = models.ConvNeXt_Tiny_Weights.DEFAULT if pretrained else None
        model = models.convnext_tiny(weights=weights)
        output_dim = int(model.classifier[-1].in_features)
        model.classifier = nn.Sequential(model.classifier[0], model.classifier[1], nn.Identity())
        return NormalizedEncoder(model), output_dim
    raise ValueError(f"Unsupported backbone={name!r}; choose tiny, resnet18, resnet50, or convnext_tiny")


def build_slice_encoder(config: dict, load_checkpoint: bool = True) -> tuple[nn.Module, int]:
    name = str(config.get("backbone", "resnet18"))
    checkpoint = config.get("checkpoint")
    pretrained = bool(config.get("pretrained", True)) and not checkpoint
    if name == "tiny":
        model: nn.Module = TinySliceEncoder()
        output_dim = TinySliceEncoder.output_dim
    else:
        model, output_dim = _torchvision_encoder(name, pretrained=pretrained)
    if load_checkpoint and checkpoint:
        payload = torch.load(Path(checkpoint), map_location="cpu", weights_only=True)
        state = payload.get("state_dict", payload) if isinstance(payload, dict) else payload
        try:
            model.load_state_dict(state, strict=True)
        except RuntimeError:
            target = model.encoder if isinstance(model, NormalizedEncoder) else model
            cleaned = {
                key.removeprefix("module.").removeprefix("encoder."): value
                for key, value in state.items()
                if not key.endswith(("fc.weight", "fc.bias", "classifier.2.weight", "classifier.2.bias"))
            }
            target.load_state_dict(cleaned, strict=False)
    model.eval()
    for parameter in model.parameters():
        parameter.requires_grad = False
    return model, output_dim


@torch.inference_mode()
def encode_slices(
    encoder: nn.Module,
    images: torch.Tensor,
    device: torch.device,
    batch_size: int = 48,
    amp: bool = True,
) -> torch.Tensor:
    encoder.eval()
    outputs: list[torch.Tensor] = []
    use_amp = bool(amp and device.type == "cuda")
    for start in range(0, len(images), batch_size):
        batch = images[start : start + batch_size].to(device, non_blocking=True)
        with torch.autocast(device_type=device.type, enabled=use_amp):
            features = encoder(batch)
        outputs.append(features.float().cpu())
    return torch.cat(outputs, dim=0)
