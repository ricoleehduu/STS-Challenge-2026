from __future__ import annotations

import math
import re
from collections import Counter

import numpy as np

from .constants import ENTITY_NAMES, FIELDS
from .entities import extract_entities
from .records import clean_text


def tokenize(text: str) -> list[str]:
    return re.findall(r"[a-z0-9#]+|[\u4e00-\u9fff]", clean_text(text).casefold())


def _ngrams(tokens: list[str], n: int) -> Counter[tuple[str, ...]]:
    return Counter(tuple(tokens[index:index + n]) for index in range(max(0, len(tokens) - n + 1)))


def bleu_precision(prediction: str, reference: str, n: int) -> float:
    predicted, expected = _ngrams(tokenize(prediction), n), _ngrams(tokenize(reference), n)
    total = sum(predicted.values())
    if not total:
        return 0.0
    overlap = sum(min(count, expected[gram]) for gram, count in predicted.items())
    pred_len, ref_len = len(tokenize(prediction)), len(tokenize(reference))
    brevity = 1.0 if pred_len >= ref_len else math.exp(1.0 - ref_len / max(1, pred_len))
    return brevity * overlap / total


def rouge_l(prediction: str, reference: str) -> float:
    first, second = tokenize(prediction), tokenize(reference)
    if not first or not second:
        return 0.0
    previous = [0] * (len(second) + 1)
    for token in first:
        current = [0]
        for index, other in enumerate(second, 1):
            current.append(previous[index - 1] + 1 if token == other else max(previous[index], current[-1]))
        previous = current
    precision, recall = previous[-1] / len(first), previous[-1] / len(second)
    return 2 * precision * recall / max(precision + recall, 1e-8)


def meteor_approx(prediction: str, reference: str) -> float:
    predicted, expected = Counter(tokenize(prediction)), Counter(tokenize(reference))
    matches = sum(min(count, expected[token]) for token, count in predicted.items())
    if not matches:
        return 0.0
    precision = matches / max(1, sum(predicted.values()))
    recall = matches / max(1, sum(expected.values()))
    return 10 * precision * recall / max(recall + 9 * precision, 1e-8)


def cider_approx(prediction: str, reference: str) -> float:
    """Single-reference CIDEr-style n-gram cosine proxy in the 0-1 range."""
    similarities = []
    for n in range(1, 5):
        predicted = _ngrams(tokenize(prediction), n)
        expected = _ngrams(tokenize(reference), n)
        vocabulary = set(predicted) | set(expected)
        if not vocabulary:
            similarities.append(0.0)
            continue
        dot = sum(predicted[gram] * expected[gram] for gram in vocabulary)
        first_norm = math.sqrt(sum(predicted[gram] ** 2 for gram in vocabulary))
        second_norm = math.sqrt(sum(expected[gram] ** 2 for gram in vocabulary))
        similarities.append(dot / max(first_norm * second_norm, 1e-8))
    return float(np.mean(similarities))


def set_prf(predicted: set[str], expected: set[str]) -> dict[str, float]:
    true_positive = len(predicted & expected)
    precision = true_positive / len(predicted) if predicted else float(not expected)
    recall = true_positive / len(expected) if expected else float(not predicted)
    return {"precision": precision, "recall": recall, "f1": 2 * precision * recall / max(precision + recall, 1e-8)}


def evaluate_case(prediction: dict[str, str], reference: dict[str, str], weights: dict | None = None) -> dict[str, float]:
    pred_text = " ".join(clean_text(prediction.get(field, "")) for field in FIELDS)
    ref_text = " ".join(clean_text(reference.get(field, "")) for field in FIELDS)
    result = {f"bleu_{n}": bleu_precision(pred_text, ref_text, n) for n in range(1, 5)}
    result["meteor"] = meteor_approx(pred_text, ref_text)
    result["rouge_l"] = rouge_l(pred_text, ref_text)
    result["cider"] = cider_approx(pred_text, ref_text)
    predicted_entities, expected_entities = extract_entities(prediction), extract_entities(reference)
    for name in ENTITY_NAMES:
        for metric, value in set_prf(predicted_entities[name], expected_entities[name]).items():
            result[f"{name}_{metric}"] = value
    pred_diag = clean_text(prediction.get("Diagnosis", "")).casefold()
    ref_diag = clean_text(reference.get("Diagnosis", "")).casefold()
    result["diagnosis_exact_match"] = float(bool(pred_diag) and pred_diag == ref_diag)
    result["diagnosis_partial_match"] = rouge_l(pred_diag, ref_diag)
    result["field_completion_rate"] = sum(bool(clean_text(prediction.get(field))) for field in FIELDS) / len(FIELDS)
    result["pred_field_completion_rate"] = result["field_completion_rate"]
    for metric in ("precision", "recall", "f1"):
        result[f"tooth_notations_{metric}"] = result[f"teeth_{metric}"]
        result[f"tooth_notation_{metric}"] = result[f"teeth_{metric}"]
        result[f"treatment_actions_{metric}"] = result[f"treatments_{metric}"]
    result["diagnosis_code_recall"] = result["diagnosis_codes_recall"]
    result["treatment_plan_recall"] = result["treatments_recall"]
    weights = weights or {"text": 0.35, "teeth": 0.15, "diagnoses": 0.20, "diagnosis_codes": 0.10, "treatments": 0.12, "medications": 0.03, "completion": 0.05}
    text_score = float(np.mean([result[f"bleu_{n}"] for n in range(1, 5)] + [result["meteor"], result["rouge_l"], result["cider"]]))
    diagnosis_score = float(np.mean([result["diagnoses_f1"], result["diagnosis_partial_match"], result["diagnosis_exact_match"]]))
    result["weighted_proxy"] = (
        float(weights.get("text", 0.35)) * text_score
        + float(weights.get("teeth", 0.15)) * result["teeth_f1"]
        + float(weights.get("diagnoses", 0.20)) * diagnosis_score
        + float(weights.get("diagnosis_codes", 0.10)) * result["diagnosis_codes_f1"]
        + float(weights.get("treatments", 0.12)) * result["treatments_f1"]
        + float(weights.get("medications", 0.03)) * result["medications_f1"]
        + float(weights.get("completion", 0.05)) * result["field_completion_rate"]
    )
    return result


def evaluate_predictions(predictions: dict[str, dict[str, str]], references: dict[str, dict[str, str]], weights: dict | None = None) -> dict:
    common = sorted(set(predictions) & set(references))
    cases = {case_id: evaluate_case(predictions[case_id], references[case_id], weights) for case_id in common}
    names = sorted({name for values in cases.values() for name in values})
    mean = {name: float(np.mean([value[name] for value in cases.values()])) if cases else 0.0 for name in names}
    return {"num_cases": len(references), "num_evaluated": len(common), "num_missing_predictions": len(set(references) - set(predictions)), "metrics_mean": mean, "case_results": cases}
