# Design provenance

This repository contains an independent training and inference implementation
for STS 2026 Challenge Task 3. The primary complete-method package under
`src/gq_tsr` is self-contained and does not import code, configuration, caches,
or checkpoints from other workspaces. The package under `src/sts_task3_v7` is
retained as a separate frozen-feature retrieval baseline.

The design was informed by the following public research ideas:

- MMDental: task schema and paired CBCT/medical-record data contract.
- HCC-Merlin and Merlin: image-text contrastive adaptation and
  parameter-efficient medical representation learning.
- DentVLM: staged dental visual-language alignment and fixed-format inference.
- OralGPT/MMOral: dental entity structuring, evidence-first generation, and
  evaluation-oriented data organization.
- nnU-Net v2: foreground bounding-box cropping and memory-conscious in-place
  normalization.
- Mean Teacher/EMA self-ensembling: homogeneous Teacher-Student consistency.
- 3D ResNet and Transformer practice: multi-scale volume encoding and learned
  clinical query decoding.
- Common high-throughput PyTorch practice: AMP, gradient accumulation,
  checkpoint resumption, and memory-conscious volume normalization.

Third-party Python dependencies retain their own licenses. Challenge data,
patient records, trained weights, and local experiment caches are not included.
