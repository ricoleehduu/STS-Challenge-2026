# GQ-TSR: CBCT-to-Clinical Record Prediction

[![Python](https://img.shields.io/badge/Python-3.10%2B-3776AB?logo=python&logoColor=white)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Challenge](https://img.shields.io/badge/STS%202026-Task%203-2F80ED)](#task-and-output)

Complete, independently trainable and verifiable research code for **STS 2026
Challenge Task 3**, which predicts a structured seven-field dental clinical
record from a cone beam computed tomography (CBCT) volume.

GQ-TSR (Guarded Query Teacher-Student Retrieval) combines image-based
pretraining, global-local visual modeling, structured clinical queries, guarded
teacher-student learning, and field-wise retrieval from labeled reference
records. Retrieval keeps the final text traceable to observed clinical records
and avoids unconstrained report generation.

![GQ-TSR framework](assets/GQ_TSR.png)

The source framework figure is also available as [GQ_TSR.pdf](GQ_TSR.pdf).

## Repository scope

This repository contains two explicitly separated implementations:

1. `gq_tsr`: the **complete trainable GQ-TSR method**. It includes image-only
   masked-volume pretraining, a trainable global-local 3D ResNet encoder,
   structured record/entity/field queries, a homogeneous EMA Teacher-Student,
   guarded online and cross-fold pseudo-labeling, checkpoint safety gates,
   out-of-fold entity calibration, field-wise clinical retrieval, validation,
   and submission generation.
2. `sts_task3_v7`: the original lightweight frozen 2.5D feature-cache retrieval
   baseline. It remains available for historical reproduction and low-resource
   inference, but it is not the full GQ-TSR training path.

The complete implementation is self-contained in this directory and does not
import code, caches, checkpoints, or configuration from another repository.

## Task and output

Each case must contain exactly these seven non-empty string fields:

```text
Main appeal
Present medical history
Oral Check
Diagnosis
Treatment plan
Handle
Doctor advices
```

The submission archive must contain exactly one root-level file,
`predictions.json`, keyed by case ID.

## Repository layout

```text
.
|-- assets/GQ_TSR.png        # framework figure
|-- configs/
|   |-- gq_tsr/default.yaml  # full 3D training configuration
|   |-- gq_tsr/smoke.yaml    # CPU-friendly structural smoke run
|   |-- default.yaml         # legacy v7 retrieval configuration
|   `-- smoke.yaml           # legacy v7 smoke configuration
|-- src/gq_tsr/              # complete GQ-TSR model/training/validation
|-- src/sts_task3_v7/        # legacy frozen-feature retrieval baseline
|-- tests/gq_tsr/            # architecture, loss, guard, and retrieval tests
|-- examples/create_synthetic_gq_tsr_dataset.py
|-- tools/run_gq_tsr.py      # no-install complete-method CLI
|-- tools/run_v7.py          # legacy baseline CLI
|-- 完整训练验证指南.md
|-- GQ_TSR.pdf
`-- pyproject.toml
```

Challenge data, patient records, NIfTI volumes, feature caches, checkpoints, and
trained bundles are intentionally not distributed.

## Installation

Requirements: Python 3.10 or newer. The full default model should be trained on
a CUDA GPU. CPU is supported for unit tests and the reduced smoke configuration.

```bash
git clone https://github.com/Myselffe/GQ-TSR_STS-2026-Challenge-Task3.git
cd GQ-TSR_STS-2026-Challenge-Task3
python -m venv .venv
source .venv/bin/activate  # Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -e .
```

The complete default workflow does not require a frozen feature cache or an
externally pretrained encoder. It first pretrains the trainable 3D encoder from
the supplied labeled and unlabeled CBCT volumes, then transfers that encoder to
the five-fold Teacher-Student stage. `--skip-pretrain` is provided only as an
ablation.

Verify the installation:

```bash
gq-tsr --help
gq-tsr run-all --help
python -m pytest -q --basetemp tmp/pytest
```

Without an editable install, commands can be run through:

```bash
python tools/run_gq_tsr.py --help
```

## Expected data contract

The complete `gq_tsr` pipeline consumes the following data roles:

```text
<data-root>/
|-- Train-Labeled/
|   |-- Train-Labeled.csv
|   `-- <case>/<case>.nii[.gz]
|-- Train-Unlabeled/<case>/<case>.nii[.gz]
|-- Validation/<case>/<case>.nii[.gz]
`-- evaluation/simulated_validation_ground_truth.csv
```

Nested case directories are optional; files are discovered recursively. The
default configuration expects 50 labeled, 200 unlabeled, and 50 external
validation volumes. `configs/gq_tsr/smoke.yaml` disables strict counts. No
unlabeled CSV argument exists: unlabeled target fields cannot enter training.

## Complete training and validation

Set paths for your environment:

```bash
DATA_ROOT=/path/to/task3
RUN_DIR=runs/gq_tsr_full
CONFIG=configs/gq_tsr/default.yaml
```

Run the entire method with one command:

```bash
gq-tsr run-all \
  --labeled-dir "$DATA_ROOT/Train-Labeled" \
  --labeled-csv "$DATA_ROOT/Train-Labeled/Train-Labeled.csv" \
  --unlabeled-dir "$DATA_ROOT/Train-Unlabeled" \
  --validation-dir "$DATA_ROOT/Validation" \
  --validation-csv "$DATA_ROOT/evaluation/simulated_validation_ground_truth.csv" \
  --config "$CONFIG" \
  --output-dir "$RUN_DIR" \
  --device cuda \
  --resume
```

This executes, in order:

1. split/count/label-firewall audit;
2. NIfTI canonicalization, foreground cropping, robust normalization, and
   image-only volume caching;
3. masked-volume 3D self-supervised pretraining;
4. five-fold supervised warmup;
5. guarded joint EMA Teacher-Student learning with unlabeled CBCT;
6. out-of-fold calibration and field-wise retrieval;
7. external validation and `submission.zip` generation.

The main outputs are:

```text
run_all_summary.json
data_firewall_audit.json
volume_cache/<split>/<case>.npy
pretrain/encoder_pretrained.pt
train/checkpoints/{warm,joint}_fold_*.pt
train/model_bundle.pt
train/training_summary.json
train/validation/validation_metrics.json
train/validation/predictions.json
train/validation/submission.zip
```

To re-run validation without training:

```bash
gq-tsr validate \
  --bundle "$RUN_DIR/train/model_bundle.pt" \
  --validation-dir "$DATA_ROOT/Validation" \
  --validation-csv "$DATA_ROOT/evaluation/simulated_validation_ground_truth.csv" \
  --volume-cache "$RUN_DIR/volume_cache" \
  --output-dir "$RUN_DIR/validation_repeat" \
  --device cuda
```

For a structural CPU smoke run, first create synthetic data and then replace the
configuration with `configs/gq_tsr/smoke.yaml` and the device with `cpu`:

```bash
python examples/create_synthetic_gq_tsr_dataset.py --output tmp/synthetic_gq_tsr
python tools/run_gq_tsr.py run-all \
  --labeled-dir tmp/synthetic_gq_tsr/Train-Labeled \
  --labeled-csv tmp/synthetic_gq_tsr/Train-Labeled/Train-Labeled.csv \
  --unlabeled-dir tmp/synthetic_gq_tsr/Train-Unlabeled \
  --validation-dir tmp/synthetic_gq_tsr/Validation \
  --validation-csv tmp/synthetic_gq_tsr/evaluation/validation_ground_truth.csv \
  --config configs/gq_tsr/smoke.yaml \
  --output-dir tmp/synthetic_gq_tsr_run \
  --device cpu
```

See [完整训练验证指南.md](完整训练验证指南.md) for stage-by-stage commands,
Windows PowerShell examples, resume behavior, outputs, and troubleshooting.

## Complete-method commands

- `audit-data`: verify exact image/CSV joins, split isolation, expected counts,
  and the unlabeled-label firewall.
- `cache-volumes`: cache normalized image volumes (not frozen features).
- `pretrain`: run image-only masked-volume pretraining.
- `train`: run five-fold warmup and guarded joint EMA training.
- `validate`: score a trained bundle on an external labeled split.
- `predict`: build predictions and a submission ZIP for an image-only split.
- `evaluate`: score an existing `predictions.json`.
- `run-all`: execute the complete training and validation workflow.

Run `gq-tsr <command> --help` for all arguments. The legacy baseline remains
available through `sts-task3-v7` and `tools/run_v7.py`.

## Configuration

The complete method is configured by `configs/gq_tsr/default.yaml`. Important
groups are `volume`, `augmentation`, `model`, `text`, `pretrain`, `training`,
`pseudo_labels`, `entity_calibration`, `retrieval`, `evaluation`, and `logging`.
Every run writes the fully merged configuration and its SHA-256 fingerprint.

## Results

The method manuscript reports an official public-validation Weighted Score of
**0.26** with **1.00 field completion** over 50 cases. Historical proxy metrics
for the separate frozen-feature baseline, together with the complete-path smoke
test status, are recorded in [RESULTS.md](RESULTS.md). No new full-data GPU score
is claimed by this source-integration update.

## Reproducibility and responsible use

- The code seeds the complete training and retrieval pipeline and records the
  resolved configuration, its SHA-256 fingerprint, and run artifacts.
- External validation labels are used only after training for final evaluation;
  they never enter fold selection, text target fitting, pseudo-label generation,
  calibration, or retrieval-bank construction.
- Outputs are research predictions, not medical advice, and must not be used for
  clinical decision-making without independent validation and qualified review.
- Use only de-identified data for which you have the necessary permissions.

## Citation

If this repository is useful in your work, cite the method by its title:

```bibtex
@misc{gqtsr2026,
  title  = {GQ-TSR: Guarded Query Teacher-Student Retrieval for
            CBCT-to-Clinical Record Prediction},
  year   = {2026},
  note   = {STS 2026 Challenge Task 3 method}
}
```

## License

Code is released under the [MIT License](LICENSE). Third-party packages and the
challenge data remain subject to their respective licenses and terms.
