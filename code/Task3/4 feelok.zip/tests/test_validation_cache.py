from __future__ import annotations

import json
from types import SimpleNamespace

import numpy as np

from sts_task3_v7.config import load_config
from sts_task3_v7.feature_store import FeatureStore, sha256_file
from sts_task3_v7.pipeline import _validate_validation_provenance, extract_validation_cache


def _write_feature(root, split: str, case_id: str, offset: float = 0.0) -> None:
    target = root / split
    target.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        target / f"{case_id}.npz",
        features=(np.arange(8, dtype=np.float32).reshape(2, 4) + offset).astype(np.float16),
        plane_ids=np.asarray([0, 1], dtype=np.int8),
        positions=np.asarray([0.25, 0.75], dtype=np.float32),
        case_id=np.asarray(case_id),
    )


def _write_cache_metadata(root, encoder: bytes) -> None:
    config = load_config(None)
    root.mkdir(parents=True, exist_ok=True)
    (root / "encoder.pt").write_bytes(encoder)
    (root / "manifest.json").write_text(
        json.dumps(
            {
                "output_dim": 4,
                "backbone": config["encoder"]["backbone"],
                "preprocess": config["preprocess"],
                "splits": ["labeled", "unlabeled"],
            }
        ),
        encoding="utf-8",
    )


def test_extract_validation_cache_copies_only_manifest_ids(tmp_path, monkeypatch):
    validation_ids = [str(index) for index in range(1, 51)]
    training_cache = tmp_path / "task3_new" / "feature_cache"
    source_cache = tmp_path / "task3" / "feature_cache"
    _write_cache_metadata(training_cache, b"same-frozen-encoder")
    _write_cache_metadata(source_cache, b"same-frozen-encoder")
    _write_feature(training_cache, "labeled", "train-1")
    for index, case_id in enumerate(validation_ids):
        _write_feature(source_cache, "unlabeled", case_id, float(index))
    _write_feature(source_cache, "unlabeled", "not-validation", 100.0)

    monkeypatch.setattr(
        "sts_task3_v7.pipeline.load_simulation",
        lambda *args, **kwargs: SimpleNamespace(
            validation_case_ids=validation_ids,
            train_records={"train-1": {}},
        ),
    )
    output = tmp_path / "validation_cache"
    manifest = extract_validation_cache(
        tmp_path / "simulation", training_cache, source_cache, output
    )

    copied = sorted((output / "validation").glob("*.npz"))
    assert len(copied) == 50
    assert not (output / "validation" / "not-validation.npz").exists()
    assert manifest["creation_method"] == "extract_cached_features"
    assert manifest["num_copied"] == 50
    assert manifest["num_reencoded"] == 0
    assert manifest["splits"] == ["validation"]
    assert (output / "encoder.pt").read_bytes() == b"same-frozen-encoder"
    for case_id in validation_ids:
        assert sha256_file(output / "validation" / f"{case_id}.npz") == sha256_file(
            source_cache / "unlabeled" / f"{case_id}.npz"
        )
    _validate_validation_provenance(FeatureStore([output], allowed_splits={"validation"}))
