from __future__ import annotations

import json

import numpy as np

from sts_task3_v7.feature_store import FeatureStore, build_descriptor


def _write_case(root, split: str, case_id: str, offset: float = 0.0) -> None:
    target = root / split
    target.mkdir(parents=True, exist_ok=True)
    features = np.arange(12 * 4, dtype=np.float32).reshape(12, 4) + offset
    np.savez_compressed(
        target / f"{case_id}.npz",
        features=features.astype(np.float16),
        plane_ids=np.repeat(np.arange(3), 4).astype(np.int8),
        positions=np.tile(np.linspace(0, 1, 4), 3).astype(np.float32),
        case_id=np.asarray(case_id),
    )


def test_feature_store_audit_and_descriptors(tmp_path):
    root = tmp_path / "cache"
    _write_case(root, "labeled", "1")
    _write_case(root, "unlabeled", "2", 1.0)
    (root / "manifest.json").write_text(json.dumps({"output_dim": 4}), encoding="utf-8")
    store = FeatureStore([root], require_same_encoder=True)
    audit = store.require({"1", "2"}).to_dict()
    assert audit["passed"]
    payload = store.load("1")
    assert build_descriptor(payload, "global").shape == (4,)
    assert build_descriptor(payload, "plane").shape == (12,)
    assert build_descriptor(payload, "pyramid4", 2).shape == (28,)


def test_conflicting_duplicate_is_rejected(tmp_path):
    first, second = tmp_path / "first", tmp_path / "second"
    _write_case(first, "labeled", "1", 0.0)
    _write_case(second, "labeled", "1", 2.0)
    try:
        FeatureStore([first, second], verify_duplicate_features=True)
    except ValueError as exc:
        assert "Conflicting duplicate" in str(exc)
    else:
        raise AssertionError("Conflicting duplicate cache was accepted")
