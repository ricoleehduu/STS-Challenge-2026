from __future__ import annotations

import numpy as np

from sts_task3_v7.config import load_config
from sts_task3_v7.constants import FIELDS
from sts_task3_v7.feature_store import FeatureStore
from sts_task3_v7.retrieval_model import ValidationGuidedRetriever


def _write_case(root, case_id: str, center: float) -> None:
    target = root / "cache"
    target.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(int(case_id))
    features = rng.normal(center, 0.01, size=(12, 8)).astype(np.float32)
    np.savez_compressed(
        target / f"{case_id}.npz",
        features=features.astype(np.float16),
        plane_ids=np.repeat(np.arange(3), 4).astype(np.int8),
        positions=np.tile(np.linspace(0, 1, 4), 3).astype(np.float32),
        case_id=np.asarray(case_id),
    )


def _record(label: str) -> dict[str, str]:
    return {field: f"{label} {field}" for field in FIELDS}


def test_retriever_fits_and_generates_all_fields(tmp_path):
    root = tmp_path / "features"
    records = {}
    sources = {}
    for index in range(1, 9):
        _write_case(root, str(index), float(index % 2))
        records[str(index)] = _record("odd" if index % 2 else "even")
        sources[str(index)] = "primary" if index <= 4 else "weak"
    _write_case(root, "9", 1.0)
    _write_case(root, "10", 0.0)
    config = load_config(None)
    config["descriptors"].update({"names": ["global"], "pca_dim": 4, "pca_whiten": False})
    config["semantic"].update({
        "svd_dim": 4,
        "max_features": 200,
        "ridge_alphas": [1.0],
        "fit_scopes": ["combined"],
    })
    config["retrieval"].update({
        "reference_scopes": ["combined", "weak"],
        "top_k": [1],
        "strategies": ["nearest"],
        "semantic_weights": [0.0, 1.0],
        "visual_spaces": ["raw"],
    })
    store = FeatureStore([root], require_same_encoder=False)
    model = ValidationGuidedRetriever(config).fit(records, sources, store)
    candidates = model.generate_candidates(["9", "10"], store)
    assert set(candidates) == set(FIELDS)
    assert all(candidates[field] for field in FIELDS)
    assert all(set(next(iter(candidates[field].values()))) == {"9", "10"} for field in FIELDS)
