from __future__ import annotations

from copy import deepcopy

import numpy as np
import pytest

from gq_tsr.cli import build_parser
from gq_tsr.config import config_fingerprint, load_config, validate_config
from gq_tsr.constants import ENTITY_NAMES, FIELDS
from gq_tsr.inference import prediction_diversity_audit
from gq_tsr.monitoring import EVALUATION_FIELDS
from gq_tsr.training import (
    build_offline_pseudo, joint_candidate_qualification, warm_candidate_improved,
)


def test_invalid_joint_schedule_fails_before_training() -> None:
    config = deepcopy(load_config("configs/gq_tsr/smoke.yaml"))
    config["training"].update({
        "joint_steps": 50,
        "online_teacher_start_step": 500,
        "joint_min_steps_before_selection": 1000,
    })
    with pytest.raises(ValueError, match="joint schedule"):
        validate_config(config)


def test_warm_only_configuration_can_disable_joint_schedule() -> None:
    config = load_config("configs/gq_tsr/ablations/warm_only.yaml")
    assert config["training"]["enable_joint"] is False
    assert config["training"]["joint_steps"] == 0


def test_config_fingerprint_changes_with_effective_setting() -> None:
    first = load_config("configs/gq_tsr/smoke.yaml")
    second = deepcopy(first)
    second["training"]["head_learning_rate"] *= 0.5
    assert config_fingerprint(first) != config_fingerprint(second)


def test_prediction_diversity_audit_detects_collapse() -> None:
    predictions = {
        str(index): {field: "same text" for field in FIELDS} for index in range(10)
    }
    provenance = {
        str(index): {
            field: {"reference_case_id": "ref-1", "fold_votes": 1} for field in FIELDS
        }
        for index in range(10)
    }
    audit = prediction_diversity_audit(
        predictions, provenance, load_config("configs/gq_tsr/smoke.yaml"), 5
    )
    assert audit["unique_full_records"] == 1
    assert audit["full_record_unique_ratio"] == 0.1
    assert audit["fields"][FIELDS[0]]["top_reference_fraction"] == 1.0
    assert audit["fields"][FIELDS[0]]["fold_majority_fraction"] == 0.0
    assert any("fold instability" in warning for warning in audit["warnings"])


def test_evaluation_csv_schema_has_no_duplicate_columns() -> None:
    assert len(EVALUATION_FIELDS) == len(set(EVALUATION_FIELDS))


def test_offline_pseudo_requires_positive_support_and_caps_negatives() -> None:
    config = deepcopy(load_config("configs/gq_tsr/smoke.yaml"))
    config["pseudo_labels"]["minimum_offline_positives_per_family"] = 2
    config["pseudo_labels"]["maximum_negative_to_positive_ratio"] = 1.0
    case_ids = ["a", "b"]
    probabilities = {}
    for name in ENTITY_NAMES:
        if name == "treatments":
            probabilities[name] = np.asarray([
                [0.95, 0.01, 0.02, 0.03],
                [0.96, 0.04, 0.05, 0.06],
            ], dtype=np.float32)
        elif name == "teeth":
            probabilities[name] = np.full((2, 4), 0.01, np.float32)
        else:
            probabilities[name] = np.full((2, 4), 0.50, np.float32)
    folds = [{"case_ids": case_ids, "entity_probabilities": probabilities} for _ in range(5)]
    _, audit = build_offline_pseudo(folds, config)
    assert audit["families"]["treatments"]["positive"] == 2
    assert audit["families"]["treatments"]["negative"] == 2
    assert audit["families"]["teeth"]["selected"] == 0
    assert audit["families"]["teeth"]["gate_reason"] == "insufficient_positive_pseudo_labels"


def test_offline_pseudo_ablation_disables_every_family() -> None:
    config = deepcopy(load_config("configs/gq_tsr/smoke.yaml"))
    config["pseudo_labels"]["enable_offline_hard_pseudo"] = False
    case_ids = ["a"]
    probabilities = {
        name: np.full((1, 2), 0.99, np.float32) for name in ENTITY_NAMES
    }
    folds = [{"case_ids": case_ids, "entity_probabilities": probabilities} for _ in range(5)]
    pseudo, audit = build_offline_pseudo(folds, config)
    assert audit["selected"] == 0
    assert all(
        row["gate_reason"] == "offline_hard_pseudo_disabled"
        for row in audit["families"].values()
    )
    assert all(not bool(value["mask"].any()) for value in pseudo["a"].values())


def test_stage_specific_checkpoint_guards() -> None:
    selection = load_config("configs/gq_tsr/smoke.yaml")["training"]["checkpoint_selection"]
    best = {"step": 100, "loss": 7.0, "weighted_proxy": 0.25, "diversity_qualified": True}
    warm_candidate = {"loss_total": 6.8, "weighted_proxy": 0.24, "field_unique_ratio": 0.30}
    assert warm_candidate_improved(warm_candidate, best, selection)[0]
    warm = {"best_loss": 7.0}
    unsafe_joint = {"loss_total": 9.0, "weighted_proxy": 0.30, "field_unique_ratio": 0.30}
    safe_joint = {"loss_total": 7.5, "weighted_proxy": 0.26, "field_unique_ratio": 0.30}
    assert joint_candidate_qualification(unsafe_joint, best, warm, selection) == (False, "validation_loss_guard")
    assert joint_candidate_qualification(safe_joint, best, warm, selection)[0]


def test_validate_cli_accepts_retrieval_only_overrides() -> None:
    args = build_parser().parse_args([
        "validate", "--bundle", "bundle.pt", "--validation-dir", "validation",
        "--validation-csv", "ground_truth.csv", "--output-dir", "output",
        "--hubness-penalty", "0.05", "--entity-rerank-weight", "0.15",
        "--calibrated-entity-hard-weight", "0.6", "--entity-constraint-top-k", "20",
        "--no-hard-entity-constraints",
        "--no-cross-fold-candidate-aggregation",
    ])
    assert args.hubness_penalty == 0.05
    assert args.entity_rerank_weight == 0.15
    assert args.calibrated_entity_hard_weight == 0.6
    assert args.entity_constraint_top_k == 20
    assert args.hard_entity_constraints is False
    assert args.cross_fold_candidate_aggregation is False


def test_final_default_uses_measured_soft_retrieval_profile() -> None:
    config = load_config()
    assert config["training"]["experiment_name"] == "final_guarded_ema_soft_retrieval"
    assert config["retrieval"]["hubness_penalty"] == 0.15
    assert config["training"]["checkpoint_retrieval"]["hubness_penalty"] == 0.10
    assert config["retrieval"]["calibrated_entity_hard_weight"] == 0.0
    assert config["retrieval"]["enable_hard_entity_constraints"] is False
    assert config["retrieval"]["cross_fold_candidate_aggregation"] is False
