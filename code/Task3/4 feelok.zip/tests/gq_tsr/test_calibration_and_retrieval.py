from __future__ import annotations

from copy import deepcopy

import numpy as np

from gq_tsr.calibration import fit_entity_calibration
from gq_tsr.config import load_config
from gq_tsr.constants import ENTITY_NAMES, FIELDS
from gq_tsr.entities import EntityVocabulary
from gq_tsr.retrieval import ensemble_text_predictions, retrieve_text


def _vocabulary() -> EntityVocabulary:
    return EntityVocabulary(
        teeth=["11"], diagnoses=["caries"], diagnosis_codes=["K02.9"],
        treatments=["restoration"], medications=["amoxicillin"],
    )


def test_oof_calibration_finds_reliable_family_threshold() -> None:
    config = deepcopy(load_config("configs/gq_tsr/smoke.yaml"))
    config["entity_calibration"]["minimum_positive_cases"] = 2
    values = np.asarray([[0.95], [0.80], [0.25], [0.10]], np.float32)
    expected = np.asarray([[1.0], [1.0], [0.0], [0.0]], np.float32)
    calibration = fit_entity_calibration(
        {name: values.copy() for name in ENTITY_NAMES},
        {name: expected.copy() for name in ENTITY_NAMES},
        config,
    )
    medication = calibration["families"]["medications"]
    assert medication["reliable"] is True
    assert medication["f1"] == 1.0
    assert 0.25 < medication["threshold"] <= 0.801
    assert calibration["source"] == "out_of_fold_labeled_only"


def test_reliable_medication_prediction_constrains_clinical_text() -> None:
    config = deepcopy(load_config("configs/gq_tsr/smoke.yaml"))
    config["retrieval"].update({
        "top_k": 1, "entity_constraint_top_k": 2,
        "enable_hard_entity_constraints": True,
        "hard_entity_constraints": ["medications"],
        "calibrated_entity_hard_weight": 0.5,
    })
    config["entity_calibration"] = {
        "enabled": True,
        "families": {
            name: {"threshold": 0.5, "reliable": name == "medications"}
            for name in ENTITY_NAMES
        },
    }
    vocabulary = _vocabulary()
    reference_ids = ["no-drug", "drug"]
    reference_records = {
        "no-drug": {field: f"No drug reference for {field}" for field in FIELDS},
        "drug": {field: f"Alternative reference for {field}" for field in FIELDS},
    }
    reference_records["drug"]["Handle"] = "Amoxicillin prescribed"
    reference_records["drug"]["Doctor advices"] = "Take amoxicillin as directed"
    query_fields = np.tile(np.asarray([[[1.0, 0.0]]], np.float32), (1, len(FIELDS), 1))
    reference_fields = np.zeros((2, len(FIELDS), 2), np.float32)
    reference_fields[0, :, 0] = 1.0
    reference_fields[1, :, :] = np.asarray([0.8, 0.6], np.float32)
    query_entities = {
        name: np.asarray([[0.9 if name == "medications" else 0.0]], np.float32)
        for name in ENTITY_NAMES
    }
    prediction, provenance = retrieve_text(
        ["query"], query_fields, query_entities, reference_ids, reference_records,
        reference_fields, vocabulary, config,
    )
    assert prediction["query"]["Handle"] == "Amoxicillin prescribed"
    assert provenance["query"]["Handle"]["entity_constraints_applied"] == ["medications"]


def test_all_positive_presence_collapse_is_not_reliable() -> None:
    config = deepcopy(load_config("configs/gq_tsr/smoke.yaml"))
    config["entity_calibration"].update({
        "minimum_positive_cases": 1,
        "minimum_positive_labels_per_class": 1,
    })
    values = np.full((4, 1), 0.90, np.float32)
    expected = np.asarray([[1.0], [0.0], [0.0], [0.0]], np.float32)
    calibration = fit_entity_calibration(
        {name: values.copy() for name in ENTITY_NAMES},
        {name: expected.copy() for name in ENTITY_NAMES},
        config,
    )
    medication = calibration["families"]["medications"]
    assert medication["reliable"] is False
    assert medication["precision"] == 0.25
    assert "quality_guard" in medication["reason"]


def test_disabled_hard_constraint_keeps_semantic_top1() -> None:
    config = deepcopy(load_config("configs/gq_tsr/smoke.yaml"))
    config["retrieval"].update({
        "top_k": 1, "entity_constraint_top_k": 2,
        "enable_hard_entity_constraints": False,
        "hard_entity_constraints": ["medications"],
        "calibrated_entity_hard_weight": 0.0,
    })
    config["entity_calibration"] = {
        "enabled": True,
        "families": {
            name: {"threshold": 0.5, "reliable": name == "medications"}
            for name in ENTITY_NAMES
        },
    }
    vocabulary = _vocabulary()
    records = {
        "semantic": {field: f"Semantic {field}" for field in FIELDS},
        "drug": {field: f"Amoxicillin {field}" for field in FIELDS},
    }
    query_fields = np.tile(np.asarray([[[1.0, 0.0]]], np.float32), (1, len(FIELDS), 1))
    reference_fields = np.zeros((2, len(FIELDS), 2), np.float32)
    reference_fields[0, :, 0] = 1.0
    reference_fields[1, :, 1] = 1.0
    query_entities = {
        name: np.asarray([[0.9 if name == "medications" else 0.0]], np.float32)
        for name in ENTITY_NAMES
    }
    prediction, provenance = retrieve_text(
        ["query"], query_fields, query_entities, ["semantic", "drug"], records,
        reference_fields, vocabulary, config,
    )
    assert prediction["query"]["Handle"] == "Semantic Handle"
    assert provenance["query"]["Handle"]["entity_constraints_applied"] == []


def test_cross_fold_topk_consensus_does_not_fake_top1_votes() -> None:
    config = deepcopy(load_config("configs/gq_tsr/smoke.yaml"))
    config["retrieval"].update({
        "cross_fold_candidate_aggregation": True,
        "minimum_candidate_fold_support": 2,
    })
    fold_predictions = []
    fold_provenance = []
    for fold in range(3):
        top = f"fold-{fold}-top"
        fold_predictions.append({"case": {field: top for field in FIELDS}})
        fold_provenance.append({
            "case": {
                field: {
                    "score": 1.0, "reference_case_id": f"ref-{fold}",
                    "candidates": [
                        {"text": top, "rank": 0, "score": 1.0, "reference_case_id": f"ref-{fold}"},
                        {"text": "shared candidate", "rank": 1, "score": 0.9, "reference_case_id": "shared"},
                    ],
                }
                for field in FIELDS
            }
        })
    prediction, provenance = ensemble_text_predictions(
        fold_predictions, fold_provenance, config
    )
    assert prediction["case"][FIELDS[0]] == "shared candidate"
    assert provenance["case"][FIELDS[0]]["fold_votes"] == 0
    assert provenance["case"][FIELDS[0]]["candidate_fold_support"] == 3
    assert provenance["case"][FIELDS[0]]["aggregation_mode"] == "cross_fold_topk_consensus"
