from __future__ import annotations

import inspect

import torch

from gq_tsr.config import load_config
from gq_tsr.data import load_strict_task_data
from gq_tsr.ema import create_teacher, update_teacher
from gq_tsr.entities import EntityVocabulary
from gq_tsr.model import build_model


def _vocabulary() -> EntityVocabulary:
    return EntityVocabulary(
        teeth=[f"{q}{p}" for q in range(1, 5) for p in range(1, 9)],
        diagnoses=["caries", "pulpitis"], diagnosis_codes=["K02.9"],
        treatments=["restoration"], medications=["amoxicillin"],
    )


def test_teacher_is_exact_frozen_copy() -> None:
    config = load_config("configs/gq_tsr/smoke.yaml")
    student = build_model(config["model"], _vocabulary())
    teacher = create_teacher(student)
    assert type(student) is type(teacher)
    assert sum(p.numel() for p in student.parameters()) == sum(p.numel() for p in teacher.parameters())
    assert all(not p.requires_grad for p in teacher.parameters())
    with torch.no_grad():
        next(student.parameters()).add_(1.0)
    update_teacher(teacher, student, 1, 0.99, 0.999, 10)
    assert not torch.equal(next(student.parameters()), next(teacher.parameters()))


def test_forward_contract() -> None:
    config = load_config("configs/gq_tsr/smoke.yaml")
    model = build_model(config["model"], _vocabulary()).eval()
    with torch.no_grad():
        output = model(torch.zeros(1, 1, 32, 48, 48))
    assert output["entity_logits"]["teeth"].shape == (1, 32)
    assert output["field_embeddings"].shape == (1, 7, 8)
    assert output["record_embedding"].shape == (1, 8)


def test_overlapping_crop_branch_contract() -> None:
    config = load_config("configs/gq_tsr/smoke.yaml")
    config["model"]["local_crops"]["enabled"] = True
    model = build_model(config["model"], _vocabulary()).eval()
    with torch.no_grad():
        output = model(torch.zeros(1, 1, 32, 48, 48))
    assert output["field_embeddings"].shape == (1, 7, 8)


def test_unlabeled_csv_is_structurally_impossible() -> None:
    assert "unlabeled_csv" not in inspect.signature(load_strict_task_data).parameters
