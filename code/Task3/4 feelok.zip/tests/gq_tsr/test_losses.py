from __future__ import annotations

from pathlib import Path

import torch

from gq_tsr.config import load_config
from gq_tsr.losses import gate_pseudo_mask, supervised_loss, teacher_consistency_loss


def test_no_unsafe_probability_bce_in_training_losses() -> None:
    source = (Path(__file__).parents[2] / "src" / "gq_tsr" / "losses.py").read_text(encoding="utf-8")
    assert "binary_cross_entropy_with_logits" in source
    assert "F.binary_cross_entropy(" not in source


def test_field_contrast_uses_queue_negatives_for_batch_one() -> None:
    config = load_config("configs/gq_tsr/smoke.yaml")["training"]
    config["loss_weights"]["field_text_contrast"] = 1.0
    output = {
        "record_embedding": torch.nn.functional.normalize(torch.ones(1, 8), dim=-1),
        "field_embeddings": torch.nn.functional.normalize(torch.ones(1, 7, 8), dim=-1),
        "entity_logits": {name: torch.empty(1, 0) for name in (
            "teeth", "diagnoses", "diagnosis_codes", "treatments", "medications"
        )},
        "count_logits": {name: torch.zeros(1, 2) for name in (
            "teeth", "diagnoses", "diagnosis_codes", "treatments", "medications"
        )},
    }
    batch = {
        "record_target": output["record_embedding"].clone(),
        "field_targets": output["field_embeddings"].clone(),
        "entity_targets": {name: torch.empty(1, 0) for name in output["entity_logits"]},
        "count_targets": {name: torch.zeros(1, dtype=torch.long) for name in output["count_logits"]},
    }
    positive_weights = {name: torch.empty(0) for name in output["entity_logits"]}
    negative_fields = output["field_embeddings"].repeat(2, 1, 1)
    _, parts = supervised_loss(
        output, batch, positive_weights, config,
        negative_field_targets=negative_fields,
    )
    assert torch.isfinite(parts["field_text_contrast"])
    assert float(parts["field_text_contrast"]) > 0.0


def test_pseudo_gate_rejects_negative_only_rows_and_caps_negatives() -> None:
    probabilities = torch.tensor([
        [0.95, 0.01, 0.02, 0.03, 0.04, 0.05],
        [0.01, 0.02, 0.03, 0.04, 0.05, 0.06],
    ])
    targets = (probabilities >= 0.80).float()
    raw_mask = (probabilities >= 0.80) | (probabilities <= 0.10)
    gated = gate_pseudo_mask(probabilities, targets, raw_mask, 1, 3.0)
    assert int((gated[0] & (targets[0] >= 0.5)).sum()) == 1
    assert int((gated[0] & (targets[0] < 0.5)).sum()) == 3
    assert not bool(gated[1].any())


def test_consistency_ablation_keeps_embeddings_but_disables_hard_pseudo() -> None:
    config = load_config("configs/gq_tsr/ablations/consistency_only.yaml")
    names = ("teeth", "diagnoses", "diagnosis_codes", "treatments", "medications")
    student = {
        "record_embedding": torch.ones(1, 8),
        "field_embeddings": torch.ones(1, 7, 8),
        "entity_logits": {name: torch.zeros(1, 2) for name in names},
        "count_logits": {name: torch.zeros(1, 3) for name in names},
    }
    teacher = {
        "record_embedding": torch.zeros(1, 8),
        "field_embeddings": torch.zeros(1, 7, 8),
        "entity_logits": {name: torch.full((1, 2), 10.0) for name in names},
        "count_logits": {name: torch.zeros(1, 3) for name in names},
    }
    total, parts, coverage = teacher_consistency_loss(student, teacher, config, True)
    assert coverage["pseudo_selected"] == 0
    assert float(parts["pseudo_entity"]) == 0.0
    assert float(parts["embedding_consistency"]) > 0.0
    assert float(total) > 0.0
