from __future__ import annotations

from sts_task3_v7.config import DEFAULT_CONFIG
from sts_task3_v7.constants import FIELDS
from sts_task3_v7.selection import select_policy


def _record(token: str) -> dict[str, str]:
    return {field: f"{token} {field}" for field in FIELDS}


def test_validation_selection_uses_global_field_sources_not_case_oracle():
    references = {"1": _record("good"), "2": _record("good")}
    candidates = {field: {} for field in FIELDS}
    for field in FIELDS:
        candidates[field]["bad"] = {"1": f"bad {field}", "2": f"bad {field}"}
        candidates[field]["good"] = {"1": f"good {field}", "2": f"good {field}"}
    config = {**DEFAULT_CONFIG, "selection": {"max_candidates_per_field": 4, "coordinate_passes": 2}}
    selected = select_policy(candidates, references, config)
    assert set(selected.policy.values()) == {"good"}
    assert selected.evaluation["metrics_mean"]["weighted_proxy"] > 0.9
    assert "case" not in selected.report["selection_scope"].split(";")[0].casefold()
